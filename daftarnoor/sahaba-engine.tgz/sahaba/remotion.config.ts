import { Config } from "@remotion/cli/config";
import fs from "fs";
Config.setVideoImageFormat("jpeg");
Config.setCodec("h264");
Config.setCrf(18);
Config.setPixelFormat("yuv420p");
const chrome = process.env.REMOTION_CHROME || "/usr/bin/google-chrome";
if (fs.existsSync(chrome)) Config.setBrowserExecutable(chrome);
Config.setChromiumOpenGlRenderer("swangle");
