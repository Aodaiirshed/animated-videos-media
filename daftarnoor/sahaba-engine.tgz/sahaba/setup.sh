#!/usr/bin/env bash
# Restore the Daftar Noor Sahaba engine in a fresh session. Run from the unpacked folder: bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"
CA=/root/.ccr/ca-bundle.crt
[ -f "$CA" ] && export NODE_EXTRA_CA_CERTS=$CA PIP_CERT=$CA
npm ci --no-audit --no-fund --loglevel=error
pip install -q --break-system-packages edge-tts certifi 2>/dev/null || pip install -q edge-tts certifi
# edge-tts (aiohttp) trusts certifi only: add the proxy CA once
if [ -f "$CA" ]; then
  CP=$(python3 -c "import certifi;print(certifi.where())")
  grep -q "$(sed -n 2p "$CA")" "$CP" || cat "$CA" >> "$CP"
fi
command -v ffmpeg >/dev/null || { echo "ffmpeg missing: apt-get install -y ffmpeg"; exit 1; }
command -v bc >/dev/null || apt-get install -y -qq bc >/dev/null 2>&1 || true
python3 tools/gen_stories.py
npx tsc -p . && echo "SETUP OK"
