import React from "react";
import { Composition } from "remotion";
import { Story, storyDuration } from "./Story";
import { STORIES } from "./stories";

export const Root: React.FC = () => (
  <>
    {STORIES.map((p) => (
      <Composition
        key={p.sb.slug}
        id={p.sb.slug}
        component={Story as any}
        durationInFrames={storyDuration(p)}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={p}
      />
    ))}
  </>
);
