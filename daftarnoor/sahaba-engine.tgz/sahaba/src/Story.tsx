import React from "react";
import { AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Loop } from "remotion";
import { SCENES } from "./scenes";
import { FontFaces, Grain, Vignette } from "./ui";

export type Word = { t: number; d: number; w: string };
export type Gen = { id: string; file: string; dur: number; words: Word[] }[];
export type Scene = { id: string; visual: string; vo: string; cap: string; emphasis?: string[]; hold?: number; lines?: { text: string; word: number }[] };
export type SB = { slug: string; name: string; revealWord?: string; scenes: Scene[]; cta: string };
export type StoryProps = { sb: SB; gen: Gen };

const FPS = 30;
const PAD = 0.25;
export const sceneFrames = (s: Scene, g: Gen[number]) => Math.round((g.dur + PAD + (s.hold ?? 0)) * FPS);
export const storyDuration = (p: StoryProps) => p.sb.scenes.reduce((a, s, i) => a + sceneFrames(s, p.gen[i]), 0);

const strip = (s: string) => s.replace(/[ً-ْـ…،,.؟?!]/g, "");

const Captions: React.FC<{ words: Word[]; emphasis: string[] }> = ({ words, emphasis }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const pages: Word[][] = [];
  for (let i = 0; i < words.length; i += 3) pages.push(words.slice(i, i + 3));
  let page = pages.findIndex((p, i) => t >= p[0].t - 0.05 && (i === pages.length - 1 || t < pages[i + 1][0].t - 0.05));
  if (page < 0) page = t < (words[0]?.t ?? 0) ? -1 : pages.length - 1;
  if (page < 0) return null;
  const last = words[words.length - 1];
  if (last && t > last.t + last.d + 0.6) return null;
  const emph = emphasis.map(strip);
  return (
    <div style={{ position: "absolute", top: 1180, left: 90, right: 160, display: "flex", flexDirection: "row-reverse", justifyContent: "center", flexWrap: "wrap", gap: "0 26px", direction: "ltr" }}>
      {pages[page].map((w, i) => {
        const start = Math.round(w.t * FPS);
        const sp = spring({ frame: frame - start, fps: FPS, config: { damping: 12, stiffness: 180 } });
        const on = frame >= start;
        const isE = emph.includes(strip(w.w));
        return (
          <span key={i} style={{
            fontFamily: "Tajawal", fontWeight: 800, fontSize: isE ? 104 : 88, lineHeight: 1.35,
            color: on ? (isE ? "#f2c75c" : "#ffffff") : "rgba(255,255,255,0.35)",
            transform: `scale(${on ? 0.85 + 0.15 * sp : 0.85})`, display: "inline-block",
            WebkitTextStroke: "3px rgba(0,0,0,0.85)", paintOrder: "stroke fill",
            textShadow: "0 6px 24px rgba(0,0,0,0.6)", direction: "rtl",
          }}>{w.w}</span>
        );
      })}
    </div>
  );
};

const SceneWrap: React.FC<{ scene: Scene; g: Gen[number]; dur: number; sb: SB; first: boolean }> = ({ scene, g, dur, sb, first }) => {
  const frame = useCurrentFrame();
  const Visual = SCENES[scene.visual];
  const fadeIn = first ? 1 : interpolate(frame, [0, 8], [0, 1], { extrapolateRight: "clamp" });
  const flash = !first && (scene.visual === "ahad" || scene.visual === "quote" || scene.visual === "reveal") ? interpolate(frame, [0, 3, 12], [0, 0.85, 0], { extrapolateRight: "clamp" }) : 0;
  return (
    <AbsoluteFill style={{ opacity: fadeIn }}>
      <Visual dur={dur} words={g.words} name={sb.name} cta={sb.cta} scene={scene} revealWord={sb.revealWord ?? "بلال"} />
      <Captions words={g.words} emphasis={scene.emphasis ?? []} />
      <AbsoluteFill style={{ background: "#fff8e6", opacity: flash }} />
    </AbsoluteFill>
  );
};

export const Story: React.FC<StoryProps> = ({ sb, gen }) => {
  let at = 0;
  return (
    <AbsoluteFill style={{ background: "#07090b" }}>
      <FontFaces />
      <Loop durationInFrames={60 * FPS}><Audio src={staticFile("sfx/wind.wav")} volume={0.22} /></Loop>
      {sb.scenes.map((s, i) => {
        const dur = sceneFrames(s, gen[i]);
        const from = at;
        at += dur;
        return (
          <Sequence key={s.id} from={from} durationInFrames={dur}>
            <SceneWrap scene={s} g={gen[i]} dur={dur} sb={sb} first={i === 0} />
            <Audio src={staticFile(gen[i].file)} volume={1} />
            {i > 0 && <Audio src={staticFile("sfx/whoosh.wav")} volume={0.35} />}
            {(["ahad", "quote", "reveal", "sun", "cave"].includes(s.visual)) && <Audio src={staticFile("sfx/boom.wav")} volume={0.55} />}
            {s.visual === "dark" && <Loop durationInFrames={24}><Audio src={staticFile("sfx/beat.wav")} volume={0.6} /></Loop>}
          </Sequence>
        );
      })}
      <Vignette />
      <Grain />
      <div style={{ position: "absolute", top: 140, width: "100%", textAlign: "center", fontFamily: "Tajawal", fontWeight: 700, fontSize: 34, color: "rgba(231,211,163,0.75)", letterSpacing: 2 }}>دفتر نور · قصص الصحابة</div>
    </AbsoluteFill>
  );
};
