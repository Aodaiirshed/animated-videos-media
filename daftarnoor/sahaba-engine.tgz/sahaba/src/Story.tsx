import React from "react";
import { AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Loop } from "remotion";
import { SCENES } from "./scenes";
import { FontFaces, Grain, Vignette } from "./ui";

export type Word = { t: number; d: number; w: string };
export type Gen = { id: string; file: string; dur: number; words: Word[] }[];
export type Scene = { id: string; visual: string; vo: string; cap: string; emphasis?: string[]; hold?: number; lines?: { text: string; word: number }[]; cam?: string; tr?: string; sfx?: [string, number, number][]; hookY?: number };
export type SB = { slug: string; name: string; revealWord?: string; scenes: Scene[]; cta: string; pad?: number };
export type StoryProps = { sb: SB; gen: Gen };

const FPS = 30;
const PAD = 0.25;
export const sceneFrames = (s: Scene, g: Gen[number], pad: number = PAD) => Math.round((g.dur + pad + (s.hold ?? 0)) * FPS);
export const storyDuration = (p: StoryProps) => p.sb.scenes.reduce((a, s, i) => a + sceneFrames(s, p.gen[i], p.sb.pad ?? PAD), 0);

const strip = (s: string) => s.replace(/[ً-ْـ…،,.؟?!]/g, "");

const Captions: React.FC<{ words: Word[]; emphasis: string[] }> = ({ words, emphasis }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const pages: Word[][] = [];
  for (let i = 0; i < words.length; i += 3) pages.push(words.slice(i, i + 3));
  let page = pages.findIndex((p, i) => t >= p[0].t - 0.05 && (i === pages.length - 1 || t < pages[i + 1][0].t - 0.05));
  if (page < 0) page = t < (words[0]?.t ?? 0) ? -1 : pages.length - 1;
  if (page < 0) return null;
  const last = words[words.length - 1];
  if (last && t > last.t + last.d + 0.6) return null;
  const emph = emphasis.map(strip);
  return (
    <div style={{ position: "absolute", top: 1180, left: 90, right: 160, display: "flex", flexDirection: "row-reverse", justifyContent: "center", flexWrap: "wrap", gap: "0 26px", direction: "ltr" }}>
      {pages[page].map((w, i) => {
        const start = Math.round(w.t * FPS);
        const sp = spring({ frame: frame - start, fps: FPS, config: { damping: 12, stiffness: 180 } });
        const on = frame >= start;
        const isE = emph.includes(strip(w.w));
        return (
          <span key={i} style={{
            fontFamily: "Tajawal", fontWeight: 800, fontSize: isE ? 104 : 88, lineHeight: 1.35,
            color: on ? (isE ? "#f2c75c" : "#ffffff") : "rgba(255,255,255,0.35)",
            transform: `scale(${on ? 0.85 + 0.15 * sp : 0.85})`, display: "inline-block",
            WebkitTextStroke: "3px rgba(0,0,0,0.85)", paintOrder: "stroke fill",
            textShadow: "0 6px 24px rgba(0,0,0,0.6)", direction: "rtl",
          }}>{w.w}</span>
        );
      })}
    </div>
  );
};

/** v3 camera moves (never the same twice in a row — set per scene) */
const camStyle = (cam: string | undefined, f: number, dur: number): React.CSSProperties => {
  if (!cam) return {};
  const k = interpolate(f, [0, dur], [0, 1], { extrapolateRight: "clamp" });
  const e = k * k * (3 - 2 * k);
  switch (cam) {
    case "push": return { transform: `scale(${1 + 0.12 * e})` };
    case "pull": return { transform: `scale(${1.14 - 0.12 * e})` };
    case "panL": return { transform: `scale(1.14) translateX(${45 - 90 * e}px)` };
    case "panR": return { transform: `scale(1.14) translateX(${-45 + 90 * e}px)` };
    case "tiltUp": return { transform: `scale(1.14) translateY(${-60 + 120 * e}px)` };
    case "drift": return { transform: `scale(${1.03 + 0.04 * e}) rotate(${-0.8 + 1.6 * e}deg)` };
    default: return {};
  }
};

/** big on-screen hook/quote lines over any visual (line 0 of the first scene is visible on frame 1) */
const HookLines: React.FC<{ scene: Scene; words: Word[]; first: boolean }> = ({ scene, words, first }) => {
  const frame = useCurrentFrame();
  const lines = scene.lines ?? [];
  const maxLen = Math.max(...lines.map((x) => x.text.replace(/[\u064B-\u0652]/g, "").length));
  const fs = Math.min(150, Math.floor(2300 / Math.max(1, maxLen)));
  const top = scene.hookY ?? 260;
  const shine = interpolate(frame % 75, [0, 22], [-30, 130], { extrapolateRight: "clamp" });
  return (
    <>
      <div style={{ position: "absolute", top: top - 40, left: 0, right: 0, height: lines.length * fs * 1.35 + 80, background: "linear-gradient(rgba(20,10,0,0), rgba(20,10,0,0.45) 25%, rgba(20,10,0,0.45) 75%, rgba(20,10,0,0))" }} />
      {lines.map((l, i) => {
        const st = first ? -30 : Math.round((words[Math.min(l.word, words.length - 1)]?.t ?? i) * FPS);
        const sp = spring({ frame: frame - st, fps: FPS, config: { damping: 12 } });
        return (
          <div key={i} style={{ position: "absolute", top: (scene.hookY ?? 260) + i * (fs * 1.35), left: 40, right: 40, textAlign: "center", fontFamily: "Amiri", fontWeight: 700, fontSize: fs, lineHeight: 1.3, direction: "rtl",
            color: i === lines.length - 1 && lines.length > 1 ? "#f2c75c" : "#fff8e6", opacity: sp, transform: `translateY(${(1 - sp) * 30}px) scale(${0.9 + 0.1 * sp})`,
            WebkitTextStroke: "4px rgba(30,15,0,0.9)", paintOrder: "stroke fill", textShadow: "0 8px 30px rgba(0,0,0,0.65)",
            maskImage: `linear-gradient(100deg, #000 ${shine - 12}%, rgba(0,0,0,0.75) ${shine}%, #000 ${shine + 12}%)` }}>{l.text}</div>
        );
      })}
    </>
  );
};

const SceneWrap: React.FC<{ scene: Scene; g: Gen[number]; dur: number; sb: SB; first: boolean }> = ({ scene, g, dur, sb, first }) => {
  const frame = useCurrentFrame();
  const Visual = SCENES[scene.visual];
  const tr = scene.tr;
  let fadeIn = first ? 1 : interpolate(frame, [0, 8], [0, 1], { extrapolateRight: "clamp" });
  let inStyle: React.CSSProperties = {};
  let flashOn = !first && (scene.visual === "ahad" || scene.visual === "quote" || scene.visual === "reveal");
  if (tr && !first) {
    fadeIn = 1;
    flashOn = tr === "flash";
    if (tr === "match") fadeIn = interpolate(frame, [0, 5], [0.3, 1], { extrapolateRight: "clamp" });
    if (tr === "push") { const p = interpolate(frame, [0, 9], [0, 1], { extrapolateRight: "clamp" }); inStyle = { transform: `scale(${1.3 - 0.3 * p})`, filter: `blur(${(1 - p) * 14}px)` }; }
    if (tr === "wipe") { const p = interpolate(frame, [0, 10], [0, 100], { extrapolateRight: "clamp" }); inStyle = { clipPath: `inset(0 0 0 ${100 - p}%)` }; }
  }
  const flash = flashOn ? interpolate(frame, [0, 3, 12], [0, 0.85, 0], { extrapolateRight: "clamp" }) : 0;
  const wipeEdge = tr === "wipe" && !first ? interpolate(frame, [0, 10], [1080, -60], { extrapolateRight: "clamp" }) : null;
  return (
    <AbsoluteFill style={{ opacity: fadeIn, ...inStyle }}>
      <AbsoluteFill style={camStyle(scene.cam, frame, dur)}>
        <Visual dur={dur} words={g.words} name={sb.name} cta={sb.cta} scene={scene} revealWord={sb.revealWord ?? "بلال"} />
      </AbsoluteFill>
      {scene.visual !== "quote" && scene.lines && <HookLines scene={scene} words={g.words} first={first} />}
      {!(scene.visual !== "quote" && scene.lines) && <Captions words={g.words} emphasis={scene.emphasis ?? []} />}
      {wipeEdge !== null && frame < 11 && <div style={{ position: "absolute", top: 0, bottom: 0, left: wipeEdge, width: 60, background: "linear-gradient(90deg, rgba(255,240,190,0), rgba(255,240,190,0.95), rgba(255,240,190,0))" }} />}
      <AbsoluteFill style={{ background: "#fff8e6", opacity: flash }} />
    </AbsoluteFill>
  );
};

export const Story: React.FC<StoryProps> = ({ sb, gen }) => {
  let at = 0;
  return (
    <AbsoluteFill style={{ background: "#07090b" }}>
      <FontFaces />
      <Loop durationInFrames={60 * FPS}><Audio src={staticFile("sfx/wind.wav")} volume={0.22} /></Loop>
      {sb.scenes.map((s, i) => {
        const dur = sceneFrames(s, gen[i], sb.pad ?? PAD);
        const v3 = !!s.tr;
        const from = at;
        at += dur;
        return (
          <Sequence key={s.id} from={from} durationInFrames={dur}>
            <SceneWrap scene={s} g={gen[i]} dur={dur} sb={sb} first={i === 0} />
            <Audio src={staticFile(gen[i].file)} volume={1} />
            {i > 0 && (!v3 || s.tr === "push" || s.tr === "wipe") && <Audio src={staticFile("sfx/whoosh.wav")} volume={v3 ? 0.25 : 0.35} />}
            {(v3 ? s.visual === "reveal" : ["ahad", "quote", "reveal", "sun", "cave"].includes(s.visual)) && <Audio src={staticFile("sfx/boom.wav")} volume={0.55} />}
            {(s.sfx ?? []).map(([n, at, v], k) => <Sequence key={k} from={Math.round(at * FPS)}><Audio src={staticFile(`sfx/${n}.wav`)} volume={v} /></Sequence>)}
            {s.visual === "dark" && <Loop durationInFrames={24}><Audio src={staticFile("sfx/beat.wav")} volume={0.6} /></Loop>}
          </Sequence>
        );
      })}
      <Vignette />
      <Grain />
      <div style={{ position: "absolute", top: 140, width: "100%", textAlign: "center", fontFamily: "Tajawal", fontWeight: 700, fontSize: 34, color: "rgba(231,211,163,0.75)", letterSpacing: 2 }}>دفتر نور · قصص الصحابة</div>
    </AbsoluteFill>
  );
};
