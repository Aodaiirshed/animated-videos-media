import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, random } from "remotion";
import { Camera, Particles } from "./ui";
import type { Word } from "./Story";

import type { Scene } from "./Story";
import { SCENES2 } from "./scenes2";
import { SCENES3 } from "./scenes3";
export type VisualProps = { dur: number; words: Word[]; name: string; cta: string; scene: Scene; revealWord: string };
const FPS = 30;
const W = 1080, H = 1920;

/* ---------- shared pieces ---------- */
const Mountains: React.FC<{ color: string; y: number; seed: string; amp?: number; opacity?: number }> = ({ color, y, seed, amp = 220, opacity = 1 }) => {
  const pts: string[] = [`0,${H}`, `0,${y}`];
  for (let i = 0; i <= 12; i++) {
    const x = (i / 12) * W;
    const yy = y - random(`${seed}${i}`) * amp;
    pts.push(`${x},${yy}`);
  }
  pts.push(`${W},${H}`);
  return <svg width={W} height={H} style={{ position: "absolute", opacity }}><polygon points={pts.join(" ")} fill={color} /></svg>;
};

const Dunes: React.FC<{ color: string; y: number; phase?: number }> = ({ color, y, phase = 0 }) => (
  <svg width={W} height={H} style={{ position: "absolute" }}>
    <path d={`M0 ${y} C 250 ${y - 120 + phase} 450 ${y + 60} 700 ${y - 40} S 1000 ${y - 140 + phase} 1080 ${y - 60} L1080 ${H} L0 ${H} Z`} fill={color} />
  </svg>
);

const Palm: React.FC<{ x: number; y: number; s: number; color: string }> = ({ x, y, s, color }) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={color}>
    <path d="M-6 0 Q -2 -160 6 -300 L 14 -300 Q 8 -160 10 0 Z" />
    {[-70, -35, 0, 35, 70, 110, -110].map((a, i) => (
      <path key={i} transform={`translate(10,-300) rotate(${a})`} d="M0 0 Q 70 -30 150 20 Q 70 -5 0 8 Z" />
    ))}
  </g>
);

/* ---------- scenes ---------- */
const Sun: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const r = interpolate(f, [0, dur], [230, 300]);
  const shimmer = Math.sin(f / 4) * 6;
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#7a1d07 0%, #d4561a 40%, #f2a33a 70%, #f6c565 100%)" }}>
      <Camera dur={dur} to={1.15}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <defs>
            <radialGradient id="sg"><stop offset="0%" stopColor="#fffbe6" /><stop offset="45%" stopColor="#ffd56b" /><stop offset="100%" stopColor="rgba(255,150,40,0)" /></radialGradient>
          </defs>
          <circle cx={540} cy={620} r={r * 2.2} fill="url(#sg)" opacity={0.6} />
          <circle cx={540} cy={620} r={r * 0.62} fill="#fff4cc" />
        </svg>
        <Mountains color="#8a3a17" y={1250 + shimmer} seed="m1" amp={260} opacity={0.85} />
        <Mountains color="#5a230e" y={1430} seed="m2" amp={300} />
        <Mountains color="#2b1007" y={1640} seed="m3" amp={200} />
        <Particles n={40} color="#ffe2a0" seed="dust1" size={[1.5, 4]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Empty: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#2a1a3a 0%, #a34a2a 55%, #e0894a 100%)" }}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <Dunes color="#b3622f" y={1150} phase={Math.sin(f / 30) * 10} />
        <Dunes color="#8a4520" y={1380} />
        <Dunes color="#4a2410" y={1620} />
        <Particles n={90} color="#f4c58a" seed="sand" speed={3} size={[1, 3]} area={[900, 1900]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Drag: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const len = interpolate(f, [0, dur * 0.8], [0, 1], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#5c1b0a, #a8431b 50%, #c86a2d)" }}>
      <Camera dur={dur} to={1.1} shake={f % 45 < 6 ? 14 : 2}>
        <Mountains color="#4a1a0a" y={900} seed="v1" amp={420} />
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <path d="M-50 1200 L1130 1200 L1130 1920 L-50 1920 Z" fill="#7a3414" />
          <path d="M 1080 1820 C 820 1640 620 1560 380 1450 S 120 1320 -40 1260" stroke="#3a1608" strokeWidth={26} fill="none" strokeLinecap="round" strokeDasharray="2400" strokeDashoffset={2400 * (1 - len)} opacity={0.85} />
          <path d="M 1080 1860 C 820 1680 620 1600 380 1490 S 120 1360 -40 1300" stroke="#5a240c" strokeWidth={10} fill="none" strokeDasharray="2400" strokeDashoffset={2400 * (1 - len)} opacity={0.7} />
        </svg>
        <Particles n={70} color="#e8a066" seed="kick" speed={4} size={[2, 7]} area={[1250, 1900]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Dark: React.FC<VisualProps> = () => {
  const f = useCurrentFrame();
  const pulse = 0.25 + 0.35 * Math.max(0, Math.sin((f / 24) * Math.PI * 2));
  return (
    <AbsoluteFill style={{ background: "#030405" }}>
      <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 42%, rgba(242,199,92,${pulse * 0.35}) 0%, rgba(0,0,0,0) 45%)` }} />
      <Particles n={60} color="#cfd8ff" seed="stars" speed={0.05} size={[0.8, 2.2]} area={[0, 1100]} />
    </AbsoluteFill>
  );
};

const Ahad: React.FC<VisualProps> = ({ words }) => {
  const f = useCurrentFrame();
  const t1 = Math.round((words[0]?.t ?? 0) * FPS), t2 = Math.round((words[1]?.t ?? 1) * FPS);
  const a = spring({ frame: f - t1, fps: FPS, config: { damping: 9 } });
  const b = spring({ frame: f - t2, fps: FPS, config: { damping: 9 } });
  const ring = (st: number) => interpolate(f - st, [0, 25], [0, 900], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const ringO = (st: number) => interpolate(f - st, [0, 25], [0.8, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 45%, #3a2a0a 0%, #0a0806 60%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {[t1, t2].map((st, i) => <circle key={i} cx={540} cy={i ? 980 : 640} r={ring(st)} stroke="#f2c75c" strokeWidth={6} fill="none" opacity={f >= st ? ringO(st) : 0} />)}
      </svg>
      {[{ s: a, y: 470 }, { s: b, y: 810 }].map((o, i) => (
        <div key={i} style={{ position: "absolute", top: o.y, width: "100%", textAlign: "center", fontFamily: "Amiri", fontWeight: 700, fontSize: 260, color: "#f2c75c", transform: `scale(${o.s})`, opacity: o.s, textShadow: "0 0 60px rgba(242,199,92,0.7)" }}>أحَدٌ</div>
      ))}
      <Particles n={50} color="#f2c75c" seed="emb" rise speed={1.5} size={[1.5, 4]} />
    </AbsoluteFill>
  );
};

const Chain: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const brk = Math.round(dur * 0.5);
  const p = spring({ frame: f - brk, fps: FPS, config: { damping: 14, stiffness: 60 } });
  const glow = interpolate(f, [brk, brk + 20], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const link = (i: number) => {
    const cy = 300 + i * 150;
    const vertical = i % 2 === 0;
    return vertical
      ? <ellipse key={i} cx={540} cy={cy} rx={55} ry={100} stroke="url(#metal)" strokeWidth={26} fill="none" />
      : <ellipse key={i} cx={540} cy={cy} rx={20} ry={100} stroke="url(#metal)" strokeWidth={26} fill="none" />;
  };
  return (
    <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 50%, rgba(255,226,150,${0.12 + glow * 0.7}) 0%, #120e08 65%)` }}>
      <Camera dur={dur} to={1.06} shake={f > brk && f < brk + 10 ? 20 : 0}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <defs><linearGradient id="metal" x1="0" x2="1"><stop offset="0" stopColor="#5d6067" /><stop offset="0.5" stopColor="#c9ccd2" /><stop offset="1" stopColor="#4a4c52" /></linearGradient></defs>
          <g transform={`translate(${-p * 120},${-p * 380}) rotate(${-p * 25} 540 600)`}>{[0, 1, 2].map(link)}</g>
          <g transform={`translate(${p * 140},${p * 420}) rotate(${p * 30} 540 900)`}>{[3, 4, 5].map(link)}</g>
        </svg>
        <Particles n={70} color="#ffe6a3" seed="lib" rise speed={1 + glow * 2.5} size={[1.5, 5]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Dawn: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const k = interpolate(f, [0, dur], [0, 1]);
  const sky = `linear-gradient(rgb(${10 + 40 * k},${20 + 60 * k},${50 + 70 * k}) 0%, rgb(${40 + 180 * k},${50 + 120 * k},${80 + 40 * k}) 60%, rgb(${120 + 120 * k},${90 + 100 * k},${70 + 40 * k}) 100%)`;
  const rings = [0, 20, 40, 60];
  return (
    <AbsoluteFill style={{ background: sky }}>
      <Camera dur={dur} to={1.08}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          {rings.map((d, i) => {
            const rr = ((f + d) % 80) / 80;
            return <circle key={i} cx={540} cy={1180} r={80 + rr * 700} stroke="#ffe7b0" strokeWidth={5} fill="none" opacity={(1 - rr) * 0.7} />;
          })}
          <rect x={0} y={1300} width={W} height={620} fill="#1d1712" />
          {[[60, 1300, 260, 180], [330, 1300, 180, 130], [700, 1300, 300, 160]].map(([x, y, w, h], i) => <rect key={i} x={x} y={y - h} width={w} height={h} fill="#2a2018" />)}
          <Palm x={250} y={1320} s={1.1} color="#140f0b" />
          <Palm x={880} y={1330} s={1.3} color="#140f0b" />
          <Palm x={600} y={1310} s={0.8} color="#1a140f" />
        </svg>
        <Particles n={40} color="#fff2cc" seed="dawnst" speed={0.05} size={[0.8, 2]} area={[0, 700]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Jannah: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 35%, #fff3cf 0%, #7fbf9a 35%, #0f3b33 80%)" }}>
      <Camera dur={dur} from={1.12} to={1.0}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const st = Math.round((words[Math.min(words.length - 1, 4 + i)]?.t ?? i) * FPS);
            const rr = interpolate(f - st, [0, 30], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
            return <ellipse key={i} cx={540} cy={1250} rx={40 + rr * 500} ry={12 + rr * 120} stroke="#fff6d8" strokeWidth={4} fill="none" opacity={f >= st ? (1 - rr) * 0.8 : 0} />;
          })}
          <Palm x={160} y={1500} s={1.6} color="#0c2c25" />
          <Palm x={930} y={1520} s={1.8} color="#0c2c25" />
        </svg>
        <Particles n={80} color="#fffbe8" seed="noor" rise speed={1} size={[1.5, 5]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Reveal: React.FC<VisualProps> = ({ name, cta, words, dur, revealWord, scene }) => {
  const f = useCurrentFrame();
  const nameAt = Math.round((words.find((w) => w.w.replace(/[ً-ْ]/g, "").includes(revealWord))?.t ?? 3) * FPS);
  const s = spring({ frame: f - nameAt, fps: FPS, config: { damping: 11 } });
  const ctaO = interpolate(f, [dur - 60, dur - 40], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 40%, #1d6b66 0%, #0b3b39 55%, #05201f 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute", opacity: 0.12 }}>
        {Array.from({ length: 14 }).map((_, r) => Array.from({ length: 8 }).map((__, c) => (
          <g key={`${r}-${c}`} transform={`translate(${c * 150 + (r % 2) * 75},${r * 150})`}>
            <rect x={-30} y={-30} width={60} height={60} fill="none" stroke="#e7d3a3" strokeWidth={3} />
            <rect x={-30} y={-30} width={60} height={60} fill="none" stroke="#e7d3a3" strokeWidth={3} transform="rotate(45)" />
          </g>
        )))}
      </svg>
      <div style={{ position: "absolute", top: 560, left: 60, right: 60, textAlign: "center", transform: `scale(${s})`, opacity: s }}>
        <div style={{ fontFamily: "Amiri", fontWeight: 700, fontSize: name.length > 14 ? 130 : 190, color: "#f2c75c", textShadow: "0 0 50px rgba(242,199,92,0.6)", lineHeight: 1.3 }}>{name}</div>
        <div style={{ fontFamily: "Amiri", fontWeight: 700, fontSize: 70, color: "#e7d3a3", marginTop: 10 }}>{(scene as any).fem ? "رضي الله عنها" : "رضي الله عنه"}</div>
      </div>
      <div style={{ position: "absolute", top: 1230, left: 120, right: 160, textAlign: "center", opacity: ctaO, fontFamily: "Tajawal", fontWeight: 800, fontSize: 48, color: "#fff", lineHeight: 1.5 }}>{cta}</div>
      <Particles n={60} color="#f2c75c" seed="rev" rise speed={0.8} size={[1.5, 4]} />
    </AbsoluteFill>
  );
};

const Cave: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const flick = 0.75 + 0.25 * Math.sin(f / 3) * Math.sin(f / 7);
  return (
    <AbsoluteFill style={{ background: "#020203" }}>
      <Camera dur={dur} from={1.0} to={1.14}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <defs>
            <radialGradient id="mouth" cx="50%" cy="45%" r="50%"><stop offset="0" stopColor="#1b2a4a" /><stop offset="1" stopColor="#0a1020" /></radialGradient>
            <radialGradient id="torch"><stop offset="0" stopColor={`rgba(255,170,60,${0.55 * flick})`} /><stop offset="1" stopColor="rgba(255,120,30,0)" /></radialGradient>
          </defs>
          <path d="M 250 1500 C 180 1100 260 700 470 560 C 600 480 760 560 840 760 C 920 980 900 1300 840 1500 Z" fill="url(#mouth)" />
          <ellipse cx={420} cy={1380} rx={260} ry={150} fill="url(#torch)" />
          <ellipse cx={720} cy={1400} rx={240} ry={140} fill="url(#torch)" />
          <linearGradient id="rock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#2e2218" /><stop offset="0.5" stopColor="#1a130d" /><stop offset="1" stopColor="#0d0906" /></linearGradient>
          <path d="M0 0 H1080 V1920 H0 Z M 250 1500 C 180 1100 260 700 470 560 C 600 480 760 560 840 760 C 920 980 900 1300 840 1500 Z" fill="url(#rock)" fillRule="evenodd" />
          <path d="M 250 1500 C 180 1100 260 700 470 560 C 600 480 760 560 840 760 C 920 980 900 1300 840 1500" fill="none" stroke={`rgba(255,160,70,${0.35 * flick})`} strokeWidth={6} />
          {[[120, 300, 200], [880, 420, 160], [60, 900, 240], [960, 1100, 200], [180, 1700, 260], [900, 1750, 220]].map(([x, y, r], i) => <ellipse key={i} cx={x} cy={y} rx={r} ry={r * 0.55} fill="rgba(0,0,0,0.25)" />)}
          <path d="M0 1500 H1080 V1920 H0 Z" fill="#1c140d" />
          <path d="M0 1500 H1080" stroke={`rgba(255,160,70,${0.25 * flick})`} strokeWidth={4} />
        </svg>
        <Particles n={50} color="#e8eeff" seed="cavest" speed={0.04} size={[0.8, 2.2]} area={[600, 1300]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Footsteps: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const steps = 10;
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#0d1426 0%, #2a2a3a 40%, #4a3a2c 100%)" }}>
      <Camera dur={dur} to={1.1} shake={1.5}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <rect x={0} y={900} width={W} height={1020} fill="#5a4330" />
          {Array.from({ length: steps }).map((_, i) => {
            const appear = (i / steps) * dur * 0.8;
            const o = interpolate(f, [appear, appear + 6], [0, 0.85], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
            const y = 1850 - i * 95;
            const x = 540 + (i % 2 ? 60 : -60) + Math.sin(i) * 20;
            const sc = 1 - i * 0.06;
            return <ellipse key={i} cx={x} cy={y} rx={26 * sc} ry={52 * sc} fill="#2a1d12" opacity={o} />;
          })}
          <path d="M 300 900 C 360 700 720 700 780 900 Z" fill="#06070b" />
        </svg>
        <Particles n={40} color="#d9c2a0" seed="fdust" speed={1.5} size={[1, 3]} area={[1000, 1900]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Quote: React.FC<VisualProps> = ({ words, scene }) => {
  const f = useCurrentFrame();
  const lines = scene.lines ?? [];
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 42%, #2a2410 0%, #07070a 62%)" }}>
      {lines.map((l, i) => {
        const st = Math.round((words[Math.min(l.word, words.length - 1)]?.t ?? i) * FPS);
        const s = spring({ frame: f - st, fps: FPS, config: { damping: 12 } });
        return (
          <div key={i} style={{ position: "absolute", top: 430 + i * 270, width: "100%", textAlign: "center", fontFamily: "Amiri", fontWeight: 700, fontSize: Math.min(lines.length > 1 ? 150 : 170, Math.floor(2500 / Math.max(...lines.map((x) => x.text.replace(/[\u064B-\u0652]/g, "").length)))), color: "#f2c75c", opacity: s, transform: `translateY(${(1 - s) * 40}px)`, textShadow: "0 0 50px rgba(242,199,92,0.6)", lineHeight: 1.3 }}>{l.text}</div>
        );
      })}
      <Particles n={50} color="#f2c75c" seed="q" rise speed={1} size={[1.5, 4]} />
    </AbsoluteFill>
  );
};

const Coins: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 60%, #3a2a0e 0%, #0b0805 70%)" }}>
      <Camera dur={dur} to={1.08}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          {Array.from({ length: 40 }).map((_, i) => {
            const t0 = random(`c${i}`) * dur * 0.7;
            const p = interpolate(f, [t0, t0 + 18], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
            const x = 340 + random(`cx${i}`) * 400;
            const yEnd = 960 - random(`cy${i}`) * 120 - Math.min(i, 30) * 4;
            const y = interpolate(p, [0, 1], [-60, yEnd]);
            return p > 0 ? <ellipse key={i} cx={x} cy={y} rx={34} ry={p < 1 ? 34 : 12} fill="#e9b949" stroke="#9a6d12" strokeWidth={4} /> : null;
          })}
          <ellipse cx={540} cy={990} rx={300} ry={60} fill="rgba(233,185,73,0.18)" />
        </svg>
        <Particles n={40} color="#ffe6a3" seed="cn" rise speed={1} size={[1.5, 4]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Well: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const drop = interpolate(f, [0, dur * FPS * 0.6], [0, 1], { extrapolateRight: "clamp" });
  const ripple = (f % 45) / 45;
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#f2a65a 0%, #f7d39a 35%, #e7b980 60%)" }}>
      <Camera dur={dur} from={1.0} to={1.12}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <circle cx={820} cy={420} r={110} fill="#fff1c9" opacity={0.9} />
        </svg>
        <Dunes color="#d39a5e" y={1020} phase={Math.sin(f / 40) * 8} />
        <Palm x={140} y={1080} s={1.3} color="#5a3a1e" />
        <Palm x={960} y={1100} s={1.1} color="#5a3a1e" />
        <Dunes color="#b8793f" y={1300} />
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <ellipse cx={540} cy={1080} rx={240} ry={60} fill="#3b2a1a" />
          <ellipse cx={540} cy={1080} rx={190} ry={44} fill="#1d4f7a" />
          <ellipse cx={540} cy={1080} rx={190 * ripple} ry={44 * ripple} fill="none" stroke="#9fd6f2" strokeWidth={4} opacity={1 - ripple} />
          <path d="M300 1080 V 1240 Q 540 1310 780 1240 V 1080 Q 540 1150 300 1080 Z" fill="#a8743f" />
          {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M${300 + i * 96} 1090 V 1255`} stroke="#7a5228" strokeWidth={4} />)}
          <path d="M300 1160 Q 540 1225 780 1160" stroke="#7a5228" strokeWidth={4} fill="none" />
          <path d="M320 1080 V 760 M 760 1080 V 760" stroke="#4a2f18" strokeWidth={22} />
          <rect x={290} y={740} width={500} height={34} rx={10} fill="#4a2f18" />
          <path d={`M540 774 V ${830 + drop * 200}`} stroke="#3b2a1a" strokeWidth={5} />
          <path d={`M505 ${830 + drop * 200} h70 l-10 60 h-50 z`} fill="#6b4524" />
        </svg>
        <Particles n={30} color="#fff3d6" seed="well" rise speed={0.6} size={[1.5, 3.5]} area={[300, 1400]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Water: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 40%, #1f5f86 0%, #0a1f33 70%)" }}>
      <Camera dur={dur} to={1.1}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          {Array.from({ length: 6 }).map((_, i) => {
            const t = ((f + i * 18) % 110) / 110;
            return <ellipse key={i} cx={540} cy={900} rx={60 + t * 460} ry={20 + t * 150} fill="none" stroke="#9fd6f2" strokeWidth={5} opacity={(1 - t) * 0.8} />;
          })}
          {Array.from({ length: 14 }).map((_, i) => {
            const t = ((f + i * 9) % 60) / 60;
            const x = 540 + Math.sin(i * 2.1) * 30;
            return <ellipse key={`d${i}`} cx={x} cy={380 + t * 520} rx={9} ry={15} fill="#bfe8ff" opacity={1 - t * 0.6} />;
          })}
        </svg>
        <Particles n={50} color="#bfe8ff" seed="wtr" rise speed={0.8} size={[1.5, 4]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Cloak: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const fold = interpolate(f, [dur * FPS * 0.55, dur * FPS * 0.85], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const w = 380 * (1 - fold * 0.75);
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 45%, #3b2340 0%, #120a14 70%)" }}>
      <Camera dur={dur} to={1.1}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <circle cx={540} cy={820} r={360} fill="#f2d589" opacity={0.08 + fold * 0.12} />
          {Array.from({ length: 36 }).map((_, i) => {
            const t = ((f + i * 7) % 70) / 70;
            const x = 540 + Math.sin(i * 1.7) * 260 * (1 - fold * 0.6);
            const y = 260 + t * 620;
            return <circle key={i} cx={x} cy={y} r={3 + (i % 3) * 2} fill="#f6e2a8" opacity={(1 - t) * (1 - fold * 0.5)} />;
          })}
          <path d={`M${540 - w} 900 Q 540 ${860 - fold * 40} ${540 + w} 900 L ${540 + w + 30} ${990 + fold * 20} Q 540 ${940 + fold * 20} ${540 - w - 30} ${990 + fold * 20} Z`} fill="#e8dcc4" />
          <path d={`M${540 - w} 900 Q 540 ${860 - fold * 40} ${540 + w} 900`} stroke="#c9a24c" strokeWidth={6} fill="none" />
          {Array.from({ length: 5 }).map((_, i) => <path key={`l${i}`} d={`M${540 - w + (i + 1) * (2 * w) / 6} ${905 - Math.sin(((i + 1) / 6) * Math.PI) * 30} l 8 70`} stroke="#cdbf9f" strokeWidth={3} />)}
        </svg>
        <Particles n={40} color="#f2d589" seed="clk" rise speed={0.8} size={[1.5, 4]} />
      </Camera>
    </AbsoluteFill>
  );
};

const Door: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const flick = 0.8 + 0.2 * Math.sin(f / 4) * Math.sin(f / 9);
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#0e1830 0%, #1d2440 50%, #2a2230 100%)" }}>
      <Camera dur={dur} from={1.0} to={1.12}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <defs><radialGradient id="dg"><stop offset="0" stopColor={`rgba(255,190,90,${0.6 * flick})`} /><stop offset="1" stopColor="rgba(255,150,60,0)" /></radialGradient></defs>
          <rect x={140} y={560} width={800} height={900} fill="#5a4030" />
          <rect x={120} y={540} width={840} height={40} fill="#4a3426" />
          {Array.from({ length: 9 }).map((_, i) => <path key={i} d={`M140 ${640 + i * 95} H940`} stroke="#4c3527" strokeWidth={3} />)}
          <path d="M430 1460 V 980 Q 540 870 650 980 V 1460 Z" fill="#ffcf7a" opacity={0.85 * flick} />
          <path d="M430 1460 V 980 Q 540 870 650 980 V 1460" fill="none" stroke="#3a281c" strokeWidth={14} />
          <circle cx={540} cy={1200} r={420} fill="url(#dg)" />
          <path d="M760 760 h40 v70 h-40 z" fill="#c9a24c" />
          <circle cx={780} cy={800} r={60} fill="url(#dg)" />
          <path d="M0 1460 H1080 V1920 H0 Z" fill="#1a1410" />
          <path d="M430 1460 L 300 1920 H 780 L 650 1460 Z" fill="#ffcf7a" opacity={0.12 * flick} />
        </svg>
        <Particles n={40} color="#ffe2a8" seed="door" rise speed={0.5} size={[1.2, 3]} area={[600, 1500]} />
      </Camera>
    </AbsoluteFill>
  );
};

export const SCENES: Record<string, React.FC<VisualProps>> = {
  sun: Sun, door: Door, cloak: Cloak, well: Well, water: Water, cave: Cave, footsteps: Footsteps, quote: Quote, coins: Coins, empty: Empty, drag: Drag, dark: Dark, ahad: Ahad, chain: Chain, dawn: Dawn, jannah: Jannah, reveal: Reveal, ...SCENES2, ...SCENES3,
};
