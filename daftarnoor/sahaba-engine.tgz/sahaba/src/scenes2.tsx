import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, random } from "remotion";
import { Camera, Particles } from "./ui";
import type { VisualProps } from "./scenes";

/* v3 scenes (23 Nov 2026): every scene has an internal beat every 1–3 s. No people drawn. */
const FPS = 30;
const W = 1080, H = 1920;
const cl = { extrapolateLeft: "clamp" as const, extrapolateRight: "clamp" as const };
const wordAt = (words: { t: number; w: string }[], key: string, fb: number) => {
  const w = words.find((x) => x.w.replace(/[ً-ْ]/g, "").includes(key));
  return Math.round((w ? w.t : fb) * FPS);
};

const PalmTree: React.FC<{ x: number; y: number; s: number; color: string; sway?: number; leaf?: string }> = ({ x, y, s, color, sway = 0, leaf }) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-7 0 Q -2 -160 5 -300 L 15 -300 Q 9 -160 11 0 Z" fill={color} />
    {[-70, -35, 0, 35, 70, 110, -110].map((a, i) => (
      <path key={i} transform={`translate(10,-300) rotate(${a + sway * (i % 2 ? 1 : -0.7)})`} d="M0 0 Q 70 -30 150 20 Q 70 -5 0 8 Z" fill={leaf ?? color} />
    ))}
  </g>
);

const Sapling: React.FC<{ x: number; y: number; s: number; sway: number }> = ({ x, y, s, sway }) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx={0} cy={4} rx={46} ry={12} fill="#6b4423" />
    <path d="M-5 0 Q 0 -60 3 -110 L 9 -110 Q 6 -60 5 0 Z" fill="#7a5a2e" />
    {[-60, -25, 15, 50, 85].map((a, i) => (
      <path key={i} transform={`translate(6,-108) rotate(${a - 15 + sway * (i % 2 ? 1 : -1)})`} d="M0 0 Q 45 -22 95 10 Q 45 -4 0 6 Z" fill={i % 2 ? "#4f8a3a" : "#3f7a30"} />
    ))}
  </g>
);

const DaySky: React.FC<{ k?: number }> = ({ k = 0 }) => (
  <AbsoluteFill style={{ background: `linear-gradient(rgb(${120 + 40 * k},${178 + 20 * k},${220}) 0%, #f6e3b8 52%, #f2c98a 70%)` }} />
);

/* ---------- Grove: saplings spring up row by row (hook) / grown palms swaying ---------- */
const Grove: React.FC<VisualProps> = ({ dur, scene }) => {
  const f = useCurrentFrame();
  const grown = (scene as any).grown;
  const rows = [
    { y: 1130, n: 7, s: 0.55 },
    { y: 1330, n: 6, s: 0.8 },
    { y: 1600, n: 5, s: 1.1 },
    { y: 1900, n: 4, s: 1.45 },
  ];
  // growth order: big foreground rows first (already up on frame 1), far rows spring up after
  const order: number[] = [];
  { let o = 0; const tmp: number[][] = rows.map((r) => Array(r.n).fill(0)); for (let ri = rows.length - 1; ri >= 0; ri--) for (let i = 0; i < rows[ri].n; i++) tmp[ri][i] = o++; tmp.forEach((r) => r.forEach((v) => order.push(v))); }
  let idx = 0;
  return (
    <AbsoluteFill>
      <DaySky k={grown ? 0.6 : 0} />
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={860} cy={360} r={110 + Math.sin(f / 10) * 4} fill="#fff6d6" opacity={0.95} />
        <circle cx={860} cy={360} r={230} fill="#fff1c0" opacity={0.25} />
        <path d={`M0 1000 C 300 960 700 990 1080 950 L1080 ${H} L0 ${H} Z`} fill="#c58c52" />
        <path d={`M0 1000 C 300 960 700 990 1080 950`} stroke="#e7b77a" strokeWidth={6} fill="none" />
        {rows.map((r, ri) => <path key={ri} d={`M0 ${r.y + 10} Q 540 ${r.y - 20} 1080 ${r.y + 10}`} stroke="#9c6a3a" strokeWidth={8 * r.s} fill="none" opacity={0.6} />)}
        {rows.map((r, ri) =>
          Array.from({ length: r.n }).map((_, i) => {
            const k = idx++;
            const x = ((i + 0.5) / r.n) * W + (ri % 2 ? 40 : -20);
            const start = grown ? -60 : -50 + order[k] * 4; // first ones already up on frame 1
            const g = spring({ frame: f - start, fps: FPS, config: { damping: 10, stiffness: 120 } });
            const sway = Math.sin(f / 9 + k) * (grown ? 9 : 4);
            const puff = interpolate(f - start, [0, 14], [0, 1], cl);
            return (
              <g key={`${ri}-${i}`}>
                {f >= start && puff < 1 && <circle cx={x} cy={r.y} r={20 + puff * 70 * r.s} fill="#e9c08a" opacity={(1 - puff) * 0.7} />}
                {grown
                  ? <PalmTree x={x} y={r.y} s={r.s * 0.95} color="#5a3a1e" leaf="#3d6e2c" sway={sway} />
                  : <g transform={`translate(0,${(1 - g) * 40})`} opacity={Math.min(1, g * 1.4)}><Sapling x={x} y={r.y} s={r.s * Math.max(0.01, g)} sway={sway} /></g>}
              </g>
            );
          })
        )}
      </svg>
      <Particles n={30} color="#fff3d0" seed="grv" rise speed={0.7} size={[1.5, 3.5]} area={[300, 1500]} />
      {/* top shade so hook text reads on bright sky */}
      <AbsoluteFill style={{ background: "linear-gradient(rgba(30,15,0,0.55) 0%, rgba(30,15,0,0.15) 35%, rgba(0,0,0,0) 45%)" }} />
    </AbsoluteFill>
  );
};

/* ---------- Home in Persia: warm house, lamp lights up, smoke rises ---------- */
const Home: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const lampOn = interpolate(f, [18, 30], [0.15, 1], cl);
  const flick = 0.85 + 0.15 * Math.sin(f / 3) * Math.sin(f / 7);
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#f0a86a 0%, #e07d4f 40%, #7c3f3a 75%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={200} cy={560} r={90} fill="#ffe0a6" opacity={0.85} />
        <rect x={120} y={760} width={840} height={760} fill="#c9a37a" />
        <rect x={100} y={730} width={880} height={50} fill="#a8825a" />
        <path d="M 300 760 L 300 640 Q 540 470 780 640 L 780 760 Z" fill="#b48c63" />
        {/* arched window */}
        <path d="M 230 1250 V 1000 Q 330 880 430 1000 V 1250 Z" fill={`rgba(255,196,110,${lampOn * flick})`} stroke="#6b4a2e" strokeWidth={12} />
        <path d="M 330 900 V 1250 M 230 1100 H 430" stroke="#6b4a2e" strokeWidth={8} />
        <circle cx={330} cy={1120} r={240} fill={`rgba(255,190,100,${0.22 * lampOn * flick})`} />
        {/* door */}
        <path d="M 620 1520 V 1080 Q 740 970 860 1080 V 1520 Z" fill="#6b3f22" stroke="#4a2a14" strokeWidth={12} />
        <circle cx={830} cy={1300} r={10} fill="#d8b25c" />
        {/* tile band */}
        {Array.from({ length: 11 }).map((_, i) => <rect key={i} x={130 + i * 76} y={800} width={60} height={60} fill={i % 2 ? "#2f6f8f" : "#e7d3a3"} opacity={0.85} transform={`rotate(45 ${160 + i * 76} 830)`} />)}
        <rect x={0} y={1520} width={W} height={400} fill="#5a3826" />
        {/* chimney smoke */}
        {Array.from({ length: 8 }).map((_, i) => {
          const t = ((f + i * 12) % 96) / 96;
          return <circle key={i} cx={860 + Math.sin(t * 6 + i) * 30} cy={700 - t * 500} r={20 + t * 50} fill="#f6e6d0" opacity={(1 - t) * 0.35} />;
        })}
        <rect x={830} y={650} width={60} height={90} fill="#8f6a46" />
      </svg>
      <Particles n={25} color="#ffe6b8" seed="home" speed={0.5} size={[1.2, 3]} area={[400, 1500]} />
    </AbsoluteFill>
  );
};

/* ---------- Door shuts, bolt slides: kept inside like a girl ---------- */
const HomeShut: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const close = interpolate(f, [4, 16], [0, 1], { ...cl, easing: (t) => t * t });
  const bolt = interpolate(f, [34, 46], [0, 1], cl);
  const shake = f > 16 && f < 22 ? (random(`hs${f}`) - 0.5) * 18 : 0;
  const flick = 0.8 + 0.2 * Math.sin(f / 3) * Math.sin(f / 8);
  const doorW = 520 * (0.12 + 0.88 * close);
  return (
    <AbsoluteFill style={{ background: "#3a2418" }}>
      <AbsoluteFill style={{ transform: `translate(${shake}px,0)` }}>
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <rect x={0} y={0} width={W} height={H} fill="#7a5236" />
          {Array.from({ length: 14 }).map((_, i) => <path key={i} d={`M0 ${i * 140} H${W}`} stroke="#6a4630" strokeWidth={3} />)}
          {/* doorway glow (outside world) */}
          <rect x={280} y={500} width={520} height={1100} fill="#ffd894" />
          <rect x={280} y={500} width={520} height={1100} fill={`rgba(255,240,200,${0.5 * (1 - close)})`} />
          {/* door leaf closing from the left */}
          <rect x={280} y={500} width={doorW} height={1100} fill="#5a3218" stroke="#3a1e0c" strokeWidth={10} />
          {Array.from({ length: 4 }).map((_, i) => <path key={i} d={`M${280 + ((i + 1) * doorW) / 5} 510 V1590`} stroke="#45260f" strokeWidth={6} />)}
          {/* bolt */}
          <rect x={300 + 380 * (1 - bolt)} y={1020} width={240} height={34} rx={8} fill="#b58a3c" opacity={close > 0.98 ? 1 : 0} />
          <rect x={760} y={1000} width={50} height={74} fill="#6b5326" opacity={close > 0.98 ? 1 : 0} />
          {/* light leaking under the door */}
          <rect x={280} y={1595} width={520} height={10} fill={`rgba(255,210,130,${0.8 * flick})`} />
          <path d="M280 1605 L 160 1920 H 920 L 800 1605 Z" fill={`rgba(255,200,120,${0.18 * flick})`} />
          {/* lamp inside */}
          <circle cx={900} cy={760} r={26} fill="#ffcf7a" />
          <circle cx={900} cy={760} r={190} fill={`rgba(255,190,100,${0.28 * flick})`} />
          <path d="M885 790 h30 l-6 30 h-18 z" fill="#8a6a2a" />
        </svg>
        <Particles n={40} color="#e8c99a" seed="hsd" speed={0.4} size={[1, 3]} area={[400, 1700]} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ---------- Fire temple flame he had to keep alight ---------- */
const Fire: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const flare = 1 + 0.35 * interpolate(f, [36, 44, 70], [0, 1, 0], cl);
  const flame = (k: number, w: number, h: number, c: string) => {
    const a = Math.sin(f / 4 + k) * 18, b = Math.sin(f / 6 + k * 2) * 24;
    return <path d={`M ${540 - w} 1180 C ${540 - w} ${1180 - h * 0.5} ${540 - w * 0.3 + a} ${1180 - h * 0.7} ${540 + b} ${1180 - h} C ${540 + w * 0.3 + a} ${1180 - h * 0.6} ${540 + w} ${1180 - h * 0.4} ${540 + w} 1180 Z`} fill={c} />;
  };
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 55%, #6a2a10 0%, #2a0e06 55%, #120604 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={540} cy={1000} r={520 * flare} fill="rgba(255,140,40,0.16)" />
        {/* arches behind */}
        {[180, 540, 900].map((x, i) => <path key={i} d={`M ${x - 130} 1300 V 640 Q ${x} 460 ${x + 130} 640 V 1300`} stroke="#4a1e0e" strokeWidth={30} fill="none" />)}
        <g transform={`translate(540 1180) scale(${flare}) translate(-540 -1180)`}>
          {flame(0, 170, 520, "#c2410c")}
          {flame(1.3, 125, 430, "#f97316")}
          {flame(2.1, 80, 330, "#fbbf24")}
          {flame(3.4, 40, 210, "#fff1b8")}
        </g>
        {/* stone altar */}
        <path d="M 330 1180 H 750 L 700 1260 H 380 Z" fill="#7d6a5a" />
        <rect x={400} y={1260} width={280} height={300} fill="#6b5a4c" />
        <path d="M 340 1560 H 740 V 1620 H 340 Z" fill="#594a3e" />
        <rect x={0} y={1620} width={W} height={300} fill="#1f0c06" />
      </svg>
      <Particles n={70} color="#ffb347" seed="emb2" rise speed={2.2} size={[1.5, 4.5]} area={[500, 1300]} />
    </AbsoluteFill>
  );
};

/* ---------- Route on a parchment map: Persia → Sham → Madinah, lamps = monks ---------- */
const Road: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [4, dur - 10], [0, 1], cl);
  const pts = [[880, 760], [620, 540], [330, 620], [260, 980], [380, 1330]];
  const labels = [["فارس", 880, 840], ["الشام", 300, 500], ["المدينة", 380, 1440]] as const;
  const d = `M ${pts.map((q) => q.join(" ")).join(" L ")}`;
  const len = 2000;
  return (
    <AbsoluteFill style={{ background: "#e9d6ae" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <defs><radialGradient id="pm" cx="50%" cy="50%" r="70%"><stop offset="0.5" stopColor="rgba(0,0,0,0)" /><stop offset="1" stopColor="rgba(90,55,20,0.55)" /></radialGradient></defs>
        <path d="M 1080 300 C 900 420 940 700 1080 900 Z" fill="#9cc3cf" opacity={0.6} />
        <path d="M 0 1500 C 200 1450 300 1700 160 1920 L 0 1920 Z" fill="#9cc3cf" opacity={0.6} />
        {Array.from({ length: 30 }).map((_, i) => <circle key={i} cx={random(`mp${i}`) * W} cy={300 + random(`mq${i}`) * 1400} r={3} fill="#b08a55" opacity={0.5} />)}
        <path d={d} stroke="#b08a55" strokeWidth={6} fill="none" strokeDasharray="14 14" opacity={0.5} />
        <path d={d} stroke="#7a2e12" strokeWidth={10} fill="none" strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - p)} />
        {pts.map(([x, y], i) => {
          const at = i / (pts.length - 1);
          const on = spring({ frame: f - (4 + at * (dur - 14)), fps: FPS, config: { damping: 9 } });
          const flick = 0.75 + 0.25 * Math.sin(f / 3 + i);
          return (
            <g key={i} opacity={on}>
              <circle cx={x} cy={y} r={60 * flick} fill="rgba(255,190,90,0.35)" />
              <circle cx={x} cy={y} r={20 * on} fill={i === pts.length - 1 ? "#1d6b66" : "#c2410c"} stroke="#fff3d6" strokeWidth={5} />
            </g>
          );
        })}
        <rect width={W} height={H} fill="url(#pm)" />
      </svg>
      {labels.map(([t, x, y], i) => {
        const at = [0, 0.5, 1][i];
        const o = interpolate(f, [4 + at * (dur - 20), 14 + at * (dur - 20)], [0, 1], cl);
        return <div key={i} style={{ position: "absolute", left: x - 200, top: y - 50, width: 400, textAlign: "center", fontFamily: "Reem Kufi", fontWeight: 700, fontSize: 64, color: "#5a2a10", opacity: o, direction: "rtl" }}>{t}</div>;
      })}
    </AbsoluteFill>
  );
};

/* ---------- Sold: swinging chain + tally of masters scratched on the wall ---------- */
const Tally: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const swing = Math.sin(f / 9) * 9;
  const n = 12;
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 40%, #5a4636 0%, #241a12 75%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <defs><linearGradient id="mt2" x1="0" x2="1"><stop offset="0" stopColor="#5d6067" /><stop offset="0.5" stopColor="#c9ccd2" /><stop offset="1" stopColor="#4a4c52" /></linearGradient></defs>
        {Array.from({ length: 8 }).map((_, r) => <path key={r} d={`M0 ${300 + r * 160} H${W}`} stroke="#3a2c20" strokeWidth={4} />)}
        {Array.from({ length: n }).map((_, i) => {
          const st = 10 + i * ((dur - 30) / n);
          const p = interpolate(f, [st, st + 5], [0, 1], cl);
          const grp = Math.floor(i / 5), j = i % 5;
          const x = 200 + grp * 260 + j * 42;
          if (j === 4) return <path key={i} d={`M ${x - 175} 1340 L ${x - 175 + 210 * p} ${1340 - 200 * p}`} stroke="#e7d3a3" strokeWidth={10} strokeLinecap="round" opacity={p > 0 ? 0.9 : 0} />;
          return <path key={i} d={`M ${x} 1150 V ${1150 + 220 * p}`} stroke="#e7d3a3" strokeWidth={10} strokeLinecap="round" opacity={p > 0 ? 0.9 : 0} />;
        })}
        <g transform={`rotate(${swing} 540 0)`}>
          {Array.from({ length: 7 }).map((_, i) => i % 2 === 0
            ? <ellipse key={i} cx={540} cy={60 + i * 120} rx={45} ry={80} stroke="url(#mt2)" strokeWidth={22} fill="none" />
            : <ellipse key={i} cx={540} cy={60 + i * 120} rx={16} ry={80} stroke="url(#mt2)" strokeWidth={22} fill="none" />)}
          <path d="M 470 900 A 70 70 0 1 0 610 900" stroke="url(#mt2)" strokeWidth={28} fill="none" />
        </g>
      </svg>
      <Particles n={40} color="#d9c2a0" seed="tly" speed={0.6} size={[1, 3]} />
    </AbsoluteFill>
  );
};

/* ---------- Digging holes, saplings set into them one by one ---------- */
const Dig: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const holes = [[260, 1150, 0.7], [560, 1120, 0.7], [840, 1160, 0.7], [180, 1420, 1], [540, 1440, 1], [900, 1430, 1], [340, 1760, 1.3], [780, 1780, 1.3]];
  const half = dur * 0.45;
  return (
    <AbsoluteFill>
      <DaySky k={0.3} />
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={220} cy={380} r={95} fill="#fff6d6" />
        <PalmTree x={940} y={1000} s={1.1} color="#6a4a2a" leaf="#4a7a36" sway={Math.sin(f / 10) * 6} />
        <PalmTree x={110} y={990} s={0.9} color="#6a4a2a" leaf="#4a7a36" sway={Math.sin(f / 11) * 6} />
        <path d={`M0 1000 C 300 970 700 990 1080 960 L1080 ${H} L0 ${H} Z`} fill="#b97c45" />
        {holes.map(([x, y, s], i) => {
          const hs = 4 + i * (half / holes.length);
          const h = spring({ frame: f - hs, fps: FPS, config: { damping: 12 } });
          const ps = half + i * ((dur - half - 10) / holes.length);
          const drop = interpolate(f, [ps, ps + 8], [-300, 0], { ...cl, easing: (t) => 1 - (1 - t) * (1 - t) });
          const dirt = interpolate(f - hs, [0, 12], [0, 1], cl);
          return (
            <g key={i}>
              {f >= hs && dirt < 1 && Array.from({ length: 6 }).map((_, k) => <circle key={k} cx={x + Math.cos(k) * 80 * dirt * s} cy={y - Math.abs(Math.sin(k * 1.7)) * 120 * dirt * s + 60 * dirt * dirt} r={8 * s} fill="#7a4a24" opacity={1 - dirt} />)}
              <ellipse cx={x} cy={y} rx={70 * s * h} ry={22 * s * h} fill="#4a2a12" />
              <ellipse cx={x + 60 * s} cy={y - 6} rx={34 * s * h} ry={16 * s * h} fill="#9a6232" />
              {f >= ps && <g transform={`translate(0,${drop})`}><Sapling x={x} y={y} s={s * 0.8} sway={Math.sin(f / 7 + i) * 4} /></g>}
            </g>
          );
        })}
      </svg>
      <Particles n={30} color="#f0d2a0" seed="dig" speed={1.2} size={[1, 3]} area={[1000, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Khaybar: banner flapping over the fortress (hook) ---------- */
const Fortress: React.FC<{ y: number; s: number; c: string; c2: string }> = ({ y, s, c, c2 }) => (
  <g transform={`translate(540 ${y}) scale(${s}) translate(-540 0)`}>
    <path d="M 60 0 L 200 -180 L 420 -230 L 700 -210 L 900 -160 L 1040 0 Z" fill={c2} />
    {[[300, -380, 130], [470, -470, 150], [660, -420, 140], [820, -330, 110]].map(([x, yy, w], i) => (
      <g key={i}>
        <rect x={x - w / 2} y={yy} width={w} height={-yy - 150} fill={c} />
        {Array.from({ length: 4 }).map((_, k) => <rect key={k} x={x - w / 2 + k * (w / 4)} y={yy - 26} width={w / 8} height={26} fill={c} />)}
        <rect x={x - 10} y={yy + 60} width={20} height={36} fill="#2a1a10" opacity={0.7} />
      </g>
    ))}
    <rect x={200} y={-260} width={680} height={110} fill={c} />
  </g>
);

const Banner: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const wave = (x: number, ph: number) => Math.sin(f / 5 + x / 70 + ph) * (12 + x / 18);
  const pts: string[] = [];
  const bx = 170, by = 330, bw = 560, bh = 340;
  for (let i = 0; i <= 10; i++) { const x = (i / 10) * bw; pts.push(`${bx + 18 + x},${by + wave(x, 0)}`); }
  for (let i = 10; i >= 0; i--) { const x = (i / 10) * bw; pts.push(`${bx + 18 + x},${by + bh + wave(x, 0.6)}`); }
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#8fb9d8 0%, #f3dcae 50%, #e9b77a 68%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={860} cy={720} r={120} fill="#fff4d0" opacity={0.95} />
        <circle cx={860} cy={720} r={260} fill="#fff0c0" opacity={0.25} />
        <Fortress y={1250} s={1} c="#a97850" c2="#8a5c3a" />
        <path d={`M0 1240 C 300 1210 700 1250 1080 1220 L1080 ${H} L0 ${H} Z`} fill="#c08850" />
        <PalmTree x={960} y={1420} s={1.3} color="#5a3a1e" leaf="#3d6e2c" sway={Math.sin(f / 8) * 7} />
        <PalmTree x={120} y={1500} s={1.1} color="#5a3a1e" leaf="#3d6e2c" sway={Math.sin(f / 9) * 7} />
        {/* pole */}
        <rect x={bx} y={by - 40} width={22} height={1500} fill="#4a2c16" />
        <circle cx={bx + 11} cy={by - 46} r={22} fill="#d8b25c" />
        <polygon points={pts.join(" ")} fill="#1c1c1c" />
        <polygon points={pts.join(" ")} fill="url(#bsh)" />
        <defs><linearGradient id="bsh" x1="0" x2="1">{Array.from({ length: 6 }).map((_, i) => <stop key={i} offset={i / 5} stopColor={i % 2 ? "rgba(255,255,255,0.10)" : "rgba(0,0,0,0.18)"} />)}</linearGradient></defs>
      </svg>
      <Particles n={40} color="#f6dcae" seed="ban" speed={2.5} size={[1, 3]} area={[1100, 1900]} />
      <AbsoluteFill style={{ background: "linear-gradient(rgba(0,0,0,0) 0%, rgba(0,0,0,0) 55%, rgba(30,15,0,0.35) 100%)" }} />
    </AbsoluteFill>
  );
};

/* ---------- Fortresses on the hills, birds cross ---------- */
const Fort: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#9cc0dc 0%, #f1d6a6 55%, #d99a5c 75%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <Fortress y={1050} s={0.6} c="#b88a62" c2="#9a6e4a" />
        {[0, 1, 2].map((i) => {
          const st = 6 + i * 22;
          const s = spring({ frame: f - st, fps: FPS, config: { damping: 14 } });
          return <g key={i} transform={`translate(${[-330, 330, 0][i]},${(1 - s) * 260})`} opacity={s}><Fortress y={[1250, 1280, 1420][i]} s={[0.7, 0.75, 1][i]} c={["#a2724c", "#a87a52", "#8f603c"][i]} c2={["#865a38", "#8a5e3c", "#704a2c"][i]} /></g>;
        })}
        <path d={`M0 1420 C 300 1390 700 1440 1080 1400 L1080 ${H} L0 ${H} Z`} fill="#a8743f" />
        {Array.from({ length: 5 }).map((_, i) => {
          const x = ((f * 7 + i * 120) % 1400) - 200;
          const y = 520 + i * 40 + Math.sin(f / 6 + i) * 10;
          const fl = Math.sin(f / 2 + i) * 14;
          return <path key={i} d={`M ${x - 26} ${y - fl} Q ${x - 12} ${y - 8} ${x} ${y} Q ${x + 12} ${y - 8} ${x + 26} ${y - fl}`} stroke="#3a2a20" strokeWidth={5} fill="none" />;
        })}
      </svg>
      <Particles n={40} color="#f6dcae" seed="frt" speed={2} size={[1, 3]} area={[1300, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Night camp: tents light up one by one, moon slides ---------- */
const Camp: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const tents = [[180, 1350, 0.8], [470, 1300, 0.7], [780, 1340, 0.85], [320, 1600, 1.1], [760, 1640, 1.2]];
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#0f1a38 0%, #23305a 55%, #3c3350 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={interpolate(f, [0, dur], [760, 640])} cy={interpolate(f, [0, dur], [520, 470])} r={70} fill="#f4ecd0" />
        <circle cx={interpolate(f, [0, dur], [790, 670])} cy={interpolate(f, [0, dur], [500, 450])} r={62} fill="#1a2546" />
        <path d={`M0 1200 C 300 1170 700 1210 1080 1180 L1080 ${H} L0 ${H} Z`} fill="#2a2438" />
        {tents.map(([x, y, s], i) => {
          const on = interpolate(f, [8 + i * 14, 16 + i * 14], [0, 1], cl);
          const fl = 0.8 + 0.2 * Math.sin(f / 3 + i * 2);
          return (
            <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
              <circle cx={0} cy={-40} r={110} fill={`rgba(255,180,90,${0.12 * on * fl})`} />
              <path d="M -170 0 L 0 -230 L 170 0 Z" fill="#5a4a5e" />
              <path d="M -40 0 L 0 -150 L 40 0 Z" fill={`rgba(255,196,110,${0.15 + 0.85 * on * fl})`} />
              <path d="M 0 -230 V -270" stroke="#3a2c3e" strokeWidth={8} />
            </g>
          );
        })}
      </svg>
      <Particles n={70} color="#e8eeff" seed="cmp" speed={0.05} size={[0.8, 2.4]} area={[0, 1100]} />
    </AbsoluteFill>
  );
};

/* ---------- Healing: blurred dawn snaps into focus at «فبرأ» ---------- */
const Heal: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const at = wordAt(words, "فبرأ", (dur / FPS) * 0.6);
  const clear = interpolate(f, [at - 4, at + 8], [0, 1], cl);
  const blur = 16 * (1 - clear);
  const ring = (k: number) => interpolate(f - at - k * 6, [0, 30], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: "#e9c38a" }}>
      <AbsoluteFill style={{ filter: `blur(${blur}px) brightness(${0.75 + 0.35 * clear})` }}>
        <AbsoluteFill style={{ background: "linear-gradient(#a9cbe3 0%, #f6e2b5 55%, #e7b072 72%)" }} />
        <svg width={W} height={H} style={{ position: "absolute" }}>
          <circle cx={540} cy={760} r={150 + 30 * clear} fill="#fff6d6" />
          <path d={`M0 1240 C 300 1200 700 1260 1080 1220 L1080 ${H} L0 ${H} Z`} fill="#b97c45" />
          <PalmTree x={220} y={1300} s={1.4} color="#5a3a1e" leaf="#3d6e2c" sway={Math.sin(f / 8) * 6} />
          <PalmTree x={860} y={1320} s={1.6} color="#5a3a1e" leaf="#3d6e2c" sway={Math.sin(f / 9) * 6} />
        </svg>
      </AbsoluteFill>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {[0, 1, 2].map((k) => { const r = ring(k); return f >= at + k * 6 ? <circle key={k} cx={540} cy={760} r={150 + r * 700} stroke="#fff6d6" strokeWidth={8} fill="none" opacity={(1 - r) * 0.8} /> : null; })}
      </svg>
      <Particles n={50} color="#fffbe8" seed="heal" rise speed={1 + clear} size={[1.5, 4]} />
    </AbsoluteFill>
  );
};

/* ---------- Gate swings open, light and dust pour out ---------- */
const Gate: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [8, 40], [0, 1], { ...cl, easing: (t) => t * t * (3 - 2 * t) });
  const shake = f > 8 && f < 40 ? (random(`gt${f}`) - 0.5) * 8 : 0;
  return (
    <AbsoluteFill style={{ background: "#8a5c3a", transform: `translate(${shake}px,0)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <rect x={0} y={0} width={W} height={H} fill="#a97850" />
        {Array.from({ length: 16 }).map((_, r) => Array.from({ length: 6 }).map((__, c) => <rect key={`${r}${c}`} x={c * 190 + (r % 2) * 95 - 40} y={r * 120} width={180} height={112} fill="none" stroke="#8a5c3a" strokeWidth={5} />))}
        <path d="M 200 1700 V 820 Q 540 520 880 820 V 1700 Z" fill="#fff1c8" />
        <circle cx={540} cy={1200} r={300 + o * 400} fill={`rgba(255,240,190,${0.5 * o})`} />
        <g transform={`translate(200 0) scale(${1 - o * 0.85} 1)`}><path d="M 0 1700 V 820 Q 170 600 340 680 V 1700 Z" fill="#5a3218" stroke="#3a1e0c" strokeWidth={10} />{[1, 2, 3].map((k) => <path key={k} d={`M 0 ${820 + k * 220} H 340`} stroke="#3a1e0c" strokeWidth={14} />)}</g>
        <g transform={`translate(880 0) scale(${-(1 - o * 0.85)} 1)`}><path d="M 0 1700 V 820 Q 170 600 340 680 V 1700 Z" fill="#5a3218" stroke="#3a1e0c" strokeWidth={10} />{[1, 2, 3].map((k) => <path key={k} d={`M 0 ${820 + k * 220} H 340`} stroke="#3a1e0c" strokeWidth={14} />)}</g>
        <rect x={0} y={1700} width={W} height={220} fill="#6b4524" />
        <path d={`M 200 1700 L ${200 - 300 * o} 1920 H ${880 + 300 * o} L 880 1700 Z`} fill={`rgba(255,235,180,${0.45 * o})`} />
        {/* banner rising through the gate */}
        <g transform={`translate(0 ${interpolate(f, [30, 60], [700, 0], cl)})`}>
          <rect x={530} y={760} width={16} height={900} fill="#4a2c16" />
          <path d={`M 546 770 Q ${640 + Math.sin(f / 5) * 20} ${780 + Math.sin(f / 4) * 14} 760 ${770 + Math.sin(f / 5) * 18} V ${960 + Math.sin(f / 4) * 18} Q 640 ${970 + Math.sin(f / 5) * 14} 546 960 Z`} fill="#1c1c1c" />
        </g>
      </svg>
      <Particles n={80} color="#f6dcae" seed="gte" speed={2.5 * o + 0.3} size={[1.5, 4]} area={[1300, 1900]} />
    </AbsoluteFill>
  );
};

export const SCENES2: Record<string, React.FC<VisualProps>> = {
  grove: Grove, home: Home, homeshut: HomeShut, fire: Fire, road: Road, tally: Tally, dig: Dig, banner: Banner, fort: Fort, camp: Camp, heal: Heal, gate: Gate,
};
