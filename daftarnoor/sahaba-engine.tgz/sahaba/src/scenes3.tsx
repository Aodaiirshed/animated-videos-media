import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, random } from "remotion";
import { Particles } from "./ui";
import type { VisualProps } from "./scenes";

/* v3b scenes (24 Nov 2026, #13–14). No people drawn. A visual beat every 1–3 s. */
const FPS = 30;
const W = 1080, H = 1920;
const cl = { extrapolateLeft: "clamp" as const, extrapolateRight: "clamp" as const };
const wordAt = (words: { t: number; w: string }[], key: string, fb: number) => {
  const w = words.find((x) => x.w.replace(/[ً-ْ]/g, "").includes(key));
  return Math.round((w ? w.t : fb) * FPS);
};

/* ---------- Kaaba at golden dusk; lamps around the mataf light one by one ---------- */
const KaabaShape: React.FC<{ glow: number }> = ({ glow }) => (
  <g>
    <ellipse cx={540} cy={1420} rx={520} ry={120} fill="#e8dcc4" />
    <ellipse cx={540} cy={1420} rx={520} ry={120} fill={`rgba(255,220,150,${0.35 * glow})`} />
    <polygon points="300,1380 300,860 640,800 640,1330" fill="#141414" />
    <polygon points="640,800 820,850 820,1360 640,1330" fill="#262626" />
    <polygon points="300,860 640,800 820,850 480,905" fill="#2e2e2e" />
    <polygon points="300,960 640,905 640,960 300,1015" fill="#c9a24a" />
    <polygon points="640,905 820,950 820,1003 640,960" fill="#a8842f" />
    <rect x={420} y={1080} width={90} height={190} fill="#b8902e" opacity={0.9} transform="skewY(-9) translate(0 70)" />
  </g>
);
const Kaaba: React.FC<VisualProps> = ({ dur, scene }) => {
  const f = useCurrentFrame();
  const n = 9;
  const lit = (i: number) => interpolate(f, [4 + i * 7, 10 + i * 7], [0, 1], cl);
  const glow = interpolate(f, [0, Math.min(dur, 80)], [0.3, 1], cl);
  const sunY = interpolate(f, [0, dur], [760, 860]);
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#f0b26b 0%, #f7d59a 38%, #f3e2bd 60%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={880} cy={sunY} r={110} fill="#fff3c8" />
        <circle cx={880} cy={sunY} r={240} fill="#fff0c0" opacity={0.3} />
        <path d="M0 900 L120 760 L260 840 L380 700 L520 820 L640 690 L800 800 L940 720 L1080 820 V1100 H0 Z" fill="#c98a55" opacity={0.75} />
        <path d="M0 1000 L160 900 L330 970 L520 880 L700 960 L880 890 L1080 960 V1250 H0 Z" fill="#a8693c" opacity={0.85} />
        <rect x={0} y={1240} width={W} height={H - 1240} fill="#d9c9a8" />
        <KaabaShape glow={glow} />
        {Array.from({ length: n }).map((_, i) => {
          const a = Math.PI * (i / (n - 1));
          const x = 540 - Math.cos(a) * 470, y = 1500 + Math.sin(a) * 260;
          const l = lit(i), fl = 0.8 + 0.2 * Math.sin(f / 3 + i);
          return (
            <g key={i}>
              <rect x={x - 5} y={y - 150} width={10} height={150} fill="#5b4630" />
              <circle cx={x} cy={y - 160} r={70 * l * fl} fill="rgba(255,190,90,0.35)" />
              <circle cx={x} cy={y - 160} r={16} fill={l > 0.5 ? "#ffd27a" : "#7b6550"} />
            </g>
          );
        })}
        {scene.id !== "s1" && <rect width={W} height={H} fill="rgba(255,230,170,0.12)" />}
      </svg>
      <Particles n={50} color="#fff2cc" seed={"kb" + scene.id} rise speed={0.9} size={[1.5, 3.5]} area={[900, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Rope: a rope winds round a wooden post and pulls tight ---------- */
const Rope: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const coils = 5;
  const tight = interpolate(f, [dur * 0.55, dur * 0.7], [0, 1], cl);
  const jerk = f > dur * 0.55 && f < dur * 0.62 ? (random(`rp${f}`) - 0.5) * 10 : 0;
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#e7b980 0%, #f3d8a6 55%, #d8a86c 100%)", transform: `translate(${jerk}px,0)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <rect x={0} y={1350} width={W} height={570} fill="#b98450" />
        {Array.from({ length: 7 }).map((_, r) => <path key={r} d={`M0 ${200 + r * 160} H${W}`} stroke="#d1a06a" strokeWidth={5} opacity={0.5} />)}
        <rect x={470} y={300} width={140} height={1200} rx={16} fill="#6b4423" />
        <rect x={490} y={300} width={24} height={1200} fill="#7f5530" />
        {Array.from({ length: coils }).map((_, i) => {
          const st = 6 + i * ((dur * 0.5) / coils);
          const p = interpolate(f, [st, st + 10], [0, 1], cl);
          const y = 620 + i * 110 - tight * i * 14;
          const rx = 120 - 26 * tight;
          return p > 0 ? (
            <path key={i} d={`M ${540 - rx} ${y} Q 540 ${y + 46} ${540 - rx + 2 * rx * p} ${y + 4}`} stroke="#c9a46a" strokeWidth={30} fill="none" strokeLinecap="round" />
          ) : null;
        })}
        <path d={`M ${540 + 110} ${640} Q ${820} ${900 + Math.sin(f / 6) * 40 * (1 - tight)} ${900} ${1500}`} stroke="#c9a46a" strokeWidth={28} fill="none" strokeLinecap="round" />
        <circle cx={540 + 90} cy={1100 - tight * 60} r={34 * tight} fill="#b48c52" />
        {/* two small lamps at the foot of the post: they keep burning, brighter, as the rope pulls tight */}
        {[380, 700].map((x, i) => { const on = interpolate(f, [dur * 0.6, dur * 0.9], [0.35, 1], cl) * (0.85 + 0.15 * Math.sin(f / 2.6 + i * 2)); return (
          <g key={i}>
            <circle cx={x} cy={1410} r={170 * on} fill={`rgba(255,200,110,${0.35 * on})`} />
            <path d={`M ${x - 46} 1440 H ${x + 46} L ${x + 30} 1470 H ${x - 30} Z`} fill="#8a6420" />
            <path d={`M ${x} ${1440 - 70 * on} Q ${x + 20} 1420 ${x} 1440 Q ${x - 20} 1420 ${x} ${1440 - 70 * on}`} fill="#fff0b0" />
          </g>); })}
      </svg>
      <Particles n={30} color="#fff0d0" seed="rope" speed={0.5} size={[1, 3]} />
    </AbsoluteFill>
  );
};

/* ---------- Two lamps: «أيُّهما؟» — one dims, the other blazes at the key word ---------- */
const Lamps: React.FC<VisualProps> = ({ dur, words, scene }) => {
  const f = useCurrentFrame();
  const ask = scene.vo.includes("؟");
  const at = ask ? 99999 : wordAt(words, "أحب", dur * 0.35 / FPS);
  const pick = interpolate(f, [at, at + 10], [0, 1], cl);
  const sway = (k: number) => Math.sin(f / 10 + k) * 6;
  const lamp = (x: number, on: number, k: number) => {
    const fl = 0.85 + 0.15 * Math.sin(f / 2.5 + k * 2);
    return (
      <g transform={`rotate(${sway(k)} ${x} 0)`}>
        <path d={`M ${x} 0 V 820`} stroke="#6b5235" strokeWidth={6} />
        <circle cx={x} cy={940} r={260 * on * fl} fill={`rgba(255,196,100,${0.28 * on})`} />
        <path d={`M ${x - 90} 840 H ${x + 90} L ${x + 60} 1040 H ${x - 60} Z`} fill="#b8892f" />
        <path d={`M ${x - 60} 860 H ${x + 60} L ${x + 40} 1020 H ${x - 40} Z`} fill={`rgba(255,${180 + 60 * on},${90 + 80 * on},${0.25 + 0.75 * on})`} />
        <path d={`M ${x} ${980 - 70 * on * fl} Q ${x + 22} 960 ${x} 1000 Q ${x - 22} 960 ${x} ${980 - 70 * on * fl}`} fill="#fff1b0" opacity={on} />
        <path d={`M ${x - 100} 1040 H ${x + 100} V 1070 H ${x - 100} Z`} fill="#8a6420" />
      </g>
    );
  };
  const both = interpolate(f, [2, 14], [0.55, 0.7], cl);
  return (
    <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 50%, #7a5a3a 0%, #3a2a1c ${60 + 20 * pick}%)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <rect x={0} y={1350} width={W} height={570} fill="#2c2016" />
        <path d="M 160 1350 V 500 Q 540 150 920 500 V 1350" fill="none" stroke="#5a4430" strokeWidth={24} />
        {lamp(330, both * (1 - 0.85 * pick), 0)}
        {lamp(750, both + (1 - both) * pick, 1)}
      </svg>
      <Particles n={40} color="#ffe2a8" seed={"lmp" + scene.id} rise speed={0.5 + pick} size={[1, 3]} />
    </AbsoluteFill>
  );
};

/* ---------- Fork in the valley path: a dark wisp reaches the fork and veers away ---------- */
const Fork: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const draw = interpolate(f, [0, dur * 0.4], [0, 1], cl);
  const t = interpolate(f, [dur * 0.25, dur * 0.95], [0, 1], cl);
  // wisp travels down the right path toward the fork, then veers left onto the other path
  const wx = t < 0.5 ? interpolate(t, [0, 0.5], [760, 560]) : interpolate(t, [0.5, 1], [560, 160]);
  const wy = t < 0.5 ? interpolate(t, [0, 0.5], [700, 1150]) : interpolate(t, [0.5, 1], [1150, 760]);
  const glowP = interpolate(f, [dur * 0.1, dur * 0.4], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#9ec3dd 0%, #f4dfb4 50%, #e3b57a 70%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <path d="M0 860 L180 640 L360 760 L540 600 L720 740 L900 620 L1080 780 V1300 H0 Z" fill="#b8814e" />
        <path d="M0 1000 L240 860 L480 960 L720 860 L1080 980 V1920 H0 Z" fill="#c99560" />
        <path d={`M 540 1920 C 540 1600 560 1300 560 1150`} stroke="#f2dcb0" strokeWidth={90} fill="none" />
        <path d="M 560 1150 C 600 950 700 800 800 640" stroke="#f2dcb0" strokeWidth={60 * draw} fill="none" />
        <path d="M 560 1150 C 480 1000 300 860 120 760" stroke="#f2dcb0" strokeWidth={60 * draw} fill="none" />
        <circle cx={540} cy={1700 - 400 * glowP} r={140} fill="rgba(255,240,190,0.45)" />
        <circle cx={540} cy={1700 - 400 * glowP} r={50} fill="#fff6d8" />
        {Array.from({ length: 10 }).map((_, i) => (
          <circle key={i} cx={wx + Math.sin(f / 4 + i) * 30 + i * 8} cy={wy + Math.cos(f / 5 + i) * 20 - i * 6} r={34 - i * 2.5} fill="#2b2420" opacity={0.55 - i * 0.04} />
        ))}
      </svg>
      <Particles n={40} color="#fff2cc" seed="frk" speed={1.4} size={[1, 3]} area={[1000, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Nine swords: each snaps in turn and drops; tally counts up; the broad Yemeni blade stays ---------- */
const Swords: React.FC<VisualProps> = ({ dur, scene }) => {
  const f = useCurrentFrame();
  const n = 9;
  const hook = scene.id === "s1";
  const span = hook ? Math.max(40, Math.min(dur - 12, 70)) : -40;
  const iv = span / n;
  const hit = hook ? Math.floor(interpolate(f, [2, 2 + span], [0, n], cl)) : 0;
  const shake = hook && (f - 2) % iv < 3 && f < 2 + span ? (random(`sw${f}`) - 0.5) * 14 : 0;
  const yem = hook ? interpolate(f, [2 + span, 2 + span + 12], [0, 1], cl) : interpolate(f, [4, 22], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#f0b673 0%, #f6d8a2 45%, #c98d52 75%)", transform: `translate(${shake}px,${shake / 2}px)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={540} cy={1060} r={190} fill="#fff1c6" opacity={0.85} />
        <rect x={0} y={1380} width={W} height={540} fill="#b4793f" />
        {Array.from({ length: n }).map((_, i) => {
          const st = 2 + i * iv;
          const broke = f >= st;
          const fall = interpolate(f, [st, st + 16], [0, 1], cl);
          const x = 120 + (i % 5) * 210 + (i >= 5 ? 105 : 0);
          const y = i >= 5 ? 1600 : 1470;
          if (!broke) return <g key={i} opacity={0.0} />;
          return (
            <g key={i}>
              <g transform={`translate(${x} ${y - 260 + 260 * fall}) rotate(${-20 + 120 * fall + i * 7})`}>
                <rect x={-8} y={-160} width={16} height={150} fill="#c9ccd2" />
                <rect x={-26} y={-10} width={52} height={12} fill="#7a5a2e" />
                <rect x={-7} y={2} width={14} height={50} fill="#4a2c16" />
              </g>
              <g transform={`translate(${x + 40} ${y + 30 * fall}) rotate(${70 * fall + 30})`}><rect x={-8} y={-90} width={16} height={90} fill="#b9bcc2" /></g>
            </g>
          );
        })}
        {/* the sword in hand, upright and big, until it snaps */}
        {hook && hit < n && (() => { const ph = ((f - 2) % iv) / iv; const crack = ph > 0.7; return (
          <g transform={`translate(540 1330) rotate(${Math.sin(f / 2) * 3}) scale(1.7)`}>
            <circle cx={0} cy={-120} r={150} fill="rgba(255,245,210,0.35)" />
            <rect x={-10} y={-300} width={20} height={290} fill="#d6d9de" />
            <rect x={-2} y={-300} width={4} height={290} fill="#9ea2a9" />
            {crack && <path d="M -16 -170 L 6 -150 L -6 -135 L 16 -118" stroke="#fff" strokeWidth={6} fill="none" />}
            <rect x={-40} y={-10} width={80} height={16} fill="#8a6420" />
            <rect x={-9} y={6} width={18} height={70} fill="#4a2c16" />
          </g>); })()}
        {/* Yemeni broad blade, upright, last */}
        <g transform={`translate(540 ${(hook ? 1180 : 930) + (1 - yem) * 120})`} opacity={yem}>
          <circle cx={0} cy={-200} r={220 * yem} fill="rgba(255,245,210,0.35)" />
          <path d="M -40 0 L -40 -420 Q 0 -500 40 -420 L 40 0 Z" fill="#e3e6ea" />
          <path d="M -6 0 L -6 -430 L 6 -430 L 6 0 Z" fill="#a9adb4" />
          <rect x={-80} y={0} width={160} height={22} fill="#8a6420" />
          <rect x={-12} y={22} width={24} height={110} fill="#4a2c16" />
        </g>
      </svg>
      <div style={{ position: "absolute", top: 1440, width: W, textAlign: "center", fontFamily: "Reem Kufi", fontWeight: 700, fontSize: 150, color: "#fff7e0", textShadow: "0 6px 24px rgba(60,20,0,0.7)", direction: "rtl" }}>
        {scene.id === "s1" && hit > 0 ? `${hit} / ٩`.replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]) : ""}
      </div>
      <Particles n={60} color="#fbe7c0" seed="swd" speed={2.2} size={[1.5, 4]} area={[1250, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Three banners on a ridge; each falls in turn as its line is spoken ---------- */
const Banners3: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const xs = [330, 540, 750];
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#e9a865 0%, #f3cf98 50%, #b8773f 72%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <circle cx={540} cy={640} r={150} fill="#fff0c4" opacity={0.9} />
        <path d={`M0 1260 C 300 1200 700 1240 1080 1200 L1080 ${H} L0 ${H} Z`} fill="#9a6232" />
        {xs.map((x, i) => {
          const st = 8 + i * ((dur - 24) / 3);
          const fall = interpolate(f, [st + 12, st + 26], [0, 1], { ...cl, easing: (t) => t * t });
          const rise = spring({ frame: f - (st - 6), fps: FPS, config: { damping: 12 } });
          const w = Math.sin(f / 5 + i) * 14;
          return (
            <g key={i} transform={`rotate(${80 * fall} ${x} 1260)`} opacity={(1 - 0.5 * fall) * Math.min(1, rise + (i === 0 ? 1 : 0))}>
              <rect x={x - 7} y={760} width={14} height={500} fill="#4a2c16" />
              <path d={`M ${x + 7} 770 Q ${x + 90} ${780 + w} ${x + 170} ${770 + w} V ${900 + w} Q ${x + 90} ${910 + w} ${x + 7} 900 Z`} fill="#1c1c1c" />
            </g>
          );
        })}
      </svg>
      <Particles n={50} color="#f6dcae" seed="b3" speed={2.4} size={[1, 3.5]} area={[1150, 1900]} />
    </AbsoluteFill>
  );
};

/* ---------- Madinah at dusk: palm-trunk masjid, lamp, drops falling into sand ---------- */
const Drops: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const drops = [0.15, 0.35, 0.55, 0.75];
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#e7a56c 0%, #f1c995 45%, #d39a62 70%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <rect x={0} y={1200} width={W} height={720} fill="#c58b55" />
        {[160, 330, 500, 670, 840].map((x, i) => <rect key={i} x={x} y={560} width={60} height={640} fill="#6b4423" />)}
        <rect x={100} y={520} width={880} height={60} fill="#7f5530" />
        <circle cx={555} cy={760} r={120 + 10 * Math.sin(f / 3)} fill="rgba(255,200,110,0.35)" />
        <circle cx={555} cy={760} r={22} fill="#ffd27a" />
        {drops.map((d, i) => {
          const st = d * dur;
          const p = interpolate(f, [st, st + 14], [0, 1], cl);
          const r = interpolate(f, [st + 14, st + 44], [0, 1], cl);
          const x = 420 + i * 80;
          return (
            <g key={i}>
              {p > 0 && p < 1 && <path d={`M ${x} ${1300 + 400 * p} q 28 44 0 68 q -28 -24 0 -68`} fill="#e8f4ff" opacity={0.9} />}
              {r > 0 && <ellipse cx={x} cy={1740} rx={20 + 160 * r} ry={6 + 40 * r} stroke="#fff4dc" strokeWidth={5} fill="none" opacity={1 - r} />}
            </g>
          );
        })}
      </svg>
      <Particles n={40} color="#fff2cc" seed="drp" speed={0.6} size={[1, 3]} />
    </AbsoluteFill>
  );
};

export const SCENES3: Record<string, React.FC<VisualProps>> = {
  kaaba: Kaaba, rope: Rope, lamps: Lamps, fork: Fork, swords: Swords, banners3: Banners3, drops: Drops,
};
