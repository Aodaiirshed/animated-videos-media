import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, random } from "remotion";
import { Particles } from "./ui";
import type { VisualProps } from "./scenes";

/* v4 scenes (27 Nov 2026, #16 Ubayy). No people drawn. Symbolic: manuscript, night sky, light, lamps. A beat every 1–3 s. */
const FPS = 30;
const W = 1080, H = 1920;
const cl = { extrapolateLeft: "clamp" as const, extrapolateRight: "clamp" as const };
const wordAt = (words: { t: number; w: string }[], key: string, fb: number) => {
  const w = words.find((x) => x.w.replace(/[ً-ْ]/g, "").includes(key));
  return Math.round((w ? w.t : fb) * FPS);
};

/* open manuscript on a wooden stand (rahl); gold lines ink in; a beam of light widens */
const MushafBase: React.FC<VisualProps & { warm?: boolean }> = ({ dur, scene, warm }) => {
  const f = useCurrentFrame();
  const beam = interpolate(f, [0, dur * 0.6], [0.35, 1], cl);
  const lineN = 9;
  const pulse = 0.85 + 0.15 * Math.sin(f / 6);
  const page = (side: 1 | -1) => {
    const x0 = side === 1 ? 545 : 135;
    return (
      <g>
        <path d={side === 1 ? `M 540 1250 Q 760 1190 960 1240 L 940 1560 Q 750 1510 540 1580 Z` : `M 540 1250 Q 320 1190 120 1240 L 140 1560 Q 330 1510 540 1580 Z`} fill="#f3e3bf" stroke="#c9a96a" strokeWidth={4} />
        {Array.from({ length: lineN }).map((_, i) => {
          const st = 4 + i * (dur * 0.7) / (lineN * 2) + (side === 1 ? 0 : (dur * 0.35));
          const p = interpolate(f, [st, st + 12], [0, 1], cl);
          const y = 1275 + i * 30 + (side === 1 ? 0 : 0);
          const len = 360 * p;
          return side === 1
            ? <path key={i} d={`M 920 ${y} q ${-len / 6} ${-8} ${-len / 3} 0 t ${-len / 3} 0 t ${-len / 3} 0`} stroke="#8a5d15" strokeWidth={5 + (i % 3)} fill="none" strokeLinecap="round" opacity={0.85} />
            : <path key={i} d={`M ${x0 + 380} ${y + 4} q ${-len / 6} ${-8} ${-len / 3} 0 t ${-len / 3} 0 t ${-len / 3} 0`} stroke="#8a5d15" strokeWidth={5 + ((i + 1) % 3)} fill="none" strokeLinecap="round" opacity={0.85} />;
        })}
      </g>
    );
  };
  return (
    <AbsoluteFill style={{ background: warm ? "radial-gradient(circle at 50% 60%, #6b4a26 0%, #2a1b0e 55%, #0d0805 100%)" : "radial-gradient(circle at 50% 62%, #3b2a16 0%, #140d07 55%, #050403 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <defs>
          <linearGradient id={"bm" + scene.id} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff3c4" stopOpacity={0} />
            <stop offset="0.5" stopColor="#ffe6a0" stopOpacity={0.35 * beam} />
            <stop offset="1" stopColor="#ffd77a" stopOpacity={0.55 * beam} />
          </linearGradient>
        </defs>
        {/* arch window */}
        <path d="M 380 160 V 520 H 700 V 160 Q 540 20 380 160 Z" fill={`rgba(255,228,160,${0.18 + 0.2 * beam})`} />
        <path d={`M 380 300 L ${540 - 260 * beam} 1560 L ${540 + 260 * beam} 1560 L 700 300 Z`} fill={`url(#bm${scene.id})`} />
        {/* stand */}
        <path d="M 300 1600 L 540 1340 L 780 1600 Z" fill="#5a3a1c" />
        <path d="M 260 1640 L 820 1640 L 780 1600 L 300 1600 Z" fill="#432a13" />
        <rect x={0} y={1650} width={W} height={270} fill="#1a110a" />
        <ellipse cx={540} cy={1400} rx={460 * pulse} ry={160 * pulse} fill={`rgba(255,210,120,${0.12 * beam})`} />
        {page(1)}
        {page(-1)}
        <path d="M 540 1250 L 540 1580" stroke="#b08a4a" strokeWidth={6} />
      </svg>
      <Particles n={55} color="#ffe6a8" seed={"mu" + scene.id} rise speed={0.45} size={[1, 3.5]} area={[300, 1600]} />
    </AbsoluteFill>
  );
};
const Mushaf: React.FC<VisualProps> = (p) => <MushafBase {...p} />;
const Mushaf2: React.FC<VisualProps> = (p) => <MushafBase {...p} warm />;

/* Madinah at night: stars, crescent, palms, a plain mosque roofline with lanterns; a light streak crosses on a key word */
const NightBase: React.FC<VisualProps & { variant: number }> = ({ dur, words, scene, variant }) => {
  const f = useCurrentFrame();
  const key = wordAt(words, variant === 0 ? "أمرني" : "أعظم", dur * 0.5 / FPS);
  const streak = interpolate(f, [key - 4, key + 14], [0, 1], cl);
  const twinkle = (i: number) => 0.4 + 0.6 * Math.abs(Math.sin(f / 9 + i * 1.7));
  const k2 = variant === 0 ? wordAt(words, "يكن", dur * 0.8 / FPS) : 99999;
  const dome = interpolate(f, [k2 - 3, k2 + 12], [0, 1], cl);
  const lampOn = (i: number) => interpolate(f, [6 + i * 9, 14 + i * 9], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: variant === 0 ? "linear-gradient(#050b1d 0%, #0e1d3c 55%, #23324f 80%)" : "linear-gradient(#0a0618 0%, #1c1440 55%, #3a2a50 82%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {Array.from({ length: 90 }).map((_, i) => (
          <circle key={i} cx={random(`sx${variant}${i}`) * W} cy={random(`sy${variant}${i}`) * 1100} r={1 + random(`sr${i}`) * 2.5} fill="#fff6dc" opacity={twinkle(i)} />
        ))}
        {/* crescent */}
        <g transform={`translate(${variant === 0 ? 800 : 270},330)`}>
          <circle r={90} fill="#ffeab0" />
          <circle cx={36} cy={-18} r={84} fill={variant === 0 ? "#08112a" : "#120c2c"} />
        </g>
        {/* streak */}
        {streak > 0 && streak < 1 && (
          <path d={`M ${1100 - 1200 * streak} ${200 + 500 * streak} l 220 -90`} stroke="#fff3c0" strokeWidth={6} strokeLinecap="round" opacity={1 - streak} />
        )}
        <circle cx={540} cy={900} r={500 * streak} fill={`rgba(255,226,150,${0.12 * (1 - Math.abs(streak - 0.5) * 2)})`} />
        {/* skyline */}
        <path d="M 0 1420 L 0 1300 L 180 1300 L 180 1250 L 420 1250 L 420 1180 Q 540 1060 660 1180 L 660 1250 L 900 1250 L 900 1300 L 1080 1300 L 1080 1420 Z" fill="#0b0f1c" />
        <ellipse cx={540} cy={1150} rx={260 + 120 * dome} ry={170 + 80 * dome} fill={`rgba(255,220,140,${0.28 * dome})`} />
        <path d="M 420 1180 Q 540 1060 660 1180" stroke={`rgba(255,226,150,${0.9 * dome})`} strokeWidth={8} fill="none" />
        <rect x={860} y={1000} width={50} height={300} fill="#0b0f1c" />
        <path d="M 850 1000 L 885 940 L 920 1000 Z" fill="#0b0f1c" />
        {[230, 330, 750, 850].map((x, i) => (
          <g key={i}>
            <circle cx={x} cy={1275} r={40 * lampOn(i)} fill="rgba(255,200,110,0.35)" />
            <rect x={x - 9} y={1262} width={18} height={26} rx={4} fill={`rgba(255,${190 + 50 * lampOn(i)},120,${0.3 + 0.7 * lampOn(i)})`} />
          </g>
        ))}
        {/* palms */}
        {[[70, 1430, 1.1], [1000, 1440, 1.25]].map(([x, y, s], i) => (
          <g key={i} transform={`translate(${x},${y}) scale(${s})`}>
            <path d="M 0 0 Q 10 -160 0 -320" stroke="#070a14" strokeWidth={18} fill="none" />
            {[-70, -30, 10, 50, 90, 130].map((a, k) => (
              <path key={k} d="M 0 -320 q 70 -30 150 30" stroke="#070a14" strokeWidth={14} fill="none" transform={`rotate(${a + Math.sin(f / 18 + k) * 3} 0 -320)`} />
            ))}
          </g>
        ))}
        <rect x={0} y={1420} width={W} height={500} fill="#06080f" />
      </svg>
      <Particles n={30} color="#cfe0ff" seed={"nt" + scene.id} speed={0.3} size={[1, 2.5]} area={[0, 1200]} />
    </AbsoluteFill>
  );
};
const Night: React.FC<VisualProps> = (p) => <NightBase {...p} variant={0} />;
const Night2: React.FC<VisualProps> = (p) => <NightBase {...p} variant={1} />;

/* the question: concentric gold rings around a big "؟" that settles, ornament ring rotates */
const NameQ: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const at = wordAt(words, "سماني", dur * 0.6 / FPS);
  const q = spring({ frame: f - at, fps: FPS, config: { damping: 10 } });
  const rot = f * 0.6;
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 40%, #2c2412 0%, #0b0906 65%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {[0, 1, 2, 3].map((i) => {
          const r = ((f * 4 + i * 110) % 440) + 120;
          return <circle key={i} cx={540} cy={760} r={r} fill="none" stroke="#e7c47a" strokeWidth={3} opacity={(1 - (r - 120) / 440) * 0.6} />;
        })}
        <g transform={`rotate(${rot} 540 760)`}>
          {Array.from({ length: 16 }).map((_, i) => (
            <rect key={i} x={540 - 22} y={760 - 330} width={44} height={44} fill="none" stroke="#c9a24f" strokeWidth={4} transform={`rotate(${i * 22.5} 540 760) rotate(45 540 ${760 - 308})`} />
          ))}
        </g>
        <circle cx={540} cy={760} r={250} fill="rgba(255,214,120,0.08)" stroke="#e7c47a" strokeWidth={5} />
      </svg>
      <div style={{ position: "absolute", top: 520, width: "100%", textAlign: "center", fontFamily: "Amiri", fontWeight: 700, fontSize: 380, lineHeight: 1, color: "#f2c75c", opacity: interpolate(f, [0, 10], [0.25, 0.5], cl) + 0.5 * q, transform: `scale(${0.7 + 0.3 * q}) rotate(${(1 - q) * -12}deg)`, textShadow: "0 0 60px rgba(242,199,92,0.7)" }}>؟</div>
      <Particles n={40} color="#f2c75c" seed="nq" rise speed={0.6} size={[1, 3]} />
    </AbsoluteFill>
  );
};

/* a single tear falls onto the parchment; gold ripple and the ink lines glow */
const Tear: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const hit = wordAt(words, "يبكي", dur * 0.7 / FPS) + 4;
  const fall = interpolate(f, [hit - 22, hit], [0, 1], cl);
  const rip = interpolate(f, [hit, hit + 40], [0, 1], cl);
  const glow = interpolate(f, [hit, hit + 20], [0, 1], cl);
  const fall2 = interpolate(f, [hit + 18, hit + 36], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 70%, #f1dfb6 0%, #c9a46a 60%, #6e4f28 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {Array.from({ length: 12 }).map((_, i) => {
          const y = 1430 + i * 38;
          const st = i * 4;
          const p = interpolate(f, [st, st + 18], [0, 1], cl);
          return <path key={i} d={`M 940 ${y} L ${940 - 800 * p} ${y + 6}`} stroke={`rgb(${120 + 120 * glow},${80 + 110 * glow},${30 + 40 * glow})`} strokeWidth={9} strokeLinecap="round" opacity={0.8} />;
        })}
        {glow > 0 && <circle cx={540} cy={1480} r={120 + 380 * rip} fill={`rgba(255,215,120,${0.25 * (1 - rip)})`} />}
        {[0, 1, 2].map((k) => {
          const r = interpolate(f, [hit + k * 7, hit + k * 7 + 40], [0, 1], cl);
          return r > 0 && r < 1 ? <ellipse key={k} cx={540} cy={1480} rx={30 + 330 * r} ry={10 + 110 * r} stroke="#fff3cf" strokeWidth={6} fill="none" opacity={1 - r} /> : null;
        })}
        {fall < 1 && <path d={`M 540 ${300 + 1140 * fall * fall} q 34 56 0 86 q -34 -30 0 -86`} fill="#eaf6ff" stroke="#ffffff" strokeWidth={2} opacity={0.95} />}
        {fall2 > 0 && fall2 < 1 && <path d={`M 470 ${300 + 1040 * fall2 * fall2} q 24 40 0 62 q -24 -22 0 -62`} fill="#eaf6ff" opacity={0.85} />}
      </svg>
      <Particles n={35} color="#fff6dc" seed="tr" speed={0.4} size={[1, 3]} />
    </AbsoluteFill>
  );
};

/* the verse: deep sky, a slow radiant star-burst behind the calligraphy (text from HookLines) */
const Verse: React.FC<VisualProps> = ({ dur }) => {
  const f = useCurrentFrame();
  const k = interpolate(f, [0, dur], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 42%, #1f4d4a 0%, #0a2321 ${45 + 20 * k}%, #030c0b 100%)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        <g transform={`rotate(${f * 0.25} 540 820)`} opacity={0.35 + 0.25 * k}>
          {Array.from({ length: 24 }).map((_, i) => (
            <path key={i} d={`M 540 820 L ${540 + 1400 * Math.cos((i * Math.PI) / 12)} ${820 + 1400 * Math.sin((i * Math.PI) / 12)} L ${540 + 1400 * Math.cos((i * Math.PI) / 12 + 0.08)} ${820 + 1400 * Math.sin((i * Math.PI) / 12 + 0.08)} Z`} fill="#e7d3a3" opacity={0.12} />
          ))}
        </g>
        {Array.from({ length: 8 }).map((_, i) => (
          <g key={i} transform={`translate(${540 + 360 * Math.cos(i * Math.PI / 4 + f / 60)},${820 + 360 * Math.sin(i * Math.PI / 4 + f / 60)}) rotate(45)`}>
            <rect x={-10} y={-10} width={20} height={20} fill="#f2c75c" opacity={0.6} />
          </g>
        ))}
      </svg>
      <Particles n={70} color="#f2e2b0" seed="vs" rise speed={0.7} size={[1, 3.5]} />
    </AbsoluteFill>
  );
};

/* the strike on the chest: abstract — a shock of light rings from the centre on "ضرب", then a lasting warm core */
const Chest: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const at = wordAt(words, "ضرب", 0.1) + 3;
  const hit = interpolate(f, [at, at + 6], [0, 1], cl);
  const shake = f >= at && f < at + 8 ? (random(`ch${f}`) - 0.5) * 18 : 0;
  const ilm = wordAt(words, "العلم", dur * 0.75 / FPS);
  const bloom = interpolate(f, [ilm, ilm + 20], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: "radial-gradient(circle at 50% 45%, #3a2410 0%, #120a04 60%, #050302 100%)", transform: `translate(${shake}px, ${shake * 0.6}px)` }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {[0, 1, 2, 3, 4].map((k) => {
          const r = interpolate(f, [at + k * 4, at + k * 4 + 36], [0, 1], cl);
          return r > 0 && r < 1 ? <circle key={k} cx={540} cy={820} r={60 + 760 * r} fill="none" stroke="#ffd98a" strokeWidth={14 * (1 - r)} opacity={1 - r} /> : null;
        })}
        <circle cx={540} cy={820} r={70 + 110 * hit + 160 * bloom + 8 * Math.sin(f / 4)} fill={`rgba(255,214,130,${0.25 + 0.35 * hit})`} />
        <circle cx={540} cy={820} r={40 + 30 * hit} fill="#fff1c2" opacity={0.4 + 0.6 * hit} />
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * Math.PI) / 6;
          const L = 180 + 420 * bloom;
          return <path key={i} d={`M ${540 + 120 * Math.cos(a)} ${820 + 120 * Math.sin(a)} L ${540 + L * Math.cos(a)} ${820 + L * Math.sin(a)}`} stroke="#f2c75c" strokeWidth={6} strokeLinecap="round" opacity={0.7 * bloom} />;
        })}
      </svg>
      <Particles n={50} color="#ffe2a0" seed="chs" rise speed={0.5 + bloom} size={[1, 3.5]} />
    </AbsoluteFill>
  );
};

/* four lamps under four arches light one by one; the lit lamps cast light on an open book below */
const Four: React.FC<VisualProps> = ({ dur, words }) => {
  const f = useCurrentFrame();
  const st = wordAt(words, "أربع", 0.8);
  const on = (i: number) => interpolate(f, [st + i * 10, st + i * 10 + 8], [0, 1], cl);
  const hi = wordAt(words, "القرآن", dur * 0.8 / FPS);
  const book = interpolate(f, [hi, hi + 15], [0, 1], cl);
  const xs = [180, 420, 660, 900];
  return (
    <AbsoluteFill style={{ background: "linear-gradient(#20160d 0%, #3b2a18 60%, #1c130b 100%)" }}>
      <svg width={W} height={H} style={{ position: "absolute" }}>
        {xs.map((x, i) => (
          <g key={i}>
            <path d={`M ${x - 110} 1420 V 620 Q ${x} 470 ${x + 110} 620 V 1420`} fill="#2a1d11" stroke="#6b5235" strokeWidth={10} />
            <path d={`M ${x} 470 V 700`} stroke="#6b5235" strokeWidth={4} />
            <circle cx={x} cy={760} r={150 * on(i) * (0.9 + 0.1 * Math.sin(f / 3 + i))} fill={`rgba(255,200,110,${0.32 * on(i)})`} />
            <path d={`M ${x - 40} 700 H ${x + 40} L ${x + 28} 800 H ${x - 28} Z`} fill="#b8892f" />
            <path d={`M ${x - 26} 712 H ${x + 26} L ${x + 18} 790 H ${x - 18} Z`} fill={`rgba(255,${170 + 70 * on(i)},${90 + 90 * on(i)},${0.2 + 0.8 * on(i)})`} />
            <path d={`M ${x} 1420 L ${x - 160 * on(i)} 1700 L ${x + 160 * on(i)} 1700 Z`} fill={`rgba(255,215,140,${0.10 * on(i)})`} />
          </g>
        ))}
        <rect x={0} y={1420} width={W} height={500} fill="#150e07" />
        <g opacity={0.4 + 0.6 * book} transform={`translate(540 1560) scale(${0.9 + 0.1 * book})`}>
          <path d="M 0 -60 Q -150 -90 -280 -60 L -270 60 Q -140 30 0 70 Z" fill="#f3e3bf" />
          <path d="M 0 -60 Q 150 -90 280 -60 L 270 60 Q 140 30 0 70 Z" fill="#f3e3bf" />
          <ellipse cx={0} cy={0} rx={340} ry={120} fill={`rgba(255,215,130,${0.2 * book})`} />
        </g>
      </svg>
      <Particles n={40} color="#ffe2a8" seed="fr" rise speed={0.5} size={[1, 3]} />
    </AbsoluteFill>
  );
};

export const SCENES4: Record<string, React.FC<VisualProps>> = {
  mushaf: Mushaf, mushaf2: Mushaf2, night: Night, night2: Night2, name: NameQ, tear: Tear, verse: Verse, chest: Chest, four: Four,
};
