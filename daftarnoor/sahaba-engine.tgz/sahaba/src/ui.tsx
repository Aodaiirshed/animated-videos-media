import React from "react";
import { AbsoluteFill, interpolate, random, staticFile, useCurrentFrame } from "remotion";

export const FontFaces: React.FC = () => (
  <style>{`
@font-face{font-family:Tajawal;src:url(${staticFile("fonts/tajawal-arabic-800-normal.woff2")}) format('woff2');font-weight:800}
@font-face{font-family:Tajawal;src:url(${staticFile("fonts/tajawal-arabic-700-normal.woff2")}) format('woff2');font-weight:700}
@font-face{font-family:Amiri;src:url(${staticFile("fonts/amiri-arabic-700-normal.woff2")}) format('woff2');font-weight:700}
@font-face{font-family:'Reem Kufi';src:url(${staticFile("fonts/reem-kufi-arabic-700-normal.woff2")}) format('woff2');font-weight:700}
`}</style>
);

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.75) 100%)", pointerEvents: "none" }} />
);

export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ opacity: 0.07, mixBlendMode: "overlay" }}>
      <svg width="1080" height="1920">
        <filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={f % 30} /></filter>
        <rect width="1080" height="1920" filter="url(#g)" />
      </svg>
    </AbsoluteFill>
  );
};

/** slow camera push + optional shake */
export const Camera: React.FC<{ dur: number; from?: number; to?: number; shake?: number; children: React.ReactNode }> = ({ dur, from = 1, to = 1.12, shake = 0, children }) => {
  const f = useCurrentFrame();
  const s = interpolate(f, [0, dur], [from, to]);
  const sx = shake ? (random(`x${f}`) - 0.5) * shake : 0;
  const sy = shake ? (random(`y${f}`) - 0.5) * shake : 0;
  return <AbsoluteFill style={{ transform: `translate(${sx}px,${sy}px) scale(${s})` }}>{children}</AbsoluteFill>;
};

/** drifting particles (dust / stars / light) */
export const Particles: React.FC<{ n: number; color: string; seed: string; speed?: number; size?: [number, number]; rise?: boolean; area?: [number, number] }> = ({ n, color, seed, speed = 1, size = [2, 6], rise = false, area = [0, 1920] }) => {
  const f = useCurrentFrame();
  return (
    <svg width="1080" height="1920" style={{ position: "absolute" }}>
      {Array.from({ length: n }).map((_, i) => {
        const x0 = random(`${seed}x${i}`) * 1080;
        const y0 = area[0] + random(`${seed}y${i}`) * (area[1] - area[0]);
        const r = size[0] + random(`${seed}r${i}`) * (size[1] - size[0]);
        const v = (0.4 + random(`${seed}v${i}`)) * speed;
        const x = (x0 + f * v * 1.6) % 1080;
        const y = rise ? ((y0 - f * v * 2.2) % 1920 + 1920) % 1920 : y0 + Math.sin(f / 20 + i) * 6;
        const o = 0.3 + 0.7 * Math.abs(Math.sin(f / 25 + i));
        return <circle key={i} cx={x} cy={y} r={r} fill={color} opacity={o} />;
      })}
    </svg>
  );
};
