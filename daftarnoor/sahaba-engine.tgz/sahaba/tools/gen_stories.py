#!/usr/bin/env python3
"""Regenerate src/stories.ts from every storyboards/<slug>.json that has src/gen/<slug>.json (run after tts.py)."""
from pathlib import Path
R = Path(__file__).resolve().parent.parent
slugs = sorted(p.stem for p in (R / "storyboards").glob("*.json") if (R / "src/gen" / f"{p.stem}.json").exists())
lines = ['import { StoryProps } from "./Story";']
for i, s in enumerate(slugs):
    lines += [f'import sb{i} from "../storyboards/{s}.json";', f'import gen{i} from "./gen/{s}.json";']
lines.append("export const STORIES: StoryProps[] = [" + ", ".join(f"{{ sb: sb{i} as any, gen: gen{i} as any }}" for i in range(len(slugs))) + "];")
(R / "src/stories.ts").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("stories:", ", ".join(slugs))
