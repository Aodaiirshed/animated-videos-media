#!/usr/bin/env bash
# Push an MP4 to the public repo and print its commit-SHA raw URL (checked 200). Usage: tools/host.sh out/sahaba-NN-slug.mp4
set -euo pipefail
f=$(readlink -f "$1"); name=$(basename "$f")
repo=${MEDIA_REPO:-/home/claude/animated-videos-media}
if [ ! -d "$repo/.git" ]; then
  git clone --filter=blob:none --sparse https://github.com/Aodaiirshed/animated-videos-media "$repo" >/dev/null 2>&1
  git -C "$repo" sparse-checkout set daftarnoor >/dev/null
fi
cd "$repo"; git pull --rebase -q origin main
mkdir -p daftarnoor; cp "$f" "daftarnoor/$name"
git add "daftarnoor/$name"; git commit -qm "daftarnoor: $name"; git push -q origin HEAD:main
sha=$(git rev-parse HEAD)
url="https://raw.githubusercontent.com/Aodaiirshed/animated-videos-media/$sha/daftarnoor/$name"
code=$(curl -s -o /dev/null -w "%{http_code}" -I "$url"); echo "$code $url"
