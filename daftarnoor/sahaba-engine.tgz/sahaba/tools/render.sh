#!/usr/bin/env bash
# Render + loudnorm -14 LUFS + check. Usage: tools/render.sh <slug> <NN>  -> out/sahaba-NN-<slug>.mp4
set -euo pipefail
cd "$(dirname "$0")/.."
slug=$1; nn=$2
npx remotion render src/index.ts "$slug" "out/$slug-raw.mp4" --concurrency=2 --log=error
ffmpeg -y -loglevel error -i "out/$slug-raw.mp4" -c:v copy -af "loudnorm=I=-14:TP=-1.5:LRA=11" -c:a aac -b:a 192k "out/sahaba-$nn-$slug.mp4"
ffprobe -v error -show_entries stream=codec_type,width,height:format=duration -of compact "out/sahaba-$nn-$slug.mp4"
d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "out/sahaba-$nn-$slug.mp4")
awk -v d="$d" 'BEGIN{ if (d>=59.5) {print "FAIL: over 60 s ("d")"; exit 1} else print "OK duration "d" s" }'
