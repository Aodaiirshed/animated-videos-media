#!/usr/bin/env bash
# QC sheet: one still at the middle of every scene (+frame 0) -> out/<slug>-scenes.jpg
set -euo pipefail
cd "$(dirname "$0")/.."
slug=$1
frames=$(node -e '
const sb=require("./storyboards/'$slug'.json"), g=require("./src/gen/'$slug'.json");
let at=0,out=[0]; sb.scenes.forEach((s,i)=>{const d=Math.round((g[i].dur+(sb.pad??0.25)+(s.hold??0))*30); out.push(at+Math.round(d*0.6)); at+=d;}); console.log(out.join(" "))')
mkdir -p out/sc-$slug; rm -f out/sc-$slug/*.jpg; i=0
for f in $frames; do npx remotion still src/index.ts "$slug" "out/sc-$slug/$(printf %02d $i).jpg" --frame=$f --scale=0.25 >/dev/null 2>&1; i=$((i+1)); done
n=$(ls out/sc-$slug | wc -l); cols=5
ffmpeg -y -loglevel error -pattern_type glob -i "out/sc-$slug/*.jpg" -vf "tile=${cols}x$(( (n+cols-1)/cols )):padding=4" -frames:v 1 "out/$slug-scenes.jpg"; echo "$n tiles -> out/$slug-scenes.jpg"
