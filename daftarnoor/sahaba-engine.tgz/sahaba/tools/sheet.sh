#!/usr/bin/env bash
# One contact sheet (3x3) of 9 stills spread over the reel -> out/<slug>-sheet.jpg. Stills render ONE AT A TIME (parallel crashes).
set -euo pipefail
cd "$(dirname "$0")/.."
slug=$1
total=$(npx remotion compositions src/index.ts 2>/dev/null | awk -v s="$slug" '$1==s{print $4}')
[ -z "$total" ] && { echo "composition $slug not found (run tools/gen_stories.py)"; exit 1; }
mkdir -p out/st-$slug; rm -f out/st-$slug/*.jpg
i=0
for f in 3 $((total*1/8)) $((total*2/8)) $((total*3/8)) $((total*4/8)) $((total*5/8)) $((total*6/8)) $((total*7/8)) $((total-20)); do
  npx remotion still src/index.ts "$slug" "out/st-$slug/$(printf %02d $i).jpg" --frame=$f --scale=0.33 >/dev/null 2>&1; i=$((i+1))
done
ffmpeg -y -loglevel error -pattern_type glob -i "out/st-$slug/*.jpg" -vf "tile=3x3:padding=6" -frames:v 1 "out/$slug-sheet.jpg"
echo "frames: $total ($(echo "scale=1;$total/30"|bc) s) -> out/$slug-sheet.jpg"
