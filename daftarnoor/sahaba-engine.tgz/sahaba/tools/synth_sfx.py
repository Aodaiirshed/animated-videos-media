#!/usr/bin/env python3
"""Synthesize v3 sound effects into public/sfx (no music)."""
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter
SR = 44100
rng = np.random.default_rng(7)
def bp(x, lo, hi):
    b, a = butter(2, [lo / (SR / 2), hi / (SR / 2)], btype="band"); return lfilter(b, a, x)
def lp(x, hi):
    b, a = butter(2, hi / (SR / 2)); return lfilter(b, a, x)
def env(n, att, dec):
    n = int(n)
    t = np.arange(n) / SR; return np.minimum(1, t / max(att, 1e-4)) * np.exp(-t / dec)
def save(name, x):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.9
    wavfile.write(f"public/sfx/{name}.wav", SR, (x * 32767).astype(np.int16))
def noise(sec): return rng.standard_normal(int(SR * sec))
# leaves rustle: band noise with slow random amplitude
n = noise(1.6); am = np.abs(lp(rng.standard_normal(len(n)), 6)) ; am /= am.max()
save("rustle", bp(n, 2500, 8000) * am * np.hanning(len(n)))
# door shut: low thump + wood knock
t = np.arange(int(SR * 0.9)) / SR
th = np.sin(2 * np.pi * 70 * t) * env(len(t), 0.002, 0.12) + 0.6 * bp(noise(0.9), 150, 900) * env(len(t), 0.001, 0.05)
bolt = np.zeros(len(t)); k = int(SR * 0.62); m = bp(noise(0.12), 1500, 5000) * env(int(SR * 0.12), 0.001, 0.03); bolt[k:k + len(m)] = 0.5 * m
save("door", th + bolt)
# fire crackle: rumble + random pops
d = 2.5; base = lp(noise(d), 300) * 0.5
for _ in range(45):
    p = rng.integers(0, int(SR * d) - 2000); L = rng.integers(200, 1200)
    base[p:p + L] += bp(rng.standard_normal(L), 2000, 7000) * env(L, 0.0005, 0.004) * rng.uniform(0.6, 2.5)
save("crackle", base * np.hanning(len(base)) ** 0.3)
# chain clinks: metallic partials
d = 1.6; x = np.zeros(int(SR * d))
for i, at in enumerate([0.0, 0.18, 0.42, 0.7, 1.05]):
    L = int(SR * 0.5); tt = np.arange(L) / SR
    c = sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(2100 + 90 * i, 1), (3420, 0.6), (5230, 0.4), (7700, 0.2)]) * env(L, 0.0005, 0.07)
    k = int(SR * at); x[k:k + L] += c[: len(x) - k] * (1 - 0.12 * i)
save("chain", x)
# coin drop: bright pings
d = 1.4; x = np.zeros(int(SR * d))
for i, at in enumerate([0.0, 0.12, 0.2, 0.33, 0.5, 0.62]):
    L = int(SR * 0.6); tt = np.arange(L) / SR
    c = sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(4200 + 150 * i, 1), (6100, 0.5), (8900, 0.3)]) * env(L, 0.0003, 0.12)
    k = int(SR * at); x[k:k + L] += c[: len(x) - k]
save("coin", x)
# digging: three spade thuds in soil
d = 2.0; x = np.zeros(int(SR * d))
for at in [0.0, 0.6, 1.2]:
    L = int(SR * 0.35); s = lp(rng.standard_normal(L), 600) * env(L, 0.002, 0.06) + 0.4 * bp(rng.standard_normal(L), 800, 3000) * env(L, 0.01, 0.12)
    k = int(SR * at); x[k:k + L] += s
save("dig", x)
# flag flapping: noise with fast flutter AM
d = 1.8; n = bp(noise(d), 200, 2500); tt = np.arange(len(n)) / SR
am = 0.4 + 0.6 * np.abs(np.sin(2 * np.pi * (5 + 2 * np.sin(2 * np.pi * 0.7 * tt)) * tt)) ** 3
save("flag", n * am * np.hanning(len(n)) ** 0.4)
# gate: low creak (frequency-swept saw) + rumble
d = 1.8; tt = np.arange(int(SR * d)) / SR
fr = 90 + 40 * np.sin(2 * np.pi * 0.6 * tt); ph = 2 * np.pi * np.cumsum(fr) / SR
saw = (ph / (2 * np.pi)) % 1 * 2 - 1
x = bp(saw, 150, 1800) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 7 * tt))) * env(len(tt), 0.05, 0.9) + 0.6 * lp(noise(d), 120) * env(len(tt), 0.1, 0.8)
save("gate", x)
print("sfx ok")
# v3b (24 Nov): sword clang (metal partials) + water drip
t = np.arange(int(SR * 1.2)) / SR
cl_ = sum(a * np.sin(2 * np.pi * fr * t) * np.exp(-t / dc) for a, fr, dc in [(1, 1730, 0.35), (0.7, 2460, 0.25), (0.5, 3310, 0.18), (0.4, 920, 0.4)])
cl_ = cl_ * env(len(t), 0.001, 0.6) + 0.5 * bp(noise(1.2), 2000, 7000) * env(len(t), 0.001, 0.02)
save("clang", cl_)
t = np.arange(int(SR * 0.5)) / SR
fr = 900 + 1400 * np.exp(-t / 0.03)
save("drip", np.sin(2 * np.pi * np.cumsum(fr) / SR) * env(len(t), 0.001, 0.07))
