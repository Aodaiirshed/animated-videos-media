#!/usr/bin/env python3
"""Arabic voiceover per scene with edge-tts + word timings -> public/vo/<slug>/*.mp3, src/gen/<slug>.json"""
import asyncio, json, subprocess, sys
from pathlib import Path

import edge_tts

ROOT = Path(__file__).parent
sb = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
slug = sb["slug"]
out = ROOT / "public" / "vo" / slug
out.mkdir(parents=True, exist_ok=True)
(ROOT / "src" / "gen").mkdir(parents=True, exist_ok=True)


async def one(scene):
    comm = edge_tts.Communicate(scene["vo"], sb["voice"]["name"], rate=sb["voice"].get("rate", "+0%"), boundary="WordBoundary")
    words, audio = [], bytearray()
    async for ch in comm.stream():
        if ch["type"] == "audio":
            audio.extend(ch["data"])
        elif ch["type"] == "WordBoundary":
            words.append({"t": ch["offset"] / 1e7, "d": ch["duration"] / 1e7, "w": ch["text"]})
    f = out / f"{scene['id']}.mp3"
    f.write_bytes(audio)
    dur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(f)]).decode())
    if sb.get("trimTail") and words:
        dur = min(dur, words[-1]["t"] + words[-1]["d"] + 0.15)
    return {"id": scene["id"], "file": f"vo/{slug}/{scene['id']}.mp3", "dur": dur, "words": words}


async def main():
    res = [await one(s) for s in sb["scenes"]]
    (ROOT / "src" / "gen" / f"{slug}.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print(sum(r["dur"] for r in res), "s total")
    for r in res:
        print(r["id"], round(r["dur"], 2), len(r["words"]))

asyncio.run(main())
