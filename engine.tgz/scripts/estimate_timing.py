"""Preview timing without a voiceover: estimates scene durations + word captions from the text.
Use it to lay out and preview a storyboard (Studio / stills) before recording or generating VO.
Usage: python3 scripts/estimate_timing.py storyboards/<slug>.json [words_per_sec]
English ~2.6 w/s, Arabic ~2.1 w/s. Replace with the real TTS timing before the final render.
"""
import json, sys, re, os
sb = json.load(open(sys.argv[1]))
wps = float(sys.argv[2]) if len(sys.argv) > 2 else (2.1 if sb.get("language") == "ar" else 2.6)
scenes = []
for sc in sb["scenes"]:
    words = sc["vo"].split()
    pauses = sum(1 for w in words if re.search(r"[.?!؟،,]$", w)) * 0.25
    speech = len(words) / wps + pauses
    t, caps = 0.15, []
    weights = [len(re.sub(r"[^\w']", "", w)) + 2 for w in words]
    for w, wt in zip(words, weights):
        d = speech * wt / sum(weights)
        caps.append({"text": w, "startMs": round(t * 1000), "endMs": round((t + d) * 1000), "timestampMs": None, "confidence": None})
        t += d
    scenes.append({"id": sc["id"], "durationSec": round(0.15 + speech + 0.3, 3), "captions": caps})
os.makedirs("src/generated", exist_ok=True)
out = {"slug": sb["slug"], "totalSec": round(sum(s["durationSec"] for s in scenes), 2), "noAudio": True, "scenes": scenes}
json.dump(out, open(f"src/generated/{sb['slug']}.timing.json", "w"), indent=1, ensure_ascii=False)
print("estimated total", out["totalSec"], "s")