#!/bin/bash
# Restores a working render environment in ~1-3 min. Run from the project folder.
set -e
npm i --no-audit --no-fund --loglevel=error
pip install --break-system-packages -q kokoro-onnx soundfile numpy >/dev/null 2>&1 || true
mkdir -p models public/sfx public/vo
[ -f models/kokoro-v1.0.onnx ] || curl -sSL -o models/kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
[ -f models/voices-v1.0.bin ] || curl -sSL -o models/voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
mkdir -p public/fonts
for f in anton/files/anton-latin-400-normal anton/files/anton-latin-ext-400-normal inter/files/inter-latin-800-normal inter/files/inter-latin-ext-800-normal cairo/files/cairo-arabic-800-normal; do cp node_modules/@fontsource/$f.woff2 public/fonts/; done
python3 scripts/make_sfx.py >/dev/null
python3 scripts/make_music.py >/dev/null
mkdir -p src/generated
for s in storyboards/kamikaze-word.json storyboards/kane-guess.json; do b=$(basename $s .json); [ -f src/generated/$b.timing.json ] || python3 scripts/tts_kokoro.py $s >/dev/null; done
export REMOTION_CHROME=${REMOTION_CHROME:-$(command -v google-chrome || command -v chromium || true)}
npx tsc -p . && echo "ENGINE READY (chrome: $REMOTION_CHROME)"