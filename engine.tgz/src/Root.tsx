import React from 'react';
import {Composition} from 'remotion';
import {Story, sceneFrames} from './Story';
import type {Storyboard, Timing} from './types';

// Register each story: storyboard JSON + timing JSON from scripts/tts_kokoro.py. Newest first.
import kamikazeSb from '../storyboards/kamikaze-word.json';
import kamikazeTiming from './generated/kamikaze-word.timing.json';
import kaneSb from '../storyboards/kane-guess.json';
import kaneTiming from './generated/kane-guess.timing.json';

const STORIES: {id: string; sb: Storyboard; timing: Timing}[] = [
  {id: 'kamikaze-word', sb: kamikazeSb as unknown as Storyboard, timing: kamikazeTiming as Timing},
  {id: 'kane-guess', sb: kaneSb as unknown as Storyboard, timing: kaneTiming as Timing},
];

const FPS = 30;

export const RemotionRoot: React.FC = () => (
  <>
    {STORIES.map(({id, sb, timing}) => (
      <Composition
        key={id}
        id={id}
        component={Story}
        fps={FPS}
        width={1080}
        height={1920}
        durationInFrames={sceneFrames(timing, sb, FPS).reduce((a, b) => a + b, 0)}
        defaultProps={{sb, timing}}
      />
    ))}
  </>
);