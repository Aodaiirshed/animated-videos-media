import {continueRender, delayRender, staticFile} from 'remotion';

// Local fonts (from @fontsource, OFL licence) so renders work offline.
const faces: [string, string, string, string][] = [
  ['Anton', 'fonts/anton-latin-400-normal.woff2', '400', 'U+0000-00FF,U+2000-206F,U+20AC'],
  ['Anton', 'fonts/anton-latin-ext-400-normal.woff2', '400', 'U+0100-024F,U+1E00-1EFF'],
  ['Inter', 'fonts/inter-latin-800-normal.woff2', '800', 'U+0000-00FF,U+2000-206F'],
  ['Inter', 'fonts/inter-latin-ext-800-normal.woff2', '800', 'U+0100-024F'],
  ['Cairo', 'fonts/cairo-arabic-800-normal.woff2', '800', 'U+0600-06FF,U+0750-077F,U+FB50-FDFF,U+FE70-FEFF'],
];

let loaded = false;
export const loadFonts = () => {
  if (loaded || typeof document === 'undefined') return;
  loaded = true;
  const handle = delayRender('fonts');
  Promise.all(
    faces.map(([family, file, weight, unicodeRange]) => {
      const f = new FontFace(family, `url(${staticFile(file)})`, {weight, unicodeRange});
      return f.load().then((ff) => document.fonts.add(ff));
    }),
  ).then(() => continueRender(handle), () => continueRender(handle));
};

export const DISPLAY = 'Anton, Cairo, sans-serif';
export const BODY = 'Inter, Cairo, sans-serif';