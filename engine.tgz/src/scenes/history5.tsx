import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* History scenes, set 5 (kamikaze explainer; respectful, non-graphic): stormWord, fleetSail, typhoonWreck, windAnswer, lastFlight, lettersDesk, calmSea. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* A medieval junk ship, facing right. */
const Junk: React.FC<{x: number; y: number; s?: number; tilt?: number; broken?: boolean}> = ({x, y, s = 1, tilt = 0, broken}) => (
  <svg width={220 * s} height={220 * s} viewBox="0 0 220 220" style={{position: 'absolute', left: x - 110 * s, top: y - 190 * s, rotate: `${tilt}deg`, overflow: 'visible'}}>
    {broken ? <path d="M110 150 L150 40" stroke={OL} strokeWidth={9} /> : <path d="M110 150 V20" stroke={OL} strokeWidth={9} />}
    {broken ? <path d="M150 40 L190 70 L140 110 Z" fill="#b45309" stroke={OL} strokeWidth={7} strokeLinejoin="round" /> : <path d="M114 26 Q170 40 166 90 Q170 120 114 130 Z" fill="#b45309" stroke={OL} strokeWidth={7} strokeLinejoin="round" />}
    {!broken ? [50, 70, 90, 110].map((yy) => <path key={yy} d={`M114 ${yy} Q150 ${yy - 4} 166 ${yy}`} stroke="#78350f" strokeWidth={4} fill="none" />) : null}
    <path d="M10 140 H210 L180 190 H40 Z" fill="#7c2d12" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
    <path d="M10 140 L0 118 L40 140 M210 140 L220 116 L184 140" fill="#7c2d12" stroke={OL} strokeWidth={7} />
  </svg>
);

const Waves: React.FC<{top: number; color?: string; amp?: number; speed?: number}> = ({top, color = '#1e3a8a', amp = 26, speed = 3}) => {
  const frame = useCurrentFrame();
  const pts = new Array(14).fill(0).map((_, i) => `Q${i * 90 + 45} ${top - amp + Math.sin(frame / 6 + i) * amp * 0.6} ${i * 90 + 90} ${top}`).join(' ');
  return <svg width={1080} height={1920} style={{position: 'absolute', left: -((frame * speed) % 90), top: 0}}><path d={`M0 ${top} ${pts} V1920 H0 Z`} fill={color} stroke={OL} strokeWidth={8} /></svg>;
};

/* stormWord: { word, tag?, tagOnWord? } — a night storm at sea; lightning flickers; the word slams in, already settled on frame 0. */
const StormWord: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.5);
  const flash = (frame + 10) % 37 < 3 ? 0.55 : 0;
  return (
    <Shake at={tAt} amount={18}>
      <Camera dur={dur} from={1.14} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0f172a, #334155)'}} />
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 330 - frame * 4) % 1500 + 1500) % 1500 - 300, top: 240 + i * 60, width: 480, height: 130, borderRadius: 80, background: '#475569', opacity: 0.85}} />)}
        <svg width={260} height={520} viewBox="0 0 260 520" style={{position: 'absolute', left: 700, top: 300, opacity: flash ? 1 : 0}}><path d="M150 0 L70 230 H140 L60 520 L220 190 H140 L200 0 Z" fill="#fde047" stroke="#fff" strokeWidth={6} /></svg>
        {new Array(50).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: ((random(`rx${i}`) * 1300 - frame * 9) % 1300 + 1300) % 1300 - 100, top: ((random(`ry${i}`) * 1900 + frame * 40) % 1900), width: 5, height: 60, background: '#cbd5e1', opacity: 0.4, rotate: '18deg'}} />)}
        <Waves top={1150} color="#1e3a8a" amp={40} speed={6} />
        <Waves top={1300} color="#172554" amp={30} speed={9} />
        <AbsoluteFill style={{background: '#fff', opacity: flash * 0.5}} />
        <div style={{position: 'absolute', top: 640, width: '100%', textAlign: 'center'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 190, color: '#fff', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', letterSpacing: 4}}>{(scene.word as string) ?? ''}</span>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={900} size={84} color="#fde047" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* fleetSail: { year, tag, tagOnWord?, tag2?, tag2OnWord? } — a sea crowded with junk ships sailing toward a small island. */
const FleetSail: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.35), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.7);
  const drift = frame * 1.6;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fdba74, #fde68a 50%)'}} />
      <svg width={500} height={300} viewBox="0 0 500 300" style={{position: 'absolute', left: 700, top: 760}}><path d="M40 300 Q80 120 200 110 Q300 40 420 120 Q480 160 500 300 Z" fill="#65a30d" stroke={OL} strokeWidth={10} /><path d="M200 110 L240 60 L280 100" fill="#4d7c0f" stroke={OL} strokeWidth={8} /></svg>
      <div style={{position: 'absolute', left: 770, top: 700, width: 300, textAlign: 'center', fontFamily: DISPLAY, fontSize: 54, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>JAPAN</div>
      <Waves top={1020} color="#1d4ed8" amp={16} speed={2} />
      {new Array(18).fill(0).map((_, i) => { const row = i % 4; return <Junk key={i} x={((random(`fx${i}`) * 700 + drift * (0.8 + row * 0.15)) % 900) - 120} y={1060 + row * 120 + Math.sin(frame / 6 + i) * 6} s={0.55 + row * 0.18} tilt={Math.sin(frame / 8 + i) * 3} />; })}
      <Tag text={(scene.year as string) ?? ''} at={-12} x={300} y={250} size={130} color="#fff" rot={-4} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={440} size={74} color="#fde047" rot={3} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={590} size={92} color="#ef4444" fg="#fff" rot={-2} /> : null}
    </Camera>
  );
};

/* typhoonWreck: { hitOnWord?, tag, helmet? } — a giant typhoon spiral sweeps in and scatters the ships; a tiny horned helmet floats by (hidden detail). */
const TyphoonWreck: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const hAt = at(captions, scene.hitOnWord, fps, dur * 0.3);
  const k = Math.max(0, frame - hAt);
  return (
    <Shake at={hAt} amount={28}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b, #475569)'}} />
        <svg width={1300} height={1300} viewBox="-650 -650 1300 1300" style={{position: 'absolute', left: -110 + Math.min(k * 8, 0) , top: 120, rotate: `${frame * 5}deg`, opacity: interpolate(frame, [hAt - 10, hAt], [0.3, 0.9], clamp)}}>
          {[0, 1, 2, 3].map((i) => <path key={i} d="M0 0 C 200 -60 340 120 300 320 C 260 520 -40 600 -260 480" fill="none" stroke="#e2e8f0" strokeWidth={60 - i * 10} strokeLinecap="round" opacity={0.35} transform={`rotate(${i * 90})`} />)}
          <circle r={70} fill="#0f172a" />
        </svg>
        <Waves top={1050} color="#1e3a8a" amp={60} speed={10} />
        {new Array(8).fill(0).map((_, i) => { const tumble = k * (2 + i % 3); return <Junk key={i} x={120 + i * 120 + Math.sin(frame / 4 + i) * (10 + k)} y={1120 + (i % 3) * 110 + Math.sin(frame / 3 + i) * 20} s={0.7} tilt={(i % 2 ? 1 : -1) * Math.min(tumble, 70 + i * 10)} broken={k > 10 + i * 3} />; })}
        {/* hidden detail: a little horned helmet bobbing in the waves for under a second */}
        {frame > dur * 0.62 && frame < dur * 0.62 + 26 ? <svg width={90} height={70} viewBox="0 0 90 70" style={{position: 'absolute', left: 860 - (frame - dur * 0.62) * 6, top: 1190 + Math.sin(frame / 3) * 10}}><path d="M15 60 Q15 20 45 18 Q75 20 75 60 Z" fill="#78716c" stroke={OL} strokeWidth={5} /><path d="M18 40 Q0 30 6 8 M72 40 Q90 30 84 8" stroke="#e7e5e4" strokeWidth={6} fill="none" strokeLinecap="round" /><circle cx={45} cy={14} r={6} fill="#ef4444" stroke={OL} strokeWidth={3} /></svg> : null}
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: ((random(`wx${i}`) * 1300 - frame * 30) % 1300 + 1300) % 1300 - 100, top: random(`wy${i}`) * 1900, width: 90, height: 5, background: '#e2e8f0', opacity: 0.5}} />)}
        <Tag text={(scene.tag as string) ?? ''} at={hAt} y={240} size={110} color="#fff" rot={-3} />
      </Camera>
    </Shake>
  );
};

/* windAnswer: { answer, answerOnWord?, year?, yearOnWord? } — wind ribbons swirl round a giant "DIVINE WIND" title; then the calendar jumps to 1944. */
const WindAnswer: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const aAt = at(captions, scene.answerOnWord, fps, 8), yAt = at(captions, scene.yearOnWord, fps, dur * 0.6);
  const s = spring({frame: frame - aAt, fps, config: {damping: 9, stiffness: 180}});
  const ys = spring({frame: frame - yAt, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={yAt} amount={18}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0ea5e9, #e0f2fe)'}} />
        {new Array(7).fill(0).map((_, i) => <svg key={i} width={1080} height={300} style={{position: 'absolute', top: 300 + i * 170, left: ((frame * (8 + i) + i * 200) % 1500) - 1200}}><path d={`M0 150 Q270 ${60 + i * 10} 540 150 T1080 150`} fill="none" stroke="#fff" strokeWidth={14} strokeLinecap="round" opacity={0.7} /></svg>)}
        <div style={{position: 'absolute', top: 560, width: '100%', textAlign: 'center', opacity: frame >= aAt ? 1 : 0, scale: String(1.6 - s * 0.6)}}>
          <div style={{fontFamily: DISPLAY, fontSize: 80, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>KAMIKAZE =</div>
          <div style={{fontFamily: DISPLAY, fontSize: 200, lineHeight: 1, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill'}}>DIVINE</div>
          <div style={{fontFamily: DISPLAY, fontSize: 200, lineHeight: 1, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill'}}>WIND</div>
        </div>
        <Tag text={(scene.answer as string) ?? ''} at={aAt} y={230} size={84} color="#4ade80" rot={-3} />
        <div style={{position: 'absolute', left: 300, top: 1100, width: 480, textAlign: 'center', opacity: frame >= yAt ? 1 : 0, scale: String(1.8 - ys * 0.8), rotate: '4deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 120, color: '#fff', background: '#111', border: `9px solid ${OL}`, borderRadius: 20, padding: '0 34px'}}>{(scene.year as string) ?? '1944'}</span>
        </div>
      </Camera>
    </Shake>
  );
};

/* lastFlight: { tag, tagOnWord? } — sunset over the sea; a small plane silhouette dives toward a distant warship; the scene cuts to black before it arrives. */
const LastFlight: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.3);
  const p = interpolate(frame, [0, dur * 0.85], [0, 0.82], clamp);
  const fade = interpolate(frame, [dur * 0.82, dur * 0.92], [0, 1], clamp);
  return (
    <Camera dur={dur} from={1.0} to={1.12}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #7c2d12, #ea580c 45%, #fdba74 62%)'}} />
      <div style={{position: 'absolute', left: 380, top: 820, width: 320, height: 320, borderRadius: '50%', background: '#fde68a', opacity: 0.9}} />
      <div style={{position: 'absolute', left: 0, top: 1060, width: 1080, height: 900, background: 'linear-gradient(180deg, #431407, #1c1917)'}} />
      <svg width={420} height={160} viewBox="0 0 420 160" style={{position: 'absolute', left: 560, top: 960}}><path d="M10 120 H410 L380 156 H40 Z M120 120 V70 H200 V40 H230 V70 H300 V120" fill="#1c1917" stroke="#1c1917" strokeWidth={6} /></svg>
      <svg width={160} height={80} viewBox="0 0 160 80" style={{position: 'absolute', left: 80 + p * 560, top: 300 + p * 640, rotate: '35deg'}}><path d="M10 40 L130 34 L150 40 L130 46 Z M60 40 L40 6 H60 L90 40 L60 74 H40 Z M120 40 L110 22 H120 L134 40 L120 58 H110 Z" fill="#1c1917" /></svg>
      <AbsoluteFill style={{background: '#000', opacity: fade}} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={240} size={74} color="#fff" rot={-2} /> : null}
    </Camera>
  );
};

/* lettersDesk: { stats: [{num, label, onWord}], tag?, tagOnWord? } — a young pilot writes a letter home by lamplight; solemn number cards appear. */
const LettersDesk: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const stats = (scene.stats as {num: string; label: string; onWord?: string}[]) ?? [];
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.4);
  return (
    <Camera dur={dur} from={1.0} to={1.06}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #1c1917, #292524)'}} />
      <div style={{position: 'absolute', left: 540 - 450, top: 900 - 450, width: 900, height: 900, borderRadius: '50%', background: 'radial-gradient(circle, rgba(253,186,116,0.35), transparent 65%)'}} />
      <div style={{position: 'absolute', left: 0, top: 1210, width: 1080, height: 80, background: '#78350f', borderTop: `8px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#0c0a09'}} />
      <Boy x={360} y={1290} height={480} stage="teen" skin={sb.character.palette.skin} rim="#fdba74" glow={0.5} mood="sad" />
      <div style={{position: 'absolute', left: 560, top: 1150, width: 240, height: 70, background: '#fef3c7', border: `6px solid ${OL}`, rotate: '-6deg'}}>{[14, 30, 46].map((y) => <div key={y} style={{position: 'absolute', left: 16, top: y, width: 200 - y, height: 5, background: '#a8a29e'}} />)}</div>
      <div style={{position: 'absolute', left: 860, top: 1090, width: 50, height: 120, background: '#fffbeb', border: `6px solid ${OL}`, borderRadius: 8}} /><div style={{position: 'absolute', left: 868, top: 1040 + Math.sin(frame / 3) * 3, width: 34, height: 54, borderRadius: '50% 50% 40% 40%', background: '#fb923c', border: `5px solid ${OL}`}} />
      {stats.map((s, i) => { const a = at(captions, s.onWord, fps, 10 + i * 30), sp = spring({frame: frame - a, fps, config: {damping: 12}}); return (
        <div key={i} style={{position: 'absolute', left: 140, top: 230 + i * 230, width: 800, height: 200, background: '#f5f5f4', border: `9px solid ${OL}`, borderRadius: 24, opacity: frame >= a ? sp : 0, translate: `0px ${(1 - sp) * 40}px`, display: 'flex', alignItems: 'center', gap: 26, padding: '0 34px'}}>
          <div style={{fontFamily: DISPLAY, fontSize: 110, color: i ? '#1d4ed8' : '#b91c1c', minWidth: 330}}>{s.num}</div>
          <div style={{fontFamily: DISPLAY, fontSize: 56, lineHeight: 1.05, color: '#1c1917'}}>{s.label}</div>
        </div>); })}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={720} size={62} color="#fde68a" rot={-2} /> : null}
    </Camera>
  );
};

/* calmSea: { tag, tagOnWord?, tag2?, tag2OnWord? } — dawn over a calm sea; one cloud drifts; text fades in (leads into the loop). */
const CalmSea: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.6);
  return (
    <Camera dur={dur} from={1.0} to={1.1}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fecaca, #fde68a 55%)'}} />
      <div style={{position: 'absolute', left: 420, top: 880, width: 240, height: 240, borderRadius: '50%', background: '#fff7ed', opacity: 0.9}} />
      <div style={{position: 'absolute', left: (frame * 2) % 1300 - 200, top: 520, width: 300, height: 90, borderRadius: 60, background: '#fff', opacity: 0.85}} />
      <Waves top={1060} color="#60a5fa" amp={8} speed={1} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={80} color="#fff" rot={-3} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={420} size={80} color="#fde047" rot={3} /> : null}
    </Camera>
  );
};

export const HISTORY5_SCENES: Record<string, React.FC<SceneProps>> = {
  stormWord: StormWord,
  fleetSail: FleetSail,
  typhoonWreck: TyphoonWreck,
  windAnswer: WindAnswer,
  lastFlight: LastFlight,
  lettersDesk: LettersDesk,
  calmSea: CalmSea,
};