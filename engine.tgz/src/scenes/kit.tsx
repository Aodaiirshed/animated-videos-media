import React from 'react';
import type {Caption} from '@remotion/captions';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';

export const wordFrame = (caps: Caption[], word: string, fps: number, fallback = 0) => {
  const c = caps.find((c) => c.text.trim().toLowerCase().startsWith(word.toLowerCase()));
  return c ? Math.round((c.startMs / 1000) * fps) : fallback;
};

export const Sky: React.FC<{top: string; mid: string; bottom: string}> = ({top, mid, bottom}) => (
  <AbsoluteFill style={{background: `linear-gradient(180deg, ${top} 0%, ${mid} 55%, ${bottom} 100%)`}} />
);

// Procedural city skyline silhouette
export const Skyline: React.FC<{y: number; color: string; seed: string; height?: number; windows?: string}> = ({
  y, color, seed, height = 260, windows,
}) => {
  const blocks = [];
  let x = -20;
  let i = 0;
  while (x < 1100) {
    const w = 50 + random(`${seed}w${i}`) * 90;
    const h = height * (0.35 + random(`${seed}h${i}`) * 0.65);
    blocks.push({x, w, h, i});
    x += w - 4;
    i++;
  }
  return (
    <svg style={{position: 'absolute', left: 0, top: y - height, overflow: 'visible'}} width={1080} height={height + 2000}>
      {blocks.map((b) => (
        <g key={b.i}>
          <rect x={b.x} y={height - b.h} width={b.w} height={b.h + 2000} fill={color} />
          {windows &&
            new Array(Math.floor(b.h / 34)).fill(0).map((_, r) =>
              new Array(Math.floor(b.w / 26)).fill(0).map((__, c) =>
                random(`${seed}${b.i}-${r}-${c}`) > 0.78 ? (
                  <rect key={`${r}-${c}`} x={b.x + 8 + c * 26} y={height - b.h + 12 + r * 34} width={10} height={14} fill={windows} opacity={0.8} />
                ) : null,
              ),
            )}
        </g>
      ))}
    </svg>
  );
};

// Explosion flashes on the horizon at deterministic times
export const HorizonFlashes: React.FC<{y: number; times: number[]; color?: string}> = ({y, times, color = '#ffb070'}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {times.map((t, i) => {
        const d = frame - t;
        if (d < 0 || d > 30) return null;
        const o = interpolate(d, [0, 3, 30], [0, 1, 0]);
        const x = 120 + random(`hf${i}`) * 840;
        return (
          <div key={i} style={{position: 'absolute', left: x - 400, top: y - 400, width: 800, height: 800, opacity: o,
            background: `radial-gradient(circle, ${color} 0%, rgba(255,120,40,0.4) 25%, transparent 60%)`, mixBlendMode: 'screen'}} />
        );
      })}
    </AbsoluteFill>
  );
};

export const Flames: React.FC<{x: number; y: number; w: number; h: number}> = ({x, y, w, h}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y - h, width: w, height: h, mixBlendMode: 'screen', filter: 'blur(6px)'}}>
      {new Array(14).fill(0).map((_, i) => {
        const fx = random(`fl${i}`) * w;
        const fl = 0.6 + 0.4 * Math.sin(frame / (2 + random(`fs${i}`) * 3) + i);
        const fh = h * (0.4 + random(`fh${i}`) * 0.6) * fl;
        const fw = 40 + random(`fw${i}`) * 70;
        return (
          <div key={i} style={{position: 'absolute', left: fx - fw / 2, bottom: 0, width: fw, height: fh,
            borderRadius: '50% 50% 40% 40% / 70% 70% 30% 30%',
            background: 'linear-gradient(0deg, #fff3b0 0%, #ffb02e 30%, #ff4d2e 65%, rgba(255,40,20,0) 100%)'}} />
        );
      })}
    </div>
  );
};

export const Smoke: React.FC<{x: number; y: number; spread?: number}> = ({x, y, spread = 300}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', filter: 'blur(30px)'}}>
      {new Array(12).fill(0).map((_, i) => {
        const life = ((frame * 1.2 + i * 40) % 480) / 480;
        const sx = x + (random(`sm${i}`) - 0.5) * spread * life * 2 + life * 120;
        const sy = y - life * 900;
        const sz = 120 + life * 420;
        return (
          <div key={i} style={{position: 'absolute', left: sx - sz / 2, top: sy - sz / 2, width: sz, height: sz,
            borderRadius: '50%', background: 'rgba(40,36,40,0.55)', opacity: (1 - life) * 0.9}} />
        );
      })}
    </AbsoluteFill>
  );
};

export const BigBackText: React.FC<{text: string; color?: string; top?: number; size?: number}> = ({
  text, color = 'rgba(255,255,255,0.08)', top = 260, size = 380,
}) => (
  <div style={{position: 'absolute', top, width: '100%', textAlign: 'center', fontFamily: 'Anton', fontSize: size,
    color: 'transparent', WebkitTextStroke: `4px ${color}`, letterSpacing: 8}}>{text}</div>
);