import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setCodec('h264');
Config.setCrf(16);            // high quality for TikTok re-encode
Config.setPixelFormat('yuv420p');
// Config.setConcurrency(4); // default = cores
// Uses a system Chrome if REMOTION_CHROME is set (handy where downloads are blocked)
if (process.env.REMOTION_CHROME) Config.setBrowserExecutable(process.env.REMOTION_CHROME);
