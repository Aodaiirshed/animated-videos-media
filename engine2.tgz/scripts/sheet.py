"""Contact sheet: python3 scripts/sheet.py <slug> [frames...] — renders stills one at a time from build/ and pastes them 270x480."""
import json, sys, subprocess, os
from PIL import Image, ImageDraw

slug = sys.argv[1]
extra = sys.argv[2:]
sb = json.load(open(f'storyboards/{slug}.json'))
t = json.load(open(f'src/generated/{slug}.timing.json'))
fps = 30
starts, s = [], 0
for sc, ts in zip(sb['scenes'], t['scenes']):
    d = round((ts['durationSec'] + sc.get('holdAfter', 0.25)) * fps)
    starts.append((s, d))
    s += d
if extra:
    frames = [int(x) for x in extra]
else:
    frames = [0, 15, 30, 45]
    for (a, d) in starts:
        frames += [a + int(d * 0.4), a + int(d * 0.85)]
    frames = sorted(set(frames))
os.makedirs(f'out/st/{slug}', exist_ok=True)
for f in frames:
    o = f'out/st/{slug}/{f}.png'
    if not os.path.exists(o):
        subprocess.run(['npx', 'remotion', 'still', 'build', slug, o, f'--frame={f}', '--log=error'], check=True)
ims = [Image.open(f'out/st/{slug}/{f}.png').resize((270, 480)) for f in frames]
cols = 8
rows = (len(ims) + cols - 1) // cols
sheet = Image.new('RGB', (270 * cols, 500 * rows), 'white')
dr = ImageDraw.Draw(sheet)
for i, (f, im) in enumerate(zip(frames, ims)):
    x, y = (i % cols) * 270, (i // cols) * 500
    sheet.paste(im, (x, y))
    dr.text((x + 5, y + 484), f'f{f} {f / fps:.1f}s', fill='black')
sheet.save(f'out/st/{slug}-sheet.png')
print(starts, frames)
