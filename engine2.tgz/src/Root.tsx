import React from 'react';
import {Composition} from 'remotion';
import {Story, sceneFrames} from './Story';
import type {Storyboard, Timing} from './types';

// Register each story here: storyboard JSON + timing JSON produced by scripts/tts_kokoro.py
import modricSb from '../storyboards/modric-refugee.json';
import modricTiming from './generated/modric-refugee.timing.json';
import breathSb from '../storyboards/hold-breath-ar.json';
import breathTiming from './generated/hold-breath-ar.timing.json';
import goalSb from '../storyboards/goal-heart-en.json';
import goalTiming from './generated/goal-heart-en.timing.json';
import wifiSb from '../storyboards/wifi-en.json';
import wifiTiming from './generated/wifi-en.timing.json';
import mahrezSb from '../storyboards/mahrez-skinny.json';
import mahrezTiming from './generated/mahrez-skinny.timing.json';
import fingersSb from '../storyboards/wrinkly-fingers-en.json';
import fingersTiming from './generated/wrinkly-fingers-en.timing.json';
import messi1Sb from '../storyboards/messi-part1.json';
import messi1Timing from './generated/messi-part1.timing.json';
import kanteSb from '../storyboards/kante-scooter.json';
import kanteTiming from './generated/kante-scooter.timing.json';
import brainSb from '../storyboards/brain-10-en.json';
import brainTiming from './generated/brain-10-en.timing.json';
import hakimiSb from '../storyboards/hakimi-guess.json';
import hakimiTiming from './generated/hakimi-guess.timing.json';
import earthSb from '../storyboards/earth-hole-en.json';
import earthTiming from './generated/earth-hole-en.timing.json';
import maneSb from '../storyboards/mane-guess.json';
import maneTiming from './generated/mane-guess.timing.json';
import survSb from '../storyboards/survive-elevator.json';
import survTiming from './generated/survive-elevator.timing.json';
import qsSb from '../storyboards/survive-quicksand.json';
import qsTiming from './generated/survive-quicksand.timing.json';
import daySb from '../storyboards/earth-one-day.json';
import dayTiming from './generated/earth-one-day.timing.json';
import nvSb from '../storyboards/nvidia-news.json';
import nvTiming from './generated/nvidia-news.timing.json';
import tfSb from '../storyboards/time-facts-1.json';
import tfTiming from './generated/time-facts-1.timing.json';
import kzSb from '../storyboards/kamikaze-word.json';
import kzTiming from './generated/kamikaze-word.timing.json';
import bgSb from '../storyboards/body-glow.json';
import bgTiming from './generated/body-glow.timing.json';
import hkSb from '../storyboards/kane-guess.json';
import hkTiming from './generated/kane-guess.timing.json';
import svSb from '../storyboards/sun-vanish.json';
import svTiming from './generated/sun-vanish.timing.json';
import ldSb from '../storyboards/diaz-guess.json';
import ldTiming from './generated/diaz-guess.timing.json';
import shSb from '../storyboards/hayha-reveal.json';
import shTiming from './generated/hayha-reveal.timing.json';
import gkSb from '../storyboards/genghis-reveal.json';
import gkTiming from './generated/genghis-reveal.timing.json';
import mtSb from '../storyboards/meat-cuts.json';
import mtTiming from './generated/meat-cuts.timing.json';
import dmSb from '../storyboards/dimaria-guess.json';
import dmTiming from './generated/dimaria-guess.timing.json';
import ulSb from '../storyboards/ulcer-doctor.json';
import ulTiming from './generated/ulcer-doctor.timing.json';
import axSb from '../storyboards/alexander-reveal.json';
import axTiming from './generated/alexander-reveal.timing.json';
import npSb from '../storyboards/napoleon-reveal.json';
import npTiming from './generated/napoleon-reveal.timing.json';
import lkSb from '../storyboards/lukaku-guess.json';
import lkTiming from './generated/lukaku-guess.timing.json';
import dvSb from '../storyboards/davies-guess.json';
import dvTiming from './generated/davies-guess.timing.json';
import gpsSb from '../storyboards/gps-works.json';
import gpsTiming from './generated/gps-works.timing.json';
import ocSb from '../storyboards/ocean-depth.json';
import ocTiming from './generated/ocean-depth.timing.json';
import ep1Sb from '../storyboards/rooftop-ep1.json';
import ep1Timing from './generated/rooftop-ep1.timing.json';

import slowSb from '../storyboards/psych-slow-change.json';
import slowTiming from './generated/psych-slow-change.timing.json';
import psychSb from '../storyboards/psych-gorilla.json';
import psychTiming from './generated/psych-gorilla.timing.json';
import bathSb from '../storyboards/bath-baby-guess.json';
import wmSb from '../storyboards/whatif-moon.json';
import wmTiming from './generated/whatif-moon.timing.json';
import pgbSb from '../storyboards/posters-guess-b.json';
import pgbTiming from './generated/posters-guess-b.timing.json';
import gblSb from '../storyboards/gut-b1-long.json';
import gblTiming from './generated/gut-b1-long.timing.json';
import gb1Sb from '../storyboards/gut-b1.json';
import gb1Timing from './generated/gut-b1.timing.json';
import p17aSb from '../storyboards/price17-guess-ar.json';
import p17aTiming from './generated/price17-guess-ar.timing.json';
import b14Sb from '../storyboards/bird14-guess.json';
import b14Timing from './generated/bird14-guess.timing.json';
import a1117Sb from '../storyboards/answers-2026-11-17.json';
import a1117Timing from './generated/answers-2026-11-17.timing.json';
import j16Sb from '../storyboards/juggle16-guess.json';
import j16Timing from './generated/juggle16-guess.timing.json';
import r2Sb from '../storyboards/rule2-decoy.json';
import r2Timing from './generated/rule2-decoy.timing.json';
import r6Sb from '../storyboards/rule6-sunkcost.json';
import r6Timing from './generated/rule6-sunkcost.timing.json';
import t11Sb from '../storyboards/tesla-gaveup.json';
import t11Timing from './generated/tesla-gaveup.timing.json';
import woSb from '../storyboards/whatif-owl-eyes.json';
import woTiming from './generated/whatif-owl-eyes.timing.json';
import wolSb from '../storyboards/whatif-owl-eyes-long.json';
import wolTiming from './generated/whatif-owl-eyes-long.timing.json';
import k17Sb from '../storyboards/keeper17-guess.json';
import k17Timing from './generated/keeper17-guess.timing.json';
import k17aSb from '../storyboards/keeper17-guess-ar.json';
import k17aTiming from './generated/keeper17-guess-ar.timing.json';
import caSb from '../storyboards/cher-ami.json';
import caTiming from './generated/cher-ami.timing.json';
import qinSb from '../storyboards/qin-clay-army.json';
import qinTiming from './generated/qin-clay-army.timing.json';
import quizSb from '../storyboards/quiz1-reveal.json';
import quizTiming from './generated/quiz1-reveal.timing.json';
import d18Sb from '../storyboards/doors18-guess.json';
import d18Timing from './generated/doors18-guess.timing.json';
import w19Sb from '../storyboards/will19-guess.json';
import w19Timing from './generated/will19-guess.timing.json';
import an19Sb from '../storyboards/answers-2026-11-19.json';
import an19Timing from './generated/answers-2026-11-19.timing.json';
import an20Sb from '../storyboards/answers-2026-11-20.json';
import an20Timing from './generated/answers-2026-11-20.timing.json';
import an21Sb from '../storyboards/answers-2026-11-21.json';
import an21Timing from './generated/answers-2026-11-21.timing.json';
import r3Sb from '../storyboards/rule3-bystander.json';
import r3Timing from './generated/rule3-bystander.timing.json';
import r4Sb from '../storyboards/rule4-spotlight.json';
import r4Timing from './generated/rule4-spotlight.timing.json';
import r5Sb from '../storyboards/rule5-ikea.json';
import r5Timing from './generated/rule5-ikea.timing.json';
import kjSb from '../storyboards/kojiro-duel.json';
import kjTiming from './generated/kojiro-duel.timing.json';
import einSb from '../storyboards/einstein-no.json';
import einTiming from './generated/einstein-no.timing.json';
import q2Sb from '../storyboards/quiz2-reveal.json';
import q2Timing from './generated/quiz2-reveal.timing.json';
import q3Sb from '../storyboards/quiz3-reveal.json';
import q3Timing from './generated/quiz3-reveal.timing.json';
import q4Sb from '../storyboards/quiz4-reveal.json';
import q5Sb from '../storyboards/quiz5-reveal.json';
import q5Timing from './generated/quiz5-reveal.timing.json';
import q6Sb from '../storyboards/quiz6-reveal.json';
import q6Timing from './generated/quiz6-reveal.timing.json';
import m22Sb from '../storyboards/meals22-guess.json';
import m22Timing from './generated/meals22-guess.timing.json';
import r7Sb from '../storyboards/rule7-footdoor.json';
import r7Timing from './generated/rule7-footdoor.timing.json';
import l12Sb from '../storyboards/leonidas-twowords.json';
import l12Timing from './generated/leonidas-twowords.timing.json';
import r8Sb from '../storyboards/rule8-scarcity.json';
import r8Timing from './generated/rule8-scarcity.timing.json';
import h13Sb from '../storyboards/raiden-record.json';
import h13Timing from './generated/raiden-record.timing.json';
import q4Timing from './generated/quiz4-reveal.timing.json';
import d21aSb from '../storyboards/doors21-guess-ar.json';
import d21aTiming from './generated/doors21-guess-ar.timing.json';
import w19aSb from '../storyboards/will19-guess-ar.json';
import w19aTiming from './generated/will19-guess-ar.timing.json';
import s20Sb from '../storyboards/splints20-guess.json';
import s20Timing from './generated/splints20-guess.timing.json';
import d21Sb from '../storyboards/doors21-guess.json';
import d21Timing from './generated/doors21-guess.timing.json';
import upSb from '../storyboards/doors21-upgrade.json';
import upTiming from './generated/doors21-upgrade.timing.json';
import an22Sb from '../storyboards/answers-2026-11-22.json';
import an22Timing from './generated/answers-2026-11-22.timing.json';
import an18Sb from '../storyboards/answers-2026-11-18.json';
import an18Timing from './generated/answers-2026-11-18.timing.json';
import ta2Sb from '../storyboards/try-afterimage.json';
import ta2Timing from './generated/try-afterimage.timing.json';
import p15Sb from '../storyboards/photo15-guess.json';
import p15Timing from './generated/photo15-guess.timing.json';
import wj1Sb from '../storyboards/wojtek-p1.json';
import wj1Timing from './generated/wojtek-p1.timing.json';
import wj2Sb from '../storyboards/wojtek-p2.json';
import wj2Timing from './generated/wojtek-p2.timing.json';
import r1Sb from '../storyboards/rule1-conformity.json';
import r1Timing from './generated/rule1-conformity.timing.json';
import p17Sb from '../storyboards/price17-guess.json';
import p17Timing from './generated/price17-guess.timing.json';
import pgSb from '../storyboards/posters-guess.json';
import pgTiming from './generated/posters-guess.timing.json';
import a16Sb from '../storyboards/answers-2026-11-16.json';
import a16Timing from './generated/answers-2026-11-16.timing.json';
import tsSb from '../storyboards/try-spiral.json';
import tsTiming from './generated/try-spiral.timing.json';
import j5Sb from '../storyboards/jump5-guess.json';
import j5Timing from './generated/jump5-guess.timing.json';
import leoSb from '../storyboards/leonardo-mirror.json';
import leoTiming from './generated/leonardo-mirror.timing.json';
import s22Sb from '../storyboards/shirt22-guess.json';
import s22Timing from './generated/shirt22-guess.timing.json';
import ans15Sb from '../storyboards/answers-2026-11-15.json';
import ans15Timing from './generated/answers-2026-11-15.timing.json';
import bathTiming from './generated/bath-baby-guess.timing.json';
const STORIES: {id: string; sb: Storyboard; timing: Timing}[] = [
  {id: 'juggle16-guess', sb: j16Sb as unknown as Storyboard, timing: j16Timing as Timing},
  {id: 'rule2-decoy', sb: r2Sb as unknown as Storyboard, timing: r2Timing as Timing},
  {id: 'rule6-sunkcost', sb: r6Sb as unknown as Storyboard, timing: r6Timing as Timing},
  {id: 'tesla-gaveup', sb: t11Sb as unknown as Storyboard, timing: t11Timing as Timing},
  {id: 'rule7-footdoor', sb: r7Sb as unknown as Storyboard, timing: r7Timing as Timing},
  {id: 'leonidas-twowords', sb: l12Sb as unknown as Storyboard, timing: l12Timing as Timing},
  {id: 'rule8-scarcity', sb: r8Sb as unknown as Storyboard, timing: r8Timing as Timing},
  {id: 'raiden-record', sb: h13Sb as unknown as Storyboard, timing: h13Timing as Timing},
  {id: 'whatif-owl-eyes', sb: woSb as unknown as Storyboard, timing: woTiming as Timing},
  {id: 'whatif-owl-eyes-long', sb: wolSb as unknown as Storyboard, timing: wolTiming as Timing},
  {id: 'keeper17-guess', sb: k17Sb as unknown as Storyboard, timing: k17Timing as Timing},
  {id: 'keeper17-guess-ar', sb: k17aSb as unknown as Storyboard, timing: k17aTiming as Timing},
  {id: 'cher-ami', sb: caSb as unknown as Storyboard, timing: caTiming as Timing},
  {id: 'qin-clay-army', sb: qinSb as unknown as Storyboard, timing: qinTiming as Timing},
  {id: 'quiz1-reveal', sb: quizSb as unknown as Storyboard, timing: quizTiming as Timing},
  {id: 'doors18-guess', sb: d18Sb as unknown as Storyboard, timing: d18Timing as Timing},
  {id: 'will19-guess', sb: w19Sb as unknown as Storyboard, timing: w19Timing as Timing},
  {id: 'answers-2026-11-19', sb: an19Sb as unknown as Storyboard, timing: an19Timing as Timing},
  {id: 'answers-2026-11-20', sb: an20Sb as unknown as Storyboard, timing: an20Timing as Timing},
  {id: 'answers-2026-11-21', sb: an21Sb as unknown as Storyboard, timing: an21Timing as Timing},
  {id: 'rule3-bystander', sb: r3Sb as unknown as Storyboard, timing: r3Timing as Timing},
  {id: 'rule4-spotlight', sb: r4Sb as unknown as Storyboard, timing: r4Timing as Timing},
  {id: 'rule5-ikea', sb: r5Sb as unknown as Storyboard, timing: r5Timing as Timing},
  {id: 'kojiro-duel', sb: kjSb as unknown as Storyboard, timing: kjTiming as Timing},
  {id: 'einstein-no', sb: einSb as unknown as Storyboard, timing: einTiming as Timing},
  {id: 'quiz2-reveal', sb: q2Sb as unknown as Storyboard, timing: q2Timing as Timing},
  {id: 'quiz3-reveal', sb: q3Sb as unknown as Storyboard, timing: q3Timing as Timing},
  {id: 'quiz5-reveal', sb: q5Sb as unknown as Storyboard, timing: q5Timing as Timing},
  {id: 'quiz6-reveal', sb: q6Sb as unknown as Storyboard, timing: q6Timing as Timing},
  {id: 'meals22-guess', sb: m22Sb as unknown as Storyboard, timing: m22Timing as Timing},
  {id: 'quiz4-reveal', sb: q4Sb as unknown as Storyboard, timing: q4Timing as Timing},
  {id: 'doors21-guess-ar', sb: d21aSb as unknown as Storyboard, timing: d21aTiming as Timing},
  {id: 'will19-guess-ar', sb: w19aSb as unknown as Storyboard, timing: w19aTiming as Timing},
  {id: 'splints20-guess', sb: s20Sb as unknown as Storyboard, timing: s20Timing as Timing},
  {id: 'doors21-guess', sb: d21Sb as unknown as Storyboard, timing: d21Timing as Timing},
  {id: 'doors21-upgrade', sb: upSb as unknown as Storyboard, timing: upTiming as Timing},
  {id: 'answers-2026-11-22', sb: an22Sb as unknown as Storyboard, timing: an22Timing as Timing},
  {id: 'answers-2026-11-18', sb: an18Sb as unknown as Storyboard, timing: an18Timing as Timing},
  {id: 'try-afterimage', sb: ta2Sb as unknown as Storyboard, timing: ta2Timing as Timing},
  {id: 'photo15-guess', sb: p15Sb as unknown as Storyboard, timing: p15Timing as Timing},
  {id: 'wojtek-p1', sb: wj1Sb as unknown as Storyboard, timing: wj1Timing as Timing},
  {id: 'wojtek-p2', sb: wj2Sb as unknown as Storyboard, timing: wj2Timing as Timing},
  {id: 'psych-slow-change', sb: slowSb as unknown as Storyboard, timing: slowTiming as Timing},
  {id: 'psych-gorilla', sb: psychSb as unknown as Storyboard, timing: psychTiming as Timing},
  {id: 'whatif-moon', sb: wmSb as unknown as Storyboard, timing: wmTiming as Timing},
  {id: 'posters-guess-b', sb: pgbSb as unknown as Storyboard, timing: pgbTiming as Timing},
  {id: 'gut-b1-long', sb: gblSb as unknown as Storyboard, timing: gblTiming as Timing},
  {id: 'gut-b1', sb: gb1Sb as unknown as Storyboard, timing: gb1Timing as Timing},
  {id: 'price17-guess-ar', sb: p17aSb as unknown as Storyboard, timing: p17aTiming as Timing},
  {id: 'bird14-guess', sb: b14Sb as unknown as Storyboard, timing: b14Timing as Timing},
  {id: 'answers-2026-11-17', sb: a1117Sb as unknown as Storyboard, timing: a1117Timing as Timing},
  {id: 'rule1-conformity', sb: r1Sb as unknown as Storyboard, timing: r1Timing as Timing},
  {id: 'price17-guess', sb: p17Sb as unknown as Storyboard, timing: p17Timing as Timing},
  {id: 'posters-guess', sb: pgSb as unknown as Storyboard, timing: pgTiming as Timing},
  {id: 'answers-2026-11-16', sb: a16Sb as unknown as Storyboard, timing: a16Timing as Timing},
  {id: 'try-spiral', sb: tsSb as unknown as Storyboard, timing: tsTiming as Timing},
  {id: 'jump5-guess', sb: j5Sb as unknown as Storyboard, timing: j5Timing as Timing},
  {id: 'leonardo-mirror', sb: leoSb as unknown as Storyboard, timing: leoTiming as Timing},
  {id: 'shirt22-guess', sb: s22Sb as unknown as Storyboard, timing: s22Timing as Timing},
  {id: 'answers-2026-11-15', sb: ans15Sb as unknown as Storyboard, timing: ans15Timing as Timing},
  {id: 'bath-baby-guess', sb: bathSb as unknown as Storyboard, timing: bathTiming as Timing},
  {id: 'ocean-depth', sb: ocSb as unknown as Storyboard, timing: ocTiming as Timing},
  {id: 'gps-works', sb: gpsSb as unknown as Storyboard, timing: gpsTiming as Timing},
  {id: 'kamikaze-word', sb: kzSb as unknown as Storyboard, timing: kzTiming as Timing},
  {id: 'body-glow', sb: bgSb as unknown as Storyboard, timing: bgTiming as Timing},
  {id: 'kane-guess', sb: hkSb as unknown as Storyboard, timing: hkTiming as Timing},
  {id: 'sun-vanish', sb: svSb as unknown as Storyboard, timing: svTiming as Timing},
  {id: 'diaz-guess', sb: ldSb as unknown as Storyboard, timing: ldTiming as Timing},
  {id: 'hayha-reveal', sb: shSb as unknown as Storyboard, timing: shTiming as Timing},
  {id: 'genghis-reveal', sb: gkSb as unknown as Storyboard, timing: gkTiming as Timing},
  {id: 'meat-cuts', sb: mtSb as unknown as Storyboard, timing: mtTiming as Timing},
  {id: 'dimaria-guess', sb: dmSb as unknown as Storyboard, timing: dmTiming as Timing},
  {id: 'ulcer-doctor', sb: ulSb as unknown as Storyboard, timing: ulTiming as Timing},
  {id: 'alexander-reveal', sb: axSb as unknown as Storyboard, timing: axTiming as Timing},
  {id: 'napoleon-reveal', sb: npSb as unknown as Storyboard, timing: npTiming as Timing},
  {id: 'lukaku-guess', sb: lkSb as unknown as Storyboard, timing: lkTiming as Timing},
  {id: 'davies-guess', sb: dvSb as unknown as Storyboard, timing: dvTiming as Timing},
  {id: 'time-facts-1', sb: tfSb as unknown as Storyboard, timing: tfTiming as Timing},
  {id: 'nvidia-news', sb: nvSb as unknown as Storyboard, timing: nvTiming as Timing},
  {id: 'earth-one-day', sb: daySb as unknown as Storyboard, timing: dayTiming as Timing},
  {id: 'survive-quicksand', sb: qsSb as unknown as Storyboard, timing: qsTiming as Timing},
  {id: 'survive-elevator', sb: survSb as unknown as Storyboard, timing: survTiming as Timing},
  {id: 'mane-guess', sb: maneSb as unknown as Storyboard, timing: maneTiming as Timing},
  {id: 'earth-hole-en', sb: earthSb as unknown as Storyboard, timing: earthTiming as Timing},
  {id: 'hakimi-guess', sb: hakimiSb as unknown as Storyboard, timing: hakimiTiming as Timing},
  {id: 'brain-10-en', sb: brainSb as unknown as Storyboard, timing: brainTiming as Timing},
  {id: 'kante-scooter', sb: kanteSb as unknown as Storyboard, timing: kanteTiming as Timing},
  {id: 'modric-refugee', sb: modricSb as Storyboard, timing: modricTiming as Timing},
  {id: 'rooftop-ep1', sb: ep1Sb as unknown as Storyboard, timing: ep1Timing as Timing},
  {id: 'messi-part1', sb: messi1Sb as unknown as Storyboard, timing: messi1Timing as Timing},
  {id: 'wrinkly-fingers-en', sb: fingersSb as unknown as Storyboard, timing: fingersTiming as Timing},
  {id: 'mahrez-skinny', sb: mahrezSb as unknown as Storyboard, timing: mahrezTiming as Timing},
  {id: 'wifi-en', sb: wifiSb as unknown as Storyboard, timing: wifiTiming as Timing},
  {id: 'goal-heart-en', sb: goalSb as unknown as Storyboard, timing: goalTiming as Timing},
  {id: 'hold-breath-ar', sb: breathSb as unknown as Storyboard, timing: breathTiming as Timing},
];

const FPS = 30;

export const RemotionRoot: React.FC = () => (
  <>
    {STORIES.map(({id, sb, timing}) => (
      <Composition
        key={id}
        id={id}
        component={Story}
        fps={FPS}
        width={1080}
        height={1920}
        durationInFrames={sceneFrames(timing, sb, FPS).reduce((a, b) => a + b, 0)}
        defaultProps={{sb, timing}}
      />
    ))}
  </>
);
