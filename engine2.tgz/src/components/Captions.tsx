import React from 'react';
import type {Caption} from '@remotion/captions';
import {Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {DISPLAY} from '../fonts';

// TikTok-style captions: pages of up to 3 words, each word pops in on its timestamp,
// the active word scales up; emphasis words are coloured.
const clean = (w: string) => w.replace(/[^\p{L}\p{N}']/gu, '').toLowerCase();

const paginate = (caps: Caption[]) => {
  const pages: Caption[][] = [];
  let cur: Caption[] = [];
  caps.forEach((c) => {
    cur.push(c);
    if (cur.length === 3 || /[.?!,]$/.test(c.text.trim())) {
      pages.push(cur);
      cur = [];
    }
  });
  if (cur.length) pages.push(cur);
  return pages;
};

export const Captions: React.FC<{
  captions: Caption[];
  emphasis?: string[];
  accent: string;
  gold: string;
  rtl?: boolean;
  top?: number;
  speaker?: {label?: string; color?: string};
}> = ({captions, emphasis = [], accent, gold, rtl, top = 1130, speaker}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const ms = (frame / fps) * 1000;
  const emph = new Set(emphasis.map(clean));
  const pages = paginate(captions);
  const page = pages.find((p) => ms >= p[0].startMs && ms < p[p.length - 1].endMs + 120);
  if (!page) return null;

  return (
    <>
    {speaker?.label ? (
      <div style={{position: 'absolute', top: top - 78, left: 0, right: 0, textAlign: 'center'}}>
        <span style={{fontFamily: 'Inter, Cairo, sans-serif', fontWeight: 800, fontSize: 40, color: '#000', background: speaker.color ?? '#fff',
          padding: '6px 26px', borderRadius: 12, boxShadow: '0 6px 18px rgba(0,0,0,0.5)', letterSpacing: 2}}>{speaker.label}</span>
      </div>
    ) : null}
    <div
      style={{
        position: 'absolute',
        left: 90,
        right: 90,
        top,
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        gap: '0 44px',
        direction: rtl ? 'rtl' : 'ltr',
      }}
    >
      {page.map((w, i) => {
        if (ms < w.startMs) return null;
        const local = ((ms - w.startMs) / 1000) * fps;
        const active = ms >= w.startMs && ms < w.endMs;
        const isEmph = emph.has(clean(w.text));
        return (
          <span
            key={i}
            style={{
              fontFamily: DISPLAY,
              fontSize: (isEmph ? 118 : 100) * (rtl ? 0.85 : 1),
              lineHeight: rtl ? 1.35 : 1.08,
              textTransform: 'uppercase',
              color: isEmph ? (i % 2 ? accent : gold) : '#fff',
              WebkitTextStroke: rtl ? '5px #000' : '10px #000',
              paintOrder: 'stroke fill',
              textShadow: '0 10px 30px rgba(0,0,0,0.85)',
              display: 'inline-block',
              scale: String(
                interpolate(local, [0, 4, 8], [0.4, active ? 1.18 : 1.08, active ? 1.1 : 1], {
                  extrapolateLeft: 'clamp',
                  extrapolateRight: 'clamp',
                  easing: Easing.out(Easing.back(2)),
                }),
              ),
              rotate: `${interpolate(local, [0, 6], [isEmph ? -6 : 0, 0], {extrapolateRight: 'clamp'})}deg`,
            }}
          >
            {w.text.trim()}
          </span>
        );
      })}
    </div>
    </>
  );
};
