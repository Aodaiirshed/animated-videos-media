import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Body scenes, set 1 (cartoon): glowHook, eyeMeter, darkCamera, faceGlow, glowClock, cellSpark, darkLoop. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* Little light particles drifting off a point. */
const Photons: React.FC<{x: number; y: number; spread: number; n?: number; power?: number; color?: string}> = ({x, y, spread, n = 26, power = 1, color = '#a7f3d0'}) => {
  const frame = useCurrentFrame();
  return <>{new Array(n).fill(0).map((_, i) => { const p = ((frame * 1.2 + random(`p${i}`) * 60) % 60) / 60; const ang = random(`a${i}`) * Math.PI * 2; const r = spread * (0.35 + p * 0.9);
    return <div key={i} style={{position: 'absolute', left: x + Math.cos(ang) * r - 7, top: y + Math.sin(ang) * r * 1.3 - 7, width: 14, height: 14, borderRadius: '50%', background: color, boxShadow: `0 0 18px ${color}`, opacity: power * (1 - p)}} />; })}</>;
};

/* glowHook: { pre, tag, tagOnWord, tag2?, tag2OnWord? } — pitch-black room; the person lights up with a soft green aura and drifting photons. */
const GlowHook: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.7);
  const g = interpolate(frame, [0, tAt], [0.25, 1], clamp) * (0.85 + Math.sin(frame / 4) * 0.15);
  return (
    <Shake at={tAt} amount={24}>
      <Camera dur={dur} from={1.25} to={1.0}>
        <AbsoluteFill style={{background: '#020208'}} />
        <div style={{position: 'absolute', left: 540 - 460, top: 1000 - 560, width: 920, height: 1120, borderRadius: '50%', background: `radial-gradient(ellipse, rgba(110,231,183,${0.55 * g}) 0%, rgba(52,211,153,${0.2 * g}) 40%, transparent 70%)`}} />
        <Boy x={540} y={1360} height={720} stage="adult" skin={sb.character.palette.skin} rim="#6ee7b7" glow={g} mood={frame >= tAt ? 'shock' : 'neutral'} />
        <Photons x={540} y={940} spread={330} power={g} />
        {frame < tAt ? <Tag text={(scene.pre as string) ?? 'RIGHT NOW...'} at={-12} y={300} size={110} color="#fff" rot={-3} /> : null}
        <Tag text={(scene.tag as string) ?? ''} at={tAt} y={220} size={120} color="#6ee7b7" rot={-3} />
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={400} size={84} color="#fff" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* eyeMeter: { tag, tagOnWord?, ratioOnWord? } — a giant cartoon eye squints at a light meter: your glow is a tiny sliver, the eye's limit is a line far above it. */
const EyeMeter: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.ratioOnWord, fps, dur * 0.5), tAt = at(captions, scene.tagOnWord, fps, dur * 0.4);
  const s = spring({frame: frame - rAt, fps, config: {damping: 8, stiffness: 200}});
  const look = Math.sin(frame / 8) * 14;
  return (
    <Shake at={rAt} amount={18}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e1b4b, #0f172a)'}} />
        <svg width={560} height={360} viewBox="0 0 560 360" style={{position: 'absolute', left: 40, top: 470}}>
          <path d="M20 180 Q280 -40 540 180 Q280 400 20 180 Z" fill="#fff" stroke={OL} strokeWidth={14} />
          <circle cx={280 + look} cy={190} r={100} fill="#3b82f6" stroke={OL} strokeWidth={10} /><circle cx={280 + look} cy={190} r={48} fill="#111" /><circle cx={258 + look} cy={168} r={16} fill="#fff" />
          <path d={`M20 180 Q280 ${-40 + Math.abs(Math.sin(frame / 10)) * 60} 540 180`} fill="#fca5a5" stroke={OL} strokeWidth={12} />
          {[0, 1, 2].map((i) => <path key={i} d={`M${120 + i * 160} ${40 + Math.abs(Math.sin(frame / 10)) * 30} l-14 -46`} stroke={OL} strokeWidth={10} strokeLinecap="round" />)}
        </svg>
        <div style={{position: 'absolute', left: 800, top: 360, width: 200, height: 900, background: '#0f172a', border: `12px solid ${OL}`, borderRadius: 24, outline: '6px solid #334155'}}>
          <div style={{position: 'absolute', left: -12, right: -12, top: 70, height: 14, background: '#f87171'}} />
          <div style={{position: 'absolute', left: -310, top: 40, width: 280, textAlign: 'right', fontFamily: DISPLAY, fontSize: 50, lineHeight: 1, color: '#fca5a5'}}>EYE CAN SEE</div>
          <div style={{position: 'absolute', left: 20, right: 20, bottom: 20, height: interpolate(frame, [0, 20], [0, 10], clamp), background: '#6ee7b7', boxShadow: '0 0 20px #6ee7b7'}} />
          <div style={{position: 'absolute', left: -310, bottom: 6, width: 280, textAlign: 'right', fontFamily: DISPLAY, fontSize: 50, lineHeight: 1, color: '#6ee7b7'}}>YOUR GLOW</div>
        </div>
        <div style={{position: 'absolute', left: 60, top: 920, width: 600, textAlign: 'center', opacity: frame >= rAt ? 1 : 0, scale: String(2 - s)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 210, lineHeight: 1, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill'}}>×1000</span>
          <div style={{fontFamily: DISPLAY, fontSize: 80, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>TOO DIM</div>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={210} size={84} color="#fff" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* darkCamera: { year?, tag, tagOnWord?, temp?, tempOnWord? } — a frosty super-camera on a tripod points at a volunteer sitting in total darkness. */
const DarkCamera: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.35), mAt = at(captions, scene.tempOnWord, fps, dur * 0.7);
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: '#04040a'}} />
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#0b0b14', borderTop: '8px solid #1e1e2e'}} />
      <div style={{position: 'absolute', left: 640, top: 600, width: 380, height: 800, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(110,231,183,0.18), transparent 70%)'}} />
      <div style={{opacity: 0.55}}><Boy x={830} y={1330} height={560} stage="adult" skin={sb.character.palette.skin} rim="#6ee7b7" glow={0.35} mood="neutral" flip /></div>
      <svg width={520} height={760} viewBox="0 0 520 760" style={{position: 'absolute', left: 30, top: 620}}>
        <path d="M200 380 L80 740 M260 380 V740 M320 380 L440 740" stroke="#64748b" strokeWidth={14} strokeLinecap="round" />
        <rect x={60} y={200} width={380} height={200} rx={30} fill="#cbd5e1" stroke={OL} strokeWidth={12} />
        <rect x={430} y={250} width={80} height={110} rx={14} fill="#94a3b8" stroke={OL} strokeWidth={10} /><circle cx={470} cy={305} r={30} fill="#1e3a8a" stroke={OL} strokeWidth={8} />
        <rect x={110} y={150} width={120} height={60} rx={10} fill="#94a3b8" stroke={OL} strokeWidth={9} />
        <path d="M60 230 Q110 210 150 236 Q200 210 250 236 Q300 210 350 236 Q400 210 440 230" fill="none" stroke="#e0f2fe" strokeWidth={14} strokeLinecap="round" />
        <circle cx={120} cy={270} r={10} fill={frame % 20 < 10 ? '#ef4444' : '#7f1d1d'} />
      </svg>
      {new Array(10).fill(0).map((_, i) => { const p = ((frame + i * 7) % 40) / 40; return <div key={i} style={{position: 'absolute', left: 120 + random(`fz${i}`) * 300, top: 800 - p * 160, width: 12, height: 12, borderRadius: 6, background: '#e0f2fe', opacity: 0.7 * (1 - p)}} />; })}
      {scene.year ? <Tag text={scene.year as string} at={0} x={320} y={210} size={110} color="#fff" rot={-4} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={390} size={74} color="#a5b4fc" rot={3} /> : null}
      {scene.temp ? <Tag text={scene.temp as string} at={mAt} x={540} y={560} size={90} color="#7dd3fc" rot={-3} /> : null}
    </Camera>
  );
};

/* faceGlow: { answer, answerOnWord?, spots: [{text,onWord,x,y}] } — a giant cartoon face; glowing patches light up on cheeks, forehead and neck. */
const FaceGlow: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const aAt = at(captions, scene.answerOnWord, fps, 10);
  const spots = (scene.spots as {text: string; onWord?: string; x: number; y: number}[]) ?? [];
  const toon = (sb.character as unknown as {toon: {skin: string; hair: string}}).toon;
  return (
    <Shake at={aAt} amount={16}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <AbsoluteFill style={{background: '#04040a'}} />
        <svg width={1080} height={1400} viewBox="0 0 1080 1400" style={{position: 'absolute', top: 340}}>
          <rect x={410} y={820} width={260} height={300} fill={toon.skin} stroke={OL} strokeWidth={14} />
          <path d="M180 1400 Q200 1100 540 1080 Q880 1100 900 1400 Z" fill="#334155" stroke={OL} strokeWidth={14} />
          <ellipse cx={540} cy={560} rx={330} ry={380} fill={toon.skin} stroke={OL} strokeWidth={16} />
          <path d="M210 470 Q220 160 540 150 Q860 160 870 470 Q800 300 540 300 Q280 300 210 470 Z" fill={toon.hair} stroke={OL} strokeWidth={14} />
          <circle cx={420} cy={560} r={30} fill="#111" /><circle cx={660} cy={560} r={30} fill="#111" /><path d="M450 760 Q540 820 630 760" fill="none" stroke="#111" strokeWidth={16} strokeLinecap="round" />
        </svg>
        <AbsoluteFill style={{background: 'rgba(2,2,8,0.45)'}} />
        {spots.map((s, i) => { const a = at(captions, s.onWord, fps, aAt + 10 + i * 14), on = interpolate(frame, [a, a + 8], [0, 1], clamp) * (0.8 + Math.sin(frame / 4 + i) * 0.2); return (
          <React.Fragment key={i}>
            <div style={{position: 'absolute', left: s.x - 150, top: s.y - 110, width: 300, height: 220, borderRadius: '50%', background: `radial-gradient(ellipse, rgba(110,231,183,${0.85 * on}), transparent 70%)`}} />
            {on > 0.2 ? <Photons x={s.x} y={s.y} spread={120} n={10} power={on} /> : null}
            <Tag text={s.text} at={a} x={s.x} y={s.y + 70} size={50} color="#6ee7b7" rot={[-4, 3, -2][i % 3]} />
          </React.Fragment>); })}
        <Tag text={(scene.answer as string) ?? ''} at={aAt} y={190} size={96} color="#4ade80" rot={-3} />
      </Camera>
    </Shake>
  );
};

/* glowClock: { peakOnWord?, lowOnWord?, tag?, tag2? } — a clock spins through the day while a glow bar rises to a peak at 4 PM and sinks at night. */
const GlowClock: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pAt = at(captions, scene.peakOnWord, fps, dur * 0.35), lAt = at(captions, scene.lowOnWord, fps, dur * 0.7);
  const hour = interpolate(frame, [0, pAt, lAt, dur], [10, 16, 23, 24], clamp);
  const g = interpolate(hour, [10, 16, 23, 24], [0.35, 1, 0.15, 0.12], clamp);
  return (
    <Camera dur={dur} from={1.0} to={1.06}>
      <AbsoluteFill style={{background: `linear-gradient(180deg, ${hour < 19 ? '#7dd3fc' : '#1e1b4b'}, ${hour < 19 ? '#fde68a' : '#020617'})`}} />
      <svg width={520} height={520} viewBox="0 0 300 300" style={{position: 'absolute', left: 60, top: 520}}>
        <circle cx={150} cy={150} r={135} fill="#fff" stroke={OL} strokeWidth={12} />
        {new Array(12).fill(0).map((_, i) => <rect key={i} x={146} y={26} width={8} height={22} fill={OL} transform={`rotate(${i * 30} 150 150)`} />)}
        <rect x={144} y={64} width={12} height={92} rx={6} fill={OL} transform={`rotate(${(hour % 12) * 30} 150 150)`} /><rect x={145} y={40} width={10} height={116} rx={5} fill="#ef4444" transform={`rotate(${hour * 360} 150 150)`} /><circle cx={150} cy={150} r={12} fill={OL} />
        <circle cx={60} cy={88} r={30} fill="#fde047" opacity={0.15} />
        <circle cx={110} cy={110} r={26} fill="#fde68a" opacity={0.3} />
        <circle cx={190} cy={110} r={26} fill="#fde68a" opacity={0.3} />
        <path d="M110 200 Q150 230 190 200" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />
      </svg>
      <div style={{position: 'absolute', left: 720, top: 470, width: 200, height: 760, background: '#0f172a', border: `12px solid ${OL}`, borderRadius: 26, overflow: 'hidden'}}>
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: `${g * 100}%`, background: 'linear-gradient(180deg, #a7f3d0, #10b981)', boxShadow: '0 0 40px #6ee7b7'}} />
      </div>
      <div style={{position: 'absolute', left: 660, top: 1250, width: 320, textAlign: 'center', fontFamily: DISPLAY, fontSize: 56, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>GLOW</div>
      <div style={{position: 'absolute', left: 60, top: 1080, width: 520, textAlign: 'center', fontFamily: DISPLAY, fontSize: 110, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>{Math.floor(hour) > 12 ? Math.floor(hour) - 12 : Math.floor(hour)} {hour >= 12 && hour < 24 ? 'PM' : 'AM'}</div>
      {scene.tag ? <Tag text={scene.tag as string} at={pAt} y={200} size={90} color="#6ee7b7" rot={-3} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={lAt} y={350} size={76} color="#fff" rot={3} /> : null}
    </Camera>
  );
};

/* cellSpark: { tag, tagOnWord?, tag2?, tag2OnWord? } — inside a cartoon cell: food pellets go into a smiling powerhouse; sparks fly and pop as tiny flashes of light. */
const CellSpark: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.6);
  return (
    <Camera dur={dur} from={1.12} to={1.0}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 55%, #fbcfe8, #db2777 80%)'}} />
      <div style={{position: 'absolute', left: 90, top: 560, width: 900, height: 900, borderRadius: '50%', background: 'radial-gradient(circle, #fdf2f8, #f9a8d4)', border: `14px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 430, top: 900, width: 220, height: 220, borderRadius: '50%', background: '#a78bfa', border: `10px solid ${OL}`}} />
      <svg width={420} height={240} viewBox="0 0 420 240" style={{position: 'absolute', left: 340, top: 640, rotate: `${Math.sin(frame / 10) * 4}deg`}}>
        <ellipse cx={210} cy={120} rx={200} ry={108} fill="#fb923c" stroke={OL} strokeWidth={12} />
        <path d="M40 120 Q80 60 120 120 Q160 180 200 120 Q240 60 280 120 Q320 180 380 120" fill="none" stroke="#c2410c" strokeWidth={10} />
        <circle cx={170} cy={92} r={12} fill="#111" /><circle cx={250} cy={92} r={12} fill="#111" /><path d="M180 150 Q210 172 240 150" stroke="#111" strokeWidth={9} fill="none" strokeLinecap="round" />
      </svg>
      {[0, 1, 2].map((i) => { const p = ((frame + i * 14) % 42) / 42; return <div key={i} style={{position: 'absolute', left: 140 + p * 260, top: 760 + Math.sin(p * 6) * 20, width: 50, height: 50, borderRadius: 14, background: '#fde047', border: `6px solid ${OL}`, opacity: p < 0.9 ? 1 : 0}} />; })}
      {new Array(10).fill(0).map((_, i) => { const p = ((frame * 1.4 + i * 9) % 50) / 50; const ang = -Math.PI / 2 + (random(`ca${i}`) - 0.5) * 2.4; const r = 80 + p * 300;
        return <svg key={i} width={70} height={70} viewBox="-35 -35 70 70" style={{position: 'absolute', left: 550 + Math.cos(ang) * r - 35, top: 760 + Math.sin(ang) * r - 35, opacity: 1 - p, scale: String(0.6 + p)}}><path d="M0 -30 L8 -8 L30 0 L8 8 L0 30 L-8 8 L-30 0 L-8 -8 Z" fill="#a7f3d0" stroke="#10b981" strokeWidth={4} /></svg>; })}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={210} size={84} color="#fff" rot={-3} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={380} size={84} color="#6ee7b7" rot={3} /> : null}
    </Camera>
  );
};

/* darkLoop: { tag, tagOnWord?, fadeOnWord? } — lights switch off around the person in bed; in the dark only their soft glow remains (sets up the loop back to the hook). */
const DarkLoop: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fAt = at(captions, scene.fadeOnWord, fps, dur * 0.3), tAt = at(captions, scene.tagOnWord, fps, dur * 0.6);
  const dark = interpolate(frame, [fAt, fAt + 4], [0, 1], clamp);
  return (
    <Camera dur={dur} from={1.0} to={1.18}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fde68a, #fdba74)'}} />
      <div style={{position: 'absolute', left: 760, top: 300, width: 40, height: 260, background: '#78716c'}} /><div style={{position: 'absolute', left: 690, top: 540, width: 180, height: 110, background: '#fef08a', border: `9px solid ${OL}`, borderRadius: '90px 90px 10px 10px', boxShadow: dark < 0.5 ? '0 30px 120px #fde047' : 'none'}} />
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#b45309', borderTop: `10px solid ${OL}`}} />
      <AbsoluteFill style={{background: '#020208', opacity: dark * 0.96}} />
      <div style={{position: 'absolute', left: 540 - 360, top: 1000 - 460, width: 720, height: 920, borderRadius: '50%', background: `radial-gradient(ellipse, rgba(110,231,183,${0.45 * dark}), transparent 70%)`}} />
      <Boy x={540} y={1360} height={620} stage="adult" skin={sb.character.palette.skin} rim={dark > 0.5 ? '#6ee7b7' : '#fff'} glow={0.3 + dark * 0.6} mood={dark > 0.5 ? 'happy' : 'neutral'} />
      {dark > 0.5 ? <Photons x={540} y={980} spread={280} n={18} power={dark * 0.8} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={92} color="#6ee7b7" rot={-3} /> : null}
    </Camera>
  );
};

export const BODY1_SCENES: Record<string, React.FC<SceneProps>> = {
  glowHook: GlowHook,
  eyeMeter: EyeMeter,
  darkCamera: DarkCamera,
  faceGlow: FaceGlow,
  glowClock: GlowClock,
  cellSpark: CellSpark,
  darkLoop: DarkLoop,
};
