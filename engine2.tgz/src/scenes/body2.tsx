import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera} from '../components/Fx';
import {BODY, DISPLAY} from '../fonts';
import {wordFrame} from './kit';

/* Body-explainer scenes, part 2: skin, fingers, water. Same navy lab family. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const C = {bg1: '#061325', bg2: '#0b2140', cyan: '#3fe0ff', coral: '#ff6b6b', mint: '#5dffb0', ink: '#e9f6ff', gold: '#ffcc4d'};
const SKIN = '#f0b892', SKIN_D = '#c9875f', SKIN_PALE = '#f4cfb6';

const Lab: React.FC = () => (
  <AbsoluteFill style={{background: `radial-gradient(circle at 50% 38%, ${C.bg2} 0%, ${C.bg1} 72%)`}} />
);

const mix = (a: string, b: string, t: number) => {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const [x, y] = [p(a), p(b)];
  return `rgb(${x.map((v, i) => Math.round(v + (y.at(i)! - v) * t)).join(',')})`;
};

/* Wavy wrinkle lines across a fingertip, amount w = 0..1 */
const wrinkles = (w: number, cx: number, top: number, width: number, rows: number, seed: string) =>
  new Array(rows).fill(0).map((_, r) => {
    const y = top + r * 46;
    let d = `M${cx - width / 2} ${y}`;
    for (let x = 0; x <= width; x += 18) {
      const n = Math.sin(x / 26 + random(`${seed}${r}`) * 6) * 9 + Math.sin(x / 9 + r) * 4;
      d += ` L${cx - width / 2 + x} ${y + n * w}`;
    }
    return <path key={r} d={d} stroke={SKIN_D} strokeWidth={3 + w * 6} fill="none" strokeLinecap="round" opacity={w * 0.9} />;
  });

/* fingerWrinkle: { mode?: "finger" | "section", wrinkleOnWord?, timerLabel? } */
const FingerWrinkle: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.wrinkleOnWord ? wordFrame(captions, scene.wrinkleOnWord as string, fps, Math.round(dur * 0.4)) : Math.round(dur * 0.4);
  const w = interpolate(frame, [at, at + 40], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  if (scene.mode === 'section') {
    const vesselR = interpolate(w, [0, 1], [46, 20]);
    return (
      <>
        <Lab />
        <Camera dur={dur} from={1.0} to={1.08}>
          <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 40, letterSpacing: 8, color: C.cyan}}>FINGERTIP · CROSS-SECTION</div>
          <svg width={1080} height={900} style={{position: 'absolute', top: 320}}>
            {/* tissue block */}
            <path d={(() => {
              let d = 'M90 160';
              for (let x = 0; x <= 900; x += 10) d += ` L${90 + x} ${160 + Math.sin(x / 34) * 38 * w + Math.sin(x / 13) * 10 * w}`;
              return d + ' L990 660 L90 660 Z';
            })()} fill={mix(SKIN, SKIN_PALE, w * 0.7)} />
            <path d={(() => {
              let d = 'M90 160';
              for (let x = 0; x <= 900; x += 10) d += ` L${90 + x} ${160 + Math.sin(x / 34) * 38 * w + Math.sin(x / 13) * 10 * w}`;
              return d;
            })()} stroke={SKIN_D} strokeWidth={8} fill="none" />
            {/* blood vessels squeezing */}
            {[200, 380, 560, 740, 880].map((x, i) => (
              <g key={i}>
                <circle cx={x} cy={420 + (i % 2) * 120} r={vesselR} fill="#d63a4a" stroke="#8a1626" strokeWidth={6} />
                <circle cx={x} cy={420 + (i % 2) * 120} r={vesselR * 0.45} fill="#ff7b88" opacity={0.6} />
              </g>
            ))}
            {/* squeeze arrows */}
            {[200, 560, 880].map((x, i) => (
              <g key={i} opacity={w > 0.05 ? 1 : 0} stroke={C.ink} strokeWidth={6} strokeLinecap="round">
                <path d={`M${x - 90} ${420 + (i % 2) * 120} l${30 * w + 10} 0`} />
                <path d={`M${x + 90} ${420 + (i % 2) * 120} l${-(30 * w + 10)} 0`} />
              </g>
            ))}
          </svg>
          {/* labels */}
          <div style={{position: 'absolute', top: 1010, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 30, opacity: interpolate(w, [0.2, 0.6], [0, 1], clamp)}}>
            <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 40, color: C.bg1, background: C.coral, padding: '10px 24px', borderRadius: 16}}>vessels squeeze</span>
            <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 40, color: C.bg1, background: C.cyan, padding: '10px 24px', borderRadius: 16}}>skin folds</span>
          </div>
        </Camera>
      </>
    );
  }
  // finger mode: a giant fingertip dipping into bath water, wrinkles forming
  const dip = interpolate(frame, [0, 20], [-120, 0], {...clamp, easing: Easing.out(Easing.cubic)});
  const mins = Math.round(interpolate(frame, [0, at + 40], [0, 5], clamp));
  return (
    <>
      <Lab />
      <Camera dur={dur} from={1.12} to={1.0}>
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <defs>
            <clipPath id="tip"><path d="M300 1500 L300 620 Q300 330 540 330 Q780 330 780 620 L780 1500 Z" /></clipPath>
            <linearGradient id="skin" x1="0" x2="1">
              <stop offset="0" stopColor={mix(SKIN_D, SKIN_PALE, w * 0.5)} />
              <stop offset="0.5" stopColor={mix(SKIN, SKIN_PALE, w * 0.6)} />
              <stop offset="1" stopColor={mix(SKIN_D, SKIN_PALE, w * 0.5)} />
            </linearGradient>
          </defs>
          <g transform={`translate(0 ${dip})`}>
            <path d="M300 1500 L300 620 Q300 330 540 330 Q780 330 780 620 L780 1500 Z" fill="url(#skin)" />
            <g clipPath="url(#tip)">
              {/* fingerprint whorl */}
              {new Array(9).fill(0).map((_, i) => (
                <ellipse key={i} cx={540} cy={560} rx={40 + i * 26} ry={30 + i * 30} fill="none" stroke={SKIN_D} strokeWidth={2.5} opacity={0.35 * (1 - w * 0.6)} />
              ))}
              {wrinkles(w, 540, 420, 520, 12, 'fw')}
            </g>
            {/* nail hint */}
            <path d="M420 400 Q540 360 660 400" stroke={SKIN_D} strokeWidth={6} fill="none" opacity={0.4} />
          </g>
        </svg>
        {/* bath water */}
        <div style={{position: 'absolute', left: 0, right: 0, top: 1000 + Math.sin(frame / 10) * 6, bottom: 0,
          background: 'linear-gradient(180deg, rgba(63,224,255,0.35), rgba(20,80,140,0.75))', borderTop: '6px solid rgba(160,240,255,0.8)'}} />
        {new Array(16).fill(0).map((_, i) => {
          const y = 1900 - ((frame * (2 + random(`bb${i}`) * 3) + random(`by${i}`) * 900) % 900);
          return <div key={i} style={{position: 'absolute', left: 200 + random(`bx${i}`) * 680, top: y, width: 14 + random(`bs${i}`) * 18, height: 14 + random(`bs${i}`) * 18,
            borderRadius: '50%', border: '3px solid rgba(220,250,255,0.7)'}} />;
        })}
        {/* timer */}
        <div style={{position: 'absolute', right: 70, top: 150, padding: '14px 30px', borderRadius: 24, background: 'rgba(6,19,37,0.85)', border: `4px solid ${C.cyan}`,
          fontFamily: DISPLAY, fontSize: 70, color: C.ink}}>{mins} MIN</div>
      </Camera>
    </>
  );
};

/* treadCompare: wrinkled fingertip vs car tyre tread, water draining through the channels */
const TreadCompare: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.tyreOnWord ? wordFrame(captions, scene.tyreOnWord as string, fps, 25) : 25;
  const sL = spring({frame, fps, config: {damping: 14}});
  const sR = spring({frame: frame - at, fps, config: {damping: 12}});
  const drops = (cx: number, seed: string, o: number) =>
    new Array(14).fill(0).map((_, i) => {
      const lane = (i % 5) - 2;
      const y = 320 + ((frame * 6 + random(`${seed}${i}`) * 520) % 520);
      return <div key={i} style={{position: 'absolute', left: cx + lane * 52 - 9 + Math.sin(y / 30) * 8, top: y, width: 18, height: 26, borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
        background: C.cyan, opacity: o * 0.85, boxShadow: `0 0 12px ${C.cyan}`}} />;
    });
  return (
    <>
      <Lab />
      <Camera dur={dur} from={1.0} to={1.06}>
        {/* fingertip pad */}
        <div style={{opacity: sL, translate: `0px ${(1 - sL) * 60}px`}}>
          <svg width={540} height={1000} style={{position: 'absolute', left: 0, top: 200}}>
            <path d="M80 760 L80 260 Q80 80 270 80 Q460 80 460 260 L460 760 Z" fill={SKIN_PALE} />
            <g>{wrinkles(1, 270, 160, 380, 12, 'tc')}</g>
          </svg>
          {drops(270, 'dl', sL)}
          <div style={{position: 'absolute', left: 0, width: 540, top: 990, textAlign: 'center', fontFamily: DISPLAY, fontSize: 60, color: C.ink}}>WRINKLED FINGER</div>
        </div>
        {/* tyre tread */}
        <div style={{opacity: sR, translate: `0px ${(1 - sR) * 60}px`}}>
          <svg width={540} height={1000} style={{position: 'absolute', left: 540, top: 200}}>
            <rect x={80} y={80} width={380} height={680} rx={60} fill="#1c1f26" stroke="#3a3f4a" strokeWidth={8} />
            {new Array(9).fill(0).map((_, i) => (
              <path key={i} d={`M100 ${130 + i * 72} L270 ${170 + i * 72} L440 ${130 + i * 72}`} stroke="#0b0d11" strokeWidth={22} fill="none" strokeLinejoin="round" />
            ))}
          </svg>
          {drops(810, 'dr', sR)}
          <div style={{position: 'absolute', left: 540, width: 540, top: 990, textAlign: 'center', fontFamily: DISPLAY, fontSize: 60, color: C.ink}}>TYRE TREAD</div>
        </div>
        <div style={{position: 'absolute', top: 120, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 42, letterSpacing: 6, color: C.gold,
          opacity: interpolate(frame, [at + 10, at + 25], [0, 1], clamp)}}>CHANNELS THAT DRAIN WATER?</div>
      </Camera>
    </>
  );
};

/* studyClash: { left: {year, verdict, detail}, right: {...}, revealOnWord } — two studies disagree */
const StudyClash: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const l = scene.left as {year: string; verdict: string; detail: string};
  const r = scene.right as {year: string; verdict: string; detail: string};
  const at = scene.revealOnWord ? wordFrame(captions, scene.revealOnWord as string, fps, 40) : 40;
  const sL = spring({frame, fps, config: {damping: 14}});
  const sR = spring({frame: frame - at, fps, config: {damping: 10}});
  const vs = spring({frame: frame - at - 8, fps, config: {damping: 8}});
  const card = (d: {year: string; verdict: string; detail: string}, x: number, s: number, col: string, mark: string) => (
    <div style={{position: 'absolute', left: x - 225, top: 330, width: 450, height: 700, borderRadius: 40, border: `6px solid ${col}`, background: 'rgba(255,255,255,0.05)',
      opacity: s, scale: String(0.85 + s * 0.15), textAlign: 'center', padding: '50px 30px', boxSizing: 'border-box'}}>
      <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, color: C.ink, opacity: 0.8}}>STUDY</div>
      <div style={{fontFamily: DISPLAY, fontSize: 120, color: C.ink, lineHeight: 1.05}}>{d.year}</div>
      <div style={{fontFamily: DISPLAY, fontSize: 180, color: col, lineHeight: 1.1}}>{mark}</div>
      <div style={{fontFamily: DISPLAY, fontSize: 64, color: col}}>{d.verdict}</div>
      <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 34, color: C.ink, marginTop: 14, opacity: 0.85}}>{d.detail}</div>
    </div>
  );
  return (
    <>
      <Lab />
      <Camera dur={dur} from={1.0} to={1.05}>
        {card(l, 285, sL, C.mint, '✓')}
        {card(r, 795, sR, C.coral, '✗')}
        <div style={{position: 'absolute', left: 540, top: 690, translate: '-50% -50%', width: 130, height: 130, borderRadius: '50%', background: C.gold, color: C.bg1,
          fontFamily: DISPLAY, fontSize: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', scale: String(vs), boxShadow: `0 0 50px ${C.gold}`}}>VS</div>
      </Camera>
    </>
  );
};

export const BODY2_SCENES: Record<string, React.FC<SceneProps>> = {
  fingerWrinkle: FingerWrinkle,
  treadCompare: TreadCompare,
  studyClash: StudyClash,
};
