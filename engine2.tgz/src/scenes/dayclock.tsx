import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* "History in one day" kit: earthClock (cartoon clock + a stage of cartoon actors) and pausePick
   ("pause the video and pick" card with 2-3 options; NO countdown). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const lerpC = (a: number[], b: number[], t: number) => `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * t)).join(',')})`;
const skyAt = (h: number) => {
  const stops: [number, number[], number[]][] = [
    [0, [12, 10, 40], [40, 20, 70]], [5, [60, 40, 110], [250, 150, 110]], [9, [70, 170, 255], [190, 230, 255]],
    [17, [70, 170, 255], [255, 220, 170]], [20, [90, 50, 130], [250, 140, 90]], [22, [20, 16, 60], [60, 30, 90]], [24, [12, 10, 40], [40, 20, 70]],
  ];
  let i = 0;
  while (i < stops.length - 2 && h >= stops[i + 1][0]) i++;
  const t = Math.min(1, Math.max(0, (h - stops[i][0]) / (stops[i + 1][0] - stops[i][0])));
  return `linear-gradient(180deg, ${lerpC(stops[i][1], stops[i + 1][1], t)} 0%, ${lerpC(stops[i][2], stops[i + 1][2], t)} 100%)`;
};

const fmt = (h: number, secs: boolean) => {
  const total = Math.min(86399.9, Math.max(0, h * 3600));
  const H = Math.floor(total / 3600), M = Math.floor((total % 3600) / 60), S = Math.floor(total % 60);
  const h12 = H % 12 === 0 ? 12 : H % 12;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${h12}:${p(M)}${secs ? ':' + p(S) : ''} ${H < 12 ? 'AM' : 'PM'}`;
};

const Clock: React.FC<{h: number; label: string; alarm?: boolean}> = ({h, label, alarm}) => {
  const frame = useCurrentFrame();
  const ha = ((h % 12) / 12) * 360, ma = ((h * 60) % 60) / 60 * 360;
  const wob = alarm ? Math.sin(frame * 1.5) * 4 : Math.sin(frame / 14) * 1.5;
  return (
    <>
      <svg width={520} height={560} viewBox="-260 -290 520 560" style={{position: 'absolute', left: 280, top: 250, rotate: `${wob}deg`}}>
        <circle cx={-150} cy={-205} r={62} fill="#ef4444" stroke={OL} strokeWidth={10} /><circle cx={150} cy={-205} r={62} fill="#ef4444" stroke={OL} strokeWidth={10} />
        <rect x={-14} y={-262} width={28} height={40} fill="#cbd5e1" stroke={OL} strokeWidth={8} />
        <circle cx={0} cy={0} r={230} fill="#ef4444" stroke={OL} strokeWidth={12} />
        <circle cx={0} cy={0} r={192} fill="#fffdf5" stroke={OL} strokeWidth={10} />
        {new Array(12).fill(0).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return <line key={i} x1={Math.sin(a) * 160} y1={-Math.cos(a) * 160} x2={Math.sin(a) * 182} y2={-Math.cos(a) * 182} stroke={OL} strokeWidth={i % 3 ? 6 : 12} strokeLinecap="round" />;
        })}
        <path d="M-70 60 Q0 110 70 60" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />
        <circle cx={-66} cy={-50} r={17} fill={OL} /><circle cx={66} cy={-50} r={17} fill={OL} />
        <circle cx={-60} cy={-56} r={6} fill="#fff" /><circle cx={72} cy={-56} r={6} fill="#fff" />
        <line x1={0} y1={0} x2={0} y2={-150} stroke={OL} strokeWidth={10} strokeLinecap="round" transform={`rotate(${ma})`} />
        <line x1={0} y1={0} x2={0} y2={-100} stroke="#ef4444" strokeWidth={16} strokeLinecap="round" transform={`rotate(${ha})`} />
        <line x1={0} y1={0} x2={0} y2={-100} stroke={OL} strokeWidth={5} strokeLinecap="round" transform={`rotate(${ha})`} opacity={0.4} />
        <circle cx={0} cy={0} r={15} fill={OL} />
        <path d="M-150 215 L-185 262 M150 215 L185 262" stroke={OL} strokeWidth={20} strokeLinecap="round" />
      </svg>
      <div style={{position: 'absolute', top: 820, width: '100%', textAlign: 'center'}}>
        <span style={{fontFamily: DISPLAY, fontSize: 96, color: '#39ff88', background: '#0b0f14', padding: '2px 34px', borderRadius: 18, border: `7px solid ${OL}`, letterSpacing: 3, fontVariantNumeric: 'tabular-nums'}}>{label}</span>
      </div>
    </>
  );
};

const Microbe: React.FC<{x: number; y: number; r: number; c: string; i: number; bored?: boolean}> = ({x, y, r, c, i, bored}) => {
  const frame = useCurrentFrame();
  const dx = Math.sin(frame / 11 + i * 2) * 26, dy = Math.cos(frame / 9 + i) * 14;
  return (
    <svg width={r * 3} height={r * 3} viewBox={`${-r * 1.5} ${-r * 1.5} ${r * 3} ${r * 3}`} style={{position: 'absolute', left: x - r * 1.5 + dx, top: y - r * 1.5 + dy}}>
      {new Array(10).fill(0).map((_, k) => {
        const a = (k / 10) * Math.PI * 2 + Math.sin(frame / 5 + k) * 0.2;
        return <line key={k} x1={Math.cos(a) * r} y1={Math.sin(a) * r} x2={Math.cos(a) * r * 1.32} y2={Math.sin(a) * r * 1.32} stroke={OL} strokeWidth={5} strokeLinecap="round" />;
      })}
      <ellipse cx={0} cy={0} rx={r * (1 + Math.sin(frame / 7 + i) * 0.06)} ry={r * (0.9 - Math.sin(frame / 7 + i) * 0.06)} fill={c} stroke={OL} strokeWidth={6} />
      <circle cx={-r * 0.32} cy={-r * 0.1} r={r * 0.2} fill="#fff" stroke={OL} strokeWidth={3} /><circle cx={r * 0.32} cy={-r * 0.1} r={r * 0.2} fill="#fff" stroke={OL} strokeWidth={3} />
      <circle cx={-r * 0.32} cy={-r * (bored ? 0.04 : 0.1)} r={r * 0.09} fill={OL} /><circle cx={r * 0.32} cy={-r * (bored ? 0.04 : 0.1)} r={r * 0.09} fill={OL} />
      {bored ? <><rect x={-r * 0.56} y={-r * 0.36} width={r * 0.48} height={r * 0.2} fill={c} /><rect x={r * 0.08} y={-r * 0.36} width={r * 0.48} height={r * 0.2} fill={c} />
        <line x1={-r * 0.2} y1={r * 0.38} x2={r * 0.2} y2={r * 0.38} stroke={OL} strokeWidth={5} strokeLinecap="round" /></>
        : <path d={`M${-r * 0.22} ${r * 0.3} Q0 ${r * 0.52} ${r * 0.22} ${r * 0.3}`} stroke={OL} strokeWidth={5} fill="none" strokeLinecap="round" />}
    </svg>
  );
};

const Fish: React.FC<{y: number; c: string; i: number; s?: number}> = ({y, c, i, s = 1}) => {
  const frame = useCurrentFrame();
  const x = ((frame * (5 + i * 1.5) + i * 330) % 1400) - 160;
  return (
    <svg width={220 * s} height={130 * s} viewBox="0 0 220 130" style={{position: 'absolute', left: x, top: y + Math.sin(frame / 8 + i) * 16}}>
      <path d={`M40 65 L4 ${30 + Math.sin(frame / 3 + i) * 8} L4 ${100 - Math.sin(frame / 3 + i) * 8} Z`} fill={c} stroke={OL} strokeWidth={7} strokeLinejoin="round" />
      <ellipse cx={118} cy={65} rx={86} ry={46} fill={c} stroke={OL} strokeWidth={7} />
      <path d="M90 22 L120 4 L140 24" fill={c} stroke={OL} strokeWidth={7} strokeLinejoin="round" />
      <circle cx={160} cy={52} r={15} fill="#fff" stroke={OL} strokeWidth={5} /><circle cx={164} cy={54} r={7} fill={OL} />
      <path d="M168 82 Q182 88 192 78" stroke={OL} strokeWidth={5} fill="none" strokeLinecap="round" />
    </svg>
  );
};

const Dino: React.FC<{x: number; y: number; scared?: boolean; gone?: number}> = ({x, y, scared, gone = 0}) => {
  const frame = useCurrentFrame();
  const bob = Math.abs(Math.sin(frame / 5)) * 10;
  return (
    <svg width={448} height={376} viewBox="0 0 560 470" style={{position: 'absolute', left: x - 224, top: y - 376 - (scared ? 0 : bob), opacity: 1 - gone, scale: String(1 - gone * 0.3), rotate: scared ? `${Math.sin(frame * 1.4) * 3}deg` : '0deg'}}>
      <path d="M120 300 Q40 300 10 230 Q60 270 130 250 Z" fill="#22c55e" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
      {[190, 300].map((lx, k) => <rect key={k} x={lx} y={330} width={52} height={120 - (k ? bob : 10 - bob)} rx={18} fill="#16a34a" stroke={OL} strokeWidth={9} />)}
      <ellipse cx={260} cy={280} rx={160} ry={100} fill="#22c55e" stroke={OL} strokeWidth={9} />
      <ellipse cx={270} cy={320} rx={100} ry={50} fill="#bbf7d0" opacity={0.7} />
      <path d="M350 230 Q380 120 400 90 L470 110 Q450 190 420 290 Z" fill="#22c55e" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
      <ellipse cx={450} cy={86} rx={84} ry={58} fill="#22c55e" stroke={OL} strokeWidth={9} />
      {[150, 200, 250, 300].map((sx, k) => <path key={k} d={`M${sx} ${200 - k * 4} l22 -40 l22 36`} fill="#f59e0b" stroke={OL} strokeWidth={7} strokeLinejoin="round" />)}
      <circle cx={462} cy={66} r={scared ? 26 : 19} fill="#fff" stroke={OL} strokeWidth={6} /><circle cx={468} cy={scared ? 58 : 68} r={scared ? 8 : 9} fill={OL} />
      {scared ? <ellipse cx={500} cy={112} rx={18} ry={14} fill="#7a1f2b" stroke={OL} strokeWidth={6} /> : <path d="M470 110 Q500 124 524 104" stroke={OL} strokeWidth={7} fill="none" strokeLinecap="round" />}
      <path d="M350 300 l40 16" stroke={OL} strokeWidth={14} strokeLinecap="round" />
    </svg>
  );
};

/* earthClock: { from, to, secs?, label?, actor: 'lava'|'microbes'|'sea'|'dino'|'human'|'blink', tag?, tagOnWord?, tag2?, tag2OnWord?,
   hitOnWord? (dino: asteroid), bored? , fast? } */
const EarthClock: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const from = (scene.from as number) ?? 0, to = (scene.to as number) ?? from;
  const startAt = at(captions, scene.sweepOnWord, fps, 4);
  const h = interpolate(frame, [startAt, Math.max(startAt + 10, dur - 10)], [from, to], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const actor = (scene.actor as string) ?? 'lava';
  const tagAt = at(captions, scene.tagOnWord, fps, 8), tag2At = at(captions, scene.tag2OnWord, fps, dur * 0.6);
  const hit = at(captions, scene.hitOnWord, fps, 1e9);
  const hitP = interpolate(frame, [hit - 16, hit], [0, 1], clamp);
  const boom = interpolate(frame, [hit, hit + 4, hit + 16], [0, 1, 0], clamp);
  const gone = interpolate(frame, [hit + 4, hit + 22], [0, 1], clamp);
  const GY = 1130;
  const ground = actor === 'lava' ? ['#f97316', '#7c2d12'] : actor === 'microbes' || actor === 'sea' ? ['#38bdf8', '#075985'] : ['#4ade80', '#166534'];
  const pop = spring({frame: frame - tagAt, fps, config: {damping: 9, stiffness: 160}});
  return (
    <Shake at={actor === 'dino' ? hit : tagAt} amount={actor === 'dino' ? 26 : 10}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <AbsoluteFill style={{background: skyAt(h)}} />
        {new Array(30).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`dx${i}`) * 1080, top: random(`dy${i}`) * 900, width: 5, height: 5, borderRadius: 3, background: '#fff',
          opacity: (h < 5 || h > 21 ? 0.7 : 0) * Math.abs(Math.sin(frame / 12 + i))}} />)}
        <Clock h={h} label={(scene.label as string) ?? fmt(h, !!scene.secs)} alarm={!!scene.fast || actor === 'blink'} />
        <div style={{position: 'absolute', left: 0, top: GY, width: 1080, height: 800, background: `linear-gradient(180deg, ${ground[0]}, ${ground[1]})`, borderTop: `9px solid ${OL}`}} />
        {actor === 'lava' ? (
          <>
            {[200, 540, 860].map((vx, i) => (
              <svg key={vx} width={300} height={260} style={{position: 'absolute', left: vx - 150, top: GY - 150}}>
                <path d="M20 160 L110 30 L190 30 L280 160 Z" fill="#57341c" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
                <path d="M110 30 L190 30 L175 70 L150 50 L125 74 Z" fill="#fde047" stroke={OL} strokeWidth={6} />
                {new Array(5).fill(0).map((_, k) => {
                  const t = ((frame + k * 7 + i * 5) % 30) / 30;
                  return <circle key={k} cx={150 + (k - 2) * 26 * t * 2} cy={30 - Math.sin(t * Math.PI) * 120} r={12 - t * 6} fill="#fb923c" stroke={OL} strokeWidth={4} opacity={1 - t} />;
                })}
              </svg>
            ))}
            {[0, 1, 2].map((i) => {
              const t = ((frame * 1.2 + i * 37) % 60) / 60;
              return <div key={i} style={{position: 'absolute', left: 900 - t * 900 + i * 60, top: 180 + t * 760 + i * 30, width: 34, height: 34, borderRadius: '50%', background: '#fde047', border: `5px solid ${OL}`, boxShadow: '-26px -22px 0 -8px #fb923c'}} />;
            })}
          </>
        ) : null}
        {actor === 'microbes' ? (
          [['#a3e635', 250, 1240, 64], ['#f472b6', 560, 1210, 80], ['#fde047', 850, 1260, 58], ['#c4b5fd', 400, 1330, 46], ['#5eead4', 720, 1340, 52]].map(([c, x, y, r], i) => (
            <div key={i} style={{scale: String(Math.min(1, pop + (scene.bored ? 1 : 0))), transformOrigin: `${x}px ${y}px`}}>
              <Microbe x={x as number} y={y as number} r={r as number} c={c as string} i={i} bored={!!scene.bored} />
            </div>
          ))
        ) : null}
        {actor === 'sea' ? (
          <>
            <Fish y={1170} c="#fb923c" i={0} s={1.2} /><Fish y={1300} c="#f472b6" i={1} /><Fish y={1230} c="#fde047" i={2} s={0.8} />
            {[180, 900].map((jx, i) => (
              <svg key={jx} width={140} height={220} style={{position: 'absolute', left: jx - 70, top: 1190 + Math.sin(frame / 10 + i * 2) * 30}}>
                {[30, 55, 85, 110].map((tx, k) => <path key={k} d={`M${tx} 80 q${Math.sin(frame / 5 + k) * 12} 50 0 110`} stroke="#c4b5fd" strokeWidth={9} fill="none" strokeLinecap="round" />)}
                <path d="M10 86 Q10 10 70 10 Q130 10 130 86 Z" fill="#c4b5fd" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
                <circle cx={52} cy={56} r={8} fill={OL} /><circle cx={90} cy={56} r={8} fill={OL} />
              </svg>
            ))}
          </>
        ) : null}
        {actor === 'dino' ? (
          <>
            <Dino x={470} y={GY + 250} scared={frame > hit - 14} gone={gone} />
            <div style={{position: 'absolute', left: 1150 - hitP * 520, top: 60 + hitP * 900, width: 110, height: 110, borderRadius: '50%', background: '#fde047', border: `9px solid ${OL}`,
              boxShadow: '60px -60px 0 -20px #fb923c, 110px -110px 0 -36px #ef4444', opacity: frame < hit && hitP > 0 ? 1 : 0}} />
            <AbsoluteFill style={{background: '#fff', opacity: boom}} />
          </>
        ) : null}
        {actor === 'human' || actor === 'blink' ? (
          <div style={{scale: String(actor === 'human' ? pop : 1), transformOrigin: `540px ${GY + 180}px`}}>
            <Boy x={540} y={GY + 230} height={370} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.2}
              pose={actor === 'human' ? 'cheer' : 'stand'} phase={frame / 4} mood={actor === 'blink' ? 'shock' : 'laugh'} />
          </div>
        ) : null}
        {actor === 'blink' ? ((scene.flash as string[]) ?? []).map((t, i, arr) => {
          const a0 = at(captions, scene.flashOnWord, fps, tag2At) + i * 7;
          const s = spring({frame: frame - a0, fps, config: {damping: 12, stiffness: 220}});
          const side = i % 2 ? 1 : -1;
          return <div key={t} style={{position: 'absolute', left: 540 + side * 300 - 200, width: 400, top: GY - 60 + Math.floor(i / 2) * 110, textAlign: 'center', opacity: frame >= a0 ? 1 : 0, scale: String(s), rotate: `${side * 5}deg`}}>
            <span style={{fontFamily: DISPLAY, fontSize: 50, color: '#111', background: ['#fde047', '#5eead4', '#f9a8d4', '#fdba74'][i % 4], padding: '2px 18px', borderRadius: 12, border: `5px solid ${OL}`}}>{t}</span>
          </div>;
        }) : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tagAt} y={1000} size={(scene.tagSize as number) ?? 80} color={(scene.tagColor as string) ?? '#ffcc4d'} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={tag2At} y={140} size={66} color="#ef4444" fg="#fff" rot={2} /> : null}
      </Camera>
    </Shake>
  );
};

/* pausePick: { title?, question, options: ['...','...','...'] } — "PAUSE & PICK" card. No countdown, shown once. */
const PausePick: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const opts = (scene.options as string[]) ?? [];
  const pauseAt = at(captions, scene.pauseOnWord, fps, dur * 0.5);
  const ps = spring({frame: frame - pauseAt, fps, config: {damping: 9, stiffness: 180}});
  const cols = ['#ea580c', '#0f766e', '#7c3aed'];
  return (
    <Shake at={pauseAt} amount={12}>
      <Camera dur={dur} from={1.0} to={1.05}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #3b2a6b 0%, #120c26 75%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.12}}>
          {new Array(18).fill(0).map((_, i) => {
            const a = (i / 18) * Math.PI * 2 + frame / 70;
            return <path key={i} d={`M540 860 L${540 + Math.cos(a) * 1700} ${860 + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.17) * 1700} ${860 + Math.sin(a + 0.17) * 1700} Z`} fill="#fff" />;
          })}
        </svg>
        <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 92, lineHeight: 1.05, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill', padding: '0 60px', boxSizing: 'border-box'}}>{(scene.question as string) ?? ''}</div>
        {opts.map((o, i) => {
          const s = spring({frame: frame - 8 - i * 6, fps, config: {damping: 12}});
          return (
            <div key={i} style={{position: 'absolute', left: 110, top: 520 + i * 170, width: 860, height: 140, background: cols[i % 3], border: `9px solid ${OL}`, borderRadius: 34, boxShadow: `0 11px 0 ${OL}`,
              scale: String(0.6 + s * 0.4), opacity: s, translate: `${(1 - s) * (i % 2 ? 200 : -200)}px 0px`}}>
              <span style={{position: 'absolute', left: 34, top: -4, fontFamily: DISPLAY, fontSize: 120, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{'ABC'[i]}</span>
              <span style={{position: 'absolute', left: 170, top: 22, fontFamily: DISPLAY, fontSize: 84, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{o}</span>
            </div>
          );
        })}
        <div style={{position: 'absolute', left: 0, right: 0, top: 520 + opts.length * 170 + 20, textAlign: 'center', opacity: frame >= pauseAt ? 1 : 0, scale: String(1.5 - ps * 0.5 + Math.sin(frame / 5) * 0.02)}}>
          <span style={{display: 'inline-block', fontFamily: DISPLAY, fontSize: 84, color: '#111', background: '#ffcc4d', padding: '6px 40px', borderRadius: 60, border: `8px solid ${OL}`, boxShadow: `0 10px 0 ${OL}`}}>
            <span style={{display: 'inline-block', width: 20, height: 58, background: '#111', marginRight: 12, verticalAlign: 'middle', borderRadius: 5}} />
            <span style={{display: 'inline-block', width: 20, height: 58, background: '#111', marginRight: 26, verticalAlign: 'middle', borderRadius: 5}} />
            {(scene.title as string) ?? 'PAUSE & PICK'}
          </span>
        </div>
      </Camera>
    </Shake>
  );
};

export const DAYCLOCK_SCENES: Record<string, React.FC<SceneProps>> = {
  earthClock: EarthClock,
  pausePick: PausePick,
};
