import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera, Shake} from '../components/Fx';
import {Boy} from '../components/Boy';
import {BODY, DISPLAY} from '../fonts';
import {wordFrame} from './kit';

/* Science-explainer scene kit. Every scene reads its content from storyboard fields,
   so a new explainer is mostly JSON. Brand look: deep navy lab background, cyan + coral
   accents, soft glow, clean labels. Text is RTL-safe (Arabic falls back to Cairo). */

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const C = {bg1: '#061325', bg2: '#0b2140', cyan: '#3fe0ff', coral: '#ff6b6b', mint: '#5dffb0', ink: '#e9f6ff'};

const LabBg: React.FC<{tint?: string}> = ({tint = C.cyan}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: `radial-gradient(circle at 50% 38%, ${C.bg2} 0%, ${C.bg1} 70%)`}}>
      {/* drifting particles = "inside the body" feel */}
      {new Array(40).fill(0).map((_, i) => {
        const y = (random(`py${i}`) * 1920 - frame * (0.6 + random(`ps${i}`))) % 1920;
        const s = 4 + random(`pr${i}`) * 14;
        return (
          <div key={i} style={{position: 'absolute', left: random(`px${i}`) * 1080, top: y < 0 ? y + 1920 : y, width: s, height: s,
            borderRadius: '50%', border: `2px solid ${tint}`, opacity: 0.12 + random(`po${i}`) * 0.2}} />
        );
      })}
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.06}}>
        {new Array(20).fill(0).map((_, i) => <line key={i} x1={0} x2={1080} y1={i * 100} y2={i * 100} stroke="#fff" />)}
        {new Array(11).fill(0).map((_, i) => <line key={i} y1={0} y2={1920} x1={i * 108} x2={i * 108} stroke="#fff" />)}
      </svg>
    </AbsoluteFill>
  );
};

const Label: React.FC<{text: string; x: number; y: number; at: number; color?: string; toX?: number; toY?: number}> = ({
  text, x, y, at, color = C.cyan, toX, toY,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - at, fps, config: {damping: 14}});
  return (
    <>
      {toX !== undefined && toY !== undefined && (
        <svg style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}} width={1} height={1}>
          <line x1={x} y1={y} x2={x + (toX - x) * s} y2={y + (toY - y) * s} stroke={color} strokeWidth={4} />
          <circle cx={toX} cy={toY} r={10 * s} fill={color} />
        </svg>
      )}
      <div style={{position: 'absolute', left: x, top: y, translate: '-50% -50%', scale: String(s), opacity: s,
        fontFamily: BODY, fontWeight: 800, fontSize: 40, color: C.bg1, background: color, padding: '10px 24px', borderRadius: 16, whiteSpace: 'nowrap'}}>
        {text}
      </div>
    </>
  );
};

/* Stylised body: head, torso, limbs + organs. Not anatomical art — a clear explainer diagram. */
type Organ = 'brain' | 'lungs' | 'heart' | 'stomach' | 'muscles' | 'diaphragm';
const ORGAN_POS: Record<Organ, [number, number]> = {
  brain: [540, 420], lungs: [540, 760], heart: [575, 800], stomach: [520, 960], muscles: [380, 1240], diaphragm: [540, 900],
};

const BodyFigure: React.FC<{focus: Organ[]; pulse: number}> = ({focus, pulse}) => {
  const on = (o: Organ) => focus.includes(o);
  const glow = (o: Organ, col: string) => (on(o) ? `drop-shadow(0 0 ${18 + pulse * 22}px ${col})` : 'none');
  const dim = (o: Organ) => (on(o) ? 1 : 0.25);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <g fill="none" stroke={C.cyan} strokeWidth={5} opacity={0.55}>
        <circle cx={540} cy={420} r={130} />
        <path d="M480 545 L480 590 M600 545 L600 590" />
        <path d="M360 620 Q540 580 720 620 L760 1080 Q540 1130 320 1080 Z" />
        <path d="M360 640 L250 1050 M720 640 L830 1050" strokeWidth={42} strokeLinecap="round" opacity={0.35} />
        <path d="M430 1100 L400 1600 M650 1100 L680 1600" strokeWidth={60} strokeLinecap="round" opacity={0.35} />
      </g>
      {/* brain */}
      <g style={{filter: glow('brain', C.coral)}} opacity={dim('brain')}>
        <ellipse cx={540} cy={405} rx={95} ry={72} fill="#ff9aa8" />
        <path d="M470 400 Q500 360 540 400 Q580 440 610 395 M480 430 Q520 410 560 440" stroke="#c75a6b" strokeWidth={6} fill="none" />
      </g>
      {/* lungs */}
      <g style={{filter: glow('lungs', C.cyan)}} opacity={dim('lungs')}>
        <path d={`M520 680 Q${420 - pulse * 15} 690 ${430 - pulse * 15} 880 Q480 900 520 860 Z`} fill="#7fd6ff" />
        <path d={`M560 680 Q${660 + pulse * 15} 690 ${650 + pulse * 15} 880 Q600 900 560 860 Z`} fill="#7fd6ff" />
      </g>
      {/* heart */}
      <g style={{filter: glow('heart', C.coral), transformOrigin: '575px 800px', scale: String(1 + (on('heart') ? pulse * 0.12 : 0))}} opacity={dim('heart')}>
        <path d="M575 840 C520 800 530 755 560 755 C572 755 575 768 575 768 C575 768 580 755 592 755 C622 755 630 800 575 840 Z" fill={C.coral} />
      </g>
      {/* diaphragm */}
      <path d={`M400 ${905 - pulse * 12} Q540 ${850 - pulse * 30} 680 ${905 - pulse * 12}`} stroke={C.mint} strokeWidth={14} fill="none"
        opacity={dim('diaphragm')} style={{filter: glow('diaphragm', C.mint)}} />
      {/* stomach */}
      <path d="M520 930 Q600 920 590 990 Q580 1050 500 1030 Q470 1000 510 980 Z" fill="#ffc46b" opacity={dim('stomach')} style={{filter: glow('stomach', '#ffc46b')}} />
      {/* muscles (thigh) */}
      <path d="M405 1150 Q370 1300 395 1420" stroke={C.coral} strokeWidth={34} strokeLinecap="round" fill="none" opacity={dim('muscles')} style={{filter: glow('muscles', C.coral)}} />
    </svg>
  );
};

/* bodyOrgan: { organs: ["lungs","diaphragm"], labels: [{text, organ, onWord?}] } */
const BodyOrgan: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const organs = (scene.organs as Organ[]) ?? ['heart'];
  const labels = (scene.labels as {text: string; organ: Organ; onWord?: string}[]) ?? [];
  const bpm = (scene.bpm as number) ?? 70;
  const pulse = Math.pow(Math.max(0, Math.sin((frame / fps) * Math.PI * (bpm / 60))), 4);
  return (
    <>
      <LabBg />
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{translate: '0px -80px'}}>
          <BodyFigure focus={organs} pulse={pulse} />
          {labels.map((l, i) => {
            const [ox, oy] = ORGAN_POS[l.organ];
            const side = i % 2 === 0 ? 1 : -1;
            const at = l.onWord ? wordFrame(captions, l.onWord, fps, 10 + i * 15) : 10 + i * 15;
            return <Label key={i} text={l.text} x={540 + side * 330} y={oy - 120 + i * 30} toX={ox} toY={oy} at={at} color={i % 2 ? C.coral : C.cyan} />;
          })}
        </AbsoluteFill>
      </Camera>
    </>
  );
};

/* bigStat: { stat: {from: 0, to: 37000000000000, prefix?, suffix?, label}, onWord? } */
const fmt = (n: number) => {
  if (n >= 1e12) return `${(n / 1e12).toFixed(n % 1e12 === 0 ? 0 : 1)}T`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(n % 1e9 === 0 ? 0 : 1)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1)}M`;
  return Math.round(n).toLocaleString('en-US');
};
const BigStat: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const st = scene.stat as {from?: number; to: number; prefix?: string; suffix?: string; label?: string; decimals?: number};
  const at = scene.onWord ? wordFrame(captions, scene.onWord as string, fps, 6) : 6;
  const v = interpolate(frame, [at, at + 40], [st.from ?? 0, st.to], {...clamp, easing: Easing.out(Easing.cubic)});
  const s = spring({frame: frame - at, fps, config: {damping: 12}});
  return (
    <>
      <LabBg tint={C.coral} />
      <Camera dur={dur} from={1.1} to={1.0}>
        {/* ECG trace behind the number */}
        <svg width={1080} height={400} style={{position: 'absolute', top: 520, opacity: 0.5}}>
          <path d={(() => {
            let d = 'M0 200';
            for (let x = 0; x <= 1080; x += 12) {
              const t = (x / 1080) * 4 - frame / 30;
              const ph = ((t % 1) + 1) % 1;
              const y = scene.trace === 'sine' ? 200 + Math.sin(t * Math.PI * 6) * 120 : ph > 0.45 && ph < 0.5 ? 200 - 160 : ph > 0.5 && ph < 0.55 ? 200 + 90 : 200 + Math.sin(t * 20) * 4;
              d += ` L${x} ${y}`;
            }
            return d;
          })()} stroke={scene.trace === 'sine' ? C.cyan : C.coral} strokeWidth={6} fill="none" />
        </svg>
        {scene.pre && frame < at + 6 ? (
          <div style={{position: 'absolute', top: 600, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 120, color: C.ink, lineHeight: 1.15,
            opacity: interpolate(frame, [0, 8, at - 2, at + 6], [0, 1, 1, 0], clamp), scale: String(interpolate(frame, [0, at], [1.08, 1], clamp))}}>
            {String(scene.pre).split('|').map((l, i) => <div key={i} style={{color: i ? C.cyan : C.ink, fontSize: i ? 70 : 120}}>{l}</div>)}
          </div>
        ) : null}
        <div style={{position: 'absolute', top: 560, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 230, color: C.ink,
          opacity: scene.pre ? interpolate(frame, [at, at + 6], [0, 1], clamp) : 1,
          scale: String(interpolate(s, [0, 1], [0.7, 1])), textShadow: `0 0 60px ${C.coral}`}}>
          {st.prefix ?? ''}{st.decimals ? v.toFixed(st.decimals) : fmt(v)}{st.suffix ?? ''}
        </div>
        {st.label && (
          <div style={{position: 'absolute', top: 870, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 52,
            color: C.cyan, opacity: interpolate(frame, [at + 20, at + 35], [0, 1], clamp)}}>{st.label}</div>
        )}
      </Camera>
    </>
  );
};

/* mythFact: { myth: "...", fact: "...", flipOnWord?: "..." } */
const MythFact: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const flip = scene.flipOnWord ? wordFrame(captions, scene.flipOnWord as string, fps, dur * 0.5) : Math.round(dur * 0.5);
  const p = spring({frame: frame - flip, fps, config: {damping: 15}});
  const strike = interpolate(frame, [flip - 12, flip], [0, 1], clamp);
  const rtl = /[؀-ۿ]/.test(String(scene.myth ?? ''));
  const card = (title: string, body: string, col: string, top: number, o: number, sc: number, struck = 0) => (
    <div style={{position: 'absolute', left: 90, right: 90, top, padding: '40px 50px', borderRadius: 36, background: 'rgba(255,255,255,0.06)',
      border: `5px solid ${col}`, opacity: o, scale: String(sc), direction: rtl ? 'rtl' : 'ltr'}}>
      <div style={{fontFamily: DISPLAY, fontSize: 70, color: col, letterSpacing: 4}}>{title}</div>
      <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 48, color: C.ink, marginTop: 12, position: 'relative'}}>
        {body}
        {struck > 0 && <div style={{position: 'absolute', left: 0, top: '50%', height: 8, width: `${struck * 100}%`, background: C.coral}} />}
      </div>
    </div>
  );
  return (
    <>
      <LabBg />
      {card(rtl ? 'خرافة' : 'MYTH', String(scene.myth ?? ''), C.coral, 330, 1 - p * 0.45, 1 - p * 0.08, strike)}
      {card(rtl ? 'حقيقة' : 'FACT', String(scene.fact ?? ''), C.mint, 700, p, interpolate(p, [0, 1], [0.8, 1]))}
    </>
  );
};

/* processSteps: { steps: [{text, onWord?}] } — vertical flow with arrows, each step lights up on cue */
const ProcessSteps: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const steps = (scene.steps as {text: string; onWord?: string}[]) ?? [];
  const rtl = steps.some((s) => /[؀-ۿ]/.test(s.text));
  const gap = Math.min(190, 860 / Math.max(1, steps.length));
  return (
    <>
      <LabBg tint={C.mint} />
      <Camera dur={dur} from={1.0} to={1.06}>
        {steps.map((s, i) => {
          const at = s.onWord ? wordFrame(captions, s.onWord, fps, i * 25) : i * Math.round(dur / (steps.length + 1));
          const sp = spring({frame: frame - at, fps, config: {damping: 14}});
          const top = 250 + i * gap;
          return (
            <React.Fragment key={i}>
              {i > 0 && <div style={{position: 'absolute', left: 536, top: top - gap + 120, width: 8, height: (gap - 120) * sp, background: C.mint, opacity: 0.7}} />}
              <div style={{position: 'absolute', left: 120, right: 120, top, height: 120, borderRadius: 30, display: 'flex', alignItems: 'center', gap: 30,
                padding: '0 36px', background: `rgba(93,255,176,${0.06 + sp * 0.1})`, border: `4px solid rgba(93,255,176,${0.2 + sp * 0.8})`,
                opacity: 0.25 + sp * 0.75, translate: `${(1 - sp) * (rtl ? -60 : 60)}px 0px`, direction: rtl ? 'rtl' : 'ltr'}}>
                <div style={{width: 76, height: 76, borderRadius: '50%', background: C.mint, color: C.bg1, fontFamily: DISPLAY, fontSize: 48,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>{i + 1}</div>
                <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, color: C.ink}}>{s.text}</div>
              </div>
            </React.Fragment>
          );
        })}
      </Camera>
    </>
  );
};

/* cellFlow: blood-vessel tunnel with cells streaming past — great hook/transition scene */
const CellFlow: React.FC<SceneProps> = ({scene}) => {
  const frame = useCurrentFrame();
  const col = (scene.color as string) ?? '#e2384d';
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, #5a0a14 0%, #1a0206 75%)'}}>
      {new Array(60).fill(0).map((_, i) => {
        const z = ((random(`cz${i}`) * 100 + frame * 1.6) % 100) / 100; // depth 0..1
        const ang = random(`ca${i}`) * Math.PI * 2;
        const r = 120 + z * 900;
        const sz = 30 + z * 260;
        return (
          <div key={i} style={{position: 'absolute', left: 540 + Math.cos(ang) * r - sz / 2, top: 960 + Math.sin(ang) * r * 1.3 - sz / 2,
            width: sz, height: sz * 0.62, borderRadius: '50%', rotate: `${ang * 57}deg`, opacity: Math.min(1, z * 2.5),
            background: `radial-gradient(ellipse at 50% 50%, ${col}cc 0%, ${col} 35%, #8a0f1f 80%)`, boxShadow: `inset 0 0 ${sz / 6}px #4a0610`}} />
        );
      })}
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, transparent 30%, rgba(0,0,0,0.6) 85%)'}} />
    </AbsoluteFill>
  );
};

/* titleCard: { title, subtitle? } — series opener / question card */
const TitleCard: React.FC<SceneProps> = ({scene}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 12}});
  const rtl = /[؀-ۿ]/.test(String(scene.title ?? ''));
  return (
    <>
      <LabBg />
      <div style={{position: 'absolute', top: 560, left: 80, right: 80, textAlign: 'center', direction: rtl ? 'rtl' : 'ltr'}}>
        {scene.series ? (
          <div style={{display: 'inline-block', fontFamily: BODY, fontWeight: 800, fontSize: 38, color: C.bg1, background: C.cyan,
            padding: '8px 26px', borderRadius: 40, opacity: s}}>{String(scene.series)}</div>
        ) : null}
        <div style={{fontFamily: DISPLAY, fontSize: 120, lineHeight: 1.1, color: C.ink, marginTop: 30, scale: String(interpolate(s, [0, 1], [0.8, 1])),
          opacity: s, textShadow: `0 0 50px ${C.cyan}`}}>{String(scene.title ?? '')}</div>
      </div>
    </>
  );
};


/* fanGoal: { goalOnWord, bpmFrom, bpmTo } — night stadium, ball hits the net on cue,
   crowd + hero fan erupt, ECG spikes and a live heart-rate counter jumps. */
const FanGoal: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const g = scene.goalOnWord ? wordFrame(captions, scene.goalOnWord as string, fps, Math.round(dur * 0.6)) : Math.round(dur * 0.6);
  const bFrom = (scene.bpmFrom as number) ?? 79, bTo = (scene.bpmTo as number) ?? 108;
  const after = frame >= g;
  const fly = interpolate(frame, [g - 45, g], [0, 1], {...clamp, easing: Easing.in(Easing.quad)});
  const bpm = Math.round(interpolate(frame, [g, g + 20], [bFrom, bTo], clamp) + (after ? 0 : Math.sin(frame / 5) * 1.5));
  const flash = interpolate(frame - g, [0, 2, 12], [0, 0.8, 0], clamp);
  const ripple = after ? Math.exp(-(frame - g) / 10) * Math.sin((frame - g) / 1.6) : 0;
  const beatHz = (after ? bTo : bFrom) / 60;
  const pulse = Math.pow(Math.max(0, Math.sin((frame / fps) * Math.PI * beatHz)), 6);
  return (
    <Shake at={g} amount={24}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #02040c 0%, #071a33 55%, #0d3a22 100%)'}} />
      {[150, 930].map((x, i) => (
        <div key={i} style={{position: 'absolute', left: x - 260, top: 120, width: 520, height: 1300, transformOrigin: '50% 0', rotate: `${i ? 16 : -16}deg`,
          background: 'linear-gradient(180deg, rgba(255,255,255,0.4), transparent 70%)', filter: 'blur(18px)', mixBlendMode: 'screen'}} />
      ))}
      {/* goal + net */}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <g transform="translate(240 300)">
          <rect x={0} y={0} width={600} height={260} fill="rgba(255,255,255,0.04)" />
          {new Array(16).fill(0).map((_, i) => (
            <path key={`v${i}`} d={`M${i * 40} 0 Q${i * 40} ${130 + ripple * 30 * Math.sin(i)} ${i * 40} 260`} stroke="rgba(255,255,255,0.35)" strokeWidth={2} fill="none" />
          ))}
          {new Array(7).fill(0).map((_, i) => (
            <path key={`h${i}`} d={`M0 ${i * 43} Q300 ${i * 43 + ripple * 40} 600 ${i * 43}`} stroke="rgba(255,255,255,0.35)" strokeWidth={2} fill="none" />
          ))}
          <path d="M-8 262 L-8 -8 L608 -8 L608 262" stroke="#f2f2f2" strokeWidth={16} fill="none" />
        </g>
      </svg>
      {/* ball */}
      {!after || frame - g < 30 ? (
        <div style={{position: 'absolute', left: 540 + fly * 120 - 30 - (after ? 0 : 0), top: 1500 - fly * 1080, width: 90 - fly * 40, height: 90 - fly * 40,
          borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #fff, #bbb 60%, #555)', rotate: `${frame * 18}deg`,
          boxShadow: '0 0 30px rgba(255,255,255,0.6)', opacity: after ? interpolate(frame - g, [0, 30], [1, 0], clamp) : 1}} />
      ) : null}
      {/* crowd */}
      <svg width={1080} height={700} style={{position: 'absolute', top: 1240}}>
        {new Array(70).fill(0).map((_, i) => {
          const x = (i % 14) * 80 + (Math.floor(i / 14) % 2) * 40;
          const row = Math.floor(i / 14);
          const jump = after ? Math.abs(Math.sin((frame - g) / 4 + i)) * 26 : 0;
          const y = 120 + row * 110 - jump;
          return (
            <g key={i} opacity={0.55 + row * 0.08}>
              <circle cx={x} cy={y} r={20} fill="#0a0e18" />
              <rect x={x - 26} y={y + 18} width={52} height={90} rx={20} fill="#0a0e18" />
              {after && <path d={`M${x - 20} ${y + 26} l-18 -50 M${x + 20} ${y + 26} l18 -50`} stroke="#0a0e18" strokeWidth={12} strokeLinecap="round" />}
            </g>
          );
        })}
      </svg>
      <Boy x={540} y={1930} height={500} stage="adult" pose={after ? 'cheer' : 'stand'} phase={frame / 3}
        skin="#05070d" rim={after ? '#ffcc4d' : '#3fe0ff'} glow={after ? 1 : 0.5} />
      {/* ECG strip */}
      <svg width={1080} height={300} style={{position: 'absolute', top: 760, opacity: 0.85}}>
        <path d={(() => {
          let d = 'M0 150';
          for (let x = 0; x <= 1080; x += 8) {
            const t = x / 1080 * (after ? 6 : 3) - frame / (after ? 12 : 24);
            const ph = ((t % 1) + 1) % 1;
            const amp = after ? 130 : 60;
            const y = ph > 0.45 && ph < 0.5 ? 150 - amp : ph > 0.5 && ph < 0.55 ? 150 + amp * 0.55 : 150 + Math.sin(t * 25) * 3;
            d += ` L${x} ${y}`;
          }
          return d;
        })()} stroke={after ? C.coral : C.mint} strokeWidth={6} fill="none" style={{filter: `drop-shadow(0 0 12px ${after ? C.coral : C.mint})`}} />
      </svg>
      {/* live heart-rate HUD */}
      <div style={{position: 'absolute', right: 70, top: 120, padding: '18px 30px', borderRadius: 26, background: 'rgba(6,19,37,0.8)',
        border: `4px solid ${after ? C.coral : C.mint}`, display: 'flex', alignItems: 'center', gap: 18}}>
        <svg width={56} height={52} viewBox="0 0 24 22" style={{scale: String(1 + pulse * 0.25)}}>
          <path d="M12 21 C-6 9 3 -3 12 4 C21 -3 30 9 12 21 Z" fill={after ? C.coral : C.mint} />
        </svg>
        <div style={{fontFamily: DISPLAY, fontSize: 84, color: C.ink, lineHeight: 1}}>{bpm}</div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 28, color: C.ink, opacity: 0.8}}>BPM</div>
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

export const EXPLAINER_SCENES: Record<string, React.FC<SceneProps>> = {
  bodyOrgan: BodyOrgan,
  bigStat: BigStat,
  mythFact: MythFact,
  processSteps: ProcessSteps,
  cellFlow: CellFlow,
  titleCard: TitleCard,
  fanGoal: FanGoal,
};
