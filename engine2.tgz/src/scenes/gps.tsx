import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* "How it actually works" cartoon kit, GPS episode: mapDrift, orbitSats, satShout, clockDuel. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Space: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 60%, #312e81 0%, #0b1026 70%)'}} />
      {new Array(60).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`sx${i}`) * 1080, top: random(`sy${i}`) * 1920, width: 5, height: 5, borderRadius: 3, background: '#fff', opacity: 0.25 + 0.6 * Math.abs(Math.sin(frame / 14 + i))}} />)}
    </>
  );
};

export const Sat: React.FC<{x: number; y: number; s?: number; rot?: number; talk?: boolean; i?: number}> = ({x, y, s = 1, rot = 0, talk, i = 0}) => {
  const frame = useCurrentFrame();
  return (
    <svg width={300 * s} height={200 * s} viewBox="-150 -100 300 200" style={{position: 'absolute', left: x - 150 * s, top: y - 100 * s + Math.sin(frame / 9 + i) * 6, rotate: `${rot}deg`, overflow: 'visible'}}>
      {[-1, 1].map((d) => <g key={d}><rect x={d === -1 ? -146 : 56} y={-34} width={90} height={68} rx={8} fill="#38bdf8" stroke={OL} strokeWidth={8} />
        <path d={`M${d * 101} -34 V34 M${d === -1 ? -146 : 56} 0 h90`} stroke={OL} strokeWidth={4} opacity={0.5} /></g>)}
      <rect x={-56} y={-52} width={112} height={104} rx={20} fill="#e2e8f0" stroke={OL} strokeWidth={9} />
      <path d="M0 -52 V-84" stroke={OL} strokeWidth={8} /><circle cx={0} cy={-90} r={11} fill="#ef4444" stroke={OL} strokeWidth={6} />
      <circle cx={-22} cy={-12} r={12} fill="#fff" stroke={OL} strokeWidth={5} /><circle cx={22} cy={-12} r={12} fill="#fff" stroke={OL} strokeWidth={5} />
      <circle cx={-20} cy={-9} r={5} fill={OL} /><circle cx={24} cy={-9} r={5} fill={OL} />
      {talk ? <ellipse cx={0} cy={24} rx={14} ry={8 + Math.abs(Math.sin(frame / 2 + i)) * 10} fill="#7a1f2b" stroke={OL} strokeWidth={5} /> : <path d="M-16 20 Q0 36 16 20" stroke={OL} strokeWidth={6} fill="none" strokeLinecap="round" />}
    </svg>
  );
};

const Phone: React.FC<{x: number; y: number; w?: number; children?: React.ReactNode}> = ({x, y, w = 300, children}) => (
  <div style={{position: 'absolute', left: x - w / 2, top: y - w, width: w, height: w * 2, background: '#0f172a', border: `10px solid ${OL}`, borderRadius: w * 0.16, overflow: 'hidden', boxShadow: `0 12px 0 ${OL}`}}>{children}</div>
);

const MapArt: React.FC<{w: number; h: number}> = ({w, h}) => (
  <svg width={w} height={h} viewBox="0 0 800 1000" preserveAspectRatio="none" style={{position: 'absolute', left: 0, top: 0}}>
    <rect width={800} height={1000} fill="#e7f5d6" />
    <path d="M520 0 Q470 300 620 520 Q760 720 700 1000 L800 1000 L800 0 Z" fill="#7dd3fc" />
    {[[60, 80, 150, 180], [260, 60, 160, 150], [70, 330, 130, 190], [250, 290, 170, 130], [80, 600, 190, 150], [330, 500, 130, 200], [90, 820, 150, 130], [300, 780, 180, 150]].map(([x, y, a, b], i) => <rect key={i} x={x} y={y} width={a} height={b} rx={14} fill={i % 3 ? '#d6d3d1' : '#bbf7d0'} />)}
    <path d="M0 250 H500 M0 470 H560 M0 740 H640 M220 0 V1000 M450 0 V1000" stroke="#fff" strokeWidth={34} />
    <path d="M0 250 H500 M0 470 H560 M0 740 H640 M220 0 V1000 M450 0 V1000" stroke="#fde68a" strokeWidth={22} />
  </svg>
);

/* mapDrift: { mode: 'drift'|'fixed', km?, tag?, tagOnWord?, driftOnWord? } — a phone map; the blue dot wanders off the road into the sea. */
const MapDrift: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'drift';
  const dAt = at(captions, scene.driftOnWord, fps, 10), tAt = at(captions, scene.tagOnWord, fps, dur * 0.6);
  const p = mode === 'drift' ? interpolate(frame, [dAt, dur - 6], [0, 1], clamp) : 0;
  const fx = spring({frame: frame - tAt, fps, config: {damping: 12}});
  const W = 760, H = 1010;
  const dx = mode === 'drift' ? 209 + p * 440 : 209 + (1 - fx) * 440, dy = mode === 'drift' ? 700 - p * 420 + Math.sin(p * 9) * 30 : 700 - (1 - fx) * 420;
  const pulse = (frame % 30) / 30;
  const bad = mode === 'drift' && p > 0.45;
  return (
    <Shake at={mode === 'drift' ? 0 : tAt} amount={mode === 'drift' ? 18 : 12}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <AbsoluteFill style={{background: bad ? 'radial-gradient(circle at 50% 45%, #fca5a5, #7f1d1d)' : mode === 'fixed' ? 'radial-gradient(circle at 50% 45%, #bbf7d0, #14532d)' : 'radial-gradient(circle at 50% 45%, #bfdbfe, #1e3a8a)'}} />
        <div style={{position: 'absolute', left: 160 - 14, top: 250, width: W + 28, height: H + 110, background: '#0f172a', border: `12px solid ${OL}`, borderRadius: 70, boxShadow: `0 16px 0 ${OL}`}}>
          <div style={{position: 'absolute', left: 14, top: 50, width: W - 22, height: H, overflow: 'hidden', borderRadius: 30, border: `6px solid ${OL}`}}>
            <MapArt w={W - 22} h={H} />
            <div style={{position: 'absolute', left: dx - 90, top: dy - 90, width: 180, height: 180, borderRadius: '50%', background: bad ? '#ef4444' : '#3b82f6', opacity: 0.35 * (1 - pulse), scale: String(0.4 + pulse * 0.9)}} />
            <div style={{position: 'absolute', left: dx - 30, top: dy - 30, width: 60, height: 60, borderRadius: '50%', background: bad ? '#ef4444' : '#3b82f6', border: '9px solid #fff', boxShadow: '0 4px 14px #0008'}} />
            {mode === 'drift' && p > 0.05 ? <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}><path d={`M209 700 L${dx} ${dy}`} stroke="#ef4444" strokeWidth={10} strokeDasharray="18 14" /></svg> : null}
          </div>
        </div>
        <Boy x={900} y={1500} height={420} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.2} mood={mode === 'fixed' && frame >= tAt ? 'laugh' : bad ? 'shock' : 'neutral'} pose={mode === 'fixed' && frame >= tAt ? 'cheer' : 'stand'} phase={frame / 4} flip />
        {mode === 'drift' ? (
          <div style={{position: 'absolute', top: 330, width: '100%', textAlign: 'center', opacity: p > 0.02 ? 1 : 0}}>
            <span style={{fontFamily: DISPLAY, fontSize: 150, color: '#ef4444', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill', background: '#fff', padding: '0 30px', borderRadius: 24, border: `8px solid ${OL}`}}>+{(((scene.km as number) ?? 10) * p).toFixed(1)} KM</span>
          </div>
        ) : null}
        {scene.badge ? <Tag text={scene.badge as string} at={0} y={150} size={52} color="#111" fg="#ffcc4d" rot={0} /> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={mode === 'drift' ? 560 : 330} size={84} color={mode === 'fixed' ? '#22c55e' : '#fde047'} fg={mode === 'fixed' ? '#fff' : '#111'} /> : null}
      </Camera>
    </Shake>
  );
};

/* orbitSats: { tags: [{text,onWord,color}] } — a cartoon Earth with satellites circling, each one carrying a tiny clock. */
const OrbitSats: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string; color?: string}[]) ?? [];
  const CX = 540, CY = 900;
  const sats = new Array(8).fill(0).map((_, i) => {
    const a = frame / (36 + (i % 3) * 8) + (i / 8) * Math.PI * 2;
    const rx = 400 + (i % 2) * 70, ry = 190 + (i % 3) * 70, tilt = (i % 4) * 0.5 - 0.6;
    const x0 = Math.cos(a) * rx, y0 = Math.sin(a) * ry;
    return {x: CX + x0 * Math.cos(tilt) - y0 * Math.sin(tilt), y: CY + x0 * Math.sin(tilt) + y0 * Math.cos(tilt), front: Math.sin(a) > 0, i};
  });
  const Earth = (
    <svg width={520} height={520} viewBox="-260 -260 520 520" style={{position: 'absolute', left: CX - 260, top: CY - 260}}>
      <circle r={236} fill="#38bdf8" stroke={OL} strokeWidth={12} />
      <g transform={`translate(${Math.sin(frame / 60) * 20} 0)`}><path d="M-150 -120 Q-80 -190 10 -140 Q40 -80 -30 -50 Q-120 -30 -150 -120 Z M40 10 Q130 -30 180 40 Q170 130 90 150 Q20 110 40 10 Z M-170 60 Q-110 30 -70 90 Q-90 170 -150 150 Z" fill="#4ade80" stroke={OL} strokeWidth={7} strokeLinejoin="round" /></g>
      <circle cx={-70} cy={-10} r={20} fill={OL} /><circle cx={70} cy={-10} r={20} fill={OL} /><circle cx={-63} cy={-17} r={7} fill="#fff" /><circle cx={77} cy={-17} r={7} fill="#fff" />
      <path d="M-60 70 Q0 130 60 70" stroke={OL} strokeWidth={11} fill="none" strokeLinecap="round" />
    </svg>
  );
  const drawSat = (s: {x: number; y: number; i: number}) => (
    <React.Fragment key={s.i}>
      <Sat x={s.x} y={s.y} s={0.6} i={s.i} />
      <svg width={64} height={64} viewBox="-32 -32 64 64" style={{position: 'absolute', left: s.x - 32, top: s.y + 30}}>
        <circle r={26} fill="#fffdf5" stroke={OL} strokeWidth={6} /><line x1={0} y1={0} x2={0} y2={-17} stroke={OL} strokeWidth={5} strokeLinecap="round" transform={`rotate(${frame * 12 + s.i * 40})`} />
      </svg>
    </React.Fragment>
  );
  return (
    <Camera dur={dur} from={1.08} to={1.0}>
      <Space />
      {sats.filter((s) => !s.front).map(drawSat)}
      {Earth}
      {sats.filter((s) => s.front).map(drawSat)}
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 10 + i * 20)} y={250 + i * 125} size={78} color={t.color ?? '#ffcc4d'} rot={i % 2 ? 2 : -3} />)}
    </Camera>
  );
};

/* satShout: { mode: 'listen'|'locate', tag?, tagOnWord?, pinOnWord? } — satellites shout the time down to the phone;
   'locate' draws four timed lines that meet at a "you are here" pin. */
const SatShout: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'listen';
  const tAt = at(captions, scene.tagOnWord, fps, 8), pin = at(captions, scene.pinOnWord, fps, dur * 0.7), lineAt = at(captions, scene.lineOnWord, fps, 8);
  const sats = mode === 'listen' ? [[230, 470], [850, 470]] : [[150, 520], [400, 430], [680, 430], [930, 520]];
  const PX = 540, PY = mode === 'listen' ? 1160 : 1120;
  const ps = spring({frame: frame - pin, fps, config: {damping: 8, stiffness: 180}});
  const times = ['0.067 s', '0.070 s', '0.069 s', '0.072 s'];
  return (
    <Shake at={mode === 'listen' ? tAt : pin} amount={12}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <Space />
        <div style={{position: 'absolute', left: -200, top: 1330, width: 1480, height: 1200, borderRadius: '50%', background: 'linear-gradient(180deg, #4ade80, #166534)', border: `12px solid ${OL}`}} />
        {mode === 'listen' ? sats.map(([sx, sy], i) => [0, 1, 2].map((k) => {
          const t = ((frame + k * 12 + i * 6) % 36) / 36;
          return <div key={`${i}${k}`} style={{position: 'absolute', left: sx + (PX - sx) * t - 60 - t * 60, top: sy + (PY - 200 - sy) * t - 16, width: 120 + t * 120, height: 34, borderRadius: '50%', border: `8px solid #fde047`, borderTop: 'none', opacity: 1 - t}} />;
        })) : (
          <svg width={1080} height={1920} style={{position: 'absolute'}}>
            {sats.map(([sx, sy], i) => {
              const p = interpolate(frame, [lineAt + i * 6, lineAt + i * 6 + 14], [0, 1], clamp);
              return <line key={i} x1={sx} y1={sy + 40} x2={sx + (PX - sx) * p} y2={sy + 40 + (PY - 60 - sy - 40) * p} stroke="#fde047" strokeWidth={9} strokeDasharray="20 14" />;
            })}
          </svg>
        )}
        {sats.map(([sx, sy], i) => <Sat key={i} x={sx} y={sy} s={mode === 'listen' ? 0.95 : 0.7} i={i} talk={mode === 'listen'} />)}
        {mode === 'listen' ? sats.map(([sx, sy], i) => (
          <div key={i} style={{position: 'absolute', left: sx - 150, width: 300, top: sy + 110, textAlign: 'center', scale: String(1 + Math.sin(frame / 3 + i) * 0.04)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 40, color: '#111', background: '#fff', padding: '2px 14px', borderRadius: 14, border: `5px solid ${OL}`, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap'}}>"IT'S 12:00:0{(Math.floor(frame / 3) % 10)}!"</span>
          </div>
        )) : sats.map(([sx, sy], i) => (
          <div key={i} style={{position: 'absolute', left: sx - 110, width: 220, top: sy + 70, textAlign: 'center', opacity: interpolate(frame, [lineAt + i * 6 + 10, lineAt + i * 6 + 18], [0, 1], clamp)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 42, color: '#111', background: '#fde047', padding: '0 12px', borderRadius: 10, border: `5px solid ${OL}`}}>{times[i]}</span>
          </div>
        ))}
        <Phone x={PX} y={PY + 60} w={mode === 'listen' ? 210 : 190}>
          <MapArt w={mode === 'listen' ? 190 : 170} h={mode === 'listen' ? 400 : 360} />
        </Phone>
        {mode === 'listen' ? (
          <>
            <svg width={150} height={190} viewBox="0 0 150 190" style={{position: 'absolute', left: PX + 100, top: PY - 190, rotate: `${Math.sin(frame / 4) * 6}deg`}}>
              <path d="M20 96 Q10 14 80 12 Q140 14 136 80 Q134 120 104 138 Q96 176 60 176 Q36 174 34 150" fill="#d99a5b" stroke={OL} strokeWidth={10} strokeLinecap="round" /><path d="M56 92 Q52 50 84 48 Q108 52 104 80 Q100 100 84 108" fill="none" stroke={OL} strokeWidth={8} strokeLinecap="round" />
            </svg>
            <Boy x={300} y={1500} height={400} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.2} mood="shock" />
          </>
        ) : (
          <div style={{position: 'absolute', left: PX - 80, top: PY - 250 - (1 - ps) * 200, opacity: frame >= pin ? 1 : 0, scale: String(ps)}}>
            <svg width={160} height={210} viewBox="0 0 160 210"><path d="M80 200 Q10 110 10 76 A70 70 0 0 1 150 76 Q150 110 80 200 Z" fill="#ef4444" stroke={OL} strokeWidth={11} strokeLinejoin="round" /><circle cx={80} cy={76} r={26} fill="#fff" stroke={OL} strokeWidth={8} /></svg>
          </div>
        )}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={190} size={(scene.tagSize as number) ?? 84} color={mode === 'listen' ? '#22c55e' : '#fde047'} fg={mode === 'listen' ? '#fff' : '#111'} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={mode === 'locate' ? pin : at(captions, scene.tag2OnWord, fps, dur * 0.6)} y={mode === 'locate' ? 660 : 760} size={76} color="#fff" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* clockDuel: { gainOnWord, amount, unit, tag?, tagOnWord? } — a ground clock vs a satellite clock; the space one creeps ahead. */
const ClockDuel: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const g = at(captions, scene.gainOnWord, fps, dur * 0.45), tAt = at(captions, scene.tagOnWord, fps, dur * 0.75);
  const p = interpolate(frame, [g, g + 26], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)});
  const Clk = ({x, y, extra, c}: {x: number; y: number; extra: number; c: string}) => (
    <svg width={380} height={380} viewBox="-190 -190 380 380" style={{position: 'absolute', left: x - 190, top: y - 190}}>
      <circle r={170} fill={c} stroke={OL} strokeWidth={13} /><circle r={136} fill="#fffdf5" stroke={OL} strokeWidth={9} />
      {new Array(12).fill(0).map((_, i) => { const a = (i / 12) * Math.PI * 2; return <line key={i} x1={Math.sin(a) * 108} y1={-Math.cos(a) * 108} x2={Math.sin(a) * 126} y2={-Math.cos(a) * 126} stroke={OL} strokeWidth={7} strokeLinecap="round" />; })}
      <line x1={0} y1={0} x2={0} y2={-104} stroke="#ef4444" strokeWidth={9} strokeLinecap="round" transform={`rotate(${frame * 6 + extra})`} />
      <line x1={0} y1={0} x2={0} y2={-70} stroke={OL} strokeWidth={13} strokeLinecap="round" transform="rotate(60)" /><circle r={13} fill={OL} />
    </svg>
  );
  return (
    <Shake at={g} amount={14}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <Space />
        <div style={{position: 'absolute', left: 0, top: 960, width: 1080, height: 1000, background: 'linear-gradient(180deg, #7dd3fc 0%, #bae6fd 30%, #4ade80 31%, #166534 100%)', borderTop: `12px solid ${OL}`}} />
        <Sat x={900} y={620} s={0.6} />
        <Clk x={540} y={640} extra={p * 50} c="#a78bfa" />
        <Clk x={540} y={1150} extra={0} c="#22c55e" />
        <div style={{position: 'absolute', left: 60, top: 560, fontFamily: DISPLAY, fontSize: 70, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill', rotate: '-6deg'}}>IN ORBIT</div>
        <div style={{position: 'absolute', left: 60, top: 1090, fontFamily: DISPLAY, fontSize: 70, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill', rotate: '-6deg'}}>ON EARTH</div>
        <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', opacity: frame >= g ? 1 : 0}}>
          <span style={{fontFamily: DISPLAY, fontSize: 150, color: '#fde047', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>+{Math.round(((scene.amount as number) ?? 38) * p)}</span>
          <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, color: '#fff'}}>{(scene.unit as string) ?? 'millionths of a second, every day'}</div>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={860} size={80} color="#ef4444" fg="#fff" rot={-4} /> : null}
      </Camera>
    </Shake>
  );
};

export const GPS_SCENES: Record<string, React.FC<SceneProps>> = {
  mapDrift: MapDrift,
  orbitSats: OrbitSats,
  satShout: SatShout,
  clockDuel: ClockDuel,
};
