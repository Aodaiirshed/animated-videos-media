import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* History scenes, set 1 (cartoon): classMock, shipMap, rankCard, cannonFire, crownSelf, hatReveal, mythBust. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* Two-cornered hat, centred on cx with its bottom edge at by. */
export const Bicorne: React.FC<{cx: number; by: number; w: number; rot?: number}> = ({cx, by, w, rot = 0}) => (
  <svg width={w} height={w * 0.6} viewBox="0 0 200 120" style={{position: 'absolute', left: cx - w / 2, top: by - w * 0.6, rotate: `${rot}deg`, overflow: 'visible'}}>
    <path d="M4 104 Q0 84 26 70 Q60 6 100 6 Q140 6 174 70 Q200 84 196 104 Q150 84 100 84 Q50 84 4 104 Z" fill="#17171d" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
    <path d="M22 84 Q60 26 100 24 Q140 26 178 84" fill="none" stroke="#fbbf24" strokeWidth={7} strokeLinecap="round" />
    <circle cx={100} cy={52} r={17} fill="#ef4444" stroke={OL} strokeWidth={5} /><circle cx={100} cy={52} r={10} fill="#fff" /><circle cx={100} cy={52} r={5} fill="#2563eb" />
  </svg>
);

const Crown: React.FC<{cx: number; by: number; w: number}> = ({cx, by, w}) => (
  <svg width={w} height={w * 0.7} viewBox="0 0 200 140" style={{position: 'absolute', left: cx - w / 2, top: by - w * 0.7, overflow: 'visible'}}>
    <path d="M14 130 L6 40 L54 84 L100 14 L146 84 L194 40 L186 130 Z" fill="#fbbf24" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
    <rect x={14} y={104} width={172} height={26} fill="#f59e0b" stroke={OL} strokeWidth={7} />
    {[6, 100, 194].map((x, i) => <circle key={i} cx={x} cy={i === 1 ? 14 : 40} r={12} fill="#ef4444" stroke={OL} strokeWidth={6} />)}
    {[50, 100, 150].map((x) => <circle key={x} cx={x} cy={117} r={8} fill={x === 100 ? '#60a5fa' : '#34d399'} stroke={OL} strokeWidth={4} />)}
  </svg>
);

/* classMock: { tag, tagOnWord?, tag2?, tag2OnWord? } — classroom; a ring of kids laughs at the small new boy. */
const ClassMock: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 14), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.6);
  const kids = [{x: 150, s: '#k-a', f: false}, {x: 350, s: '#k-b', f: false}, {x: 760, s: '#k-c', f: true}, {x: 950, s: '#k-d', f: true}];
  return (
    <Shake at={0} amount={22}>
      <Camera dur={dur} from={1.22} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #fde68a, #fcd34d)'}} />
        <div style={{position: 'absolute', left: 150, top: 470, width: 780, height: 360, background: '#14532d', border: `14px solid #92400e`, borderRadius: 14, outline: `8px solid ${OL}`}}>
          <div style={{fontFamily: DISPLAY, fontSize: 96, color: '#ffffffcc', textAlign: 'center', marginTop: 44, rotate: '-3deg'}}>A  B  C</div>
          <div style={{position: 'absolute', left: 60, bottom: 50, width: 300, height: 8, background: '#ffffff88', borderRadius: 4}} /><div style={{position: 'absolute', left: 60, bottom: 90, width: 420, height: 8, background: '#ffffff88', borderRadius: 4}} />
        </div>
        <div style={{position: 'absolute', left: 0, top: 1260, width: 1080, height: 700, background: '#a16207', borderTop: `10px solid ${OL}`}} />
        {kids.map((k, i) => <Boy key={i} x={k.x} y={1330 + (i % 2) * 30} height={560} stage="teen" skin={k.s} rim="#fff" glow={0.2} mood="laugh" pose="cheer" phase={frame / 3 + i * 2} flip={k.f} />)}
        <Boy x={550} y={1400} height={430} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={frame > dur * 0.55 ? 'determined' : 'cry'} />
        {['HA', 'HA!', 'HA', 'HA!'].map((t, i) => { const p = ((frame + i * 9) % 30) / 30; return <div key={i} style={{position: 'absolute', left: [90, 300, 690, 880][i], top: [640, 560, 580, 660][i] - p * 70, fontFamily: DISPLAY, fontSize: 96, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill', opacity: frame < t2 ? 1 - p : 0, rotate: `${i % 2 ? 9 : -9}deg`}}>{t}</div>; })}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={92} color="#fff" rot={-4} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={410} size={74} color="#ef4444" fg="#fff" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* shipMap: { age?, sailOnWord?, tag?, tagOnWord?, home?, dest? } — a ship carries the boy from a small island to the mainland. */
const ShipMap: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const go = at(captions, scene.sailOnWord, fps, dur * 0.4), tAt = at(captions, scene.tagOnWord, fps, dur * 0.75);
  const p = interpolate(frame, [go, go + 50], [0, 1], {...clamp, easing: (t) => t * t * (3 - 2 * t)});
  const sx = 330 + p * 330, sy = 960 - p * 330 - Math.sin(p * Math.PI) * 40;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8, #0369a1)'}} />
      {new Array(16).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: ((random(`w${i}`) * 1200 + frame * 1.2) % 1200) - 80, top: 300 + random(`wy${i}`) * 1100, width: 90, height: 10, borderRadius: 5, background: '#ffffff55'}} />)}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <path d="M520 220 Q760 180 1100 240 L1100 760 Q900 700 820 600 Q700 560 640 440 Q520 380 520 220 Z" fill="#86efac" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
        <path d="M190 980 Q250 900 330 940 Q400 1000 350 1100 Q300 1190 220 1130 Q160 1060 190 980 Z" fill="#fde68a" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
        <path d="M330 960 Q500 860 660 630" fill="none" stroke="#fff" strokeWidth={10} strokeDasharray="6 26" strokeLinecap="round" />
        <circle cx={760} cy={470} r={22} fill="#ef4444" stroke={OL} strokeWidth={8} />
      </svg>
      <div style={{position: 'absolute', left: 110, top: 840, width: 320, textAlign: 'center', fontFamily: DISPLAY, fontSize: 56, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.home as string) ?? 'HOME'}</div>
      <div style={{position: 'absolute', left: 660, top: 330, width: 320, textAlign: 'center', fontFamily: DISPLAY, fontSize: 56, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.dest as string) ?? 'SCHOOL'}</div>
      <svg width={200} height={200} viewBox="0 0 200 200" style={{position: 'absolute', left: sx - 100, top: sy - 150 + Math.sin(frame / 6) * 6, rotate: `${Math.sin(frame / 9) * 5}deg`}}>
        <path d="M100 20 V140" stroke={OL} strokeWidth={9} /><path d="M106 26 Q170 70 108 124 Z" fill="#fff" stroke={OL} strokeWidth={8} strokeLinejoin="round" /><path d="M94 40 Q50 80 94 120 Z" fill="#fecaca" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
        <path d="M24 140 H176 L150 184 H50 Z" fill="#92400e" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
      </svg>
      <Boy x={860} y={1330} height={400} stage="child" skin={sb.character.palette.skin} rim="#fff" glow={0.4} mood="sad" flip />
      {scene.age ? <Tag text={scene.age as string} at={go} x={300} y={420} size={92} color="#fff" rot={-4} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} x={470} y={1190} size={72} color="#fde047" rot={3} /> : null}
    </Camera>
  );
};

/* rankCard: { tag, tagOnWord?, rank, of, rankOnWord? } — rain; the teen gets grim news, then a mediocre class ranking slams in. */
const RankCard: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), rAt = at(captions, scene.rankOnWord, fps, dur * 0.55);
  const s = spring({frame: frame - rAt, fps, config: {damping: 9, stiffness: 190}});
  return (
    <Shake at={rAt} amount={16}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b, #475569 70%, #334155)'}} />
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`r${i}`) * 1080, top: ((random(`ry${i}`) * 1500 + frame * 38) % 1500) - 60, width: 5, height: 54, background: '#bae6fd', opacity: 0.45, rotate: '8deg', borderRadius: 3}} />)}
        <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#1f2937', borderTop: `10px solid ${OL}`}} />
        <Boy x={290} y={1330} height={540} stage="teen" skin={sb.character.palette.skin} rim="#bae6fd" glow={0.4} mood={frame < rAt ? 'cry' : 'sad'} />
        <div style={{position: 'absolute', left: 520, top: 560, width: 470, height: 560, background: '#fffbeb', border: `10px solid ${OL}`, borderRadius: 18, boxShadow: `0 14px 0 ${OL}`, opacity: frame >= rAt ? 1 : 0, scale: String(1.8 - s * 0.8), rotate: '4deg', textAlign: 'center'}}>
          <div style={{fontFamily: DISPLAY, fontSize: 60, color: '#111', background: '#fca5a5', borderBottom: `8px solid ${OL}`, borderRadius: '8px 8px 0 0', padding: '6px 0'}}>CLASS RANK</div>
          <div style={{fontFamily: DISPLAY, fontSize: 250, lineHeight: 1.05, color: '#ef4444'}}>{(scene.rank as number) ?? 42}<span style={{fontSize: 100}}>ND</span></div>
          <div style={{fontFamily: DISPLAY, fontSize: 110, lineHeight: 1, color: '#111'}}>OUT OF {(scene.of as number) ?? 58}</div>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={300} size={80} color="#fff" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* cannonFire: { tag, tagOnWord?, tag2?, tag2OnWord? } — night battery; the young officer directs a cannon that keeps firing. */
const CannonFire: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 12), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.65);
  const cyc = 22, k = frame % cyc, t = k / cyc, fl = interpolate(k, [0, 2, 7], [1, 0.8, 0], clamp);
  return (
    <Shake at={t2} amount={20}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0f172a, #7c2d12 62%, #431407)'}} />
        {new Array(30).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`s${i}`) * 1080, top: random(`sy${i}`) * 600, width: 6, height: 6, borderRadius: 3, background: '#fff', opacity: 0.6}} />)}
        <div style={{position: 'absolute', left: 0, top: 1250, width: 1080, height: 700, background: '#292524', borderTop: `10px solid ${OL}`}} />
        <AbsoluteFill style={{background: `radial-gradient(circle at 62% 52%, rgba(253,186,116,${fl * 0.6}), transparent 55%)`}} />
        {/* ball + smoke */}
        <div style={{position: 'absolute', left: 660 + t * 520, top: 960 - t * 420 + t * t * 260, width: 50, height: 50, borderRadius: '50%', background: '#111', border: `5px solid ${OL}`}} />
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 640 + i * 34 + t * 60, top: 930 - i * 30 - t * 90, width: 80 + t * 120, height: 80 + t * 120, borderRadius: '50%', background: '#e7e5e4', opacity: 0.55 * (1 - t)}} />)}
        <svg width={520} height={420} viewBox="0 0 520 420" style={{position: 'absolute', left: 300, top: 880, translate: `${-fl * 24}px 0px`}}>
          <g transform="rotate(-24 200 260)"><rect x={150} y={215} width={330} height={90} rx={36} fill="#57534e" stroke={OL} strokeWidth={11} /><rect x={440} y={205} width={50} height={110} rx={14} fill="#44403c" stroke={OL} strokeWidth={10} /></g>
          <circle cx={200} cy={300} r={96} fill="#92400e" stroke={OL} strokeWidth={12} /><circle cx={200} cy={300} r={26} fill="#fbbf24" stroke={OL} strokeWidth={8} />
          {[0, 45, 90, 135].map((a) => <path key={a} d="M110 300 H290" stroke={OL} strokeWidth={9} transform={`rotate(${a + frame * 0} 200 300)`} />)}
          {fl > 0 ? <path d="M470 60 l70 -50 l-20 60 l80 10 l-70 40 l40 60 l-70 -30 l-30 60 l-10 -70 z" fill="#fde047" stroke="#fb923c" strokeWidth={10} opacity={fl} transform="translate(-10 -10)" /> : null}
        </svg>
        <Boy x={200} y={1320} height={520} stage="adult" skin={sb.character.palette.skin} rim="#fdba74" glow={0.6} mood="determined" pose={frame >= t2 ? 'cheer' : 'stand'} phase={frame / 5} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={270} size={84} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={440} size={100} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* crownSelf: { tag, tagOnWord?, crownOnWord? } — throne-room burst; a crown comes down onto the grown hero's own head. */
const CrownSelf: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 8), cAt = at(captions, scene.crownOnWord, fps, dur * 0.5);
  const s = spring({frame: frame - cAt, fps, config: {damping: 9, stiffness: 120}});
  const X = 540, Y = 1320, Hh = 620, top = Y - Hh * 0.985;
  return (
    <Shake at={cAt + 8} amount={18}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: '#7f1d1d'}} />
        <AbsoluteFill style={{background: 'repeating-conic-gradient(from 0deg at 50% 52%, #991b1b 0 9deg, #b91c1c 9deg 18deg)', rotate: `${frame * 0.25}deg`, scale: '2.2'}} />
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, rgba(253,224,71,0.55), transparent 55%)'}} />
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#450a0a', borderTop: `10px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 400, top: 1240, width: 280, height: 700, background: '#b91c1c', border: `8px solid ${OL}`}} />
        {new Array(26).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`c${i}`) * 1080, top: ((random(`cy${i}`) * 1400 + (frame - cAt) * 9) % 1400), width: 16, height: 16, rotate: `${frame * 5 + i * 40}deg`, background: ['#fde047', '#fff', '#fbbf24'][i % 3], opacity: frame >= cAt ? 0.9 : 0}} />)}
        <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.8} mood={frame >= cAt + 6 ? 'happy' : 'determined'} pose={frame < cAt + 10 ? 'cheer' : 'stand'} phase={0} />
        <Crown cx={X} by={top + 34 - (1 - s) * 300 - (frame < cAt ? 20 : 0)} w={230} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={100} color="#fde047" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* hatReveal: { first, last, onWord, pattern? } — spotlight on the hero; the famous hat drops on and the name slams in. */
const HatReveal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.onWord, fps, dur * 0.5);
  const s = spring({frame: frame - rAt, fps, config: {damping: 8, stiffness: 150}});
  const bg = interpolate(frame, [rAt - 2, rAt + 10], [0, 1], clamp), flash = interpolate(frame - rAt, [0, 2, 12], [0, 1, 0], clamp);
  const X = 540, Y = 1330, Hh = 600, top = Y - Hh * 0.985;
  const words = [(scene.first as string) ?? '', (scene.last as string) ?? ''];
  return (
    <Shake at={rAt} amount={28}>
      <AbsoluteFill style={{background: '#06060a'}} />
      <AbsoluteFill style={{opacity: bg * 0.5, background: (scene.pattern as string) ?? 'linear-gradient(90deg, #1d4ed8 0 33.3%, #f8fafc 33.3% 66.6%, #dc2626 66.6% 100%)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 56%, rgba(0,0,0,0) 0%, rgba(0,0,0,0.82) 70%)'}} />
      <div style={{position: 'absolute', left: 240, top: 0, width: 600, height: 1400, background: 'linear-gradient(180deg, rgba(254,249,195,0.28), transparent)', clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.9} mood={frame >= rAt ? 'happy' : 'neutral'} />
      {frame < rAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 380, textAlign: 'center', fontFamily: DISPLAY, fontSize: 300, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', scale: String(1 + Math.sin(frame / 5) * 0.06)}}>?</div> : null}
      <div style={{opacity: frame >= rAt - 6 ? 1 : 0}}><Bicorne cx={X} by={top + 62 - (1 - s) * 700} w={330} rot={(1 - s) * -30} /></div>
      <div style={{position: 'absolute', top: 190, width: '100%', textAlign: 'center'}}>
        {words.map((w, wi) => (
          <div key={wi} style={{display: 'flex', justifyContent: 'center'}}>
            {w.split('').map((ch, ci) => { const ls = spring({frame: frame - rAt - 4 - (wi * 5 + ci * 1.4), fps, config: {damping: 11, stiffness: 220}}); return (
              <span key={ci} style={{fontFamily: DISPLAY, fontSize: wi ? 158 : 180, lineHeight: 1.08, color: wi ? '#fde047' : '#fff', display: 'inline-block', translate: `0px ${(1 - ls) * 120}px`, opacity: ls, WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{ch}</span>); })}
          </div>
        ))}
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

/* mythBust: { myth, mythOnWord?, fact, factOnWord?, sub?, cta?, ctaOnWord? } — hatted hero at a measuring ruler; the myth gets struck out. */
const MythBust: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mAt = at(captions, scene.mythOnWord, fps, 6), fAt = at(captions, scene.factOnWord, fps, dur * 0.4), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.8);
  const strike = interpolate(frame, [mAt + 8, mAt + 16], [0, 1], clamp);
  const X = 360, Y = 1300, Hh = 560, top = Y - Hh * 0.985;
  return (
    <Camera dur={dur} from={1.05} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e3a8a, #3b82f6 60%, #1e40af)'}} />
      <div style={{position: 'absolute', left: 0, top: 1260, width: 1080, height: 700, background: '#172554', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 620, top: 560, width: 110, height: 710, background: '#fde68a', border: `9px solid ${OL}`, borderRadius: 10}}>
        {new Array(17).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 0, top: 20 + i * 40, width: i % 4 === 0 ? 70 : 38, height: 7, background: OL}} />)}
      </div>
      <div style={{position: 'absolute', left: 300, top: top + 96, width: 440, height: 10, background: '#ef4444', borderRadius: 5, opacity: frame >= fAt ? 1 : 0}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= fAt ? 'laugh' : 'neutral'} />
      <Bicorne cx={X} by={top + 58} w={310} />
      <div style={{position: 'absolute', left: 40, right: 40, top: 250, textAlign: 'center', opacity: frame >= mAt ? 1 : 0}}>
        <span style={{position: 'relative', fontFamily: DISPLAY, fontSize: 130, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.myth as string) ?? ''}
          <span style={{position: 'absolute', left: -10, top: '52%', height: 16, width: `${strike * 104}%`, background: '#ef4444', borderRadius: 8, rotate: '-4deg'}} /></span>
      </div>
      <Tag text={(scene.fact as string) ?? ''} at={fAt} x={800} y={760} size={120} color="#fde047" rot={4} />
      {scene.sub ? <Tag text={scene.sub as string} at={fAt + 10} x={790} y={960} size={58} color="#fff" rot={-2} /> : null}
      {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={420} size={70} color="#ef4444" fg="#fff" rot={0} /> : null}
    </Camera>
  );
};

export const HISTORY1_SCENES: Record<string, React.FC<SceneProps>> = {
  classMock: ClassMock,
  shipMap: ShipMap,
  rankCard: RankCard,
  cannonFire: CannonFire,
  crownSelf: CrownSelf,
  hatReveal: HatReveal,
  mythBust: MythBust,
};
