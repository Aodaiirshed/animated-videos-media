import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {DailyPill, SeriesBadge, Syn} from '../components/Host';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Guess Who: History #12 · Ragnarok's Real Humans #4 — Leonidas at Thermopylae (480 BC).
   Verified (Herodotus via Britannica, Wikipedia, World History Encyclopedia, National Geographic): a few thousand Greeks held the
   narrow pass for about three days; a local man (Ephialtes) showed the Persians a mountain path; Leonidas sent most allies away and
   stayed with his 300 Spartans plus allies who would not leave (Thespians). Legend-flagged: "drank rivers dry" (Herodotus' claim) and
   "Come and take them" (Plutarch, ~600 years later). Non-graphic: no fighting shown, no deaths.
   Identity lock: dark "?" silhouette / backs of shields until the reveal. Animation kit v2. */
const OL = '#1a120b';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const BADGE = 'GUESS WHO: HISTORY #12';
const DUSK = 'linear-gradient(180deg, #f59e0b 0%, #b45309 28%, #451a03 70%, #1c0a02 100%)';
const BRONZE = '#c08a3e';

const Tag: React.FC<{text: string; a: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, y, color = '#ffcc4d', size = 62, rot = -3}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < a) return null;
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: 40, right: 140, top: y, textAlign: 'center', scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`, boxShadow: `0 8px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* Two cliff walls framing a narrow pass; ground at y 1080. */
const Pass: React.FC<{children?: React.ReactNode; bg?: string}> = ({children, bg = DUSK}) => (
  <AbsoluteFill style={{background: bg}}>
    {children}
  </AbsoluteFill>
);
const Cliffs: React.FC = () => (
  <svg style={{position: 'absolute', left: 0, top: 0}} width={1080} height={1920}>
    <path d="M0 300 L170 360 L260 620 L300 1100 L0 1100 Z" fill="#3f2a1d" stroke={OL} strokeWidth="8" />
    <path d="M1080 260 L900 340 L820 640 L780 1100 L1080 1100 Z" fill="#3f2a1d" stroke={OL} strokeWidth="8" />
    <path d="M0 1080 L1080 1080 L1080 1920 L0 1920 Z" fill="#5b3a1f" />
    <path d="M0 1080 L1080 1080" stroke={OL} strokeWidth="8" />
  </svg>
);

/* Row of round bronze shields seen from behind the line (no faces). */
const ShieldWall: React.FC<{y: number; n?: number; x0?: number; gap?: number; r?: number; brace?: number}> = ({y, n = 5, x0 = 300, gap = 100, r = 62, brace = 0}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {new Array(n).fill(0).map((_, i) => {
        const bob = Math.sin(frame / 7 + i) * 3 - brace * 10;
        return <div key={i} style={{position: 'absolute', left: x0 + i * gap, top: y + bob, width: r * 2, height: r * 2, borderRadius: '50%', background: `radial-gradient(circle at 40% 35%, #e9c27a, ${BRONZE} 60%, #7c5320)`, border: `7px solid ${OL}`}}>
          <div style={{position: 'absolute', left: r * 0.45, top: r * 0.4, fontFamily: DISPLAY, fontSize: r * 0.95, color: '#7f1d1d'}}>Λ</div>
        </div>;
      })}
    </>
  );
};

/* Forest of enemy spear tips advancing from the far side (adv 0..1 moves them closer). */
const Spears: React.FC<{adv: number; y: number; n?: number}> = ({adv, y, n = 26}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {new Array(n).fill(0).map((_, i) => {
        const col = i % 13;
        const row = Math.floor(i / 13);
        const sway = Math.sin(frame / 9 + i * 1.3) * 4;
        return <div key={i} style={{position: 'absolute', left: 280 + col * 40 + row * 20 + sway, top: y - row * 40 + adv * 60, width: 6, height: 200, background: '#1c1917'}}>
          <div style={{position: 'absolute', left: -9, top: -26, width: 0, height: 0, borderLeft: '12px solid transparent', borderRight: '12px solid transparent', borderBottom: '30px solid #d6d3d1'}} />
        </div>;
      })}
    </>
  );
};

const Mystery: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 300 * s, height: 420 * s}}>
    <div style={{position: 'absolute', left: 80 * s, top: 0, width: 140 * s, height: 150 * s, borderRadius: '50%', background: '#0c0a09'}} />
    <div style={{position: 'absolute', left: 20 * s, top: 130 * s, width: 260 * s, height: 290 * s, borderRadius: `${120 * s}px ${120 * s}px ${30 * s}px ${30 * s}px`, background: '#0c0a09'}} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 10 * s, textAlign: 'center', fontFamily: DISPLAY, fontSize: 120 * s, color: '#fbbf24'}}>?</div>
  </div>
);

/* Original cartoon Greek king (reveal only): bronze helmet with a tall red crest, cheek guards, short dark beard, red cloak. */
const King: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <svg style={{position: 'absolute', left: x, top: y}} width={340 * s} height={480 * s} viewBox="0 0 340 480">
    <path d="M30 480 L60 260 Q170 215 280 260 L310 480 Z" fill="#b91c1c" stroke={OL} strokeWidth="8" />
    <path d="M110 260 Q170 240 230 260 L220 330 Q170 350 120 330 Z" fill={BRONZE} stroke={OL} strokeWidth="6" />
    <ellipse cx="170" cy="150" rx="70" ry="86" fill="#e8b98f" stroke={OL} strokeWidth="8" />
    <path d="M108 170 Q170 250 232 170 Q228 215 170 232 Q112 215 108 170 Z" fill="#3b2314" stroke={OL} strokeWidth="6" />
    <path d="M90 150 Q86 50 170 46 Q254 50 250 150 L232 196 L224 130 L116 130 L108 196 Z" fill={BRONZE} stroke={OL} strokeWidth="8" />
    <path d="M166 130 L174 130 L176 178 L164 178 Z" fill={BRONZE} stroke={OL} strokeWidth="5" />
    <circle cx="142" cy="148" r="8" fill={OL} /><circle cx="198" cy="148" r="8" fill={OL} />
    <path d="M128 132 L154 128 M186 128 L212 132" stroke={OL} strokeWidth="6" strokeLinecap="round" />
    <path d="M100 56 Q170 -30 240 56 Q206 20 170 20 Q134 20 100 56 Z" fill="#dc2626" stroke={OL} strokeWidth="7" />
    <path d="M150 196 Q170 206 190 196" stroke={OL} strokeWidth="5" fill="none" strokeLinecap="round" />
  </svg>
);

/* passHook (Arm A): frame 0 = the payoff picture already moving — a line of shields holding the narrow pass as a forest of spears advances;
   sound-off tags "480 BC" + "TWO WORDS. NO SURRENDER."; punch-in at 1.2 s; on "two" the shields brace (camera kick). */
const PassHook: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.twoOnWord, fps, dur * 0.8);
  const adv = kf(frame, [[0, 0.2], [dur, 1, EASE.smooth]]);
  const brace = kf(frame, [[tAt, 0], [tAt + 6, 1, EASE.out]]);
  const cam = {x: 540, y: kf(frame, [[0, 900], [36, 840, EASE.smooth]]), zoom: (frame < 36 ? 1.0 : 1.18) + kf(frame, [[36, 0], [dur, 0.06, EASE.smooth]]) + impulses(frame, [36, tAt + 3], 0.05, 12, 1.4), roll: impulse(frame, tAt + 3, 1.4, 14, 1.1)};
  return (
    <Pass>
      <CameraRig cam={cam}>
        <Layer depth={0.5}><div style={{position: 'absolute', left: 440, top: 260, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, #fde68a, rgba(253,230,138,0) 70%)'}} /></Layer>
        <Layer depth={0.75}><Spears adv={adv} y={640} /></Layer>
        <Layer depth={0.9}><Cliffs /></Layer>
        <Layer depth={1}>
          <ShieldWall y={930} n={5} x0={300} gap={100} r={64} brace={brace} />
          <Particles count={18} color="#fcd34d" size={8} speedY={-0.5} speedX={0.8} seed={9} opacity={0.55} />
        </Layer>
      </CameraRig>
      <Tag text="480 BC" a={0} y={300} size={70} color="#fcd34d" />
      <Tag text="TWO WORDS. NO SURRENDER." a={5} y={450} size={50} color="#fca5a5" rot={2} />
      <SeriesBadge text={BADGE} />
    </Pass>
  );
};

/* hugeArmy: { fewOnWord, riversOnWord } — the small shield line (A FEW THOUSAND) vs an endless spear sea; a river shrinks to a trickle; LEGEND? tag. */
const HugeArmy: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fAt = at(captions, scene.fewOnWord, fps, dur * 0.2);
  const rAt = at(captions, scene.riversOnWord, fps, dur * 0.8);
  const river = kf(frame, [[rAt - 4, 1], [rAt + 20, 0.08, EASE.in]]);
  const cam = {x: kf(frame, [[0, 420], [dur, 660, EASE.smooth]]), y: 800, zoom: kf(frame, [[0, 1.2], [dur, 1.0, EASE.smooth]]) + impulse(frame, rAt + 4, 0.05, 12, 1.4)};
  return (
    <Pass bg="linear-gradient(180deg, #fbbf24 0%, #92400e 45%, #292524 100%)">
      <CameraRig cam={cam}>
        <Layer depth={0.7}>
          {[0, 1, 2, 3].map((k) => <div key={k} style={{translate: `${k * 60 - 60}px 0px`}}><Spears adv={0} y={560 + k * 90} n={26} /></div>)}
          <div style={{position: 'absolute', left: 620, top: 1000, width: 400 * river + 20, height: 60, background: '#38bdf8', border: `5px solid ${OL}`, borderRadius: 30}} />
        </Layer>
        <Layer depth={1}>
          <div style={{position: 'absolute', left: 0, right: 0, top: 1080, height: 840, background: '#5b3a1f', borderTop: `8px solid ${OL}`}} />
          <ShieldWall y={1000} n={3} x0={60} gap={90} r={52} />
        </Layer>
      </CameraRig>
      <Tag text="A FEW THOUSAND" a={fAt} y={1180} size={48} color="#fcd34d" rot={-2} />
      <Tag text="DRANK RIVERS DRY? (LEGEND)" a={rAt} y={300} size={48} color="#e9d5ff" rot={2} />
    </Pass>
  );
};

/* twoWords: { comeOnWord, writerOnWord } — a scroll unrolls "COME AND TAKE THEM"; then a stamp "WRITTEN ~600 YEARS LATER". */
const TwoWords: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.comeOnWord, fps, dur * 0.35);
  const wAt = at(captions, scene.writerOnWord, fps, dur * 0.75);
  const unroll = kf(frame, [[cAt - 4, 0.1], [cAt + 10, 1, EASE.out]]);
  const cam = {x: 540, y: 820, zoom: kf(frame, [[0, 1.0], [dur, 1.14, EASE.smooth]]) + impulses(frame, [cAt + 4, wAt + 4], 0.05, 12, 1.4)};
  return (
    <Pass bg="radial-gradient(circle at 50% 40%, #92400e, #1c0a02 75%)">
      <CameraRig cam={cam}>
        <Layer depth={1}>
          <div style={{position: 'absolute', left: 140, top: 560, width: 800, height: 420 * unroll + 40, background: '#fef3c7', border: `8px solid ${OL}`, borderRadius: 16, overflow: 'hidden'}}>
            <div style={{position: 'absolute', left: 0, right: 0, top: 50, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 40, color: '#92400e', letterSpacing: 6}}>ΜΟΛΩΝ ΛΑΒΕ</div>
            <div style={{position: 'absolute', left: 0, right: 0, top: 130, textAlign: 'center', fontFamily: DISPLAY, fontSize: 104, color: '#7f1d1d', lineHeight: 1.0}}>COME AND<br />TAKE THEM</div>
          </div>
          <div style={{position: 'absolute', left: 120, top: 520, width: 840, height: 60, borderRadius: 30, background: '#d6a45c', border: `7px solid ${OL}`}} />
          <Mystery x={60} y={980} s={0.55} />
        </Layer>
      </CameraRig>
      <Tag text="SO WHAT DID HE SAY?" a={2} y={300} size={56} color="#fcd34d" />
      <Tag text="WRITTEN ~600 YEARS LATER" a={wAt} y={1180} size={48} color="#e9d5ff" rot={-3} />
    </Pass>
  );
};

/* secretPath: { daysOnWord, pathOnWord } — 3 tally marks (DAY 1-3) hold; then a dotted path lights up over the mountain behind the shields. */
const SecretPath: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dAt = at(captions, scene.daysOnWord, fps, dur * 0.15);
  const pAt = at(captions, scene.pathOnWord, fps, dur * 0.7);
  const draw = kf(frame, [[pAt - 10, 0], [pAt + 20, 1, EASE.smooth]]);
  const cam = {x: kf(frame, [[0, 540], [dur, 620, EASE.smooth]]), y: kf(frame, [[0, 860], [dur, 780, EASE.smooth]]), zoom: kf(frame, [[0, 1.05], [dur, 1.15, EASE.smooth]]) + impulse(frame, pAt + 4, 0.05, 12, 1.4)};
  return (
    <Pass bg="linear-gradient(180deg, #1e1b4b 0%, #4c1d95 40%, #1c0a02 100%)">
      <CameraRig cam={cam}>
        <Layer depth={0.8}>
          <svg style={{position: 'absolute', left: 0, top: 0}} width={1080} height={1920}>
            <path d="M560 1080 L860 420 L1080 520 L1080 1080 Z" fill="#3f2a1d" stroke={OL} strokeWidth="8" />
            <path d="M1060 560 Q930 520 880 640 Q820 780 700 820 Q600 860 560 980" fill="none" stroke="#facc15" strokeWidth="12" strokeDasharray="26 20" pathLength={1} strokeDashoffset={0} style={{strokeDasharray: `${draw} 1`}} />
          </svg>
        </Layer>
        <Layer depth={1}>
          <Cliffs />
          <ShieldWall y={930} n={4} x0={170} gap={95} r={56} />
          {[0, 1, 2].map((i) => frame >= dAt + i * 8 ? <div key={i} style={{position: 'absolute', left: 140 + i * 70, top: 640, width: 18, height: 120, background: '#fef3c7', border: `4px solid ${OL}`, rotate: '6deg'}} /> : null)}
        </Layer>
      </CameraRig>
      <Tag text="3 DAYS. THE PASS HELD." a={dAt} y={300} size={54} color="#fcd34d" />
      <Tag text="A SECRET PATH" a={pAt} y={1180} size={58} color="#fca5a5" rot={2} />
    </Pass>
  );
};

/* stayedBehind: { awayOnWord, stayedOnWord } — most shields march off-screen left; a small line stays; tag 300 + ALLIES WHO WOULDN'T LEAVE. */
const StayedBehind: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const aAt = at(captions, scene.awayOnWord, fps, dur * 0.2);
  const sAt = at(captions, scene.stayedOnWord, fps, dur * 0.5);
  const leave = kf(frame, [[aAt, 0], [aAt + 30, 1, EASE.in]]);
  const cam = {x: 540, y: 860, zoom: kf(frame, [[0, 1.0], [dur, 1.2, EASE.smooth]]) + impulse(frame, sAt + 3, 0.05, 12, 1.4)};
  return (
    <Pass>
      <CameraRig cam={cam}>
        <Layer depth={0.9}><Cliffs /></Layer>
        <Layer depth={1}>
          <div style={{translate: `${-leave * 900}px 0px`, opacity: 1 - leave * 0.7}}><ShieldWall y={800} n={6} x0={260} gap={90} r={44} /></div>
          <ShieldWall y={950} n={4} x0={330} gap={100} r={58} brace={kf(frame, [[sAt, 0], [sAt + 6, 1, EASE.out]])} />
          <Mystery x={420} y={560} s={0.75} />
        </Layer>
      </CameraRig>
      {frame >= aAt ? <Tag text="MOST SENT HOME" a={aAt} y={300} size={52} color="#e2e8f0" rot={-2} /> : null}
      <Tag text="300 + ALLIES WHO WOULDN'T LEAVE" a={sAt + 6} y={1180} size={44} color="#fcd34d" rot={2} />
    </Pass>
  );
};

/* leonidasReveal: { nameOnWord, sendOnWord } — silhouette pops into the original cartoon king; name card; Ragnarok line; send line; pill; loops into "480 BC". */
const LeonidasReveal: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nAt = at(captions, scene.nameOnWord, fps, dur * 0.3);
  const sAt = at(captions, scene.sendOnWord, fps, dur * 0.6);
  const pop = spring({frame: frame - nAt, fps, config: {damping: 9}});
  const cam = {x: 540, y: 860, zoom: kf(frame, [[0, 1.06], [nAt, 1.0, EASE.smooth], [dur, 1.08, EASE.smooth]]) + impulse(frame, nAt + 2, 0.06, 14, 1.3)};
  return (
    <Pass>
      <CameraRig cam={cam}>
        <Layer depth={0.9}><Cliffs /></Layer>
        <Layer depth={1}>
          <ShieldWall y={960} n={2} x0={110} gap={110} r={50} />
          {frame < nAt ? <Mystery x={380} y={580} s={1.2} /> : <div style={{scale: String(0.6 + 0.4 * pop), transformOrigin: '540px 900px'}}><King x={370} y={560} s={1.05} /></div>}
          <Particles count={14} color="#fcd34d" size={9} speedY={-0.7} speedX={0.3} seed={21} opacity={frame >= nAt ? 0.6 : 0} />
        </Layer>
      </CameraRig>
      {frame >= nAt ? <Tag text="LEONIDAS OF SPARTA" a={nAt} y={1100} size={84} color="#fcd34d" rot={-2} /> : null}
      {frame >= nAt + 8 ? <div style={{position: 'absolute', left: 60, right: 160, top: 1250, textAlign: 'center', whiteSpace: 'nowrap'}}><span style={{fontFamily: BODY, fontWeight: 800, fontSize: 32, color: '#fff7ed', background: 'rgba(0,0,0,0.55)', padding: '6px 18px', borderRadius: 12}}>⚔️ the real man behind a Record of Ragnarok fighter</span></div> : null}
      {frame >= sAt ? <div style={{position: 'absolute', left: 50, right: 150, top: 330, textAlign: 'center', lineHeight: 1.5}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 33, color: '#111', background: '#86efac', padding: '8px 18px', whiteSpace: 'nowrap', borderRadius: 14, border: `5px solid ${OL}`}}>📤 Send this to the friend who never backs down</span></div> : null}
      <DailyPill from={Math.round(sAt + 10)} y={500} />
      <SeriesBadge text={BADGE} />
      <Syn x={790} y={860} size={180} pose="shock" from={Math.round(nAt + 6)} to={dur} />
    </Pass>
  );
};

export const HISTORY12_SCENES: Record<string, React.FC<SceneProps>> = {passHook: PassHook, hugeArmy: HugeArmy, twoWords: TwoWords, secretPath: SecretPath, stayedBehind: StayedBehind, leonidasReveal: LeonidasReveal};
