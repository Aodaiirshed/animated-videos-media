import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {DailyPill, SeriesBadge, Syn} from '../components/Host';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles, Trail} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Guess Who: History #13 · Ragnarok's Real Humans #5 — Raiden Tameemon (1767–1825), sumo.
   Verified (Wikipedia, Guinness, Tachiai, Modern Rogue): 254 wins / 10 losses, 96.2 % = best winning percentage in sumo history;
   ~21-year career (1789/90–1811); farm family in rural Shinano; ~197 cm; ozeki, never yokozuna — reason unknown, theory: clan politics.
   Legend-flagged: "banned his best moves" ("the story goes" in VO + THE STORY SAYS on screen).
   Mini adventure: the ring → the rivals preparing → the charge → the payoff. Identity lock: the giant is a faceless, hairless
   black silhouette seen from behind until the reveal. Animation kit v2. */
const OL = '#120b06';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const BADGE = 'GUESS WHO: HISTORY #13';
const NIGHT = 'linear-gradient(180deg, #1c1030 0%, #3b1d2e 35%, #5b2a1a 70%, #2a120a 100%)';
const CLAY = '#c9925a';

const Tag: React.FC<{text: string; a: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, y, color = '#ffcc4d', size = 62, rot = -3}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < a) return null;
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: 40, right: 140, top: y, textAlign: 'center', scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`, boxShadow: `0 8px 0 ${OL}`, whiteSpace: 'nowrap'}}>{text}</span>
    </div>
  );
};

/* Arena: hanging roof with tassels, swinging paper lanterns, crowd silhouettes, the raised clay ring (straw circle). */
const Roof: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <svg style={{position: 'absolute', left: 0, top: 0}} width={1080} height={520}>
        <path d="M60 300 L540 150 L1020 300 L960 330 L120 330 Z" fill="#3b2316" stroke={OL} strokeWidth={8} />
        <rect x={120} y={330} width={840} height={36} fill="#7c2d12" stroke={OL} strokeWidth={6} />
      </svg>
      {[150, 930].map((x, i) => <div key={i} style={{position: 'absolute', left: x - 18, top: 360, width: 36, height: 90, borderRadius: 18, background: i ? '#dc2626' : '#2563eb', border: `5px solid ${OL}`, rotate: `${Math.sin(frame / 20 + i) * 4}deg`, transformOrigin: '50% 0'}} />)}
    </>
  );
};
const Lanterns: React.FC<{y?: number}> = ({y = 520}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {[90, 330, 750, 990].map((x, i) => (
        <div key={i} style={{position: 'absolute', left: x - 34, top: y + (i % 2) * 40, width: 68, height: 92, rotate: `${Math.sin(frame / 16 + i * 1.7) * 6}deg`, transformOrigin: '50% -40px'}}>
          <div style={{position: 'absolute', left: -60, top: -60, width: 188, height: 212, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,180,80,0.45), transparent 65%)', opacity: 0.8 + Math.sin(frame / 5 + i) * 0.2}} />
          <div style={{position: 'absolute', inset: 0, borderRadius: 30, background: '#fbbf24', border: `5px solid ${OL}`}} />
          <div style={{position: 'absolute', left: 10, right: 10, top: 30, height: 6, background: '#b45309'}} />
          <div style={{position: 'absolute', left: 10, right: 10, top: 56, height: 6, background: '#b45309'}} />
        </div>
      ))}
    </>
  );
};
const Crowd: React.FC<{y: number; cheer?: number}> = ({y, cheer = 0}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {new Array(15).fill(0).map((_, i) => {
        const b = Math.sin(frame / (5 + (i % 4)) + i) * (3 + cheer * 14) - cheer * Math.abs(Math.sin(frame / 4 + i)) * 12;
        return <div key={i} style={{position: 'absolute', left: -20 + i * 76, top: y + (i % 3) * 18 + b, width: 70, height: 140}}>
          <div style={{position: 'absolute', left: 17, top: 0, width: 36, height: 36, borderRadius: 18, background: '#1a0f14'}} />
          <div style={{position: 'absolute', left: 4, top: 30, width: 62, height: 110, borderRadius: '30px 30px 6px 6px', background: '#1a0f14'}} />
        </div>;
      })}
    </>
  );
};
const Ring: React.FC<{y?: number}> = ({y = 1040}) => (
  <>
    <div style={{position: 'absolute', left: -60, right: -60, top: y, height: 420, background: CLAY, borderTop: `8px solid ${OL}`, clipPath: 'polygon(8% 0, 92% 0, 100% 100%, 0 100%)'}} />
    <div style={{position: 'absolute', left: 120, width: 840, top: y + 40, height: 240, borderRadius: '50%', border: `16px solid #e7d49a`, boxShadow: `0 0 0 5px ${OL}`}} />
    <div style={{position: 'absolute', left: 430, top: y + 140, width: 70, height: 10, background: '#f5f5f4'}} />
    <div style={{position: 'absolute', left: 580, top: y + 140, width: 70, height: 10, background: '#f5f5f4'}} />
  </>
);

/* The mystery giant: faceless black silhouette from behind (no hair), with a dark belt. lean = forward lunge angle, breathe = 0..1. */
const Giant: React.FC<{x: number; y: number; s?: number; lean?: number; breathe?: number; arms?: number}> = ({x, y, s = 1, lean = 0, breathe = 0, arms = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 360 * s, height: 560 * s, rotate: `${lean}deg`, transformOrigin: '50% 100%', scale: `1 ${1 + breathe * 0.02}`}}>
    <svg width={360 * s} height={560 * s} viewBox="0 0 360 560" style={{overflow: 'visible'}}>
      <ellipse cx={180} cy={90} rx={62} ry={66} fill="#0b0708" />
      <path d={`M40 ${200 - arms * 40} Q0 ${300 - arms * 60} 10 ${360 - arms * 110}`} stroke="#0b0708" strokeWidth={58} strokeLinecap="round" fill="none" />
      <path d={`M320 ${200 - arms * 40} Q360 ${300 - arms * 60} 350 ${360 - arms * 110}`} stroke="#0b0708" strokeWidth={58} strokeLinecap="round" fill="none" />
      <ellipse cx={180} cy={300} rx={150} ry={170} fill="#0b0708" />
      <rect x={40} y={370} width={280} height={60} rx={14} fill="#2b1a3d" />
      <path d="M90 430 L70 560 L150 560 L160 440 Z M270 430 L290 560 L210 560 L200 440 Z" fill="#0b0708" />
      <ellipse cx={180} cy={300} rx={150} ry={170} fill="none" stroke="#fbbf24" strokeWidth={4} opacity={0.35} />
    </svg>
  </div>
);

/* An original cartoon rival wrestler (not the mystery): topknot, belt colour, side view. kick = leg lift 0..1, salt = arm throw 0..1. */
const Rival: React.FC<{x: number; y: number; s?: number; belt?: string; kick?: number; salt?: number; rot?: number; face?: number}> = ({x, y, s = 1, belt = '#1d4ed8', kick = 0, salt = 0, rot = 0, face = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 300 * s, height: 480 * s, rotate: `${rot}deg`, transformOrigin: '50% 80%'}}>
    <svg width={300 * s} height={480 * s} viewBox="0 0 300 480" style={{overflow: 'visible'}}>
      <g transform={`rotate(${-kick * 55} 120 360)`}><path d="M120 360 L95 470 L150 470 L150 370 Z" fill="#e0a77a" stroke={OL} strokeWidth={6} /></g>
      <path d="M180 360 L200 470 L150 470 L150 370 Z" fill="#e0a77a" stroke={OL} strokeWidth={6} />
      <ellipse cx={150} cy={260} rx={120} ry={130} fill="#eab58a" stroke={OL} strokeWidth={7} />
      <rect x={34} y={300} width={232} height={54} rx={12} fill={belt} stroke={OL} strokeWidth={6} />
      <circle cx={150} cy={100} r={62} fill="#eab58a" stroke={OL} strokeWidth={7} />
      <path d="M95 80 Q150 30 205 80 L200 64 Q150 26 100 64 Z" fill="#1c1917" stroke={OL} strokeWidth={4} />
      <ellipse cx={150} cy={40} rx={26} ry={14} fill="#1c1917" stroke={OL} strokeWidth={4} />
      <circle cx={130} cy={104} r={7} fill={OL} /><circle cx={172} cy={104} r={7} fill={OL} />
      <path d={face > 0.5 ? 'M128 136 Q150 120 174 136' : 'M130 132 L172 132'} stroke={OL} strokeWidth={6} fill="none" strokeLinecap="round" />
      <path d={face > 0.5 ? 'M118 86 L142 94 M184 86 L160 94' : 'M118 90 L142 88 M184 90 L160 88'} stroke={OL} strokeWidth={6} strokeLinecap="round" />
      <g transform={`rotate(${-salt * 150} 60 200)`}><path d="M60 200 L20 300" stroke="#eab58a" strokeWidth={40} strokeLinecap="round" /><path d="M60 200 L20 300" stroke={OL} strokeWidth={4} fill="none" opacity={0.3} /></g>
      <path d="M240 200 L280 300" stroke="#eab58a" strokeWidth={40} strokeLinecap="round" />
    </svg>
  </div>
);

/* Dust puff at (x, y) starting at frame a. */
const Dust: React.FC<{x: number; y: number; a: number}> = ({x, y, a}) => {
  const frame = useCurrentFrame();
  const d = frame - a;
  if (d < 0 || d > 24) return null;
  return <>{new Array(7).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: x + Math.cos(i) * d * 6 - 20, top: y - Math.abs(Math.sin(i * 2)) * d * 3 - 20, width: 40 + d * 2, height: 40 + d * 2, borderRadius: '50%', background: '#e7c9a0', opacity: 0.6 * (1 - d / 24)}} />)}</>;
};

const Arena: React.FC<{cam: {x: number; y: number; zoom: number; roll?: number}; cheer?: number; children: React.ReactNode; fg?: React.ReactNode}> = ({cam, cheer = 0, children, fg}) => (
  <AbsoluteFill style={{background: NIGHT}}>
    <CameraRig cam={cam}>
      <Layer depth={0.45} blur={1.5}><Crowd y={700} cheer={cheer} /></Layer>
      <Layer depth={0.7}><Roof /><Lanterns /></Layer>
      <Layer depth={1}><Ring />{children}</Layer>
      <Layer depth={1.35} blur={2}>{fg}</Layer>
    </CameraRig>
  </AbsoluteFill>
);

/* ringHook (Arm B): frame 1 is already the shove — a rival flies backwards out of the ring past the faceless giant; punch-in at 1.2 s;
   "10 LOSSES · 21 YEARS" on "ten"; on "banned" a scroll "HIS BEST MOVES" gets a red ✗ + "THE STORY SAYS". */
const RingHook: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tenOnWord, fps, dur * 0.4);
  const bAt = at(captions, scene.bannedOnWord, fps, dur * 0.8);
  const fly = kf(frame, [[0, 0.1], [26, 0.62, EASE.out]]);
  const cam = {x: kf(frame, [[0, 560], [36, 620, EASE.smooth], [dur, 600, EASE.smooth]]), y: kf(frame, [[0, 960], [36, 1000, EASE.smooth]]), zoom: (frame < 36 ? 1.0 : 1.25) + kf(frame, [[36, 0], [dur, 0.06, EASE.smooth]]) + impulses(frame, [4, 36, bAt + 3], 0.05, 12, 1.4), roll: impulse(frame, 4, 2, 14, 1.1)};
  const scroll = kf(frame, [[bAt - 10, 0], [bAt - 2, 1, EASE.overshoot]]);
  return (
    <>
      <Arena cam={cam} cheer={kf(frame, [[0, 1], [30, 0.3]])} fg={<Particles count={10} color="#fde68a" size={8} speedY={-0.5} speedX={0.4} seed={7} opacity={0.5} />}>
        <Giant x={170} y={640} s={1.05} lean={kf(frame, [[0, 18], [16, 8, EASE.out], [dur, 6]])} arms={kf(frame, [[0, 1], [18, 0.3, EASE.smooth]])} breathe={Math.sin(frame / 8)} />
        <Trail dx={frame < 24 ? 30 : 0} dy={frame < 24 ? -8 : 0}><Rival x={540 + fly * 420 + kf(frame, [[36, 0], [60, 420, EASE.in]])} y={700 - Math.sin(fly * Math.PI * 0.8) * 120 + kf(frame, [[24, 0], [34, 120, EASE.in]])} s={0.95} rot={fly * 60 + kf(frame, [[24, 0], [34, 30, EASE.out]])} face={1} /></Trail>
        <Dust x={860} y={1200} a={32} />
      </Arena>
      {frame >= tAt ? <Tag text="10 LOSSES. 21 YEARS." a={tAt} y={300} size={58} color="#fcd34d" /> : null}
      {scroll > 0 ? <div style={{position: 'absolute', left: 300, top: 480, width: 480, height: 150, scale: String(scroll), rotate: '-3deg', background: '#fef3c7', border: `6px solid ${OL}`, borderRadius: 12, textAlign: 'center', fontFamily: DISPLAY, fontSize: 56, lineHeight: '140px', color: OL}}>
        HIS BEST MOVES
        {frame >= bAt ? <div style={{position: 'absolute', inset: 0, fontSize: 170, lineHeight: '140px', color: '#dc2626', scale: String(kf(frame, [[bAt, 2], [bAt + 6, 1, EASE.out]]))}}>✗</div> : null}
      </div> : null}
      {frame >= bAt ? <Tag text="THE STORY SAYS…" a={bAt + 4} y={660} size={40} color="#e2e8f0" rot={3} /> : null}
      <SeriesBadge text={BADGE} from={60} />
    </>
  );
};

/* farmBoy: tilt down from mountain peaks to rice terraces; a tiny far-away figure walks with a carrying pole; on "grows" he grows
   (years tick 1767 → 1784); on "two" a height ruler pops "197 CM". */
const FarmBoy: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.growOnWord, fps, dur * 0.6);
  const hAt = at(captions, scene.tallOnWord, fps, dur * 0.8);
  const grow = kf(frame, [[0, 0.9], [gAt, 0.9], [hAt + 6, 2.2, EASE.smooth]]);
  const walk = frame * 2.2;
  const cam = {x: 540, y: kf(frame, [[0, 600], [gAt, 960, EASE.smooth], [dur, 1000, EASE.smooth]]), zoom: kf(frame, [[0, 1.15], [dur, 1.05, EASE.smooth]]) + impulse(frame, hAt + 3, 0.04, 12, 1.4)};
  return (
    <AbsoluteFill style={{background: 'linear-gradient(180deg, #fb923c 0%, #fcd34d 30%, #86efac 70%, #166534 100%)'}}>
      <CameraRig cam={cam}>
        <Layer depth={0.35}><svg width={1080} height={1920} style={{position: 'absolute'}}><path d="M-100 700 L200 260 L420 620 L650 200 L1000 640 L1200 500 L1200 1920 L-100 1920 Z" fill="#7c6a9c" /><path d="M200 260 L250 340 L150 340 Z M650 200 L710 300 L590 300 Z" fill="#f8fafc" /></svg></Layer>
        <Layer depth={0.6}><svg width={1080} height={1920} style={{position: 'absolute'}}><path d="M-100 900 Q300 700 600 860 T1200 800 L1200 1920 L-100 1920 Z" fill="#4d7c0f" /></svg></Layer>
        <Layer depth={1}>
          {[1000, 1120, 1240, 1360].map((y, i) => <div key={i} style={{position: 'absolute', left: -100, right: -100, top: y, height: 110, background: i % 2 ? '#65a30d' : '#84cc16', borderTop: `6px solid #3f6212`}} />)}
          <div style={{position: 'absolute', left: 260 + Math.min(walk, 200), top: 1100, width: 120, height: 240, scale: String(grow), transformOrigin: '50% 100%'}}>
            <div style={{position: 'absolute', left: 38, top: 0, width: 44, height: 44, borderRadius: 22, background: '#1c1917'}} />
            <div style={{position: 'absolute', left: 26, top: 40, width: 68, height: 120, borderRadius: 30, background: '#1c1917'}} />
            <div style={{position: 'absolute', left: -50, top: 54, width: 220, height: 8, background: '#78350f', rotate: `${Math.sin(frame / 4) * 4}deg`}} />
            <div style={{position: 'absolute', left: -60, top: 60, width: 34, height: 34, background: '#a16207', borderRadius: 6}} />
            <div style={{position: 'absolute', left: 146, top: 60, width: 34, height: 34, background: '#a16207', borderRadius: 6}} />
            <div style={{position: 'absolute', left: 34, top: 150, width: 18, height: 90, background: '#1c1917', rotate: `${Math.sin(frame / 3) * 18}deg`, transformOrigin: '50% 0'}} />
            <div style={{position: 'absolute', left: 66, top: 150, width: 18, height: 90, background: '#1c1917', rotate: `${-Math.sin(frame / 3) * 18}deg`, transformOrigin: '50% 0'}} />
          </div>
          {frame >= hAt ? <div style={{position: 'absolute', left: 820, top: 1360 - 300 * kf(frame, [[hAt, 0], [hAt + 10, 1, EASE.out]]), width: 26, height: 300 * kf(frame, [[hAt, 0], [hAt + 10, 1, EASE.out]]), background: '#fef3c7', border: `5px solid ${OL}`}} /> : null}
        </Layer>
      </CameraRig>
      <Tag text="JAPAN · 1780s" a={2} y={300} size={54} color="#fef3c7" rot={-2} />
      {frame >= gAt ? <div style={{position: 'absolute', left: 60, top: 420, fontFamily: DISPLAY, fontSize: 70, color: '#fff', textShadow: `0 5px 0 ${OL}`}}>{Math.round(kf(frame, [[gAt, 1767], [hAt, 1784]]))}</div> : null}
      {frame >= hAt ? <div style={{position: 'absolute', left: 600, top: 760}}><Tag text="197 CM" a={hAt} y={0} size={74} color="#fcd34d" rot={3} /></div> : null}
    </AbsoluteFill>
  );
};

/* rivalsPrep: lantern-lit arena, camera arcs; the rival throws salt (white arc) on "salt", stamps on "stamp" (camera jolt);
   the giant's back stays still, only breathing; on "waits" a slow push onto him + heartbeat. */
const RivalsPrep: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.saltOnWord, fps, dur * 0.3);
  const kAt = at(captions, scene.stampOnWord, fps, dur * 0.5);
  const wAt = at(captions, scene.waitOnWord, fps, dur * 0.8);
  const salt = kf(frame, [[sAt - 6, 0], [sAt + 4, 1, EASE.out], [sAt + 18, 0.2]]);
  const kick = kf(frame, [[kAt - 10, 0], [kAt - 2, 1, EASE.out], [kAt + 3, 0, EASE.in]]);
  const cam = {x: kf(frame, [[0, 720], [wAt, 560, EASE.smooth], [dur, 420, EASE.smooth]]), y: kf(frame, [[0, 900], [dur, 980, EASE.smooth]]), zoom: kf(frame, [[0, 1.1], [wAt, 1.15], [dur, 1.45, EASE.smooth]]) + impulse(frame, kAt + 2, 0.06, 14, 1.4), roll: kf(frame, [[0, 1.5], [dur, -1, EASE.smooth]])};
  return (
    <>
      <Arena cam={cam} cheer={0.2}>
        <Giant x={120} y={640} s={1.05} breathe={Math.sin(frame / 10)} lean={2} />
        <Rival x={640} y={690} s={0.9} belt="#15803d" salt={salt} kick={kick} face={0} />
        {frame >= sAt - 2 && frame < sAt + 30 ? new Array(26).fill(0).map((_, i) => {
          const d = frame - (sAt - 2);
          return <div key={i} style={{position: 'absolute', left: 660 - d * (6 + (i % 5)), top: 780 - d * 9 + d * d * (0.45 + (i % 3) * 0.08) + i * 3, width: 20, height: 20, borderRadius: 10, background: '#fff', boxShadow: '0 0 8px #fff', opacity: Math.max(0, 1 - d / 30)}} />;
        }) : null}
        <Dust x={700} y={1160} a={kAt} />
      </Arena>
      {frame >= wAt ? <Tag text="HE JUST WAITS." a={wAt} y={300} size={56} color="#e2e8f0" /> : null}
    </>
  );
};

/* theCharge: whip pan + charge on "charge"; rivals fly out one after another ("again and again"); a win counter rolls to 254. */
const TheCharge: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.chargeOnWord, fps, dur * 0.2);
  const aAt = at(captions, scene.againOnWord, fps, dur * 0.5);
  const wAt = at(captions, scene.winsOnWord, fps, dur * 0.75);
  const hits = [cAt, aAt + 4, aAt + 20];
  const belts = ['#b91c1c', '#0e7490', '#a16207'];
  const lunge = kf(frame, [[cAt - 4, 0], [cAt + 6, 1, EASE.out], [cAt + 20, 0.4]]) + kf(frame, [[aAt, 0], [aAt + 6, 0.6, EASE.out], [aAt + 26, 0.3]]);
  const count = Math.round(kf(frame, [[0, 0], [wAt - 2, 120], [wAt + 24, 254, EASE.out]]));
  const cam = {x: kf(frame, [[0, 300], [cAt, 360], [cAt + 6, 620, EASE.out], [dur, 660, EASE.smooth]]), y: 960, zoom: kf(frame, [[0, 1.3], [cAt, 1.3], [cAt + 8, 1.05, EASE.out], [dur, 1.0]]) + impulses(frame, hits.map((h) => h + 4), 0.05, 12, 1.4), roll: impulses(frame, hits.map((h) => h + 4), 1.4, 12, 1.1)};
  return (
    <>
      <Arena cam={cam} cheer={frame > cAt ? 1 : 0.4} fg={frame > cAt ? <Particles count={12} color="#fde68a" size={10} speedY={-1} speedX={0.6} seed={9} opacity={0.6} /> : null}>
        <Giant x={140 + lunge * 160} y={640} s={1.05} lean={8 + lunge * 14} arms={0.3 + lunge * 0.6} breathe={0} />
        {hits.map((h, i) => {
          const fly = kf(frame, [[h, 0], [h + 14, 1, EASE.out]]);
          if (i > 0 && frame < h - 12) return null;
          if (frame > h + 22) return null;
          const enter = i > 0 ? kf(frame, [[h - 12, 1.4], [h - 2, 0, EASE.out]]) : 0;
          return <Trail key={i} dx={fly > 0 && fly < 0.9 ? 40 : 0}><Rival x={560 + enter * 500 + fly * 600} y={690 - Math.sin(fly * Math.PI) * 100} s={0.9} belt={belts[i]} rot={fly * 50} face={fly > 0 ? 1 : 0} /></Trail>;
        })}
        {hits.map((h, i) => <Dust key={i} x={1000} y={1170} a={h + 10} />)}
      </Arena>
      {frame >= wAt - 2 ? <div style={{position: 'absolute', left: 60, right: 160, top: 300, textAlign: 'center', fontFamily: DISPLAY, fontSize: 150, color: '#fcd34d', textShadow: `0 8px 0 ${OL}`, scale: String(1 + impulse(frame, wAt + 24, 0.15, 12, 1.2))}}>{count}<span style={{fontSize: 70}}> WINS</span></div> : null}
    </>
  );
};

/* neverTop: the white champion's rope lowers towards the giant; "Never." — it's yanked away, NEVER stamp; "argue" → question marks;
   "theory?" → two rival clan banners clash, chip "THEORY: RIVAL CLANS". Camera tilts up with the rope, then down. */
const NeverTop: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nAt = at(captions, scene.neverOnWord, fps, dur * 0.4);
  const aAt = at(captions, scene.argueOnWord, fps, dur * 0.6);
  const tAt = at(captions, scene.theoryOnWord, fps, dur * 0.8);
  const ropeY = kf(frame, [[0, 120], [nAt - 2, 470, EASE.smooth], [nAt + 10, -300, EASE.in]]);
  const clash = kf(frame, [[tAt, 0], [tAt + 10, 1, EASE.overshoot]]);
  const cam = {x: 540, y: kf(frame, [[0, 640], [nAt, 760, EASE.smooth], [tAt, 900, EASE.smooth], [dur, 920]]), zoom: kf(frame, [[0, 1.2], [dur, 1.05, EASE.smooth]]) + impulses(frame, [nAt + 3, tAt + 8], 0.05, 12, 1.4)};
  return (
    <>
      <Arena cam={cam} cheer={0}>
        <Giant x={360} y={640} s={1.05} breathe={Math.sin(frame / 10)} arms={frame > nAt ? 0 : 0.2} />
        <svg width={600} height={160} style={{position: 'absolute', left: 240, top: ropeY, overflow: 'visible'}}>
          <path d="M20 40 Q300 150 580 40" stroke="#f8fafc" strokeWidth={46} fill="none" strokeLinecap="round" />
          <path d="M20 40 Q300 150 580 40" stroke="#cbd5e1" strokeWidth={10} strokeDasharray="22 18" fill="none" />
          {[200, 300, 400].map((x) => <path key={x} d={`M${x} ${95 + (x === 300 ? 10 : 0)} l-14 50 l14 -10 l14 10 Z`} fill="#fef9c3" stroke={OL} strokeWidth={3} />)}
          <line x1={300} y1={-900} x2={300} y2={60} stroke="#78716c" strokeWidth={4} />
        </svg>
        {frame >= aAt ? [0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 200 + i * 300, top: 560 - ((frame - aAt) * 2 + i * 30) % 120, fontFamily: DISPLAY, fontSize: 90, color: '#fcd34d', opacity: 0.85, rotate: `${Math.sin(frame / 4 + i) * 15}deg`}}>?</div>) : null}
        {clash > 0 ? <>
          <div style={{position: 'absolute', left: kf(frame, [[tAt, -200], [tAt + 10, 250, EASE.overshoot]]), top: 760, width: 180, height: 300, background: '#1e3a8a', border: `6px solid ${OL}`, rotate: '-10deg'}}><div style={{margin: '80px auto', width: 90, height: 90, borderRadius: '50%', border: '12px solid #fef3c7'}} /></div>
          <div style={{position: 'absolute', left: kf(frame, [[tAt, 1100], [tAt + 10, 650, EASE.overshoot]]), top: 760, width: 180, height: 300, background: '#7f1d1d', border: `6px solid ${OL}`, rotate: '10deg'}}><div style={{margin: '80px auto', width: 90, height: 90, background: '#fef3c7', rotate: '45deg'}} /></div>
        </> : null}
      </Arena>
      <Tag text="GRAND CHAMPION?" a={3} y={300} size={56} color="#f8fafc" rot={-2} />
      {frame >= nAt ? <Tag text="NEVER." a={nAt} y={420} size={110} color="#fca5a5" rot={4} /> : null}
      {frame >= tAt ? <Tag text="THEORY: RIVAL CLANS" a={tAt + 4} y={1150} size={50} color="#e2e8f0" rot={-2} /> : null}
    </>
  );
};

/* Original cartoon sumo wrestler for the reveal: big kind face, topknot, purple belt, arms crossed. */
const Raiden: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => {
  const frame = useCurrentFrame();
  return (
    <svg style={{position: 'absolute', left: x, top: y + Math.sin(frame / 12) * 4}} width={380 * s} height={560 * s} viewBox="0 0 380 560">
      <ellipse cx={190} cy={350} rx={170} ry={180} fill="#d9a27a" stroke={OL} strokeWidth={8} />
      <rect x={30} y={410} width={320} height={70} rx={16} fill="#5b21b6" stroke={OL} strokeWidth={7} />
      <path d="M60 300 Q190 380 320 300" stroke="#c48a63" strokeWidth={60} strokeLinecap="round" fill="none" />
      <path d="M60 300 Q190 380 320 300" stroke={OL} strokeWidth={6} fill="none" opacity={0.5} />
      <circle cx={190} cy={150} r={86} fill="#e3ae86" stroke={OL} strokeWidth={8} />
      <path d="M112 120 Q190 50 268 120 L262 96 Q190 40 118 96 Z" fill="#111" stroke={OL} strokeWidth={5} />
      <ellipse cx={190} cy={60} rx={34} ry={18} fill="#111" stroke={OL} strokeWidth={5} />
      <path d="M148 140 L176 136 M204 136 L232 140" stroke={OL} strokeWidth={8} strokeLinecap="round" />
      {frame % 100 < 4 ? <><line x1={150} y1={160} x2={172} y2={160} stroke={OL} strokeWidth={6} /><line x1={208} y1={160} x2={230} y2={160} stroke={OL} strokeWidth={6} /></> : <><circle cx={161} cy={160} r={9} fill={OL} /><circle cx={219} cy={160} r={9} fill={OL} /></>}
      <path d="M160 200 Q190 222 220 200" stroke={OL} strokeWidth={7} fill="none" strokeLinecap="round" />
      <circle cx={140} cy={190} r={12} fill="#f0a08a" opacity={0.6} /><circle cx={240} cy={190} r={12} fill="#f0a08a" opacity={0.6} />
    </svg>
  );
};

/* raidenReveal: silhouette turns to face us and pops into the original cartoon wrestler; 96 % chip, name card, Ragnarok line,
   silent send line, pill, Syn; loops into "For twenty-one years…". */
const RaidenReveal: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pAt = at(captions, scene.pctOnWord, fps, dur * 0.3);
  const nAt = at(captions, scene.nameOnWord, fps, dur * 0.6);
  const sAt = nAt + 10;
  const pop = spring({frame: frame - nAt, fps, config: {damping: 9}});
  const cam = {x: 540, y: kf(frame, [[0, 980], [dur, 900, EASE.smooth]]), zoom: kf(frame, [[0, 1.18], [nAt, 1.0, EASE.smooth], [dur, 1.06, EASE.smooth]]) + impulse(frame, nAt + 2, 0.06, 14, 1.3)};
  return (
    <>
      <Arena cam={cam} cheer={frame >= nAt ? 1 : 0.3} fg={<Particles count={14} color="#fcd34d" size={9} speedY={-0.7} speedX={0.3} seed={21} opacity={frame >= nAt ? 0.6 : 0.2} />}>
        {frame < nAt ? <Giant x={360} y={640} s={1.05} breathe={Math.sin(frame / 10)} /> : <div style={{scale: String(0.6 + 0.4 * pop), transformOrigin: '540px 1200px'}}><Raiden x={320} y={560} s={1.15} /></div>}
      </Arena>
      {frame >= pAt ? <Tag text="254–10 · 96%" a={pAt} y={1130} size={56} color="#fcd34d" rot={2} /> : null}
      {frame >= nAt ? <Tag text="RAIDEN TAMEEMON" a={nAt} y={530} size={80} color="#fcd34d" rot={-2} /> : null}
      {frame >= nAt + 8 ? <div style={{position: 'absolute', left: 60, right: 160, top: 1250, textAlign: 'center', whiteSpace: 'nowrap'}}><span style={{fontFamily: BODY, fontWeight: 800, fontSize: 28, color: '#fff7ed', background: 'rgba(0,0,0,0.55)', padding: '6px 16px', borderRadius: 12}}>⚔️ the real man behind a Record of Ragnarok fighter</span></div> : null}
      {frame >= sAt ? <div style={{position: 'absolute', left: 50, right: 150, top: 330, textAlign: 'center', lineHeight: 1.5}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 32, color: '#111', background: '#86efac', padding: '8px 16px', whiteSpace: 'nowrap', borderRadius: 14, border: `5px solid ${OL}`}}>📤 Send this to the friend who never loses at anything</span></div> : null}
      <DailyPill from={Math.round(sAt + 10)} y={430} />
      <SeriesBadge text={BADGE} />
      <Syn x={790} y={860} size={180} pose="shock" from={Math.round(nAt + 6)} to={dur} />
    </>
  );
};

export const HISTORY13_SCENES: Record<string, React.FC<SceneProps>> = {ringHook: RingHook, farmBoy: FarmBoy, rivalsPrep: RivalsPrep, theCharge: TheCharge, neverTop: NeverTop, raidenReveal: RaidenReveal};
