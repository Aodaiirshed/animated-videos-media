import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* History scenes, set 3 (cartoon, steppe): steppeLeft, riverFish, woodCollar, tribesUnite, empireGrow, furReveal, crowd200. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Steppe: React.FC<{sky?: string}> = ({sky}) => (
  <>
    <AbsoluteFill style={{background: sky ?? 'linear-gradient(180deg, #fdba74 0%, #fde68a 58%, #a3b86c 59%, #65803a 100%)'}} />
    <svg width={1080} height={400} style={{position: 'absolute', top: 760}}><path d="M0 400 V260 Q200 120 380 240 Q560 80 760 230 Q920 140 1080 250 V400 Z" fill="#8a9a5b" stroke={OL} strokeWidth={8} /></svg>
    <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#5b6b2f', borderTop: `10px solid ${OL}`}} />
  </>
);

const Yurt: React.FC<{x: number; y: number; w: number}> = ({x, y, w}) => (
  <svg width={w} height={w * 0.75} viewBox="0 0 400 300" style={{position: 'absolute', left: x - w / 2, top: y - w * 0.75}}>
    <path d="M30 150 Q200 20 370 150 Z" fill="#e7e5e4" stroke={OL} strokeWidth={12} strokeLinejoin="round" /><rect x={40} y={150} width={320} height={140} fill="#f5f5f4" stroke={OL} strokeWidth={12} />
    <path d="M40 190 H360 M40 240 H360" stroke="#b45309" strokeWidth={8} /><rect x={170} y={180} width={64} height={110} fill="#b45309" stroke={OL} strokeWidth={9} /><circle cx={200} cy={70} r={14} fill="#b45309" stroke={OL} strokeWidth={7} />
  </svg>
);

/* A rider seen from the side, galloping right. */
const Rider: React.FC<{x: number; y: number; s?: number; seed?: number}> = ({x, y, s = 1, seed = 0}) => {
  const frame = useCurrentFrame();
  const g = Math.sin(frame / 2 + seed);
  return (
    <svg width={260 * s} height={220 * s} viewBox="0 0 260 220" style={{position: 'absolute', left: x - 130 * s, top: y - 220 * s + Math.abs(g) * -10, overflow: 'visible'}}>
      {[60, 90, 170, 200].map((lx, i) => <rect key={i} x={lx - 9} y={130} width={18} height={70} rx={8} fill="#3f2a14" stroke={OL} strokeWidth={6} transform={`rotate(${(i % 2 ? 1 : -1) * g * 28} ${lx} 130)`} />)}
      <ellipse cx={130} cy={120} rx={88} ry={40} fill="#6b4423" stroke={OL} strokeWidth={8} /><path d="M196 104 Q214 50 236 46 L256 66 Q236 96 224 124 Z" fill="#6b4423" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
      <path d="M46 110 Q10 120 14 170" fill="none" stroke={OL} strokeWidth={14} strokeLinecap="round" />
      <rect x={104} y={40} width={50} height={64} rx={16} fill="#475569" stroke={OL} strokeWidth={8} /><circle cx={129} cy={26} r={24} fill="#e3b98a" stroke={OL} strokeWidth={8} /><path d="M104 20 Q129 -14 154 20 Z" fill="#7c2d12" stroke={OL} strokeWidth={7} />
    </svg>
  );
};

/* steppeLeft: { age?, tag, tagOnWord?, leaveOnWord?, tag2?, tag2OnWord? } — riders gallop off across the steppe, leaving a boy and his mother by one lonely tent. */
const SteppeLeft: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 14), go = at(captions, scene.leaveOnWord, fps, dur * 0.4), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.8);
  const run = Math.max(0, frame - go);
  return (
    <Shake at={0} amount={24}>
      <Shake at={t2} amount={18}>
        <Camera dur={dur} from={1.25} to={1.0}>
          <Steppe />
          <div style={{position: 'absolute', left: 760, top: 420, width: 190, height: 190, borderRadius: '50%', background: '#fff3c4', boxShadow: '0 0 120px #fde68a'}} />
          {[0, 1, 2, 3, 4].map((i) => <Rider key={i} x={640 + i * 95 + run * (16 + i * 2)} y={1110 + (i % 2) * 70 - i * 10} s={1.25 - i * 0.08} seed={i * 1.3} />)}
          {run > 0 ? [0, 1, 2, 3].map((i) => { const p = ((frame + i * 6) % 22) / 22; return <div key={i} style={{position: 'absolute', left: 560 + run * 14 - i * 80 - p * 60, top: 1100 - p * 50, width: 60 + p * 80, height: 60 + p * 80, borderRadius: '50%', background: '#fef3c7', opacity: 0.55 * (1 - p)}} />; }) : null}
          <Yurt x={200} y={1290} w={330} />
          <Boy x={470} y={1350} height={560} stage="adult" hair="long" skin="#steppe-mum-13" rim="#fff" glow={0.2} mood="sad" />
          <Boy x={300} y={1370} height={380} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={frame >= go ? 'cry' : 'sad'} />
          {scene.age ? <Tag text={scene.age as string} at={0} x={280} y={230} size={110} color="#fff" rot={-4} /> : null}
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={410} size={80} color="#a3e635" rot={3} /> : null}
          {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={580} size={104} color="#ef4444" fg="#fff" rot={-3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* riverFish: { items: [{text,onWord}] } — the boy fishes a cold river with a stick and line; what they lived on pops up. */
const RiverFish: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const items = (scene.items as {text: string; onWord?: string}[]) ?? [];
  const jump = (frame % 50) / 50;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <Steppe sky="linear-gradient(180deg, #93c5fd 0%, #dbeafe 58%, #a3b86c 59%, #65803a 100%)" />
      <div style={{position: 'absolute', left: 380, top: 1150, width: 800, height: 800, background: 'linear-gradient(180deg, #38bdf8, #0369a1)', borderTop: `10px solid ${OL}`, borderLeft: `10px solid ${OL}`, borderRadius: '120px 0 0 0'}} />
      {[0, 1, 2, 3, 4].map((i) => <div key={i} style={{position: 'absolute', left: 460 + ((i * 150 + frame * 2) % 600), top: 1210 + i * 36, width: 80, height: 9, borderRadius: 5, background: '#ffffff88'}} />)}
      <Boy x={250} y={1300} height={460} stage="child" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood="determined" />
      <svg width={520} height={420} style={{position: 'absolute', left: 290, top: 820}}><path d="M20 300 L400 40" stroke={OL} strokeWidth={16} strokeLinecap="round" /><path d="M20 300 L400 40" stroke="#92400e" strokeWidth={8} strokeLinecap="round" /><path d={`M400 40 Q${430 + Math.sin(frame / 6) * 10} 200 420 380`} fill="none" stroke="#fff" strokeWidth={5} /></svg>
      <svg width={130} height={70} viewBox="0 0 130 70" style={{position: 'absolute', left: 760, top: 1180 - Math.sin(jump * Math.PI) * 170, rotate: `${-60 + jump * 120}deg`, opacity: jump < 0.95 ? 1 : 0}}>
        <path d="M10 35 Q50 0 96 35 Q50 70 10 35 Z" fill="#fb923c" stroke={OL} strokeWidth={8} /><path d="M92 35 L124 10 V60 Z" fill="#fb923c" stroke={OL} strokeWidth={8} strokeLinejoin="round" /><circle cx={34} cy={30} r={6} fill="#111" />
      </svg>
      {items.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 10 + i * 16)} x={[330, 720, 540][i % 3]} y={250 + i * 165} size={92} color={['#fde68a', '#f472b6', '#7dd3fc'][i % 3]} rot={[-5, 4, -2][i % 3]} />)}
    </Camera>
  );
};

/* woodCollar: { tag, tagOnWord?, escapeOnWord, tag2? } — night camp; the teen stands locked in a heavy wooden neck-board, then bolts into the dark. */
const WoodCollar: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 12), eAt = at(captions, scene.escapeOnWord, fps, dur * 0.7);
  const esc = frame >= eAt, run = Math.max(0, frame - eAt);
  const X = 540 + run * 16, Y = 1340, Hh = 560, neck = Y - Hh * 0.72;
  return (
    <Shake at={eAt} amount={20}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #020617, #1e1b4b 60%, #172554)'}} />
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`s${i}`) * 1080, top: random(`sy${i}`) * 800, width: 6, height: 6, borderRadius: 3, background: '#fff', opacity: 0.4 + 0.4 * Math.sin(frame / 8 + i)}} />)}
        <div style={{position: 'absolute', left: 120, top: 330, width: 150, height: 150, borderRadius: '50%', background: '#e0e7ff', boxShadow: '0 0 80px #c7d2fe'}} />
        <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#1c1917', borderTop: `10px solid ${OL}`}} />
        <Yurt x={170} y={1290} w={300} />
        {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 850 + i * 30, top: 1210 - Math.abs(Math.sin(frame / 3 + i)) * 60, width: 50, height: 70 + Math.abs(Math.sin(frame / 3 + i)) * 60, borderRadius: '50% 50% 30% 30%', background: i === 1 ? '#fde047' : '#fb923c', border: `5px solid ${OL}`}} />)}
        <div style={{position: 'absolute', left: 820, top: 1260, width: 180, height: 26, background: '#78350f', border: `6px solid ${OL}`, rotate: '8deg'}} />
        <Boy x={X} y={Y} height={Hh} stage="teen" pose={esc ? 'run' : 'stand'} phase={frame / 1.6} skin={sb.character.palette.skin} rim="#c7d2fe" glow={0.6} mood={esc ? 'determined' : 'sad'} />
        {!esc ? <div style={{position: 'absolute', left: X - 230, top: neck - 40, width: 460, height: 96, background: '#a16207', border: `10px solid ${OL}`, borderRadius: 14, boxShadow: `0 8px 0 ${OL}`}}>
          <div style={{position: 'absolute', left: 226, top: 0, width: 8, height: 76, background: OL}} />{[30, 400].map((l) => <div key={l} style={{position: 'absolute', left: l, top: 24, width: 28, height: 28, borderRadius: '50%', background: '#44403c', border: `5px solid ${OL}`}} />)}
        </div> : <div style={{position: 'absolute', left: 310, top: 1210 + Math.min(run * 6, 40), width: 460, height: 96, background: '#a16207', border: `10px solid ${OL}`, borderRadius: 14, rotate: `${Math.min(run * 3, 24)}deg`, opacity: 0.95}}><div style={{position: 'absolute', left: 200, top: -10, width: 60, height: 96, background: '#1c1917', rotate: '20deg'}} /></div>}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={84} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={eAt} y={430} size={110} color="#4ade80" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* tribesUnite: { count?, joinOnWord?, tag, tagOnWord? } — small coloured banners race in from every side and stack behind one tall banner. */
const TribesUnite: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const n = (scene.count as number) ?? 10, jAt = at(captions, scene.joinOnWord, fps, 10), tAt = at(captions, scene.tagOnWord, fps, dur * 0.7);
  const cols = ['#ef4444', '#3b82f6', '#22c55e', '#f59e0b', '#a855f7', '#ec4899', '#14b8a6'];
  return (
    <Shake at={tAt} amount={20}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <Steppe sky="linear-gradient(180deg, #7dd3fc 0%, #e0f2fe 58%, #a3b86c 59%, #65803a 100%)" />
        {new Array(n).fill(0).map((_, i) => { const a = jAt + i * 4, p = interpolate(frame, [a, a + 14], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)}); const side = i % 2 ? 1 : -1; const tx = 540 + side * (150 + Math.floor(i / 2) * 78), sx = 540 + side * 800; const x = sx + (tx - sx) * p; const h = 330 - Math.floor(i / 2) * 18;
          return <div key={i} style={{position: 'absolute', left: x - 6, top: 1290 - h, opacity: frame >= a ? 1 : 0}}><div style={{width: 12, height: h, background: '#78350f', border: `4px solid ${OL}`}} /><div style={{position: 'absolute', left: side > 0 ? 12 : -84, top: 6, width: 84, height: 60, background: frame >= tAt ? '#1d4ed8' : cols[i % cols.length], border: `6px solid ${OL}`, rotate: `${Math.sin(frame / 4 + i) * 6}deg`}} /></div>; })}
        <div style={{position: 'absolute', left: 532, top: 560}}><div style={{width: 18, height: 740, background: '#78350f', border: `5px solid ${OL}`}} /><div style={{position: 'absolute', left: 18, top: 10, width: 230, height: 150, background: '#1d4ed8', border: `9px solid ${OL}`, rotate: `${Math.sin(frame / 5) * 4}deg`, transformOrigin: '0 0'}}><div style={{margin: '36px auto', width: 70, height: 70, borderRadius: '50%', background: '#fde047', border: `7px solid ${OL}`}} /></div></div>
        <Boy x={420} y={1350} height={520} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.7} mood={frame >= tAt ? 'laugh' : 'determined'} pose={frame >= tAt ? 'cheer' : 'stand'} phase={frame / 4} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={260} size={100} color="#fde047" rot={-3} /> : null}
        {scene.year ? <Tag text={scene.year as string} at={tAt + 8} y={430} size={76} color="#fff" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* empireGrow: { growOnWord?, tag, tagOnWord?, sub? } — a red tide swells outward from one point until it floods the whole map. */
const EmpireGrow: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.growOnWord, fps, 6), tAt = at(captions, scene.tagOnWord, fps, dur * 0.55);
  const r = interpolate(frame, [gAt, tAt + 6], [30, 760], {...clamp, easing: (t) => t * t * (3 - 2 * t)});
  const land = 'M40 720 Q120 560 300 600 Q420 500 600 560 Q760 480 900 560 Q1050 600 1050 780 Q1060 940 940 1000 Q860 1120 720 1060 Q600 1020 520 1090 Q420 1200 300 1160 Q200 1130 190 1030 Q70 990 50 870 Q20 780 40 720 Z';
  return (
    <Shake at={tAt} amount={22}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0ea5e9, #0c4a6e)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <defs><clipPath id="eg-land"><path d={land} /></clipPath></defs>
          <path d={land} fill="#fde68a" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
          <g clipPath="url(#eg-land)"><circle cx={760} cy={700} r={r} fill="#ef4444" /><circle cx={760} cy={700} r={r} fill="none" stroke="#fff" strokeWidth={8} opacity={0.7} /></g>
          <path d={land} fill="none" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
          <circle cx={760} cy={700} r={20} fill="#fff" stroke={OL} strokeWidth={8} />
          {[[420, 760], [250, 900], [600, 940], [900, 860]].map((p, i) => <path key={i} d="M0 0 l-26 -14 v28 z" transform={`translate(${p[0]} ${p[1]}) rotate(${[0, -20, 40, 200][i]})`} fill="#fff" stroke={OL} strokeWidth={6} opacity={Math.hypot(p[0] - 760, p[1] - 700) < r ? 1 : 0} />)}
        </svg>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={240} size={88} color="#fde047" rot={-3} /> : null}
        {scene.sub ? <Tag text={scene.sub as string} at={tAt + 8} y={400} size={70} color="#fff" rot={2} /> : null}
      </Camera>
    </Shake>
  );
};

const FurHat: React.FC<{cx: number; by: number; w: number; rot?: number}> = ({cx, by, w, rot = 0}) => (
  <svg width={w} height={w * 0.8} viewBox="0 0 200 160" style={{position: 'absolute', left: cx - w / 2, top: by - w * 0.8, rotate: `${rot}deg`, overflow: 'visible'}}>
    <path d="M40 110 Q46 30 100 26 Q154 30 160 110 Z" fill="#b91c1c" stroke={OL} strokeWidth={9} strokeLinejoin="round" /><circle cx={100} cy={20} r={14} fill="#fbbf24" stroke={OL} strokeWidth={7} />
    <path d="M100 34 V100" stroke="#fbbf24" strokeWidth={7} />
    <path d="M10 118 Q4 92 34 96 Q50 80 70 94 Q86 78 104 92 Q122 78 138 94 Q158 82 170 98 Q200 94 192 120 Q204 148 172 146 Q150 160 130 146 Q110 160 90 146 Q66 160 48 146 Q10 152 10 118 Z" fill="#78350f" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
  </svg>
);

/* furReveal: { first, last, onWord } — spotlight; a fur-trimmed hat drops onto the hero and the name slams in. */
const FurReveal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.onWord, fps, dur * 0.5);
  const s = spring({frame: frame - rAt, fps, config: {damping: 8, stiffness: 150}});
  const bg = interpolate(frame, [rAt - 2, rAt + 10], [0, 1], clamp), flash = interpolate(frame - rAt, [0, 2, 12], [0, 1, 0], clamp);
  const X = 540, Y = 1330, Hh = 580, top = Y - Hh * 0.985, R = Hh * 0.126;
  const words = [(scene.first as string) ?? '', (scene.last as string) ?? ''];
  return (
    <Shake at={rAt} amount={28}>
      <AbsoluteFill style={{background: '#06060a'}} />
      <AbsoluteFill style={{opacity: bg * 0.75, background: 'repeating-conic-gradient(from 0deg at 50% 56%, #1e3a8a 0 11.25deg, #1d4ed8 11.25deg 22.5deg)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 56%, rgba(0,0,0,0) 0%, rgba(0,0,0,0.85) 72%)'}} />
      <div style={{position: 'absolute', left: 240, top: 0, width: 600, height: 1400, background: 'linear-gradient(180deg, rgba(254,249,195,0.28), transparent)', clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.9} mood={frame >= rAt ? 'happy' : 'neutral'} />
      {frame < rAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 360, textAlign: 'center', fontFamily: DISPLAY, fontSize: 300, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', scale: String(1 + Math.sin(frame / 5) * 0.06)}}>?</div> : null}
      <div style={{opacity: frame >= rAt - 6 ? 1 : 0}}><FurHat cx={X} by={top + R * 0.95 - (1 - s) * 700} w={R * 3.1} rot={(1 - s) * -30} /></div>
      <div style={{position: 'absolute', top: 170, width: '100%', textAlign: 'center'}}>
        {words.map((w, wi) => (
          <div key={wi} style={{display: 'flex', justifyContent: 'center'}}>
            {w.split('').map((ch, ci) => { const ls = spring({frame: frame - rAt - 4 - (wi * 5 + ci * 1.4), fps, config: {damping: 11, stiffness: 220}}); return (
              <span key={ci} style={{fontFamily: DISPLAY, fontSize: wi ? 210 : 200, lineHeight: 1.06, color: wi ? '#fde047' : '#fff', display: 'inline-block', translate: `0px ${(1 - ls) * 120}px`, opacity: ls, WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{ch}</span>); })}
          </div>
        ))}
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

/* crowd200: { hitOnWord?, tag, tagOnWord?, note?, cta?, ctaOnWord? } — a grid of 200 little people fills in; one lights up gold. */
const Crowd200: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const hAt = at(captions, scene.hitOnWord, fps, dur * 0.4), tAt = at(captions, scene.tagOnWord, fps, dur * 0.45), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.85);
  const hit = 87;
  return (
    <Shake at={hAt} amount={16}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #312e81, #4338ca 60%, #312e81)'}} />
        <div style={{position: 'absolute', left: 90, top: 500, width: 900, display: 'grid', gridTemplateColumns: 'repeat(20, 45px)', rowGap: 16}}>
          {new Array(200).fill(0).map((_, i) => { const on = frame > 2 + i * 0.16, gold = i === hit && frame >= hAt; return (
            <div key={i} style={{width: 36, height: 56, opacity: on ? 1 : 0, scale: gold ? String(1.9 + Math.sin(frame / 4) * 0.2) : '1', zIndex: gold ? 2 : 0, position: 'relative'}}>
              <div style={{margin: '0 auto', width: 20, height: 20, borderRadius: '50%', background: gold ? '#fde047' : '#a5b4fc', border: `3px solid ${OL}`}} /><div style={{margin: '2px auto 0', width: 28, height: 30, borderRadius: '10px 10px 4px 4px', background: gold ? '#fde047' : '#818cf8', border: `3px solid ${OL}`}} />
            </div>); })}
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={230} size={110} color="#fde047" rot={-3} /> : null}
        {scene.note ? <Tag text={scene.note as string} at={tAt + 10} y={400} size={46} color="#fff" rot={0} /> : null}
        {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={1290} size={80} color="#ef4444" fg="#fff" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

export const HISTORY3_SCENES: Record<string, React.FC<SceneProps>> = {
  steppeLeft: SteppeLeft,
  riverFish: RiverFish,
  woodCollar: WoodCollar,
  tribesUnite: TribesUnite,
  empireGrow: EmpireGrow,
  furReveal: FurReveal,
  crowd200: Crowd200,
};
