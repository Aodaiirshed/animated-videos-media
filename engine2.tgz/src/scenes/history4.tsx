import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* History scenes, set 4 (cartoon, winter): snowEyes, farmSmall, invadeMap, snowTricks, dayCount, hospitalWake, hoodReveal, oldPractice. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Snow: React.FC<{n?: number; wind?: number}> = ({n = 70, wind = 6}) => {
  const frame = useCurrentFrame();
  return <>{new Array(n).fill(0).map((_, i) => { const sp = 5 + random(`sv${i}`) * 9; return <div key={i} style={{position: 'absolute', left: ((random(`sx${i}`) * 1300 + frame * wind * (0.6 + random(`sw${i}`))) % 1300) - 110, top: ((random(`sy${i}`) * 2000 + frame * sp) % 2000) - 40, width: 8 + random(`sr${i}`) * 12, height: 8 + random(`sr${i}`) * 12, borderRadius: '50%', background: '#fff', opacity: 0.85}} />; })}</>;
};

const Pines: React.FC<{y: number}> = ({y}) => (
  <>{[40, 210, 380, 700, 880, 1030].map((x, i) => <svg key={i} width={200} height={360} viewBox="0 0 200 360" style={{position: 'absolute', left: x - 100, top: y - 360 + (i % 2) * 20, scale: String(0.8 + (i % 3) * 0.18)}}>
    <rect x={88} y={280} width={24} height={80} fill="#78350f" stroke={OL} strokeWidth={7} />
    {[0, 1, 2].map((k) => <path key={k} d={`M100 ${20 + k * 80} L${170 + k * 10} ${150 + k * 70} H${30 - k * 10} Z`} fill="#166534" stroke={OL} strokeWidth={8} strokeLinejoin="round" />)}
    {[0, 1, 2].map((k) => <path key={k} d={`M100 ${20 + k * 80} L${130 + k * 4} ${76 + k * 80} Q100 ${60 + k * 80} ${70 - k * 4} ${76 + k * 80} Z`} fill="#fff" />)}
  </svg>)}</>
);

/* snowEyes: { temp, eyesOnWord?, tag?, tagOnWord? } — a blizzard; a snowbank that turns out to have two eyes. */
const SnowEyes: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const eAt = at(captions, scene.eyesOnWord, fps, dur * 0.55), tAt = at(captions, scene.tagOnWord, fps, dur * 0.8);
  const open = interpolate(frame, [eAt, eAt + 5], [0, 1], clamp), blink = (frame - eAt) % 50 > 46 ? 0.1 : 1;
  return (
    <Shake at={0} amount={24}>
      <Shake at={eAt} amount={18}>
        <Camera dur={dur} from={1.0} to={1.35}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #94a3b8, #e2e8f0 55%, #f8fafc)'}} />
          <Pines y={1010} />
          <div style={{position: 'absolute', left: 0, top: 1000, width: 1080, height: 1000, background: '#f8fafc', borderTop: `8px solid #cbd5e1`}} />
          <svg width={1080} height={520} style={{position: 'absolute', top: 760}}><path d="M120 520 Q200 220 420 190 Q560 120 700 200 Q900 240 960 520 Z" fill="#fff" stroke="#cbd5e1" strokeWidth={10} /></svg>
          {[470, 610].map((x) => <div key={x} style={{position: 'absolute', left: x - 34, top: 1010 - 30 * open * blink, width: 68, height: 60 * open * blink, borderRadius: '50%', background: '#fff', border: `7px solid ${OL}`, overflow: 'hidden'}}><div style={{position: 'absolute', left: 20, top: 12 * open, width: 30, height: 30, borderRadius: '50%', background: '#1e3a8a'}} /></div>)}
          <Snow n={90} wind={14} />
          <Tag text={(scene.temp as string) ?? '−40°'} at={0} y={250} size={170} color="#bae6fd" rot={-4} />
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={520} size={84} color="#ef4444" fg="#fff" rot={3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* farmSmall: { tags: [{text,onWord}], height, heightOnWord? } — a quiet farm; a small man beside a height ruler. */
const FarmSmall: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string}[]) ?? [];
  const hAt = at(captions, scene.heightOnWord, fps, dur * 0.65);
  const X = 420, Y = 1330, Hh = 430;
  return (
    <Camera dur={dur} from={1.06} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #7dd3fc 0%, #e0f2fe 60%, #86efac 61%, #16a34a 100%)'}} />
      <div style={{position: 'absolute', left: 640, top: 700, width: 380, height: 480, background: '#b91c1c', border: `10px solid ${OL}`}}><div style={{position: 'absolute', left: 120, bottom: 0, width: 140, height: 230, background: '#7f1d1d', border: `9px solid ${OL}`}} /><div style={{position: 'absolute', left: 150, top: 60, width: 80, height: 80, background: '#fef3c7', border: `8px solid ${OL}`}} /></div>
      <div style={{position: 'absolute', left: 600, top: 560, width: 0, height: 0, borderLeft: '230px solid transparent', borderRight: '230px solid transparent', borderBottom: '150px solid #7f1d1d'}} />
      <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#15803d', borderTop: `10px solid ${OL}`}} />
      {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 30 + i * 80, top: 1180, width: 22, height: 110, background: '#a16207', border: `6px solid ${OL}`}} />)}<div style={{position: 'absolute', left: 20, top: 1210, width: 300, height: 20, background: '#a16207', border: `6px solid ${OL}`}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood="happy" />
      <div style={{position: 'absolute', left: X + 150, top: Y - Hh, width: 14, height: Hh, background: '#fde047', border: `5px solid ${OL}`, opacity: frame >= hAt ? 1 : 0}} />
      <div style={{position: 'absolute', left: X - 130, top: Y - Hh - 6, width: 300, height: 10, background: '#ef4444', borderRadius: 5, opacity: frame >= hAt ? 1 : 0}} />
      <Tag text={(scene.height as string) ?? ''} at={hAt} x={X + 30} y={Y - Hh - 170} size={110} color="#fde047" rot={-3} />
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 8 + i * 16)} x={i ? 720 : 330} y={240 + i * 150} size={88} color={i ? '#fdba74' : '#fff'} rot={i ? 3 : -4} />)}
    </Camera>
  );
};

/* invadeMap: { year, big, small, pushOnWord? } — a huge red block rolls toward a tiny blue one. */
const InvadeMap: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pAt = at(captions, scene.pushOnWord, fps, dur * 0.5);
  const p = interpolate(frame, [pAt, pAt + 20], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)});
  return (
    <Shake at={pAt + 16} amount={22}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b, #334155)'}} />
        <Snow n={40} wind={4} />
        <div style={{position: 'absolute', left: 430 - p * 130, top: 560, width: 640, height: 640, background: '#dc2626', border: `12px solid ${OL}`, borderRadius: 40, boxShadow: `0 16px 0 ${OL}`}}>
          <div style={{fontFamily: DISPLAY, fontSize: 96, color: '#fff', textAlign: 'center', marginTop: 40}}>{(scene.big as string) ?? ''}</div>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 16, padding: '10px 40px'}}>{new Array(30).fill(0).map((_, i) => <div key={i} style={{height: 54, borderRadius: 12, background: '#7f1d1d', border: `5px solid ${OL}`, translate: `${Math.sin(frame / 3 + i) * 3}px 0px`}} />)}</div>
        </div>
        <div style={{position: 'absolute', left: 60, top: 800 + Math.sin(frame / 2) * p * 6, width: 230, height: 230, background: '#2563eb', border: `12px solid ${OL}`, borderRadius: 30, boxShadow: `0 12px 0 ${OL}`}}>
          <div style={{fontFamily: DISPLAY, fontSize: 52, color: '#fff', textAlign: 'center', marginTop: 20, lineHeight: 1.05}}>{(scene.small as string) ?? ''}</div>
          <div style={{display: 'flex', gap: 10, justifyContent: 'center', marginTop: 12}}>{[0, 1, 2].map((i) => <div key={i} style={{width: 44, height: 44, borderRadius: 10, background: '#1e3a8a', border: `5px solid ${OL}`}} />)}</div>
        </div>
        <Tag text={(scene.year as string) ?? ''} at={0} y={250} size={140} color="#fff" rot={-3} />
      </Camera>
    </Shake>
  );
};

/* snowTricks: { tricks: [{title, sub, onWord, icon: suit|snow|scope}] } — the hero in white lies in a snowbank; three trick cards slam in. */
const SnowTricks: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tr = (scene.tricks as {title: string; sub?: string; onWord?: string; icon: string}[]) ?? [];
  return (
    <Camera dur={dur} from={1.0} to={1.06}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #bfdbfe, #eff6ff 60%, #fff)'}} />
      <Pines y={1130} />
      <div style={{position: 'absolute', left: 0, top: 1120, width: 1080, height: 900, background: '#f8fafc', borderTop: '8px solid #cbd5e1'}} />
      <Boy x={540} y={1360} height={420} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.3} mood="determined" />
      <svg width={1080} height={300} style={{position: 'absolute', top: 1200}}><path d="M220 300 Q300 120 460 150 Q560 100 660 150 Q800 130 860 300 Z" fill="#fff" stroke="#cbd5e1" strokeWidth={9} /></svg>
      <Snow n={40} wind={5} />
      {tr.map((t, i) => { const a = at(captions, t.onWord, fps, 10 + i * 40), s = spring({frame: frame - a, fps, config: {damping: 9, stiffness: 190}}); return (
        <div key={i} style={{position: 'absolute', left: 90, top: 230 + i * 215, width: 900, height: 180, borderRadius: 30, border: `10px solid ${OL}`, boxShadow: `0 12px 0 ${OL}`, background: ['#fff', '#bae6fd', '#fde047'][i % 3], opacity: frame >= a ? 1 : 0, scale: String(1.5 - s * 0.5), rotate: `${[-2, 2, -1][i % 3]}deg`, display: 'flex', alignItems: 'center', gap: 30, padding: '0 34px'}}>
          <svg width={120} height={120} viewBox="0 0 120 120">
            {t.icon === 'suit' ? <><path d="M30 110 V60 Q30 34 60 34 Q90 34 90 60 V110 Z" fill="#fff" stroke={OL} strokeWidth={8} /><path d="M32 46 Q34 8 60 8 Q86 8 88 46 Q60 30 32 46 Z" fill="#fff" stroke={OL} strokeWidth={8} /><circle cx={60} cy={40} r={14} fill="#f1c9a5" stroke={OL} strokeWidth={6} /></> : null}
            {t.icon === 'snow' ? <g stroke="#0ea5e9" strokeWidth={10} strokeLinecap="round">{[0, 60, 120].map((a2) => <path key={a2} d="M60 10 V110 M60 30 L44 16 M60 30 L76 16 M60 90 L44 104 M60 90 L76 104" transform={`rotate(${a2} 60 60)`} />)}</g> : null}
            {t.icon === 'scope' ? <><circle cx={60} cy={60} r={40} fill="#e2e8f0" stroke={OL} strokeWidth={9} /><path d="M60 20 V100 M20 60 H100" stroke={OL} strokeWidth={6} /><path d="M18 18 L102 102" stroke="#ef4444" strokeWidth={14} strokeLinecap="round" /></> : null}
          </svg>
          <div><div style={{fontFamily: DISPLAY, fontSize: 78, lineHeight: 1.05, color: '#111'}}>{t.title}</div>{t.sub ? <div style={{fontFamily: DISPLAY, fontSize: 42, color: '#334155'}}>{t.sub}</div> : null}</div>
        </div>); })}
    </Camera>
  );
};

/* dayCount: { days, total, countOnWord?, note? } — a flipping day calendar beside a big tally that races upward. */
const DayCount: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.countOnWord, fps, dur * 0.5);
  const days = (scene.days as number) ?? 98, total = (scene.total as number) ?? 500;
  const d = Math.round(interpolate(frame, [4, cAt], [1, days], clamp)), n = Math.round(interpolate(frame, [4, cAt + 10], [0, total], {...clamp, easing: (t) => t * t}));
  const s = spring({frame: frame - cAt - 10, fps, config: {damping: 8, stiffness: 190}});
  return (
    <Shake at={cAt + 10} amount={22}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0f172a, #1e3a8a 60%, #0f172a)'}} />
        <Snow n={50} wind={6} />
        <div style={{position: 'absolute', left: 340, top: 250, width: 400, height: 330, background: '#fff', border: `10px solid ${OL}`, borderRadius: 26, boxShadow: `0 12px 0 ${OL}`, overflow: 'hidden', rotate: '-3deg', textAlign: 'center'}}>
          <div style={{height: 90, background: '#ef4444', borderBottom: `8px solid ${OL}`, fontFamily: DISPLAY, fontSize: 64, color: '#fff', lineHeight: '90px'}}>DAY</div>
          <div style={{fontFamily: DISPLAY, fontSize: 210, lineHeight: 1.08, color: '#111', fontVariantNumeric: 'tabular-nums'}}>{d}</div>
        </div>
        <div style={{position: 'absolute', top: 680, width: '100%', textAlign: 'center', scale: String(1 + s * 0.12)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 330, lineHeight: 1, color: '#fde047', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{n}{frame >= cAt + 10 ? '+' : ''}</span>
        </div>
        {scene.label ? <Tag text={scene.label as string} at={cAt + 10} y={1040} size={70} color="#fff" rot={2} /> : null}
        {scene.note ? <Tag text={scene.note as string} at={cAt + 20} y={1180} size={44} color="#cbd5e1" rot={0} /> : null}
      </Camera>
    </Shake>
  );
};

/* hospitalWake: { tag, tagOnWord?, wakeOnWord, date?, tag2? } — a hospital bed; the bandaged hero sleeps, a calendar flips, his eyes open. */
const HospitalWake: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), wAt = at(captions, scene.wakeOnWord, fps, dur * 0.6), eAt = at(captions, scene.tag2OnWord, fps, dur * 0.85);
  const awake = frame >= wAt, day = Math.round(interpolate(frame, [tAt, wAt], [6, 13], clamp));
  const toon = (sb.character as unknown as {toon: {skin: string; hair: string}}).toon;
  return (
    <Shake at={tAt} amount={20}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #ccfbf1, #99f6e4)'}} />
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#5eead4', borderTop: `10px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 660, top: 330, width: 330, height: 300, background: '#fff', border: `10px solid ${OL}`, borderRadius: 24, boxShadow: `0 12px 0 ${OL}`, overflow: 'hidden', rotate: '4deg', textAlign: 'center'}}>
          <div style={{height: 80, background: '#ef4444', borderBottom: `8px solid ${OL}`, fontFamily: DISPLAY, fontSize: 54, color: '#fff', lineHeight: '80px'}}>{(scene.month as string) ?? 'MARCH'}</div>
          <div style={{fontFamily: DISPLAY, fontSize: 190, lineHeight: 1.08, color: '#111'}}>{day}</div>
        </div>
        {/* bed */}
        <div style={{position: 'absolute', left: 90, top: 880, width: 40, height: 420, background: '#94a3b8', border: `8px solid ${OL}`, borderRadius: 12}} /><div style={{position: 'absolute', left: 950, top: 1000, width: 40, height: 300, background: '#94a3b8', border: `8px solid ${OL}`, borderRadius: 12}} />
        <div style={{position: 'absolute', left: 110, top: 1090, width: 860, height: 130, background: '#fff', border: `10px solid ${OL}`, borderRadius: 20}} />
        <div style={{position: 'absolute', left: 150, top: 960, width: 250, height: 150, background: '#e0f2fe', border: `10px solid ${OL}`, borderRadius: 40}} />
        <div style={{position: 'absolute', left: 190, top: 880, width: 200, height: 200, borderRadius: '50%', background: toon.skin, border: `10px solid ${OL}`}}>
          <div style={{position: 'absolute', left: -6, top: -10, width: 212, height: 90, borderRadius: '100px 100px 20px 20px', background: toon.hair, border: `8px solid ${OL}`}} />
          {[56, 126].map((x) => awake ? <div key={x} style={{position: 'absolute', left: x - 16, top: 92, width: 34, height: 34, borderRadius: '50%', background: '#fff', border: `6px solid ${OL}`}}><div style={{margin: '7px auto', width: 14, height: 14, borderRadius: '50%', background: '#111'}} /></div> : <div key={x} style={{position: 'absolute', left: x - 16, top: 108, width: 34, height: 7, borderRadius: 4, background: OL}} />)}
          <div style={{position: 'absolute', left: -8, top: 128, width: 216, height: 62, background: '#fff', border: `8px solid ${OL}`, borderRadius: '10px 10px 80px 80px'}} />
        </div>
        <div style={{position: 'absolute', left: 380, top: 1010, width: 580, height: 200, background: '#7dd3fc', border: `10px solid ${OL}`, borderRadius: '60px 30px 20px 20px'}} />
        {!awake ? [0, 1, 2].map((i) => { const p = ((frame + i * 16) % 48) / 48; return <div key={i} style={{position: 'absolute', left: 400 + p * 60, top: 860 - p * 120, fontFamily: DISPLAY, fontSize: 50 + p * 40, color: '#fff', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill', opacity: 1 - p}}>Z</div>; }) : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} x={360} y={250} size={76} color="#ef4444" fg="#fff" rot={-4} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={eAt} y={690} size={92} color="#fde047" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

const Hood: React.FC<{cx: number; by: number; w: number; rot?: number}> = ({cx, by, w, rot = 0}) => (
  <svg width={w} height={w * 0.8} viewBox="0 0 200 160" style={{position: 'absolute', left: cx - w / 2, top: by - w * 0.8, rotate: `${rot}deg`, overflow: 'visible'}}>
    <path d="M22 150 Q4 30 100 22 Q196 30 178 150 Q170 100 140 86 Q100 70 60 86 Q30 100 22 150 Z" fill="#fff" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
    <path d="M52 60 Q100 30 148 60" fill="none" stroke="#cbd5e1" strokeWidth={8} strokeLinecap="round" />
  </svg>
);

/* hoodReveal: { nick?, first, last, nickOnWord?, onWord } — snowfall; a white hood drops onto the hero, then the name slams in. */
const HoodReveal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nAt = at(captions, scene.nickOnWord, fps, 10), rAt = at(captions, scene.onWord, fps, dur * 0.5);
  const s = spring({frame: frame - nAt, fps, config: {damping: 8, stiffness: 150}});
  const bg = interpolate(frame, [rAt - 2, rAt + 10], [0, 1], clamp), flash = interpolate(frame - rAt, [0, 2, 12], [0, 1, 0], clamp);
  const X = 540, Y = 1330, Hh = 560, top = Y - Hh * 0.985, R = Hh * 0.126;
  const words = [(scene.first as string) ?? '', (scene.last as string) ?? ''];
  return (
    <Shake at={rAt} amount={28}>
      <AbsoluteFill style={{background: '#06060a'}} />
      <AbsoluteFill style={{opacity: bg * 0.8, background: 'repeating-conic-gradient(from 0deg at 50% 56%, #0c4a6e 0 11.25deg, #0369a1 11.25deg 22.5deg)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 56%, rgba(0,0,0,0) 0%, rgba(0,0,0,0.85) 72%)'}} />
      <div style={{position: 'absolute', left: 240, top: 0, width: 600, height: 1400, background: 'linear-gradient(180deg, rgba(224,242,254,0.3), transparent)', clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#e0f2fe" glow={0.9} mood={frame >= rAt ? 'happy' : 'determined'} />
      <div style={{opacity: frame >= nAt - 4 ? 1 : 0}}><Hood cx={X} by={top + R * 2.3 - (1 - s) * 700} w={R * 3.3} rot={(1 - s) * -30} /></div>
      <Snow n={50} wind={5} />
      {scene.nick ? <Tag text={scene.nick as string} at={nAt} y={628} size={70} color="#fff" rot={-2} /> : null}
      <div style={{position: 'absolute', top: 150, width: '100%', textAlign: 'center'}}>
        {words.map((w, wi) => (
          <div key={wi} style={{display: 'flex', justifyContent: 'center'}}>
            {w.split('').map((ch, ci) => { const ls = spring({frame: frame - rAt - 4 - (wi * 5 + ci * 1.4), fps, config: {damping: 11, stiffness: 220}}); return (
              <span key={ci} style={{fontFamily: DISPLAY, fontSize: 188, lineHeight: 1.06, color: wi ? '#fde047' : '#fff', display: 'inline-block', translate: `0px ${(1 - ls) * 120}px`, opacity: ls, WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{ch}</span>); })}
          </div>
        ))}
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

/* oldPractice: { age, ageOnWord?, word, wordOnWord?, cta?, ctaOnWord? } — a cosy cabin; the hero as an old man with a walking stick; one big word. */
const OldPractice: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const aAt = at(captions, scene.ageOnWord, fps, 8), wAt = at(captions, scene.wordOnWord, fps, dur * 0.55), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.85);
  const s = spring({frame: frame - wAt, fps, config: {damping: 7, stiffness: 180}});
  const X = 330, Y = 1330, Hh = 480, hc = Y - Hh * 0.87, R = Hh * 0.126;
  return (
    <Shake at={wAt} amount={20}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #7c2d12, #b45309)'}} />
        <AbsoluteFill style={{background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.12) 0 8px, transparent 8px 110px)'}} />
        <div style={{position: 'absolute', left: 640, top: 520, width: 330, height: 330, background: '#bfdbfe', border: `14px solid #451a03`, outline: `8px solid ${OL}`, overflow: 'hidden'}}><Snow n={18} wind={3} /></div>
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#451a03', borderTop: `10px solid ${OL}`}} />
        <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fde68a" glow={0.5} mood="happy" />
        <div style={{position: 'absolute', left: X - R * 1.1, top: hc - R * 1.15, width: R * 2.2, height: R * 0.95, borderRadius: `${R}px ${R}px 10px 10px`, background: '#e5e7eb', border: `7px solid ${OL}`}} />
        <div style={{position: 'absolute', left: X + 130, top: Y - 300, width: 18, height: 300, background: '#78350f', border: `6px solid ${OL}`, borderRadius: 9}} /><div style={{position: 'absolute', left: X + 100, top: Y - 316, width: 66, height: 26, background: '#78350f', border: `6px solid ${OL}`, borderRadius: 13}} />
        <Tag text={(scene.age as string) ?? ''} at={aAt} x={330} y={250} size={110} color="#fff" rot={-4} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 880, textAlign: 'center', opacity: frame >= wAt ? 1 : 0, scale: String(2.4 - s * 1.4), rotate: '-5deg'}}>
          <span style={{position: 'relative', left: 150, fontFamily: DISPLAY, fontSize: 150, color: '#111', background: '#fde047', padding: '0 34px', borderRadius: 22, border: `9px solid ${OL}`, boxShadow: `0 12px 0 ${OL}`}}>{(scene.word as string) ?? ''}</span>
        </div>
        {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={430} size={80} color="#ef4444" fg="#fff" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

export const HISTORY4_SCENES: Record<string, React.FC<SceneProps>> = {
  snowEyes: SnowEyes,
  farmSmall: FarmSmall,
  invadeMap: InvadeMap,
  snowTricks: SnowTricks,
  dayCount: DayCount,
  hospitalWake: HospitalWake,
  hoodReveal: HoodReveal,
  oldPractice: OldPractice,
};
