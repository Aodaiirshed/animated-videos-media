import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* News-explainer kit (business/tech news told with a cartoon chip mascot, no real faces, no logos):
   chipHero, breakingCards, stockCoaster, boardTable, stayOrGo. Every claim card carries a status label
   (CONFIRMED / REPORTED / COMPANY SAYS) so the video never states an allegation as fact. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Rays: React.FC<{c1: string; c2: string; cy?: number}> = ({c1, c2, cy = 820}) => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(circle at 50% ${(cy / 1920) * 100}%, ${c1} 0%, ${c2} 80%)`}} />
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.13}}>
        {new Array(18).fill(0).map((_, i) => {
          const a = (i / 18) * Math.PI * 2 + frame / 80;
          return <path key={i} d={`M540 ${cy} L${540 + Math.cos(a) * 1700} ${cy + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.17) * 1700} ${cy + Math.sin(a + 0.17) * 1700} Z`} fill="#fff" />;
        })}
      </svg>
    </>
  );
};

type ChipMood = 'cool' | 'scream' | 'sweat' | 'curious' | 'happy';
/* The mascot: a generic green computer chip with a face (not any company's logo). */
export const Chip: React.FC<{x: number; y: number; size: number; mood?: ChipMood; arms?: 'flex' | 'up' | 'down' | 'hold'}> = ({x, y, size, mood = 'happy', arms = 'down'}) => {
  const frame = useCurrentFrame();
  const sc = size / 300;
  const jit = mood === 'scream' || mood === 'sweat' ? Math.sin(frame * 1.7) * 4 : 0;
  const bob = Math.sin(frame / 7) * 6;
  const armPath = (side: number) => arms === 'flex' ? `M${side * 150} 0 L${side * 215} -10 L${side * 200} -95`
    : arms === 'up' ? `M${side * 150} -20 L${side * 215} ${-120 + Math.sin(frame / 2 + side) * 14}`
    : arms === 'hold' ? `M${side * 150} 20 L${side * 205} 70`
    : `M${side * 150} 10 L${side * 200} 90`;
  const handAt = (side: number): [number, number] => arms === 'flex' ? [side * 200, -95] : arms === 'up' ? [side * 215, -120 + Math.sin(frame / 2 + side) * 14] : arms === 'hold' ? [side * 205, 70] : [side * 200, 90];
  return (
    <svg width={560 * sc} height={560 * sc} viewBox="-280 -280 560 560" style={{position: 'absolute', left: x - 280 * sc + jit, top: y - 280 * sc + bob, overflow: 'visible'}}>
      <ellipse cx={0} cy={262} rx={150} ry={18} fill="#000" opacity={0.25} />
      {[-70, 70].map((lx) => <g key={lx}><path d={`M${lx} 140 L${lx} 235`} stroke={OL} strokeWidth={22} strokeLinecap="round" /><ellipse cx={lx + 10} cy={244} rx={34} ry={16} fill="#ef4444" stroke={OL} strokeWidth={8} /></g>)}
      {[-1, 1].map((s) => <g key={s}><path d={armPath(s)} stroke={OL} strokeWidth={22} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        {arms === 'flex' ? <circle cx={s * 222} cy={-40} r={26} fill="#84cc16" stroke={OL} strokeWidth={8} /> : null}
        <circle cx={handAt(s)[0]} cy={handAt(s)[1]} r={22} fill="#fff" stroke={OL} strokeWidth={8} /></g>)}
      {[-90, -30, 30, 90].map((p) => <g key={p} fill="#fde047" stroke={OL} strokeWidth={7}>
        <rect x={p - 13} y={-182} width={26} height={40} rx={6} /><rect x={p - 13} y={142} width={26} height={40} rx={6} />
        <rect x={-182} y={p - 13} width={40} height={26} rx={6} /><rect x={142} y={p - 13} width={40} height={26} rx={6} /></g>)}
      <rect x={-150} y={-150} width={300} height={300} rx={34} fill="#84cc16" stroke={OL} strokeWidth={12} />
      <rect x={-112} y={-112} width={224} height={224} rx={20} fill="#65a30d" stroke={OL} strokeWidth={7} />
      <path d="M-112 -60 L-60 -112" stroke="#bef264" strokeWidth={10} strokeLinecap="round" opacity={0.6} />
      {mood === 'cool' ? (
        <><path d="M-100 -52 H100 V-14 Q62 20 22 -8 L0 -22 L-22 -8 Q-62 20 -100 -14 Z" fill={OL} /><path d="M-78 -40 l22 0 M34 -40 l22 0" stroke="#fff" strokeWidth={7} strokeLinecap="round" />
          <path d="M-46 52 Q0 92 54 46" stroke={OL} strokeWidth={10} fill="none" strokeLinecap="round" /></>
      ) : (
        <>
          {[-48, 48].map((ex) => <g key={ex}><ellipse cx={ex} cy={-30} rx={30} ry={mood === 'scream' ? 40 : 34} fill="#fff" stroke={OL} strokeWidth={7} />
            <circle cx={ex + (mood === 'curious' ? 10 : 0)} cy={-26 + (mood === 'sweat' ? 6 : 0)} r={mood === 'scream' ? 9 : 14} fill={OL} /></g>)}
          {mood === 'scream' ? <ellipse cx={0} cy={62} rx={34} ry={42} fill="#7a1f2b" stroke={OL} strokeWidth={8} />
            : mood === 'sweat' ? <path d="M-44 70 q11 -16 22 0 q11 16 22 0 q11 -16 22 0 q11 16 22 0" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />
            : mood === 'curious' ? <ellipse cx={8} cy={62} rx={16} ry={18} fill="#7a1f2b" stroke={OL} strokeWidth={7} />
            : <path d="M-46 48 Q0 96 46 48 Z" fill="#7a1f2b" stroke={OL} strokeWidth={8} strokeLinejoin="round" />}
          {mood === 'sweat' || mood === 'scream' ? [0, 1, 2].map((k) => {
            const t = ((frame + k * 9) % 26) / 26;
            return <path key={k} d={`M${-150 + k * 150} ${-170 - t * 60} q-12 22 0 30 q12 -8 0 -30 Z`} fill="#7fd4ff" stroke={OL} strokeWidth={5} opacity={1 - t} transform={`rotate(${(k - 1) * 20} ${-150 + k * 150} -170)`} />;
          }) : null}
        </>
      )}
    </svg>
  );
};

/* chipHero: { mode: 'crash'|'flex'|'detective', amount?, amountLabel?, countOnWord?, tags?: [{text,onWord}], badge?, title? } */
const ChipHero: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'crash';
  const cAt = at(captions, scene.countOnWord, fps, 6);
  const tags = (scene.tags as {text: string; onWord?: string; color?: string}[]) ?? [];
  const n = Math.round(((scene.amount as number) ?? 600) * interpolate(frame, [cAt, cAt + 26], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)}));
  const bg = mode === 'crash' ? ['#7f1d1d', '#1c0a0a'] : mode === 'flex' ? ['#bef264', '#3f6212'] : ['#7dd3fc', '#0c4a6e'];
  const lens = mode === 'detective' ? {x: 620 + Math.sin(frame / 12) * 150, y: 1180 + Math.cos(frame / 9) * 40} : null;
  return (
    <Shake at={mode === 'crash' ? 0 : at(captions, tags[0]?.onWord, fps, 10)} amount={mode === 'crash' ? 24 : 10}>
      <Camera dur={dur} from={1.07} to={1.0}>
        <Rays c1={bg[0]} c2={bg[1]} />
        {mode === 'crash' ? new Array(26).fill(0).map((_, i) => {
          const t = ((frame * (0.8 + random(`bv${i}`) * 0.8) + random(`bo${i}`) * 90) % 90) / 90;
          return <div key={i} style={{position: 'absolute', left: 540 + (random(`bx${i}`) - 0.5) * 300 + (random(`bd${i}`) - 0.5) * 1300 * t, top: 900 - t * 1100, width: 110, height: 56, background: '#86efac', border: `6px solid ${OL}`, borderRadius: 8,
            rotate: `${frame * 5 + i * 50}deg`, opacity: 1 - t * 0.7, textAlign: 'center', fontFamily: DISPLAY, fontSize: 38, lineHeight: '44px', color: '#166534'}}>$</div>;
        }) : null}
        {mode === 'flex' ? ['CHATBOTS', 'ROBOTS', 'DATA CENTERS', 'SELF-DRIVING'].map((t, i) => {
          const a = frame / 40 + (i / 4) * Math.PI * 2;
          return <div key={t} style={{position: 'absolute', left: 540 + Math.cos(a) * 380 - 160, width: 320, top: 880 + Math.sin(a) * 150 - 34, textAlign: 'center', zIndex: Math.sin(a) > 0 ? 3 : 0}}>
            <span style={{fontFamily: DISPLAY, fontSize: 44, color: '#111', background: '#fff', padding: '2px 18px', borderRadius: 30, border: `5px solid ${OL}`}}>{t}</span></div>;
        }) : null}
        {mode === 'detective' ? (
          <svg width={620} height={460} viewBox="0 0 620 460" style={{position: 'absolute', left: 380, top: 960}}>
            <path d="M20 90 L20 430 Q20 450 40 450 L580 450 Q600 450 600 430 L600 130 Q600 110 580 110 L300 110 L260 60 L50 60 Q20 60 20 90 Z" fill="#fbbf24" stroke={OL} strokeWidth={11} strokeLinejoin="round" />
            <rect x={70} y={170} width={480} height={90} rx={12} fill="#fffbeb" stroke={OL} strokeWidth={8} />
            <text x={310} y={236} textAnchor="middle" fontFamily="Anton" fontSize={62} fill="#111">INVESTIGATION</text>
            {[300, 350, 400].map((ly) => <rect key={ly} x={70} y={ly} width={ly === 400 ? 300 : 480} height={18} rx={9} fill="#92400e" opacity={0.5} />)}
          </svg>
        ) : null}
        <div style={{position: 'absolute', inset: 0, zIndex: 2}}>
          <Chip x={mode === 'detective' ? 270 : 540} y={mode === 'detective' ? 1090 : 880} size={mode === 'detective' ? 250 : 330}
            mood={mode === 'crash' ? 'scream' : mode === 'flex' ? 'cool' : 'curious'} arms={mode === 'crash' ? 'up' : mode === 'flex' ? 'flex' : 'hold'} />
        </div>
        {lens ? (
          <svg width={300} height={300} style={{position: 'absolute', left: lens.x - 110, top: lens.y - 110, zIndex: 4}}>
            <path d="M190 190 L270 270" stroke={OL} strokeWidth={34} strokeLinecap="round" /><path d="M190 190 L270 270" stroke="#92400e" strokeWidth={18} strokeLinecap="round" />
            <circle cx={110} cy={110} r={92} fill="#e0f2fe" fillOpacity={0.55} stroke={OL} strokeWidth={16} /><path d="M60 80 Q80 50 115 46" stroke="#fff" strokeWidth={12} fill="none" strokeLinecap="round" />
          </svg>
        ) : null}
        {mode === 'crash' ? (
          <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', zIndex: 5}}>
            <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, color: '#fecaca', letterSpacing: 4}}>{(scene.amountLabel as string) ?? 'MARKET VALUE'}</div>
            <div style={{fontFamily: DISPLAY, fontSize: 190, lineHeight: 1.02, color: '#ef4444', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>−${n}B</div>
          </div>
        ) : null}
        {scene.title ? <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 104, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill', zIndex: 5}}>{scene.title as string}</div> : null}
        <div style={{position: 'absolute', inset: 0, zIndex: 6}}>
          {scene.badge ? <Tag text={scene.badge as string} at={0} y={150} size={50} color="#111" fg="#ffcc4d" rot={0} /> : null}
          {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 12 + i * 20)} y={(mode === 'detective' ? 380 : 420) + i * 130} size={70} color={t.color ?? '#ffcc4d'} rot={i % 2 ? 2 : -3} />)}
        </div>
      </Camera>
    </Shake>
  );
};

/* breakingCards: { date?, cards: [{text, status, color, onWord}] } — a phone with notification cards; each card has a status label. */
const BreakingCards: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cards = (scene.cards as {text: string; status: string; color?: string; onWord?: string}[]) ?? [];
  const ats = cards.map((c, i) => at(captions, c.onWord, fps, 10 + i * 40));
  const last = ats.filter((a) => frame >= a).pop() ?? 0;
  return (
    <Shake at={last} amount={10}>
      <Camera dur={dur} from={1.0} to={1.05}>
        <Rays c1="#fda4af" c2="#881337" cy={860} />
        <div style={{position: 'absolute', left: 150, top: 240, width: 780, height: 1170, background: '#0f172a', border: `12px solid ${OL}`, borderRadius: 70, boxShadow: `0 16px 0 ${OL}`}}>
          <div style={{position: 'absolute', left: 290, top: 22, width: 200, height: 30, borderRadius: 15, background: OL}} />
          <div style={{position: 'absolute', left: 40, top: 80, right: 40, fontFamily: DISPLAY, fontSize: 60, color: '#fff'}}>
            <span style={{background: '#ef4444', padding: '0 18px', borderRadius: 10, opacity: 0.6 + 0.4 * Math.abs(Math.sin(frame / 6))}}>BREAKING</span>
            <span style={{float: 'right', fontFamily: BODY, fontWeight: 800, fontSize: 34, color: '#94a3b8', lineHeight: '74px'}}>{(scene.date as string) ?? ''}</span>
          </div>
          {cards.map((c, i) => {
            const s = spring({frame: frame - ats[i], fps, config: {damping: 12, stiffness: 170}});
            return (
              <div key={i} style={{position: 'absolute', left: 36, right: 36, top: 190 + i * 310, height: 280, background: '#fff', border: `8px solid ${OL}`, borderRadius: 30, opacity: frame >= ats[i] ? 1 : 0,
                translate: `${(1 - s) * 700}px 0px`, boxShadow: `0 9px 0 ${OL}`}}>
                <span style={{position: 'absolute', left: 22, top: 18, fontFamily: DISPLAY, fontSize: 40, color: '#fff', background: c.color ?? '#f59e0b', padding: '0 16px', borderRadius: 10, border: `5px solid ${OL}`}}>{c.status}</span>
                <div style={{position: 'absolute', left: 26, right: 22, top: 88, fontFamily: DISPLAY, fontSize: 50, lineHeight: 1.1, color: '#111'}}>{c.text}</div>
              </div>
            );
          })}
        </div>
        <Chip x={930} y={1330} size={170} mood="sweat" arms="up" />
      </Camera>
    </Shake>
  );
};

/* stockCoaster: { top?, topOnWord?, pct, dropOnWord, label? } — the share price as a rollercoaster with the chip in the cart. */
const StockCoaster: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const topAt = at(captions, scene.topOnWord, fps, 6), drop = at(captions, scene.dropOnWord, fps, dur * 0.55);
  const p = interpolate(frame, [0, drop, drop + 26], [0, 0.42, 1], clamp);
  const pts: [number, number][] = [[40, 800], [200, 700], [340, 620], [470, 560], [560, 600], [660, 800], [760, 1010], [880, 1120], [1040, 1170]];
  const pos = (t: number): [number, number, number] => {
    const f = t * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(f)), u = f - i;
    const [x1, y1] = pts[i], [x2, y2] = pts[i + 1];
    return [x1 + (x2 - x1) * u, y1 + (y2 - y1) * u, (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI];
  };
  const [cx, cy, ang] = pos(p);
  const pct = Math.round(((scene.pct as number) ?? 33) * interpolate(frame, [drop, drop + 26], [0, 1], clamp));
  const falling = frame >= drop;
  return (
    <Shake at={drop} amount={22}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <Rays c1={falling ? '#fca5a5' : '#bbf7d0'} c2={falling ? '#7f1d1d' : '#14532d'} cy={900} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          {new Array(8).fill(0).map((_, i) => <line key={i} x1={0} x2={1080} y1={480 + i * 110} y2={480 + i * 110} stroke="#fff" strokeOpacity={0.12} strokeWidth={4} />)}
          {pts.map(([x, y], i) => <line key={i} x1={x} y1={y} x2={x} y2={1260} stroke={OL} strokeWidth={10} opacity={0.6} />)}
          <polyline points={pts.map((q) => q.join(',')).join(' ')} fill="none" stroke={OL} strokeWidth={30} strokeLinejoin="round" strokeLinecap="round" />
          <polyline points={pts.map((q) => q.join(',')).join(' ')} fill="none" stroke={falling ? '#ef4444' : '#22c55e'} strokeWidth={16} strokeLinejoin="round" strokeLinecap="round" />
          <rect x={0} y={1260} width={1080} height={660} fill="#00000055" />
        </svg>
        <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, rotate: `${ang}deg`, transformOrigin: `${cx}px ${cy}px`}}>
          <div style={{position: 'absolute', left: cx - 120, top: cy - 96, width: 240, height: 80, background: '#facc15', border: `9px solid ${OL}`, borderRadius: '14px 14px 34px 34px'}} />
          {[-70, 70].map((w) => <div key={w} style={{position: 'absolute', left: cx + w - 22, top: cy - 30, width: 44, height: 44, borderRadius: '50%', background: '#334155', border: `8px solid ${OL}`}} />)}
          <Chip x={cx} y={cy - 190} size={170} mood={falling ? 'scream' : 'happy'} arms="up" />
        </div>
        <div style={{position: 'absolute', top: 290, width: '100%', textAlign: 'center', opacity: falling ? 1 : 0}}>
          <span style={{fontFamily: DISPLAY, fontSize: 200, color: '#ef4444', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>−{pct}%</span>
          <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, color: '#fff'}}>{(scene.label as string) ?? 'from its peak'}</div>
        </div>
        {scene.top ? <div style={{opacity: falling ? 0 : 1}}><Tag text={scene.top as string} at={topAt} y={300} size={62} color="#f59e0b" rot={-2} /></div> : null}
      </Camera>
    </Shake>
  );
};

/* boardTable: { count, tags: [{text,onWord}] } — a boardroom of anonymous cartoon directors around a table and one empty spot-lit chair. */
const BoardTable: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string; color?: string}[]) ?? [];
  const count = (scene.count as number) ?? 10;
  const back = Math.min(6, Math.ceil(count * 0.6)), front = count - back;
  return (
    <Camera dur={dur} from={1.06} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b 0%, #0f172a 60%, #020617 100%)'}} />
      <div style={{position: 'absolute', left: 60, top: 360, width: 960, height: 300, background: '#334155', border: `9px solid ${OL}`, borderRadius: 16, overflow: 'hidden'}}>
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 30 + i * 235, top: 26, width: 200, height: 240, background: '#7dd3fc', border: `7px solid ${OL}`, borderRadius: 8, opacity: 0.55}} />)}
      </div>
      {/* spotlight + empty chair */}
      <div style={{position: 'absolute', left: 390, top: 300, width: 300, height: 760, background: 'linear-gradient(180deg, rgba(253,224,71,0.45), transparent 95%)', clipPath: 'polygon(38% 0, 62% 0, 100% 100%, 0 100%)'}} />
      <svg width={220} height={300} style={{position: 'absolute', left: 430, top: 700}}>
        <rect x={30} y={10} width={160} height={200} rx={34} fill="#ef4444" stroke={OL} strokeWidth={10} /><rect x={20} y={190} width={180} height={50} rx={16} fill="#dc2626" stroke={OL} strokeWidth={10} />
      </svg>
      <div style={{position: 'absolute', left: 470, top: 740 + Math.sin(frame / 6) * 8, width: 140, textAlign: 'center', fontFamily: DISPLAY, fontSize: 130, color: '#fde047', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>?</div>
      {[100, 235, 370, 710, 845, 980].slice(0, back).map((x, i) => {
        return <Boy key={i} x={x} y={1090} height={330} stage="adult" skin={`#dir${i}`} rim="#fff" glow={0} mood={i % 2 ? 'neutral' : 'determined'} flip={x > 540} />;
      })}
      <div style={{position: 'absolute', left: 30, top: 1020, width: 1020, height: 150, background: 'linear-gradient(180deg, #b45309, #78350f)', border: `10px solid ${OL}`, borderRadius: 40}} />
      {new Array(front).fill(0).map((_, i) => {
        const x = 190 + (i * 700) / Math.max(1, front - 1);
        return <Boy key={i} x={x} y={1330} height={380} stage="adult" skin={`#dirf${i}`} rim="#fff" glow={0} mood={i % 2 ? 'determined' : 'neutral'} flip={x > 540} />;
      })}
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 12 + i * 24)} y={170 + i * 110} size={64} color={t.color ?? '#ffcc4d'} rot={i % 2 ? 2 : -2} />)}
    </Camera>
  );
};

/* stayOrGo: { stamp, left, right, cta } — closing card: two doors and an "as of" stamp so the video is honest about timing. */
const StayOrGo: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - 4, fps, config: {damping: 11}});
  const st = at(captions, scene.stampOnWord, fps, 8);
  const Door = ({x, c, label}: {x: number; c: string; label: string}) => (
    <div style={{position: 'absolute', left: x, top: 640, width: 360, height: 560, background: c, border: `12px solid ${OL}`, borderRadius: '180px 180px 0 0', boxShadow: `0 14px 0 ${OL}`, scale: String(s), transformOrigin: '50% 100%'}}>
      <div style={{position: 'absolute', right: 34, top: 300, width: 36, height: 36, borderRadius: '50%', background: '#fde047', border: `7px solid ${OL}`}} />
      <div style={{position: 'absolute', top: 120, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 120, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>{label}</div>
    </div>
  );
  return (
    <Camera dur={dur} from={1.05} to={1.0}>
      <Rays c1="#3b2a6b" c2="#120c26" cy={860} />
      <Tag text={(scene.stamp as string) ?? ''} at={st} y={240} size={58} color="#fff" rot={-2} />
      <div style={{position: 'absolute', top: 390, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 150, color: '#fde047', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.title as string) ?? ''}</div>
      <Door x={110} c="#16a34a" label={(scene.left as string) ?? 'STAY'} />
      <Door x={610} c="#dc2626" label={(scene.right as string) ?? 'GO'} />
      <Chip x={540} y={1090} size={150} mood="sweat" arms="down" />
    </Camera>
  );
};

export const NEWS_SCENES: Record<string, React.FC<SceneProps>> = {
  chipHero: ChipHero,
  breakingCards: BreakingCards,
  stockCoaster: StockCoaster,
  boardTable: BoardTable,
  stayOrGo: StayOrGo,
};
