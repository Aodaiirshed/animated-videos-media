import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Psychology set 1 (cartoon): passDrill (count / replay / again), halfCrowd, brainSpotlight, phoneDriver. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* A simple original cartoon player with a chosen shirt colour. */
const Player: React.FC<{x: number; y: number; shirt: string; skin: string; hair: string; phase: number; s?: number; dim?: number}> = ({x, y, shirt, skin, hair, phase, s = 1, dim = 1}) => {
  const step = Math.sin(phase) * 16;
  return (
    <svg width={220 * s} height={400 * s} viewBox="-110 -330 220 400" style={{position: 'absolute', left: x - 110 * s, top: y - 330 * s, opacity: dim}}>
      <path d={`M-22 20 L${-26 + step} 64`} stroke={OL} strokeWidth={22} strokeLinecap="round" />
      <path d={`M22 20 L${26 - step} 64`} stroke={OL} strokeWidth={22} strokeLinecap="round" />
      <path d={`M-22 20 L${-26 + step} 64`} stroke="#334155" strokeWidth={12} strokeLinecap="round" />
      <path d={`M22 20 L${26 - step} 64`} stroke="#334155" strokeWidth={12} strokeLinecap="round" />
      <rect x={-48} y={-150} width={96} height={175} rx={30} fill={shirt} stroke={OL} strokeWidth={8} />
      <path d={`M-46 -120 L${-82} ${-60 - step * 0.6}`} stroke={OL} strokeWidth={24} strokeLinecap="round" />
      <path d={`M46 -120 L${82} ${-60 + step * 0.6}`} stroke={OL} strokeWidth={24} strokeLinecap="round" />
      <path d={`M-46 -120 L${-82} ${-60 - step * 0.6}`} stroke={skin} strokeWidth={13} strokeLinecap="round" />
      <path d={`M46 -120 L${82} ${-60 + step * 0.6}`} stroke={skin} strokeWidth={13} strokeLinecap="round" />
      <circle cx={0} cy={-210} r={62} fill={skin} stroke={OL} strokeWidth={8} />
      <path d="M-58 -232 Q0 -300 58 -232 Q30 -256 0 -254 Q-30 -256 -58 -232 Z" fill={hair} stroke={OL} strokeWidth={6} />
      <circle cx={-20} cy={-208} r={8} fill={OL} /><circle cx={20} cy={-208} r={8} fill={OL} />
      <path d="M-18 -180 Q0 -166 18 -180" stroke={OL} strokeWidth={6} fill="none" strokeLinecap="round" />
    </svg>
  );
};

/* Original cartoon gorilla, walking + chest thump. */
const Gorilla: React.FC<{x: number; y: number; thump: number; phase: number; s?: number}> = ({x, y, thump, phase, s = 1}) => {
  const step = Math.sin(phase) * 14;
  const armL = thump > 0 ? -40 - Math.abs(Math.sin(phase * 2.2)) * 30 : 60;
  return (
    <svg width={300 * s} height={420 * s} viewBox="-150 -350 300 420" style={{position: 'absolute', left: x - 150 * s, top: y - 350 * s}}>
      <path d={`M-38 10 L${-44 + step} 64`} stroke={OL} strokeWidth={42} strokeLinecap="round" />
      <path d={`M38 10 L${44 - step} 64`} stroke={OL} strokeWidth={42} strokeLinecap="round" />
      <ellipse cx={0} cy={-90} rx={95} ry={120} fill="#2b2b33" stroke={OL} strokeWidth={8} />
      <ellipse cx={0} cy={-80} rx={52} ry={70} fill="#4b4b57" />
      <path d={`M-80 -150 Q-130 ${-60 + (thump > 0 ? -80 : 0)} ${-60} ${armL}`} stroke={OL} strokeWidth={46} fill="none" strokeLinecap="round" />
      <path d={`M80 -150 Q130 ${-60 + (thump > 0 ? -80 : 0)} ${60} ${armL}`} stroke={OL} strokeWidth={46} fill="none" strokeLinecap="round" />
      <path d={`M-80 -150 Q-130 ${-60 + (thump > 0 ? -80 : 0)} ${-60} ${armL}`} stroke="#2b2b33" strokeWidth={32} fill="none" strokeLinecap="round" />
      <path d={`M80 -150 Q130 ${-60 + (thump > 0 ? -80 : 0)} ${60} ${armL}`} stroke="#2b2b33" strokeWidth={32} fill="none" strokeLinecap="round" />
      <circle cx={0} cy={-250} r={66} fill="#2b2b33" stroke={OL} strokeWidth={8} />
      <ellipse cx={0} cy={-236} rx={44} ry={36} fill="#6b6b78" />
      <circle cx={-18} cy={-262} r={9} fill="#fff" /><circle cx={18} cy={-262} r={9} fill="#fff" />
      <circle cx={-18} cy={-262} r={4} fill={OL} /><circle cx={18} cy={-262} r={4} fill={OL} />
      <path d="M-16 -222 Q0 -212 16 -222" stroke={OL} strokeWidth={6} fill="none" strokeLinecap="round" />
    </svg>
  );
};

/* passDrill: { mode: 'count'|'replay'|'again', passes?: number, tag?, tagOnWord?, circleOnWord? }
   Three white-shirt and three dark-shirt players weave on a gym floor; the white team makes exactly `passes` passes.
   A dark cartoon gorilla walks through the middle (40%→80% of the pass window) and thumps its chest.
   count: hook — "COUNT THE WHITE PASSES" from frame 0, no counter. replay: fast replay with a live counter to `passes`, then
   everything freezes, players dim and a red ring circles the gorilla ("DID YOU SEE IT?"). again: the loop-back screen. */
const PassDrill: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'count';
  const passes = (scene.passes as number) ?? 15;
  const circleAt = at(captions, scene.circleOnWord, fps, Math.round(dur * 0.55));
  const winEnd = mode === 'replay' ? Math.max(20, circleAt - 6) : dur - 4;
  const winStart = mode === 'replay' ? 0 : 6;
  // drill time 0..1 (frozen after the window in replay)
  const prog = interpolate(frame, [winStart, winEnd], [0, 1], clamp);
  // replay freezes with the gorilla mid chest-thump in the centre (drill time 0.61)
  const u = mode === 'replay' ? prog * 0.61 : prog;
  const speed = mode === 'replay' ? 2.2 : 1;
  const ph = frame * 0.32 * speed;
  // players orbit two loose rings
  const pos = (team: number, i: number) => {
    const a = u * Math.PI * 2 * (team ? -0.9 : 0.75) + i * ((Math.PI * 2) / 3) + team * 0.9;
    return {x: 540 + Math.cos(a) * (team ? 300 : 340), y: 1150 + Math.sin(a) * 120 + (team ? 30 : 0)};
  };
  // white ball: pass k goes from player k%3 to (k+1)%3 during [k/passes, (k+1)/passes)
  const wk = Math.min(passes - 1, Math.floor(u * passes));
  const wf = Math.min(1, u * passes - wk);
  const a0 = pos(0, wk % 3), a1 = pos(0, (wk + 1) % 3);
  const wbx = a0.x + (a1.x - a0.x) * wf, wby = a0.y - 150 + (a1.y - a0.y) * wf - Math.sin(wf * Math.PI) * 120;
  // dark ball: 11 passes, offset rhythm
  const dk = Math.floor(u * 11), df = u * 11 - dk;
  const d0 = pos(1, dk % 3), d1 = pos(1, (dk + 2) % 3);
  const dbx = d0.x + (d1.x - d0.x) * df, dby = d0.y - 140 + (d1.y - d0.y) * df - Math.sin(df * Math.PI) * 70;
  // gorilla path
  const gx = interpolate(u, [0.38, 0.55, 0.68, 0.84], [1250, 560, 540, -200], clamp);
  const thump = u > 0.55 && u < 0.68 ? 1 : 0;
  const count = mode === 'replay' ? Math.min(passes, Math.floor(prog * passes + (prog >= 1 ? 1 : 0))) : 0;
  const frozen = mode === 'replay' && frame >= circleAt - 6;
  const dim = frozen ? 0.28 : 1;
  const ring = spring({frame: frame - circleAt, fps, config: {damping: 12}});
  const players = [0, 1, 2].map((i) => ({team: 0, i})).concat([0, 1, 2].map((i) => ({team: 1, i})));
  const gYo = 1190;
  const sorted = players.map((p) => ({...p, ...pos(p.team, p.i)})).sort((a, b) => a.y - b.y);
  return (
    <Shake at={mode === 'replay' ? circleAt : -100} amount={14}>
      <Camera dur={dur} from={mode === 'again' ? 1.12 : 1.0} to={mode === 'again' ? 1.0 : 1.06}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #334155 0%, #475569 42%, #b45309 42%, #d97706 100%)'}} />
        {/* gym wall details */}
        {new Array(5).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 60 + i * 210, top: 420, width: 150, height: 300, background: '#64748b', border: `6px solid ${OL}`, borderRadius: 8, opacity: 0.5}} />)}
        <svg width={1080} height={1120} style={{position: 'absolute', top: 806}}>
          {new Array(14).fill(0).map((_, i) => <line key={i} x1={i * 90 - 300} y1={0} x2={i * 120 - 400} y2={1120} stroke="#92400e" strokeWidth={4} opacity={0.5} />)}
          <ellipse cx={540} cy={360} rx={420} ry={150} fill="none" stroke="#fef3c7" strokeWidth={10} opacity={0.8} />
        </svg>
        {/* players behind gorilla line, gorilla, players in front */}
        {sorted.filter((p) => p.y < gYo).map((p) => <Player key={`${p.team}${p.i}`} x={p.x} y={p.y} shirt={p.team ? '#111827' : '#f8fafc'} skin={['#f1c27d', '#8d5524', '#c68642'][p.i]} hair={p.team ? '#3f2a14' : '#111'} phase={ph + p.i * 2} s={0.95} dim={dim} />)}
        <div style={{opacity: 1}}><Gorilla x={gx} y={gYo + 40} thump={thump} phase={ph} s={1.0} /></div>
        {sorted.filter((p) => p.y >= gYo).map((p) => <Player key={`${p.team}${p.i}f`} x={p.x} y={p.y} shirt={p.team ? '#111827' : '#f8fafc'} skin={['#f1c27d', '#8d5524', '#c68642'][p.i]} hair={p.team ? '#3f2a14' : '#111'} phase={ph + p.i * 2} s={0.95} dim={dim} />)}
        {/* balls */}
        <div style={{position: 'absolute', left: wbx - 28, top: wby - 28, width: 56, height: 56, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #e2e8f0)', border: `6px solid ${OL}`, opacity: dim}} />
        <div style={{position: 'absolute', left: dbx - 26, top: dby - 26, width: 52, height: 52, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #94a3b8, #1f2937)', border: `6px solid ${OL}`, opacity: dim}} />
        {/* replay: counter + ring */}
        {mode === 'replay' ? (
          <div style={{position: 'absolute', right: 150, top: 470, textAlign: 'center'}}>
            <div style={{fontFamily: DISPLAY, fontSize: 200, lineHeight: 1, color: '#fff', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill'}}>{count}</div>
            <div style={{fontFamily: DISPLAY, fontSize: 48, color: '#fff', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill'}}>PASSES</div>
          </div>
        ) : null}
        {mode === 'replay' && frame >= circleAt ? (
          <div style={{position: 'absolute', left: gx - 200, top: gYo - 380, width: 400, height: 460, borderRadius: '50%', border: '16px solid #ef4444', scale: String(1.6 - ring * 0.6), opacity: ring, boxShadow: '0 0 40px #ef4444'}} />
        ) : null}
        {mode === 'replay' ? <Tag text="DID YOU SEE IT?" at={circleAt + 4} y={250} size={92} color="#ef4444" fg="#fff" rot={-4} /> : null}
        {mode === 'count' ? <Tag text={(scene.tag as string) ?? 'COUNT THE WHITE PASSES'} at={-12} y={190} size={74} color="#fff" rot={-3} /> : null}
        {mode === 'count' ? <div style={{position: 'absolute', left: 0, right: 0, top: 300, textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 40, color: '#fff', WebkitTextStroke: `4px ${OL}`, paintOrder: 'stroke fill'}}>⚪ white shirts only</div> : null}
        {mode === 'again' ? <Tag text={(scene.tag as string) ?? 'COUNT AGAIN 👀'} at={2} y={190} size={84} color="#ffcc4d" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* halfCrowd: { stat, label, sub?, subOnWord? } — 20 little viewers; half of them with closed eyes/"?" bubbles; a big 50% stamp. */
const HalfCrowd: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.subOnWord, fps, dur * 0.6);
  const big = spring({frame: frame - 4, fps, config: {damping: 9, stiffness: 160}});
  return (
    <Camera dur={dur} from={1.0} to={1.07}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 35%, #1e3a8a 0%, #0b1020 80%)'}} />
      <div style={{position: 'absolute', top: 170, width: '100%', textAlign: 'center', scale: String(0.4 + big * 0.6)}}>
        <span style={{fontFamily: DISPLAY, fontSize: 260, lineHeight: 1, color: '#ffcc4d', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.stat as string) ?? '1 in 2'}</span>
        <div style={{fontFamily: DISPLAY, fontSize: 64, color: '#fff', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.label as string) ?? 'NEVER SAW IT'}</div>
      </div>
      {new Array(20).fill(0).map((_, i) => {
        const col = i % 5, row = Math.floor(i / 5);
        const seeN = scene.seeCount as number | undefined;
        const missed = seeN == null ? (i * 7) % 2 === 0 : (i * 7) % 20 >= seeN;
        const pop = spring({frame: frame - 10 - i * 2, fps, config: {damping: 12}});
        const x = 150 + col * 195, y = 720 + row * 160;
        return (
          <div key={i} style={{position: 'absolute', left: x - 60, top: y - 60, width: 120, height: 120, scale: String(pop)}}>
            <svg width={120} height={120} viewBox="-60 -60 120 120">
              <circle r={52} fill={missed ? '#64748b' : '#fbbf24'} stroke={OL} strokeWidth={7} />
              {missed ? (
                <>
                  <path d="M-26 -8 L-10 -8 M10 -8 L26 -8" stroke={OL} strokeWidth={7} strokeLinecap="round" />
                  <path d="M-12 22 L12 22" stroke={OL} strokeWidth={6} strokeLinecap="round" />
                </>
              ) : (
                <>
                  <circle cx={-17} cy={-8} r={11} fill="#fff" stroke={OL} strokeWidth={4} /><circle cx={17} cy={-8} r={11} fill="#fff" stroke={OL} strokeWidth={4} />
                  <circle cx={-17} cy={-8} r={5} fill={OL} /><circle cx={17} cy={-8} r={5} fill={OL} />
                  <ellipse cx={0} cy={24} rx={10} ry={13} fill={OL} />
                </>
              )}
            </svg>
            {missed ? <div style={{position: 'absolute', right: -14, top: -30, fontFamily: DISPLAY, fontSize: 52, color: '#f8fafc', WebkitTextStroke: `4px ${OL}`, paintOrder: 'stroke fill'}}>?</div> : null}
          </div>
        );
      })}
      {scene.sub ? <Tag text={scene.sub as string} at={sAt} y={560} size={58} color="#fff" rot={-2} /> : null}
    </Camera>
  );
};

/* brainSpotlight: { term, termOnWord? } — a cartoon brain shines a narrow flashlight beam on a ball; outside the beam the world goes grey
   and an unexpected object fades out; the term pops in. */
const BrainSpotlight: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.termOnWord, fps, dur * 0.55);
  const narrow = interpolate(frame, [0, dur * 0.5], [1, 0], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const fade = interpolate(frame, [dur * 0.15, dur * 0.5], [1, 0], clamp);
  const halfW = 120 + narrow * 380;
  return (
    <Shake at={tAt} amount={10}>
      <Camera dur={dur} from={1.04} to={1.0}>
        <AbsoluteFill style={{background: '#0f172a'}} />
        {/* the world: things around the ball */}
        <div style={{position: 'absolute', left: 120, top: 980, fontSize: 130, opacity: fade, filter: `grayscale(${1 - fade})`}}>🦍</div>
        <div style={{position: 'absolute', left: 820, top: 1020, fontSize: 110, opacity: fade, filter: `grayscale(${1 - fade})`}}>🚲</div>
        <div style={{position: 'absolute', left: 760, top: 1250, fontSize: 110, opacity: fade, filter: `grayscale(${1 - fade})`}}>🐈</div>
        <div style={{position: 'absolute', left: 150, top: 1250, fontSize: 110, opacity: fade, filter: `grayscale(${1 - fade})`}}>☂️</div>
        {/* beam */}
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <defs>
            <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fef9c3" stopOpacity="0.85" /><stop offset="1" stopColor="#fef9c3" stopOpacity="0.15" /></linearGradient>
          </defs>
          <path d={`M490 610 L590 610 L${540 + halfW} 1360 L${540 - halfW} 1360 Z`} fill="url(#beam)" />
        </svg>
        <div style={{position: 'absolute', left: 490, top: 1110, width: 100, height: 100, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #e2e8f0)', border: `7px solid ${OL}`, translate: `0 ${Math.abs(Math.sin(frame / 5)) * -30}px`}} />
        {/* brain with a flashlight */}
        <svg width={420} height={330} viewBox="-210 -170 420 330" style={{position: 'absolute', left: 330, top: 330}}>
          <path d="M-150 20 C-200 -40 -170 -130 -90 -140 C-60 -175 10 -175 30 -140 C100 -170 180 -110 160 -40 C200 0 170 80 110 80 L-100 80 C-160 80 -180 50 -150 20 Z" fill="#f9a8d4" stroke={OL} strokeWidth={10} />
          <path d="M-90 -100 Q-60 -60 -100 -20 M0 -130 Q-20 -80 20 -40 M80 -110 Q60 -60 100 -30 M-40 10 Q0 40 40 10" stroke="#db2777" strokeWidth={8} fill="none" strokeLinecap="round" />
          <circle cx={-40} cy={-40} r={14} fill={OL} /><circle cx={40} cy={-40} r={14} fill={OL} />
          <path d="M-20 20 L20 20" stroke={OL} strokeWidth={8} strokeLinecap="round" />
          <rect x={-40} y={80} width={80} height={70} rx={10} fill="#64748b" stroke={OL} strokeWidth={8} />
        </svg>
        <Tag text={(scene.term as string) ?? 'INATTENTIONAL BLINDNESS'} at={tAt} y={170} size={66} color="#ffcc4d" rot={-2} />
      </Camera>
    </Shake>
  );
};

/* phoneDriver: { tag?, tagOnWord? } — a cartoon driver (seen through the windscreen) stares at a glowing phone;
   a pedestrian on a crossing in front is drawn faded/ghosted until a red warning flash (no crash, non-graphic). */
const PhoneDriver: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.55);
  const ghost = interpolate(frame, [tAt, tAt + 8], [0.18, 1], clamp);
  const warn = interpolate(frame, [tAt, tAt + 3, tAt + 14], [0, 0.45, 0], clamp);
  return (
    <Shake at={tAt} amount={12}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #7dd3fc 0%, #bae6fd 40%, #94a3b8 41%, #64748b 100%)'}} />
      {/* crossing stripes */}
      {new Array(7).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 60 + i * 140, top: 820, width: 90, height: 150, background: '#f8fafc', transform: 'perspective(600px) rotateX(55deg)'}} />)}
      {/* pedestrian (ghosted) */}
      <div style={{position: 'absolute', left: 420 + Math.sin(frame / 10) * 8, top: 560, opacity: ghost}}>
        <svg width={200} height={330} viewBox="-100 -260 200 330">
          <circle cx={0} cy={-200} r={48} fill="#f1c27d" stroke={OL} strokeWidth={7} />
          <rect x={-42} y={-150} width={84} height={150} rx={24} fill="#22c55e" stroke={OL} strokeWidth={7} />
          <path d={`M-20 0 L${-28 + Math.sin(frame / 4) * 12} 60 M20 0 L${28 - Math.sin(frame / 4) * 12} 60`} stroke={OL} strokeWidth={16} strokeLinecap="round" />
        </svg>
      </div>
      {/* car interior frame */}
      <div style={{position: 'absolute', left: -40, right: -40, top: 980, height: 1000, background: '#1f2937', borderTop: `14px solid ${OL}`, borderRadius: '60% 60% 0 0 / 22% 22% 0 0'}} />
      <div style={{position: 'absolute', left: 300, top: 1230, width: 480, height: 480, borderRadius: '50%', border: `40px solid #111827`, boxShadow: `0 0 0 8px ${OL}`}} />
      {/* driver head looking down at phone */}
      <svg width={360} height={360} viewBox="-180 -180 360 360" style={{position: 'absolute', left: 360, top: 980}}>
        <circle cx={0} cy={0} r={110} fill="#c68642" stroke={OL} strokeWidth={9} />
        <path d="M-108 -30 Q0 -170 108 -30 Q60 -80 0 -80 Q-60 -80 -108 -30 Z" fill="#1a1a1a" />
        <path d="M-50 30 Q-35 40 -20 30 M20 30 Q35 40 50 30" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />
      </svg>
      <div style={{position: 'absolute', left: 600, top: 1320, width: 150, height: 250, borderRadius: 24, background: '#0f172a', border: `9px solid ${OL}`, boxShadow: '0 0 90px 30px rgba(96,165,250,0.55)', rotate: '-12deg'}}>
        <div style={{position: 'absolute', inset: 12, borderRadius: 14, background: 'linear-gradient(180deg, #60a5fa, #a78bfa)'}} />
      </div>
      <AbsoluteFill style={{background: '#ef4444', opacity: warn}} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={170} size={74} color="#ef4444" fg="#fff" rot={-3} /> : null}
    </Shake>
  );
};

export const PSYCH1_SCENES: Record<string, React.FC<SceneProps>> = {
  passDrill: PassDrill,
  halfCrowd: HalfCrowd,
  brainSpotlight: BrainSpotlight,
  phoneDriver: PhoneDriver,
};
