import React from 'react';
import {AbsoluteFill, interpolate, interpolateColors, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Psychology set 2 (cartoon): shellGame (count / reveal / again) — a cups-and-ball game while the room changes SLOWLY
   (gradual change blindness): wall colour blue→orange, tablecloth green→red, wall clock fades out. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

// slot swaps; the ball starts under the cup in slot 0 and ends in slot 1 (middle) — verified.
const SWAPS: [number, number][] = [[0, 1], [1, 2], [0, 2], [0, 1], [1, 2], [0, 1], [0, 2], [1, 2], [0, 1], [0, 2], [1, 2], [0, 1], [1, 2]];
const SLOT_X = [250, 540, 830];

const Tag: React.FC<{text: string; at: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: 40, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Room: React.FC<{k: number; w?: number; h?: number; scale?: number}> = ({k, w = 1080, h = 1920, scale = 1}) => {
  // k: 0 = start of the slow change, 1 = fully changed
  const wall = interpolateColors(k, [0, 1], ['#3b6fd8', '#e8742c']);
  const cloth = interpolateColors(k, [0, 1], ['#16a34a', '#c0262d']);
  const clock = 1 - k;
  return (
    <div style={{position: 'absolute', width: w, height: h, overflow: 'hidden'}}>
      <div style={{position: 'absolute', inset: 0, background: wall}} />
      {/* wall panels */}
      {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: (80 + i * 320) * scale, top: 360 * scale, width: 240 * scale, height: 520 * scale, border: `${6 * scale}px solid rgba(0,0,0,0.18)`, borderRadius: 14 * scale}} />)}
      {/* clock */}
      <div style={{position: 'absolute', left: 800 * scale, top: 170 * scale, width: 170 * scale, height: 170 * scale, borderRadius: '50%', background: '#fff', border: `${10 * scale}px solid ${OL}`, opacity: clock}}>
        <div style={{position: 'absolute', left: '50%', top: '18%', width: 8 * scale, height: '34%', background: OL, translate: '-50% 0'}} />
        <div style={{position: 'absolute', left: '50%', top: '50%', width: '30%', height: 8 * scale, background: OL}} />
      </div>
      {/* table */}
      <div style={{position: 'absolute', left: -20 * scale, right: -20 * scale, top: 980 * scale, height: 980 * scale, background: cloth, borderTop: `${12 * scale}px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 1000 * scale, height: 60 * scale, background: 'rgba(255,255,255,0.12)'}} />
    </div>
  );
};

const Cup: React.FC<{x: number; y: number; lift?: number; tint?: string}> = ({x, y, lift = 0, tint = '#ef4444'}) => (
  <svg width={240} height={260} viewBox="0 0 240 260" style={{position: 'absolute', left: x - 120, top: y - 230 - lift}}>
    <path d="M40 20 L200 20 L225 230 L15 230 Z" fill={tint} stroke={OL} strokeWidth={10} strokeLinejoin="round" />
    <path d="M30 20 L210 20" stroke={OL} strokeWidth={14} strokeLinecap="round" />
    <path d="M70 60 L60 200" stroke="#fff" strokeWidth={14} strokeLinecap="round" opacity={0.35} />
    <path d="M25 150 L215 150" stroke="#fde047" strokeWidth={12} opacity={0.9} />
  </svg>
);

/* shellGame: { mode: 'count'|'reveal'|'again', tag?, liftOnWord?, splitOnWord? }
   count: ball shown, cups drop over it, then 13 swaps; the room changes slowly across the whole scene.
   reveal: the room is in its CHANGED state; the middle cup lifts (ball), then a BEFORE/AFTER split slides in.
   again: changed room fading back to the start look (loop seam), tag "WATCH THE WALL". */
const ShellGame: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'count';
  const tableY = 1180;
  const liftAt = at(captions, scene.liftOnWord, fps, 8);
  const splitAt = at(captions, scene.splitOnWord, fps, Math.round(dur * 0.55));

  // cup slots over time (count mode)
  const dropEnd = 34; // ball visible, then cups come down
  const swapStart = 44, swapEnd = Math.max(swapStart + 60, dur - 8);
  const per = (swapEnd - swapStart) / SWAPS.length;
  const cupSlot = [0, 1, 2]; // cup id -> slot
  let mid: {a: number; b: number; f: number} | null = null;
  if (mode === 'count') {
    for (let i = 0; i < SWAPS.length; i++) {
      const s0 = swapStart + i * per;
      const [a, b] = SWAPS[i];
      const ca = cupSlot.indexOf(a), cb = cupSlot.indexOf(b);
      if (frame >= s0 + per) { cupSlot[ca] = b; cupSlot[cb] = a; continue; }
      if (frame >= s0) mid = {a, b, f: (frame - s0) / per};
      break;
    }
  }
  const cupXY = (id: number) => {
    if (mode !== 'count') return {x: SLOT_X[id === 0 ? 1 : id === 1 ? 0 : 2], y: tableY};
    const slot = cupSlot[id];
    if (mid && (slot === mid.a || slot === mid.b)) {
      const other = slot === mid.a ? mid.b : mid.a;
      const e = mid.f < 0.5 ? 2 * mid.f * mid.f : 1 - Math.pow(-2 * mid.f + 2, 2) / 2;
      const x = SLOT_X[slot] + (SLOT_X[other] - SLOT_X[slot]) * e;
      const y = tableY + (slot === mid.a ? -1 : 1) * Math.sin(mid.f * Math.PI) * 70;
      return {x, y};
    }
    return {x: SLOT_X[slot], y: tableY};
  };
  const k = mode === 'count' ? interpolate(frame, [0, dur], [0, 1], clamp) : mode === 'reveal' ? 1 : interpolate(frame, [0, dur], [1, 0.0], clamp);
  const drop = mode === 'count' ? interpolate(frame, [12, dropEnd], [1, 0], clamp) : 0;
  const lift = mode === 'reveal' ? spring({frame: frame - liftAt, fps, config: {damping: 13}}) * 220 : 0;
  const split = mode === 'reveal' ? spring({frame: frame - splitAt, fps, config: {damping: 14}}) : 0;
  return (
    <Shake at={mode === 'reveal' ? splitAt : -99} amount={12}>
      <Camera dur={dur} from={mode === 'again' ? 1.1 : 1.0} to={mode === 'again' ? 1.0 : 1.04}>
        <Room k={k} />
        {/* ball */}
        <div style={{position: 'absolute', left: (mode === 'count' ? SLOT_X[0] : SLOT_X[1]) - 45, top: tableY - 92, width: 90, height: 90, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fef08a, #eab308)', border: `8px solid ${OL}`, opacity: mode === 'count' && frame > dropEnd + 2 ? 0 : 1}} />
        {/* cups (drop in from above at the start of count) */}
        {[0, 1, 2].map((id) => {
          const p = cupXY(id);
          return <Cup key={id} x={p.x} y={p.y - drop * 1300} lift={mode === 'reveal' && id === 0 ? lift : 0} />;
        })}
        {mode === 'count' ? <Tag text={(scene.tag as string) ?? 'KEEP YOUR EYES ON THE BALL'} at={-12} y={400} size={66} color="#fff" rot={-2} /> : null}
        {mode === 'again' ? <Tag text={(scene.tag as string) ?? 'NOW WATCH THE WALL 👀'} at={2} y={400} size={70} color="#ffcc4d" rot={2} /> : null}
        {/* BEFORE / AFTER split */}
        {mode === 'reveal' ? (
          <div style={{position: 'absolute', left: 0, right: 0, top: 120, height: 640, translate: `0 ${(1 - split) * -800}px`}}>
            {[0, 1].map((i) => (
              <div key={i} style={{position: 'absolute', left: 40 + i * 520, top: 0, width: 480, height: 600, borderRadius: 26, overflow: 'hidden', border: `10px solid ${OL}`, boxShadow: `0 12px 0 ${OL}`}}>
                <div style={{position: 'absolute', left: -60, top: -40, width: 1080, height: 1920, scale: '0.5', transformOrigin: '0 0'}}><Room k={i} /></div>
                <div style={{position: 'absolute', left: 0, right: 0, bottom: 14, textAlign: 'center', fontFamily: DISPLAY, fontSize: 64, color: '#fff', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill'}}>{i ? 'NOW' : 'START'}</div>
              </div>
            ))}
          </div>
        ) : null}
      </Camera>
    </Shake>
  );
};

export const PSYCH2_SCENES: Record<string, React.FC<SceneProps>> = {
  shellGame: ShellGame,
};
