import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Owl, Raccoon, Study, Counter, Board, W} from '../components/Duo';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* THE HIDDEN RULE #7 — Foot-in-the-door (Freedman & Fraser 1966, JPSP 4:195–202: big "DRIVE CAREFULLY" lawn sign;
   asked cold ~17 % agreed; after first agreeing to a small 3-inch safe-driving sign ~76 % agreed).
   Duo look + animation kit v2 (same Set wrapper as rule6). Both characters lip-synced: talk goes to the scene's speaker.
   Scenes: signHook, tinyAsk, kitYes, footReveal, studyBars, doorTurn. */
const OL = '#1b120b';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const talkOf = (mouth: number[] | undefined, f: number) => (mouth ? mouth[Math.min(mouth.length - 1, Math.max(0, f))] ?? 0 : 0);
const spk = (scene: SceneProps['scene'], who: string, mouth: number[] | undefined, f: number) => ((scene.speaker ?? 'prof') === who ? talkOf(mouth, f) : 0);

const Badge: React.FC<{text: string}> = ({text}) => (
  <div style={{position: 'absolute', left: 40, top: 190, fontFamily: BODY, fontWeight: 800, fontSize: 30, letterSpacing: 4, color: W.cream, border: `3px solid ${W.cream}`, borderRadius: 10, padding: '4px 14px', opacity: 0.85}}>{text}</div>
);

const Set: React.FC<{cam: {x: number; y: number; zoom: number; roll?: number}; board?: React.ReactNode; actors?: React.ReactNode; counterTop?: number}> = ({cam, board, actors, counterTop = 1260}) => (
  <CameraRig cam={cam}>
    <Layer depth={0.55} blur={1}><Study /></Layer>
    <Layer depth={0.8}>{board}</Layer>
    <Layer depth={1}>{actors}</Layer>
    <Layer depth={1.2}><Counter top={counterTop} /></Layer>
  </CameraRig>
);

/* Kit's little house (on the chalkboard). */
const House: React.FC<{x: number; y: number; s?: number; smallSign?: number}> = ({x, y, s = 1, smallSign = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 300 * s, height: 280 * s}}>
    <div style={{position: 'absolute', left: 0, top: 0, width: 0, height: 0, borderLeft: `${150 * s}px solid transparent`, borderRight: `${150 * s}px solid transparent`, borderBottom: `${110 * s}px solid ${W.coral}`}} />
    <div style={{position: 'absolute', left: 25 * s, top: 108 * s, width: 250 * s, height: 170 * s, background: W.cream, border: `5px solid ${OL}`}} />
    <div style={{position: 'absolute', left: 50 * s, top: 140 * s, width: 80 * s, height: 70 * s, background: '#9ad6f0', border: `5px solid ${OL}`}} />
    {smallSign > 0 ? <div style={{position: 'absolute', left: 62 * s, top: 158 * s, width: 56 * s, height: 34 * s, scale: String(smallSign), background: W.gold, border: `3px solid ${OL}`, borderRadius: 4, fontFamily: BODY, fontWeight: 900, fontSize: 11 * s, color: OL, textAlign: 'center', lineHeight: 1.05, paddingTop: 3 * s}}>BE A SAFE<br />DRIVER</div> : null}
    <div style={{position: 'absolute', left: 170 * s, top: 170 * s, width: 70 * s, height: 108 * s, background: W.woodDark, border: `5px solid ${OL}`}} />
  </div>
);

/* The giant ugly lawn sign. wob = rocking angle. */
const BigSign: React.FC<{x: number; y: number; s?: number; wob?: number; pop?: number}> = ({x, y, s = 1, wob = 0, pop = 1}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 520 * s, height: 360 * s, rotate: `${wob}deg`, transformOrigin: '50% 100%', scale: String(pop)}}>
    <div style={{position: 'absolute', left: 80 * s, top: 200 * s, width: 22 * s, height: 160 * s, background: W.woodDark, border: `4px solid ${OL}`}} />
    <div style={{position: 'absolute', left: 420 * s, top: 200 * s, width: 22 * s, height: 160 * s, background: W.woodDark, border: `4px solid ${OL}`}} />
    <div style={{position: 'absolute', left: 0, top: 0, width: 520 * s, height: 220 * s, background: '#f3efe7', border: `7px solid ${OL}`, borderRadius: 8, rotate: '-2deg', textAlign: 'center'}}>
      <div style={{fontFamily: DISPLAY, fontSize: 78 * s, color: W.coral, marginTop: 22 * s, lineHeight: 0.95, letterSpacing: -1, rotate: '3deg'}}>DRIVE</div>
      <div style={{fontFamily: DISPLAY, fontSize: 70 * s, color: '#3a5fcd', lineHeight: 0.95, rotate: '-4deg'}}>CAREFULLY</div>
    </div>
  </div>
);

const Tag: React.FC<{text: string; a: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, y, color = W.gold, size = 56, rot = -3}) => {
  const frame = useCurrentFrame();
  if (frame < a) return null;
  const s = kf(frame - a, [[0, 1.6], [8, 1, EASE.overshoot]]);
  return (
    <div style={{position: 'absolute', left: 40, right: 140, top: y, textAlign: 'center', scale: String(s), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 24px', borderRadius: 14, border: `6px solid ${OL}`, boxShadow: `0 8px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* signHook (Arm A): frame 0 = the payoff picture already moving — the giant ugly sign wobbling on Kit's lawn, Kit grinning, owl shaking his head;
   sound-off tag "WHY DID HE SAY YES?"; punch-in cut at 1.2 s; on "yes." the sign slams down (camera kick). */
const SignHook: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const yAt = at(captions, scene.yesOnWord, fps, dur * 0.8);
  const wob = Math.sin(frame / 5) * 5 * (frame < yAt ? 1 : 0.3);
  const slam = kf(frame, [[yAt - 1, 1], [yAt + 4, 1.12, EASE.out], [yAt + 10, 1, EASE.overshoot]]);
  const cam = {x: kf(frame, [[0, 540], [36, 600, EASE.smooth], [dur, 620, EASE.smooth]]), y: kf(frame, [[0, 860], [36, 760, EASE.smooth]]), zoom: (frame < 36 ? 1.0 : 1.16) + kf(frame, [[36, 0], [dur, 0.06, EASE.smooth]]) + impulses(frame, [36, yAt + 3], 0.05, 12, 1.4), roll: impulse(frame, yAt + 3, 1.4, 14, 1.1)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 440, height: 120, background: '#3f7a4a'}} />
          <House x={40} y={170} s={0.95} />
          <BigSign x={330} y={110} s={1.05} wob={wob} pop={slam} />
          <Particles count={10} color={W.chalk} size={8} speedY={-0.6} speedX={0.4} seed={3} opacity={0.5} />
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={spk(scene, 'prof', mouth, frame)} look={0.5} point={kf(frame, [[10, 0], [22, 1, EASE.out]])} />
          <Raccoon x={660} y={840} s={1.15} look={-0.3} joy={0.9} arm={0.5 + Math.sin(frame / 6) * 0.2} />
        </>} />
      <Tag text="WHY DID HE SAY YES?" a={0} y={300} size={58} color={W.gold} />
      <Badge text={(scene.badge as string) ?? 'THE HIDDEN RULE #7'} />
    </AbsoluteFill>
  );
};

/* tinyAsk: { tinyOnWord } — flashback (sepia board): a stranger's hand offers a tiny card; it pops into Kit's window on "tiny". "2 WEEKS EARLIER" tag. */
const TinyAsk: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tinyOnWord, fps, dur * 0.45);
  const card = kf(frame, [[tAt, 0], [tAt + 9, 1, EASE.overshoot]]);
  const cam = {x: kf(frame, [[0, 480], [dur, 440, EASE.smooth]]), y: kf(frame, [[0, 640], [dur, 600, EASE.smooth]]), zoom: kf(frame, [[0, 1.25], [dur, 1.4, EASE.smooth]]) + impulse(frame, tAt + 4, 0.05, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', inset: 0, background: 'rgba(201,139,63,0.18)'}} />
          <div style={{position: 'absolute', left: 0, right: 0, top: 440, height: 120, background: '#3f7a4a'}} />
          <House x={60} y={170} s={0.95} smallSign={card} />
          {/* stranger: just an arm with a clipboard reaching in from the right */}
          <div style={{position: 'absolute', left: kf(frame, [[0, 900], [12, 560, EASE.out]]), top: 250, width: 340, height: 40, background: '#5b6b8c', border: `5px solid ${OL}`, borderRadius: 20}} />
          <div style={{position: 'absolute', left: kf(frame, [[0, 860], [12, 520, EASE.out]]), top: 190, width: 110, height: 140, background: W.cream, border: `5px solid ${OL}`, borderRadius: 8, rotate: '-8deg'}}>
            <div style={{margin: '18px 12px', height: 8, background: W.grey}} /><div style={{margin: '10px 12px', height: 8, background: W.grey}} />
          </div>
          {frame >= tAt ? <div style={{position: 'absolute', left: 120, top: 120, fontFamily: DISPLAY, fontSize: 40, color: W.gold, scale: String(card)}}>↓ TINY</div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={spk(scene, 'prof', mouth, frame)} look={0.5} point={1} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} joy={0.4} />
        </>} />
      <Tag text="2 WEEKS EARLIER" a={2} y={300} size={52} color="#e9d5ff" rot={2} />
    </AbsoluteFill>
  );
};

/* kitYes: { yesOnWord } — Kit (lip-synced) shrugs happily and gives a thumbs-up wind-up; a green "YES ✓" pops. */
const KitYes: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const yAt = at(captions, scene.yesOnWord, fps, dur * 0.5);
  const arm = kf(frame, [[yAt - 6, 0.2], [yAt, 0, EASE.anticip], [yAt + 8, 1, EASE.overshoot]]);
  const cam = {x: kf(frame, [[0, 760], [dur, 740, EASE.smooth]]), y: kf(frame, [[0, 1000], [dur, 980, EASE.smooth]]), zoom: kf(frame, [[0, 1.35], [dur, 1.45, EASE.smooth]]) + impulse(frame, yAt + 6, 0.06, 14, 1.3), roll: -1};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        actors={<>
          <Raccoon x={640} y={840} s={1.2} talk={spk(scene, 'kit', mouth, frame)} look={-0.2} joy={0.9} arm={Math.max(0, arm)} />
          {frame >= yAt ? <div style={{position: 'absolute', left: 520, top: 700, rotate: '-8deg', scale: String(kf(frame, [[yAt, 0.3], [yAt + 8, 1, EASE.overshoot]])), fontFamily: DISPLAY, fontSize: 90, color: '#111', background: '#86efac', border: `7px solid ${OL}`, borderRadius: 18, padding: '0 26px'}}>YES ✓</div> : null}
          <Particles count={12} color={W.gold} size={10} speedY={-0.8} speedX={0.2} seed={5} opacity={frame > yAt ? 0.6 : 0} />
        </>} />
    </AbsoluteFill>
  );
};

/* footReveal: { bigOnWord, titleOnWord } — a door with a small foot wedged in it; on "big" the door swings wide (small yes → big yes); title slams. */
const FootReveal: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bAt = at(captions, scene.bigOnWord, fps, dur * 0.3);
  const tAt = at(captions, scene.titleOnWord, fps, dur * 0.7);
  const open = kf(frame, [[0, 0.12], [bAt, 0.18], [bAt + 14, 0.85, EASE.out]]);
  const title = kf(frame, [[tAt, 0], [tAt + 9, 1, EASE.overshoot]]);
  const cam = {x: 540, y: kf(frame, [[0, 760], [dur, 800, EASE.smooth]]), zoom: kf(frame, [[0, 1.15], [dur, 1.05, EASE.smooth]]) + impulses(frame, [bAt + 8, tAt + 6], 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 300, top: 140, width: 300, height: 380, background: '#0b0f0d', border: `6px solid ${W.chalk}`}} />
          <div style={{position: 'absolute', left: 300, top: 140, width: 300, height: 380, background: W.wood, border: `6px solid ${OL}`, transformOrigin: '0% 50%', transform: `perspective(900px) rotateY(${-open * 80}deg)`}}>
            <div style={{position: 'absolute', left: 240, top: 190, width: 26, height: 26, borderRadius: 13, background: W.gold}} />
          </div>
          <div style={{position: 'absolute', left: 520 - open * 40, top: 470, width: 130, height: 46, background: W.coral, border: `5px solid ${OL}`, borderRadius: '30px 30px 12px 12px'}} />
          <div style={{position: 'absolute', left: 620, top: 300, fontFamily: BODY, fontWeight: 900, fontSize: 34, color: W.chalk, lineHeight: 1.3}}>small yes<br /><span style={{opacity: frame >= bAt ? 1 : 0.15, color: W.gold}}>→ BIG YES</span></div>
          {frame >= tAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 26, textAlign: 'center', scale: String(title), fontFamily: DISPLAY, fontSize: 80, color: W.coral}}>FOOT IN THE DOOR</div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={spk(scene, 'prof', mouth, frame)} point={frame > bAt ? 1 : 0} look={0.5} />
          <Raccoon x={660} y={840} s={1.15} look={-0.5} joy={frame > tAt ? 0 : 0.3} />
        </>} />
    </AbsoluteFill>
  );
};

/* studyBars: { askOnWord, coldOnWord, warmOnWord } — 1966 study card; spoken quick question; bar 1 fills to 17 % ("1 IN 6") then bar 2 to 76 % ("3 IN 4"). */
const StudyBars: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.coldOnWord, fps, dur * 0.45);
  const wAt = at(captions, scene.warmOnWord, fps, dur * 0.85);
  const b1 = kf(frame, [[cAt, 0], [cAt + 14, 0.17, EASE.out]]);
  const b2 = kf(frame, [[wAt, 0], [wAt + 18, 0.76, EASE.overshoot]]);
  const cam = {x: kf(frame, [[0, 520], [dur, 540, EASE.smooth]]), y: 720, zoom: kf(frame, [[0, 1.08], [dur, 1.18, EASE.smooth]]) + impulses(frame, [cAt + 4, wAt + 6], 0.04, 12, 1.4)};
  const rows = [{lab: 'ASKED STRAIGHT AWAY', v: b1, c: W.grey, show: cAt, txt: '1 IN 6'}, {lab: 'AFTER THE TINY SIGN', v: b2, c: W.coral, show: wAt, txt: '3 IN 4'}];
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 20, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 30, color: W.grey, letterSpacing: 3}}>FREEDMAN & FRASER · 1966</div>
          <div style={{position: 'absolute', left: 0, right: 0, top: 62, textAlign: 'center', fontFamily: DISPLAY, fontSize: 46, color: W.chalk}}>"PUT A HUGE SIGN ON YOUR LAWN?"</div>
          {rows.map((r, i) => (
            <div key={i} style={{position: 'absolute', left: 50, top: 160 + i * 170}}>
              <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 30, color: W.chalk, letterSpacing: 2}}>{r.lab}</div>
              <div style={{marginTop: 10, width: 500, height: 74, borderRadius: 12, border: `4px solid ${W.chalk}`, overflow: 'hidden'}}>
                <div style={{width: `${r.v * 100}%`, height: '100%', background: r.c}} />
              </div>
              {frame >= r.show + 10 ? <div style={{position: 'absolute', left: 525, top: 40, whiteSpace: 'nowrap', fontFamily: DISPLAY, fontSize: 66, color: i ? W.coral : W.chalk, scale: String(kf(frame, [[r.show + 10, 0.4], [r.show + 18, 1, EASE.overshoot]]))}}>{r.txt}</div> : null}
            </div>
          ))}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={spk(scene, 'prof', mouth, frame)} point={1} look={0.5} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} joy={frame >= wAt ? 0 : 0.2} />
        </>} />
    </AbsoluteFill>
  );
};

/* doorTurn: { watchOnWord } — "You think I'm talking about signs": free trial, borrow 5 → 50; then the rule card; silent send line; loops into the hook. */
const DoorTurn: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const qAt = at(captions, scene.watchOnWord, fps, dur * 0.6);
  const icons = [['🆓', 'THE FREE TRIAL'], ['💸', 'BORROW 5… THEN 50'], ['📝', '"JUST ONE QUICK FAVOUR"']];
  const cam = {x: kf(frame, [[0, 540], [dur, 560, EASE.smooth]]), y: kf(frame, [[0, 760], [dur, 800, EASE.smooth]]), zoom: kf(frame, [[0, 1.04], [qAt, 1.12, EASE.smooth], [dur, 1.16, EASE.smooth]]) + impulse(frame, qAt + 4, 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 20, right: 20, top: 24, textAlign: 'center', fontFamily: DISPLAY, fontSize: 52, color: W.chalk}}>YOU THINK I'M TALKING ABOUT SIGNS.</div>
          {icons.map(([ic, lab], i) => {
            const s = kf(frame, [[14 + i * 12, 0], [24 + i * 12, 1, EASE.overshoot]]);
            return <div key={i} style={{position: 'absolute', left: 40 + i * 280, top: 120, width: 260, textAlign: 'center', scale: String(s), opacity: frame >= qAt ? 0.5 : 1}}>
              <div style={{fontSize: 120}}>{ic}</div>
              <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 25, color: W.chalk, letterSpacing: 1}}>{lab}</div>
            </div>;
          })}
          {frame >= qAt ? <div style={{position: 'absolute', left: 60, right: 60, top: 290, scale: String(kf(frame, [[qAt, 0.3], [qAt + 9, 1, EASE.overshoot]])), background: W.cream, border: `5px solid ${OL}`, borderRadius: 18, padding: '14px 20px', textAlign: 'center', fontFamily: DISPLAY, fontSize: 48, color: OL, lineHeight: 1.1}}>WATCH THE SMALL YES.</div> : null}
          <div style={{position: 'absolute', left: 30, right: 30, top: 430, textAlign: 'center', opacity: kf(frame, [[qAt + 10, 0], [qAt + 20, 1, EASE.out]])}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 30, color: '#111', background: '#86efac', padding: '6px 16px', borderRadius: 12, border: `4px solid ${OL}`}}>📤 Send this to the friend who can't say no</span></div>
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={spk(scene, 'prof', mouth, frame)} look={0.3} point={frame >= qAt ? 1 : 0} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} joy={0.2} />
        </>} />
    </AbsoluteFill>
  );
};

export const RULE7_SCENES: Record<string, React.FC<SceneProps>> = {signHook: SignHook, tinyAsk: TinyAsk, kitYes: KitYes, footReveal: FootReveal, studyBars: StudyBars, doorTurn: DoorTurn};
