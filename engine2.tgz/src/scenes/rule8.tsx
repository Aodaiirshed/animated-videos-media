import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Owl, Raccoon, Study, Counter, Board, W} from '../components/Duo';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles, Trail} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* THE HIDDEN RULE #8 — Scarcity (Worchel, Lee & Adewole 1975, JPSP 32:906–914: the same cookies were rated more desirable
   from a jar of 2 than from a jar of 10; rated higher still when the jar went from plenty to scarce because others wanted them).
   Duo look + animation kit v2 (Set wrapper from rule6/7). The bias HAPPENS to Kit first (he lunges past the full jar),
   then the Professor names it. Scenes: jarHook, twoJars, kitGrab, scarcityName, studyJars, jarTurn. */
const OL = '#1b120b';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const talkOf = (mouth: number[] | undefined, f: number) => (mouth ? mouth[Math.min(mouth.length - 1, Math.max(0, f))] ?? 0 : 0);
const spk = (scene: SceneProps['scene'], who: string, mouth: number[] | undefined, f: number) => ((scene.speaker ?? 'prof') === who ? talkOf(mouth, f) : 0);

const Badge: React.FC<{text: string}> = ({text}) => (
  <div style={{position: 'absolute', left: 40, top: 190, fontFamily: BODY, fontWeight: 800, fontSize: 30, letterSpacing: 4, color: W.cream, border: `3px solid ${W.cream}`, borderRadius: 10, padding: '4px 14px', opacity: 0.85}}>{text}</div>
);

const Set: React.FC<{cam: {x: number; y: number; zoom: number; roll?: number}; board?: React.ReactNode; actors?: React.ReactNode; front?: React.ReactNode}> = ({cam, board, actors, front}) => (
  <CameraRig cam={cam}>
    <Layer depth={0.55} blur={1}><Study /></Layer>
    <Layer depth={0.8}>{board}</Layer>
    <Layer depth={1}>{actors}</Layer>
    <Layer depth={1.2}><Counter top={1260} />{front}</Layer>
  </CameraRig>
);

/* One cookie (chocolate chips); bite = 0..1 takes a round bite out of the top-right. */
const Cookie: React.FC<{x: number; y: number; r?: number; rot?: number; bite?: number}> = ({x, y, r = 26, rot = 0, bite = 0}) => (
  <svg width={r * 2 + 8} height={r * 2 + 8} viewBox="-4 -4 60 60" style={{position: 'absolute', left: x - r, top: y - r, rotate: `${rot}deg`, overflow: 'visible'}}>
    <defs><mask id={`bt${Math.round(x)}${Math.round(y)}`}><rect x={-4} y={-4} width={60} height={60} fill="#fff" />{bite > 0 ? <circle cx={46} cy={8} r={16 * bite} fill="#000" /> : null}</mask></defs>
    <g mask={`url(#bt${Math.round(x)}${Math.round(y)})`}>
      <circle cx={26} cy={26} r={25} fill="#d59a52" stroke={OL} strokeWidth={3.5} />
      {[[16, 16], [33, 13], [28, 30], [14, 34], [38, 36]].map(([cx, cy], i) => <circle key={i} cx={cx} cy={cy} r={3.6} fill="#4a2a17" />)}
    </g>
  </svg>
);

/* Glass jar standing with its base at (x, y). n cookies stacked; label text on a paper tag; wob = tilt; glow = golden halo. */
const Jar: React.FC<{x: number; y: number; n: number; s?: number; label?: string; labelColor?: string; wob?: number; glow?: number; dim?: number; lid?: number}> = ({x, y, n, s = 1, label, labelColor = W.cream, wob = 0, glow = 0, dim = 0, lid = 0}) => {
  const w = 170 * s;
  const h = 230 * s;
  const pos = (i: number) => ({cx: (32 + (i % 3) * 52 + (Math.floor(i / 3) % 2) * 18) * s, cy: h - (30 + Math.floor(i / 3) * 40) * s});
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y - h, width: w, height: h, rotate: `${wob}deg`, transformOrigin: '50% 100%', filter: dim ? `brightness(${1 - dim * 0.55}) saturate(${1 - dim * 0.6})` : undefined}}>
      {glow > 0 ? <div style={{position: 'absolute', left: -70 * s, top: -70 * s, width: w + 140 * s, height: h + 140 * s, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,201,77,0.65), transparent 65%)', opacity: glow}} /> : null}
      <div style={{position: 'absolute', left: 0, top: 26 * s, width: w, height: h - 26 * s, borderRadius: `${26 * s}px ${26 * s}px ${34 * s}px ${34 * s}px`, background: 'rgba(200,235,245,0.22)', border: `${5 * s}px solid ${OL}`, overflow: 'hidden'}}>
        {new Array(n).fill(0).map((_, i) => {
          const p = pos(i);
          return <Cookie key={i} x={p.cx} y={p.cy - 26 * s} r={24 * s} rot={i * 47} />;
        })}
        <div style={{position: 'absolute', left: 16 * s, top: 14 * s, width: 14 * s, height: h * 0.55, borderRadius: 8, background: 'rgba(255,255,255,0.35)'}} />
      </div>
      <div style={{position: 'absolute', left: 12 * s, top: 2 * s - lid * 70 * s, width: w - 24 * s, height: 34 * s, borderRadius: 8 * s, background: '#b0503a', border: `${5 * s}px solid ${OL}`, rotate: `${lid * -25}deg`}} />
      {label ? <div style={{position: 'absolute', left: -20 * s, right: -20 * s, top: h * 0.42, textAlign: 'center'}}>
        <span style={{fontFamily: DISPLAY, fontSize: 40 * s, color: OL, background: labelColor, border: `${4 * s}px solid ${OL}`, borderRadius: 10 * s, padding: `0 ${12 * s}px`, display: 'inline-block', rotate: '-6deg'}}>{label}</span>
      </div> : null}
    </div>
  );
};

const Chip: React.FC<{text: string; a: number; x: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, x, y, color = W.gold, size = 64, rot = -4}) => {
  const frame = useCurrentFrame();
  if (frame < a) return null;
  const s = kf(frame - a, [[0, 0.2], [9, 1, EASE.overshoot]]);
  return <div style={{position: 'absolute', left: x, top: y, scale: String(s), rotate: `${rot}deg`, fontFamily: DISPLAY, fontSize: size, color: OL, background: color, border: `6px solid ${OL}`, borderRadius: 16, padding: '0 20px', boxShadow: `0 8px 0 ${OL}`, whiteSpace: 'nowrap'}}>{text}</div>;
};

/* jarHook (Arm B, motion on frame 1): Kit is already mid-lunge from the right, past the full jar, towards the jar with two;
   punch-in at 1.2 s; on "Except" he hugs the jar (it wobbles); on "fight" he yanks it to his chest (camera kick). */
const JarHook: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const eAt = at(captions, scene.exceptOnWord, fps, dur * 0.5);
  const fAt = at(captions, scene.fightOnWord, fps, dur * 0.8);
  const kx = kf(frame, [[0, 790], [10, 720, EASE.out], [fAt, 725], [fAt + 8, 760, EASE.overshoot]]);
  const dx = frame < 10 ? 22 : 0;
  const jarX = kf(frame, [[fAt, 640], [fAt + 8, 760, EASE.overshoot]]);
  const wob = Math.sin(frame / 2.4) * kf(frame, [[0, 7], [14, 2], [eAt, 2], [eAt + 2, 9], [eAt + 18, 2]]);
  const cam = {x: kf(frame, [[0, 600], [36, 700, EASE.smooth], [dur, 720, EASE.smooth]]), y: kf(frame, [[0, 1020], [36, 1060, EASE.smooth]]), zoom: (frame < 36 ? 1.38 : 1.62) + kf(frame, [[36, 0], [dur, 0.07, EASE.smooth]]) + impulses(frame, [36, fAt + 4], 0.05, 12, 1.4), roll: impulse(frame, fAt + 4, 1.5, 14, 1.1)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<div style={{position: 'absolute', left: 330, top: 560, width: 520, height: 150, rotate: `${Math.sin(frame / 9) * 3 + impulse(frame, fAt + 2, 5, 16, 0.9)}deg`, transformOrigin: '50% -60px'}}>
          <div style={{position: 'absolute', left: 90, top: -60, width: 6, height: 60, background: OL}} /><div style={{position: 'absolute', left: 424, top: -60, width: 6, height: 60, background: OL}} />
          <div style={{position: 'absolute', inset: 0, background: W.wood, border: `8px solid ${OL}`, borderRadius: 18, textAlign: 'center', fontFamily: DISPLAY, fontSize: 76, lineHeight: '130px', color: W.cream}}>🍪 COOKIES</div>
        </div>}
        actors={<>
          <Owl x={0} y={800} s={1.15} talk={spk(scene, 'prof', mouth, frame)} look={kf(frame, [[0, 1], [eAt, 1], [eAt + 6, 0.6]])} point={kf(frame, [[eAt, 0], [eAt + 8, 0.7, EASE.out]])} />
          <Jar x={430} y={1268} n={10} label="10" />
          <Jar x={jarX} y={1268} n={2} label="ONLY 2!" labelColor={W.gold} wob={wob} glow={0.5 + Math.sin(frame / 6) * 0.2} />
          <Trail dx={dx} trail={3}><Raccoon x={kx} y={830} s={1.1} look={-1} joy={0.7} arm={frame >= eAt ? 0.55 : 0.9} talk={spk(scene, 'kit', mouth, frame)} /></Trail>
          <Particles count={8} color={W.gold} size={9} speedY={-0.7} speedX={0.1} seed={4} opacity={0.45} />
        </>} />
      {frame >= eAt ? <Chip text="SAME COOKIES?" a={eAt} x={230} y={455} size={60} /> : null}
      <Badge text={(scene.badge as string) ?? 'THE HIDDEN RULE #8'} />
    </AbsoluteFill>
  );
};

/* twoJars: cookies drop into both jars from the top ("same baker"); camera trucks from the jar of ten to the jar of two;
   the owl taps each jar; Kit's eyes dart between them. */
const TwoJars: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tenOnWord, fps, dur * 0.55);
  const wAt = at(captions, scene.twoOnWord, fps, dur * 0.85);
  const n10 = Math.min(10, Math.floor(kf(frame, [[0, 0], [Math.max(8, tAt - 4), 10]])));
  const n2 = Math.min(2, Math.floor(kf(frame, [[6, 0], [24, 2]])));
  const cam = {x: kf(frame, [[0, 400], [tAt, 430, EASE.smooth], [wAt, 680, EASE.smooth], [dur, 700, EASE.smooth]]), y: kf(frame, [[0, 1000], [dur, 1040, EASE.smooth]]), zoom: kf(frame, [[0, 1.5], [dur, 1.42, EASE.smooth]]) + impulses(frame, [tAt + 3, wAt + 3], 0.04, 12, 1.4)};
  const drop = (frame % 9) / 9;
  return (
    <AbsoluteFill>
      <Set cam={cam}
        actors={<>
          <Owl x={60} y={800} s={1.15} talk={spk(scene, 'prof', mouth, frame)} look={frame < wAt ? 0.4 : 1} point={kf(frame, [[tAt - 6, 0], [tAt, 0.8, EASE.out], [wAt - 6, 0.5], [wAt, 1, EASE.out]])} />
          <Jar x={440} y={1268} n={n10} label={frame >= tAt ? '10' : undefined} lid={frame < tAt - 4 ? 1 : 0} />
          <Jar x={700} y={1268} n={n2} label={frame >= wAt ? 'ONLY 2!' : undefined} labelColor={W.gold} lid={frame < 26 ? 1 : 0} wob={frame >= wAt ? impulse(frame, wAt, 6, 14, 1.2) : 0} />
          {frame < tAt - 4 ? <Cookie x={440 + Math.sin(frame) * 20} y={860 + drop * 180} r={24} rot={frame * 20} /> : null}
          <Raccoon x={830} y={860} s={0.95} look={frame < tAt ? -0.2 : frame < wAt ? -1 : 0.4} joy={frame >= wAt ? 0.6 : 0.1} />
        </>} />
      <Chip text="SAME BAKER" a={4} x={120} y={330} size={50} color={W.cream} rot={-3} />
      {frame >= tAt ? <Chip text="10" a={tAt} x={300} y={560} size={90} color={W.cream} /> : null}
      {frame >= wAt ? <Chip text="2" a={wAt} x={700} y={560} size={90} rot={5} /> : null}
    </AbsoluteFill>
  );
};

/* kitGrab (Kit speaks): close, handheld; Kit's arm dives into the jar of two, pulls a cookie, bites it on "better!" (crumbs burst). */
const KitGrab: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bAt = at(captions, scene.biteOnWord, fps, dur * 0.75);
  const reach = kf(frame, [[0, 0], [10, 1, EASE.out], [22, 1], [34, 0, EASE.smooth]]);
  const ck = kf(frame, [[22, 0], [34, 1, EASE.smooth]]);
  const cam = {x: kf(frame, [[0, 640], [dur, 700, EASE.smooth]]) + Math.sin(frame / 7) * 4, y: kf(frame, [[0, 1080], [dur, 1040, EASE.smooth]]), zoom: kf(frame, [[0, 1.55], [dur, 1.75, EASE.smooth]]) + impulse(frame, bAt + 2, 0.06, 14, 1.3), roll: kf(frame, [[0, 2], [dur, -1.5, EASE.smooth]])};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        actors={<>
          <Jar x={540} y={1268} n={ck > 0.5 ? 1 : 2} label="ONLY 2!" labelColor={W.gold} lid={0.35} wob={Math.sin(frame / 2) * 3 * reach} />
          <Raccoon x={640} y={830} s={1.1} look={kf(frame, [[0, -0.8], [30, 0.2]])} joy={frame >= bAt ? 0.95 : 0.6} arm={0.3 + reach * 0.3} talk={spk(scene, 'kit', mouth, frame)} />
          {ck > 0 ? <Cookie x={kf(frame, [[22, 560], [34, 905, EASE.smooth]])} y={kf(frame, [[22, 1110], [34, 1010, EASE.smooth]])} r={30} rot={frame * 3} bite={frame >= bAt ? 1 : 0} /> : null}
          {frame >= bAt ? <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>{new Array(9).fill(0).map((_, i) => {
            const d = frame - bAt;
            return <div key={i} style={{position: 'absolute', left: 905 + Math.cos(i * 0.9) * d * 7, top: 1000 + Math.sin(i * 1.7) * d * 5 + d * d * 0.35, width: 9, height: 9, borderRadius: 3, background: '#c98a44', opacity: Math.max(0, 1 - d / 26)}} />;
          })}</div> : null}
        </>} />
    </AbsoluteFill>
  );
};

/* scarcityName: pull back; Kit chews happily; the full jar dims, the jar of two glows; SCARCITY slams on the board;
   on "rare" a WANT meter needle swings to max. */
const ScarcityName: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.titleOnWord, fps, dur * 0.25);
  const rAt = at(captions, scene.rareOnWord, fps, dur * 0.55);
  const title = kf(frame, [[tAt, 0], [tAt + 9, 1, EASE.overshoot]]);
  const needle = kf(frame, [[0, -60], [rAt, -50], [rAt + 12, 62, EASE.overshoot]]) + Math.sin(frame / 3) * (frame > rAt + 12 ? 3 : 0);
  const cam = {x: 540, y: kf(frame, [[0, 1000], [dur, 820, EASE.smooth]]), zoom: kf(frame, [[0, 1.4], [dur, 1.02, EASE.smooth]]) + impulse(frame, tAt + 5, 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          {frame >= tAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 34, textAlign: 'center', scale: String(title), fontFamily: DISPLAY, fontSize: 108, color: W.coral}}>SCARCITY</div> : null}
          {frame >= rAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 170, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 40, color: W.chalk, opacity: kf(frame, [[rAt, 0], [rAt + 8, 1]])}}>LOOKS RARE → "MUST BE BETTER"</div> : null}
          <svg width={420} height={240} viewBox="0 0 420 240" style={{position: 'absolute', left: 240, top: 260}}>
            <path d="M40 210 A170 170 0 0 1 380 210" fill="none" stroke={W.chalk} strokeWidth={10} />
            <path d="M300 90 A170 170 0 0 1 380 210" fill="none" stroke={W.coral} strokeWidth={14} />
            <line x1={210} y1={210} x2={210 + Math.sin((needle * Math.PI) / 180) * 150} y2={210 - Math.cos((needle * Math.PI) / 180) * 150} stroke={W.gold} strokeWidth={10} strokeLinecap="round" />
            <circle cx={210} cy={210} r={16} fill={W.gold} />
            <text x={210} y={150} textAnchor="middle" fontFamily={BODY} fontWeight={900} fontSize={34} fill={W.chalk}>WANT</text>
          </svg>
        </Board>}
        actors={<>
          <Owl x={0} y={800} s={1.15} talk={spk(scene, 'prof', mouth, frame)} look={0.6} point={kf(frame, [[tAt - 4, 0.2], [tAt + 4, 1, EASE.out]])} />
          <Jar x={430} y={1268} n={10} label="10" dim={kf(frame, [[rAt, 0], [rAt + 12, 1]])} />
          <Jar x={590} y={1268} n={1} label="ONLY 2!" labelColor={W.gold} glow={kf(frame, [[rAt, 0], [rAt + 12, 1]])} />
          <Raccoon x={700} y={830} s={1.05} look={-0.4} joy={0.5 + Math.sin(frame / 4) * 0.2} talk={Math.max(0, Math.sin(frame / 3)) * 0.5} />
          <Cookie x={950} y={1010} r={26} bite={1} />
        </>} />
    </AbsoluteFill>
  );
};

/* studyJars: the 1975 study on the board. Two jars with LIKE bars; "Which did they like more?" → the bar of the jar of two grows past
   the jar of ten on "nearly"; on "others" a third jar empties from 10 to 2 as hands grab cookies, and its bar goes highest. */
const StudyJars: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const qAt = at(captions, scene.askOnWord, fps, dur * 0.45);
  const aAt = at(captions, scene.answerOnWord, fps, dur * 0.6);
  const oAt = at(captions, scene.othersOnWord, fps, dur * 0.85);
  const bar10 = kf(frame, [[qAt, 0], [qAt + 14, 0.45, EASE.out]]);
  const bar2 = kf(frame, [[qAt, 0], [qAt + 14, 0.45, EASE.out], [aAt, 0.45], [aAt + 14, 0.7, EASE.overshoot]]);
  const bar3 = kf(frame, [[oAt + 10, 0], [oAt + 26, 0.92, EASE.overshoot]]);
  const n3 = Math.max(2, 10 - Math.floor(kf(frame, [[oAt - 4, 0], [oAt + 14, 8]])));
  const cam = {x: kf(frame, [[0, 520], [oAt, 520], [oAt + 20, 640, EASE.smooth], [dur, 650, EASE.smooth]]), y: kf(frame, [[0, 620], [dur, 680, EASE.smooth]]), zoom: kf(frame, [[0, 1.12], [oAt, 1.18, EASE.smooth], [dur, 1.12, EASE.smooth]]) + impulses(frame, [aAt + 4, oAt + 8], 0.035, 12, 1.4)};
  const Col: React.FC<{x: number; n: number; bar: number; lab: string; hot?: boolean; show: boolean}> = ({x, n, bar, lab, hot, show}) => (
    <div style={{position: 'absolute', left: x, top: 100, width: 250, height: 440, opacity: show ? 1 : 0}}>
      <Jar x={125} y={230} n={n} s={0.9} />
      <div style={{position: 'absolute', left: 30, top: 250, width: 190, height: 150, border: `4px solid ${W.chalk}`, borderRadius: 10, overflow: 'hidden'}}>
        <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: `${bar * 100}%`, background: hot ? W.coral : W.grey}} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 404, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 24, color: W.chalk}}>{lab}</div>
    </div>
  );
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 16, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 28, color: W.grey, letterSpacing: 3}}>WORCHEL, LEE & ADEWOLE · 1975</div>
          <div style={{position: 'absolute', left: 0, right: 0, top: 54, textAlign: 'center', fontFamily: DISPLAY, fontSize: 40, color: W.chalk}}>SAME COOKIE. WHICH DID THEY LIKE MORE?</div>
          <Col x={20} n={10} bar={bar10} lab="JAR OF 10" show />
          <Col x={300} n={2} bar={bar2} lab="JAR OF 2" hot={frame >= aAt} show />
          <Col x={600} n={n3} bar={bar3} lab="OTHERS GRABBED THEM" hot show={frame >= oAt - 6} />
          {frame >= oAt - 4 && frame < oAt + 18 ? <div style={{position: 'absolute', left: 690 + Math.sin(frame) * 30, top: kf(frame, [[oAt - 4, 260], [oAt + 18, 60]]), fontSize: 64, rotate: '20deg'}}>✋</div> : null}
          {frame >= qAt && frame < aAt ? <div style={{position: 'absolute', left: 250, top: 230, fontFamily: DISPLAY, fontSize: 120, color: W.gold, rotate: `${Math.sin(frame / 3) * 12}deg`}}>?</div> : null}
        </Board>}
        actors={<>
          <Owl x={0} y={800} s={1.15} talk={spk(scene, 'prof', mouth, frame)} point={frame > qAt ? 1 : 0.4} look={0.5} />
          <Raccoon x={700} y={840} s={1.05} look={frame < aAt ? -0.8 : -0.2} joy={frame >= oAt ? 0 : 0.3} arm={0.35 + Math.sin(frame / 5) * 0.15} />
        </>} />
      {frame >= aAt ? <Chip text="THE NEARLY EMPTY ONE" a={aAt} x={150} y={1150} size={50} /> : null}
    </AbsoluteFill>
  );
};

/* jarTurn: "You think I'm talking about cookies" — a phone shop page "ONLY 3 LEFT IN STOCK" (blinking), a sale countdown ticking,
   then the question card; Kit sheepishly puts the cookie back; silent send line; loops into the hook (Kit lunges again). */
const JarTurn: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.stockOnWord, fps, dur * 0.3);
  const tAt = at(captions, scene.saleOnWord, fps, dur * 0.45);
  const qAt = at(captions, scene.askOnWord, fps, dur * 0.6);
  const secs = 59 - Math.floor(Math.max(0, frame - tAt) / fps);
  const blink = Math.floor(frame / 8) % 2 === 0;
  const cam = {x: kf(frame, [[0, 600], [dur, 500, EASE.smooth]]), y: kf(frame, [[0, 760], [dur, 800, EASE.smooth]]), zoom: kf(frame, [[0, 1.0], [qAt, 1.08, EASE.smooth], [dur, 1.13, EASE.smooth]]) + impulse(frame, qAt + 4, 0.04, 12, 1.4), roll: kf(frame, [[0, -1], [dur, 1, EASE.smooth]])};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 20, right: 20, top: 20, textAlign: 'center', fontFamily: DISPLAY, fontSize: 48, color: W.chalk}}>YOU THINK I'M TALKING ABOUT COOKIES.</div>
          <div style={{position: 'absolute', left: 60, top: 100, width: 330, height: 300, background: '#f8fafc', border: `6px solid ${OL}`, borderRadius: 24, scale: String(kf(frame, [[sAt - 8, 0], [sAt, 1, EASE.overshoot]])), opacity: frame >= qAt ? 0.55 : 1}}>
            <div style={{margin: '20px auto 0', width: 150, height: 100, borderRadius: 14, background: '#93c5fd', border: `4px solid ${OL}`}} />
            <div style={{textAlign: 'center', marginTop: 16, fontFamily: BODY, fontWeight: 900, fontSize: 28, color: blink ? '#dc2626' : '#7f1d1d'}}>ONLY 3 LEFT IN STOCK</div>
            <div style={{margin: '12px auto 0', width: 200, height: 46, borderRadius: 12, background: '#22c55e', border: `4px solid ${OL}`, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 26, lineHeight: '40px'}}>BUY NOW</div>
          </div>
          {frame >= tAt ? <div style={{position: 'absolute', left: 440, top: 140, scale: String(kf(frame, [[tAt, 0.3], [tAt + 9, 1, EASE.overshoot]])), opacity: frame >= qAt ? 0.55 : 1}}>
            <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 30, color: W.chalk}}>SALE ENDS IN</div>
            <div style={{fontFamily: DISPLAY, fontSize: 92, color: W.gold}}>23:59:{String(Math.max(0, secs)).padStart(2, '0')}</div>
          </div> : null}
          {frame >= qAt ? <div style={{position: 'absolute', left: 50, right: 50, top: 300, scale: String(kf(frame, [[qAt, 0.3], [qAt + 9, 1, EASE.overshoot]])), background: W.cream, border: `5px solid ${OL}`, borderRadius: 18, padding: '10px 18px', textAlign: 'center', fontFamily: DISPLAY, fontSize: 42, color: OL, lineHeight: 1.1}}>WOULD I WANT IT IF THERE WERE 100?</div> : null}
          <div style={{position: 'absolute', left: 30, right: 30, top: 450, textAlign: 'center', opacity: kf(frame, [[qAt + 10, 0], [qAt + 20, 1, EASE.out]])}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 23, whiteSpace: 'nowrap', color: '#111', background: '#86efac', padding: '6px 12px', borderRadius: 12, border: `4px solid ${OL}`}}>📤 Send this to the friend who buys anything "almost sold out"</span></div>
        </Board>}
        actors={<>
          <Owl x={0} y={800} s={1.15} talk={spk(scene, 'prof', mouth, frame)} look={frame < qAt ? 0.3 : 1} point={frame >= sAt && frame < qAt ? 1 : 0.3} />
          <Jar x={590} y={1268} n={frame >= qAt + 14 ? 2 : 1} label="ONLY 2!" labelColor={W.gold} lid={frame >= qAt + 14 ? 0 : 1} />
          <Raccoon x={700} y={840} s={1.05} look={frame < qAt ? -0.6 : -1} joy={frame < qAt ? 0.2 : 0} arm={kf(frame, [[qAt, 0.2], [qAt + 12, 0.45, EASE.smooth], [qAt + 20, 0.15]])} />
          {frame < qAt + 14 ? <Cookie x={kf(frame, [[qAt, 905], [qAt + 14, 600, EASE.smooth]])} y={kf(frame, [[qAt, 1010], [qAt + 14, 1110, EASE.smooth]])} r={26} bite={1} /> : null}
        </>} />
    </AbsoluteFill>
  );
};

export const RULE8_SCENES: Record<string, React.FC<SceneProps>> = {jarHook: JarHook, twoJars: TwoJars, kitGrab: KitGrab, scarcityName: ScarcityName, studyJars: StudyJars, jarTurn: JarTurn};
