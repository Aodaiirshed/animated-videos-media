import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Embers, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Scenes for daily story series (cinematic, warm/dark, silhouettes only). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/* Recurring grandmother silhouette: bun, rounded shoulders, long dress. */
export const Grandma: React.FC<{x: number; y: number; height: number; skin?: string; rim?: string; pointUp?: number}> = ({
  x, y, height, skin = '#0d0d12', rim = '#ffb347', pointUp = 0,
}) => {
  const s = height / 200;
  return (
    <svg style={{position: 'absolute', left: x - 60 * s, top: y - 200 * s, overflow: 'visible', filter: `drop-shadow(0 0 14px ${rim}) drop-shadow(0 0 2px ${rim})`}}
      width={120 * s} height={200 * s} viewBox="0 0 120 200">
      <circle cx={60} cy={30} r={17} fill={skin} />
      <circle cx={66} cy={12} r={9} fill={skin} />
      <path d="M38 52 Q60 42 82 52 L92 200 L28 200 Z" fill={skin} />
      <path d={`M40 60 l${-14 - pointUp * 6} ${50 - pointUp * 100}`} stroke={skin} strokeWidth={10} strokeLinecap="round" />
      <path d={`M80 60 l${14 + pointUp * 10} ${50 - pointUp * 110}`} stroke={skin} strokeWidth={10} strokeLinecap="round" />
    </svg>
  );
};

/* nightRoom: { counterFrom?, counterTo?, counterLabel?, onWord? } — a boy in a dark bedroom at night,
   a medicine pen glowing on the nightstand, a night counter ticking up. Non-graphic. */
const NightRoom: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.onWord ? wordFrame(captions, scene.onWord as string, fps, 10) : 10;
  const from = (scene.counterFrom as number) ?? 1, to = (scene.counterTo as number) ?? 365;
  const n = Math.round(interpolate(frame, [at, dur - 10], [from, to], {...clamp, easing: Easing.in(Easing.quad)}));
  const glow = 0.6 + 0.4 * Math.sin(frame / 8);
  return (
    <Camera dur={dur} from={1.15} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #03040a 0%, #0a1020 100%)'}} />
      {/* window with moon */}
      <div style={{position: 'absolute', left: 600, top: 260, width: 360, height: 460, background: 'linear-gradient(180deg,#0f1d3a,#1a2c52)', border: '14px solid #070a12'}}>
        <div style={{position: 'absolute', left: 190, top: 70, width: 110, height: 110, borderRadius: '50%', background: '#f4efd8', boxShadow: '0 0 80px 20px rgba(244,239,216,0.45)'}} />
        <div style={{position: 'absolute', left: 166, top: 0, width: 14, height: 460, background: '#070a12'}} />
        <div style={{position: 'absolute', left: 0, top: 220, width: 360, height: 14, background: '#070a12'}} />
      </div>
      {/* moonlight beam */}
      <div style={{position: 'absolute', left: 300, top: 500, width: 700, height: 1000, background: 'linear-gradient(200deg, rgba(200,210,255,0.16), transparent 70%)', transform: 'skewX(-18deg)'}} />
      {/* bed */}
      <svg width={1080} height={700} style={{position: 'absolute', top: 1000}}>
        <rect x={80} y={180} width={640} height={120} rx={20} fill="#151a2a" />
        <rect x={80} y={120} width={180} height={80} rx={30} fill="#1f2638" />
        <rect x={70} y={60} width={30} height={330} fill="#0d111c" />
        <rect x={760} y={170} width={200} height={220} fill="#0d111c" />
      </svg>
      {/* medicine pen on nightstand */}
      <div style={{position: 'absolute', left: 800, top: 1130, width: 120, height: 26, borderRadius: 13, background: '#e8f4ff',
        boxShadow: `0 0 ${20 + glow * 30}px rgba(120,200,255,${0.5 + glow * 0.3})`, rotate: '-8deg'}}>
        <div style={{position: 'absolute', left: 80, top: 4, width: 30, height: 18, borderRadius: 6, background: '#5fb4ff'}} />
      </div>
      <Boy x={400} y={1220} height={360} stage="child" skin={sb.character.palette.skin} rim="#a9c4ff" glow={0.6} />
      {/* night counter */}
      <div style={{position: 'absolute', left: 150, top: 300, opacity: interpolate(frame, [at, at + 8], [0, 1], clamp)}}>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 38, letterSpacing: 8, color: '#a9c4ff'}}>{(scene.counterLabel as string) ?? 'NIGHT'}</div>
        <div style={{fontFamily: DISPLAY, fontSize: 170, lineHeight: 1, color: '#fff', textShadow: '0 0 40px rgba(120,170,255,0.6)'}}>{n}</div>
      </div>
    </Camera>
  );
};

/* grandmaPitch: { insistOnWord?, playOnWord? } — dusty pitch at sunset; big kids, a tiny boy,
   a coach shaking his head, and grandma stepping forward until the boy is sent on. */
const GrandmaPitch: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const insist = scene.insistOnWord ? wordFrame(captions, scene.insistOnWord as string, fps, dur * 0.4) : dur * 0.4;
  const play = scene.playOnWord ? wordFrame(captions, scene.playOnWord as string, fps, dur * 0.75) : dur * 0.75;
  const step = spring({frame: frame - insist, fps, config: {damping: 14}});
  const run = spring({frame: frame - play, fps, config: {damping: 16}});
  const shake = frame < insist ? Math.sin(frame / 3) * 6 : 0;
  return (
    <Camera dur={dur} from={1.0} to={1.1}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #2a0f1e 0%, #a2421e 45%, #f2a14a 70%, #6b3a1c 72%, #3a2010 100%)'}} />
      <div style={{position: 'absolute', left: 620, top: 620, width: 260, height: 260, borderRadius: '50%', background: '#ffd27a', boxShadow: '0 0 160px 60px rgba(255,190,90,0.55)'}} />
      {/* goal posts far */}
      <svg width={1080} height={400} style={{position: 'absolute', top: 760}}>
        <path d="M140 220 L140 100 L360 100 L360 220" stroke="#2a160a" strokeWidth={10} fill="none" />
      </svg>
      {/* big kids */}
      {[0, 1, 2, 3].map((i) => (
        <Boy key={i} x={560 + i * 120} y={1300 + (i % 2) * 20} height={320} stage="teen" pose="run" phase={frame / 4 + i} skin="#1a0d06" rim="#ffb066" glow={0.3} />
      ))}
      {/* coach */}
      <div style={{rotate: `${shake}deg`}}>
        <Boy x={300} y={1300} height={420} stage="adult" hair="short" skin="#140a05" rim="#ffb066" glow={0.4} />
      </div>
      {/* grandma steps forward */}
      <Grandma x={140 + step * 70} y={1330} height={380} rim="#ffd27a" />
      {/* tiny boy: by her side, then runs onto the pitch */}
      <Boy x={220 + step * 60 + run * 300} y={1340} height={190} stage="child" pose={run > 0.05 && run < 0.95 ? 'run' : 'stand'} phase={frame / 3}
        skin={sb.character.palette.skin} rim="#ffe08a" glow={0.9} />
      <Embers count={30} color="#ffcf8a" seed="dust" rise={2} />
    </Camera>
  );
};

/* growthChart: { label?, flatOnWord?, labelOnWord? } — height marks on a wall: other kids' lines climb, his stays flat. */
const GrowthChart: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const flatAt = scene.flatOnWord ? wordFrame(captions, scene.flatOnWord as string, fps, 15) : 15;
  const labelAt = scene.labelOnWord ? wordFrame(captions, scene.labelOnWord as string, fps, dur * 0.6) : dur * 0.6;
  const grow = interpolate(frame, [0, flatAt + 30], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const lab = spring({frame: frame - labelAt, fps, config: {damping: 12}});
  const ages = [7, 8, 9, 10, 11];
  return (
    <Camera dur={dur} from={1.06} to={1.0}>
      <AbsoluteFill style={{background: '#1b1612'}} />
      {/* wallpaper stripes */}
      <AbsoluteFill style={{backgroundImage: 'repeating-linear-gradient(90deg, rgba(255,255,255,0.03) 0 40px, transparent 40px 80px)'}} />
      {/* door frame with height marks */}
      <div style={{position: 'absolute', left: 300, top: 160, width: 480, height: 1300, borderLeft: '26px solid #4a3523', borderRight: '26px solid #4a3523', borderTop: '26px solid #4a3523'}} />
      {new Array(14).fill(0).map((_, i) => (
        <div key={i} style={{position: 'absolute', left: 326, top: 300 + i * 80, width: 30, height: 4, background: 'rgba(255,255,255,0.25)'}} />
      ))}
      {/* other kids' marks: climbing */}
      {ages.map((a, i) => {
        const y = 1100 - i * 120 * grow;
        return (
          <div key={a} style={{position: 'absolute', left: 360, top: y, width: 200, height: 6, background: '#9fc3ff', opacity: 0.7}}>
            <span style={{position: 'absolute', left: 210, top: -22, fontFamily: BODY, fontWeight: 800, fontSize: 30, color: '#9fc3ff'}}>friends, age {a}</span>
          </div>
        );
      })}
      {/* his marks: stuck */}
      {ages.map((a, i) => (
        <div key={`h${a}`} style={{position: 'absolute', left: 360, top: 1150 - Math.min(i, 2) * 30 * grow, width: 200, height: 8, background: '#ff6b6b',
          opacity: frame > flatAt + i * 6 ? 1 : 0, boxShadow: '0 0 14px #ff6b6b'}} />
      ))}
      <Boy x={460} y={1460} height={300} stage="child" skin={sb.character.palette.skin} rim="#ff9b8a" glow={0.7} />
      <div style={{position: 'absolute', top: 1500, left: 0, right: 0, textAlign: 'center', opacity: lab, scale: String(0.8 + lab * 0.2)}}>
        <span style={{fontFamily: DISPLAY, fontSize: 64, color: '#fff', background: '#c8231b', padding: '8px 28px', borderRadius: 14}}>
          {(scene.label as string) ?? 'GROWTH HORMONE DEFICIENCY'}
        </span>
      </div>
    </Camera>
  );
};

/* moneyJar: { stampText?, stampOnWord?, drainOnWord? } — a family savings jar empties; a stamp lands. */
const MoneyJar: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const drainAt = scene.drainOnWord ? wordFrame(captions, scene.drainOnWord as string, fps, 10) : 10;
  const stampAt = scene.stampOnWord ? wordFrame(captions, scene.stampOnWord as string, fps, dur * 0.7) : dur * 0.7;
  const level = interpolate(frame, [drainAt, stampAt], [1, 0.08], clamp);
  const st = spring({frame: frame - stampAt, fps, config: {damping: 12, stiffness: 300}});
  return (
    <Shake at={stampAt} amount={18}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #2b2112 0%, #08070a 70%)'}} />
        {/* jar */}
        <div style={{position: 'absolute', left: 290, top: 380, width: 500, height: 640, borderRadius: '60px 60px 90px 90px', border: '10px solid rgba(220,235,255,0.55)',
          background: 'rgba(220,235,255,0.06)', overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: `${level * 100}%`}}>
            {new Array(60).fill(0).map((_, i) => (
              <div key={i} style={{position: 'absolute', left: (i % 8) * 60 + ((Math.floor(i / 8) % 2) * 30), bottom: Math.floor(i / 8) * 36, width: 64, height: 22,
                borderRadius: '50%', background: 'linear-gradient(#ffe08a,#c99a2a)', border: '2px solid #8a6516'}} />
            ))}
          </div>
        </div>
        <div style={{position: 'absolute', left: 330, top: 340, width: 420, height: 60, borderRadius: 14, background: '#5a4630'}} />
        {/* coins falling out of the bottom */}
        {frame > drainAt && frame < stampAt && new Array(10).fill(0).map((_, i) => {
          const t = ((frame - drainAt) * 3 + i * 40) % 300;
          return <div key={i} style={{position: 'absolute', left: 500 + Math.sin(i * 7) * 120, top: 1040 + t, width: 50, height: 18, borderRadius: '50%',
            background: '#e6b947', opacity: 1 - t / 300, rotate: `${t * 3}deg`}} />;
        })}
        {/* stamp */}
        {frame >= stampAt && (
          <div style={{position: 'absolute', top: 600, width: '100%', textAlign: 'center', rotate: '-9deg', scale: String(interpolate(st, [0, 1], [3, 1])), opacity: st}}>
            <span style={{fontFamily: DISPLAY, fontSize: 130, color: '#ff3b30', border: '12px solid #ff3b30', padding: '0 30px', background: 'rgba(0,0,0,0.35)'}}>
              {(scene.stampText as string) ?? 'HELP STOPPED'}
            </span>
          </div>
        )}
      </Camera>
    </Shake>
  );
};

/* cliffhanger: { next?: "PART 2", tease?, sandOnWord? } — reusable series ending: hourglass running out,
   lone silhouette, "TO BE CONTINUED", next-part card. */
const Cliffhanger: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.sandOnWord ? wordFrame(captions, scene.sandOnWord as string, fps, 10) : 10;
  const sand = interpolate(frame, [0, dur], [0, 1], clamp);
  const tbc = spring({frame: frame - at, fps, config: {damping: 12}});
  const card = spring({frame: frame - at - 20, fps, config: {damping: 13}});
  const heartbeat = Math.pow(Math.max(0, Math.sin(frame / 7)), 8);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #1a0a0a 0%, #030303 75%)'}} />
      <AbsoluteFill style={{boxShadow: `inset 0 0 ${180 + heartbeat * 120}px rgba(200,30,20,${0.35 + heartbeat * 0.3})`}} />
      {/* hourglass */}
      <svg width={1080} height={900} style={{position: 'absolute', top: 200}}>
        <path d="M390 60 L690 60 L560 380 L690 700 L390 700 L520 380 Z" fill="none" stroke="#d9c8a0" strokeWidth={10} />
        <rect x={360} y={40} width={360} height={26} rx={10} fill="#6b4a26" />
        <rect x={360} y={694} width={360} height={26} rx={10} fill="#6b4a26" />
        {/* top sand shrinking */}
        <path d={`M${400 + sand * 100} ${70 + sand * 250} L${680 - sand * 100} ${70 + sand * 250} L545 375 L535 375 Z`} fill="#e6b947" />
        {/* stream */}
        <rect x={536} y={380} width={8} height={300} fill="#e6b947" opacity={sand < 0.98 ? 0.9 : 0} />
        {/* bottom pile growing */}
        <path d={`M${400} 692 L${680} 692 L${540 + 140 * (1 - sand)} ${692 - sand * 140} L${540 - 140 * (1 - sand)} ${692 - sand * 140} Z`} fill="#e6b947" />
      </svg>
      <Boy x={540} y={1500} height={300} stage="child" skin={sb.character.palette.skin} rim="#ff8a6a" glow={0.6} />
      <div style={{position: 'absolute', top: 1050, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 110, color: '#fff', opacity: tbc,
        letterSpacing: interpolate(tbc, [0, 1], [30, 4]), textShadow: '0 0 40px rgba(255,80,60,0.6)'}}>TO BE CONTINUED…</div>
      <div style={{position: 'absolute', top: 1190, width: '100%', textAlign: 'center', opacity: card, scale: String(0.8 + card * 0.2)}}>
        <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 48, color: '#000', background: sb.palette.gold, padding: '16px 40px', borderRadius: 60}}>
          {(scene.next as string) ?? 'PART 2'} · {(scene.tease as string) ?? 'TOMORROW'}
        </span>
      </div>
    </AbsoluteFill>
  );
};

/* seriesTitle: { title, part, subtitle?, pattern? } — big series opener card (name shown). */
const SeriesTitle: React.FC<SceneProps> = ({sb, scene, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 13}});
  const s2 = spring({frame: frame - 10, fps, config: {damping: 13}});
  return (
    <Camera dur={dur} from={1.1} to={1.0}>
      <AbsoluteFill style={{background: '#050608'}} />
      <AbsoluteFill style={{opacity: 0.35, backgroundImage: (scene.pattern as string) ?? 'linear-gradient(180deg, #74acdf 0 33%, #f4f4f4 33% 66%, #74acdf 66% 100%)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, rgba(0,0,0,0.15), rgba(0,0,0,0.9) 75%)'}} />
      <div style={{position: 'absolute', top: 420, width: '100%', textAlign: 'center'}}>
        <div style={{display: 'inline-block', fontFamily: BODY, fontWeight: 800, fontSize: 46, letterSpacing: 10, color: '#000', background: sb.palette.gold,
          padding: '10px 34px', borderRadius: 50, opacity: s2, scale: String(0.8 + s2 * 0.2)}}>{String(scene.part ?? 'PART 1')}</div>
        <div style={{fontFamily: DISPLAY, fontSize: 158, lineHeight: 1.02, color: '#fff', marginTop: 30, opacity: s, translate: `0px ${(1 - s) * 80}px`,
          WebkitTextStroke: '6px #000', paintOrder: 'stroke fill', textShadow: '0 0 60px rgba(116,172,223,0.6)'}}>{String(scene.title ?? '')}</div>
        {scene.subtitle ? <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 48, color: '#cfe4ff', marginTop: 24, opacity: s2}}>{String(scene.subtitle)}</div> : null}
      </div>
    </Camera>
  );
};

export const SERIES1_SCENES: Record<string, React.FC<SceneProps>> = {
  nightRoom: NightRoom,
  grandmaPitch: GrandmaPitch,
  growthChart: GrowthChart,
  moneyJar: MoneyJar,
  cliffhanger: Cliffhanger,
  seriesTitle: SeriesTitle,
};
