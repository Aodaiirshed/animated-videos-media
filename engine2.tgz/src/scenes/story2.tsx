import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Embers, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* More cinematic story scenes for player videos (warm/dark film look, silhouettes only). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Rain: React.FC<{count?: number; speed?: number}> = ({count = 120, speed = 38}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {new Array(count).fill(0).map((_, i) => {
        const x = random(`rx${i}`) * 1200 - 60;
        const y = ((random(`ry${i}`) * 2100 + frame * speed * (0.7 + random(`rs${i}`) * 0.6)) % 2100) - 100;
        return <div key={i} style={{position: 'absolute', left: x, top: y, width: 2.5, height: 46, background: 'rgba(190,210,255,0.35)', rotate: '12deg'}} />;
      })}
    </AbsoluteFill>
  );
};

/* rainyBench: { stage?, ghost?: true, fadeOnWord? } — lonely boy by a bench under floodlights in the rain.
   With ghost, an adult silhouette (the parent) stands beside him and fades away on cue. */
const RainyBench: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fadeAt = scene.fadeOnWord ? wordFrame(captions, scene.fadeOnWord as string, fps, dur * 0.5) : dur * 0.5;
  const ghostO = scene.ghost ? interpolate(frame, [fadeAt - 4, fadeAt + 22], [0.95, 0], clamp) : 0;
  const flicker = 0.85 + 0.15 * Math.sin(frame / 2.3) * Math.sin(frame / 5.1);
  const stage = (scene.stage as 'child' | 'teen' | 'adult') ?? 'child';
  return (
    <Camera dur={dur} from={1.12} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #03050b 0%, #0b1426 55%, #0a1a12 100%)'}} />
      {/* floodlight */}
      <div style={{position: 'absolute', left: 700, top: 140, width: 160, height: 40, background: '#fff', borderRadius: 8, boxShadow: `0 0 ${120 * flicker}px 40px rgba(220,235,255,${0.55 * flicker})`}} />
      <div style={{position: 'absolute', left: 300, top: 160, width: 900, height: 1600, transformOrigin: '70% 0', rotate: '18deg',
        background: `linear-gradient(180deg, rgba(220,235,255,${0.28 * flicker}), transparent 75%)`, filter: 'blur(24px)'}} />
      {/* wet pitch + reflections */}
      <svg width={1080} height={700} style={{position: 'absolute', top: 1260}}>
        <rect width={1080} height={700} fill="#071a10" />
        <ellipse cx={560} cy={180} rx={420} ry={60} fill="rgba(220,235,255,0.12)" />
        <line x1={0} y1={30} x2={1080} y2={30} stroke="rgba(255,255,255,0.35)" strokeWidth={6} />
      </svg>
      {/* bench */}
      <svg width={1080} height={300} style={{position: 'absolute', top: 1110}}>
        <rect x={160} y={100} width={420} height={22} rx={6} fill="#1b2230" />
        <rect x={160} y={60} width={420} height={16} rx={6} fill="#1b2230" />
        <rect x={190} y={120} width={14} height={90} fill="#141a24" />
        <rect x={540} y={120} width={14} height={90} fill="#141a24" />
      </svg>
      {scene.ghost ? (
        <div style={{opacity: ghostO, filter: `blur(${(1 - ghostO) * 8}px)`}}>
          <Boy x={470} y={1300} height={520} stage="adult" hair="short" skin="#10161f" rim="#9fc3ff" glow={0.6} />
        </div>
      ) : null}
      <Boy x={scene.ghost ? 650 : 540} y={1300} height={stage === 'child' ? 300 : 400} stage={stage} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.7} />
      <Rain />
    </Camera>
  );
};

/* ladder: { tiers: [{label, onWord?}] } — league tiers as platforms; the hero climbs one per cue. */
const Ladder: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tiers = (scene.tiers as {label: string; onWord?: string; fail?: boolean}[]) ?? [];
  const ats = tiers.map((t, i) => (t.onWord ? wordFrame(captions, t.onWord, fps, 10 + i * 30) : 10 + i * 30));
  let level = 0;
  ats.forEach((a, i) => { if (frame >= a) level = i; });
  const prev = Math.max(0, level - 1);
  const p = spring({frame: frame - (ats.at(level) ?? 0), fps, config: {damping: 14}});
  const plat = (i: number) => ({x: 90 + i * 250, y: 860 - i * 250});
  const cur = plat(level), pr = plat(prev);
  const bx = level === 0 ? cur.x + 110 : pr.x + 110 + (cur.x - pr.x) * p;
  const by = level === 0 ? cur.y : pr.y + (cur.y - pr.y) * p - Math.sin(p * Math.PI) * 120;
  return (
    <Camera dur={dur} from={1.0} to={1.08} panY={60}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 70% 20%, #2a1a08 0%, #07070b 65%)'}} />
      {tiers.map((t, i) => {
        const {x, y} = plat(i);
        const on = frame >= (ats.at(i) ?? 0);
        const s = spring({frame: frame - (ats.at(i) ?? 0), fps, config: {damping: 15}});
        const col = t.fail ? '#c8231b' : sb.palette.gold;
        return (
          <div key={i} style={{opacity: on ? 1 : 0.18}}>
            <div style={{position: 'absolute', left: x, top: y, width: 380, height: 36, borderRadius: 10, background: on ? col : '#444',
              boxShadow: on ? `0 0 40px ${col}` : 'none'}} />
            <div style={{position: 'absolute', left: x, top: y + 50, width: 520, fontFamily: DISPLAY, fontSize: 76, color: on ? '#fff' : '#777',
              translate: `${(1 - s) * 40}px 0px`, opacity: on ? s : 1, textDecoration: t.fail && on ? 'line-through' : 'none', textDecorationColor: '#c8231b'}}>{t.label}</div>
          </div>
        );
      })}
      <Boy x={bx} y={by} height={300} stage="teen" pose={p < 0.95 && level > 0 ? 'run' : 'stand'} phase={frame / 3} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.9} />
      <Embers count={40} color={sb.palette.gold} seed="lad" rise={3} />
    </Camera>
  );
};

/* priceTag: { price, priceLabel?, onWord? } — a paper price tag drops in and swings. */
const PriceTag: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.onWord ? wordFrame(captions, scene.onWord as string, fps, 15) : 15;
  const drop = spring({frame: frame - at, fps, config: {damping: 7, mass: 0.9}});
  const swing = Math.sin((frame - at) / 7) * 9 * Math.exp(-Math.max(0, frame - at) / 40);
  return (
    <Shake at={at + 6} amount={12}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 35%, #2b2112 0%, #08070a 70%)'}} />
        {/* the hero waiting, small, at the bottom */}
        <Boy x={540} y={1500} height={330} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} />
        <div style={{position: 'absolute', left: 540, top: 120, width: 4, height: interpolate(drop, [0, 1], [0, 280]), background: '#d9c8a0', translate: '-50% 0'}} />
        <div style={{position: 'absolute', left: 540, top: 120, transformOrigin: '50% 0', rotate: `${swing}deg`, translate: `-50% ${interpolate(drop, [0, 1], [-900, 0])}px`}}>
          <div style={{marginTop: 280, width: 620, padding: '50px 40px 60px', background: '#efe2c4', borderRadius: '30px 30px 30px 30px',
            clipPath: 'polygon(14% 0, 86% 0, 100% 14%, 100% 100%, 0 100%, 0 14%)', textAlign: 'center', boxShadow: '0 40px 80px rgba(0,0,0,0.6)'}}>
            <div style={{width: 46, height: 46, borderRadius: '50%', background: '#08070a', margin: '0 auto 30px'}} />
            <div style={{fontFamily: DISPLAY, fontSize: 150, color: '#1d1a14', lineHeight: 1}}>{String(scene.price ?? '')}</div>
            {scene.priceLabel ? <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 40, color: '#5a4a2c', marginTop: 16}}>{String(scene.priceLabel)}</div> : null}
          </div>
        </div>
      </Camera>
    </Shake>
  );
};

/* skyTribute: { colors?: [c1, c2], starOnWord? } — the hero looks up; one star (a lost parent) brightens. */
const SkyTribute: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.starOnWord ? wordFrame(captions, scene.starOnWord as string, fps, 20) : 20;
  const [c1, c2] = (scene.colors as string[]) ?? ['#1f9d55', '#f4f4f4'];
  const star = spring({frame: frame - at, fps, config: {damping: 16}});
  return (
    <Camera dur={dur} from={1.0} to={1.12} panY={-40}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #02040a 0%, #061224 70%, #0b1a14 100%)'}} />
      {new Array(140).fill(0).map((_, i) => (
        <div key={i} style={{position: 'absolute', left: random(`sx${i}`) * 1080, top: random(`sy${i}`) * 1100, width: 3, height: 3, borderRadius: '50%',
          background: '#fff', opacity: 0.3 + 0.5 * Math.abs(Math.sin(frame / 20 + i))}} />
      ))}
      {/* aurora in the national colours (late hint) */}
      <div style={{position: 'absolute', left: -200, top: 300, width: 1500, height: 500, rotate: '-12deg', filter: 'blur(60px)', opacity: 0.35 * star,
        background: `linear-gradient(90deg, transparent, ${c1}, ${c2}, ${c1}, transparent)`}} />
      {/* the star */}
      <div style={{position: 'absolute', left: 700, top: 380, width: 30, height: 30, borderRadius: '50%', background: '#fff', translate: '-50% -50%',
        boxShadow: `0 0 ${20 + star * 90}px ${10 + star * 40}px rgba(255,240,200,${0.4 + star * 0.5})`, scale: String(0.5 + star)}} />
      <svg width={1080} height={600} style={{position: 'absolute', top: 1380}}>
        <path d="M0 120 Q540 40 1080 120 L1080 600 L0 600 Z" fill="#03060a" />
      </svg>
      <Boy x={420} y={1440} height={560} stage={(scene.stage as 'child' | 'teen' | 'adult') ?? 'adult'} pose={frame >= at && scene.pose === 'cheer' ? 'cheer' : 'stand'} skin={sb.character.palette.skin} rim="#ffe7b0" glow={0.4 + star * 0.6} />
    </Camera>
  );
};


/* guessCard: { question?, cta?, pattern?, patternSize?, onWord? } — mystery ending with NO name:
   the silhouette stays dark, a giant "?" lands, and viewers are pushed to comment their guess. */
const GuessCard: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.onWord ? wordFrame(captions, scene.onWord as string, fps, Math.round(dur * 0.35)) : Math.round(dur * 0.35);
  const q = spring({frame: frame - at, fps, config: {damping: 9, stiffness: 180}});
  const bg = interpolate(frame, [at - 4, at + 14], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const flash = interpolate(frame - at, [0, 2, 12], [0, 0.85, 0], clamp);
  const ctaS = spring({frame: frame - at - 18, fps, config: {damping: 12}});
  const bob = Math.sin(frame / 6) * 10;
  return (
    <Shake at={at} amount={26}>
      <AbsoluteFill style={{background: '#050505'}} />
      <AbsoluteFill style={{opacity: bg * 0.9}}>
        <AbsoluteFill style={{rotate: '-12deg', scale: '1.6', translate: `${frame * 2}px 0px`,
          backgroundImage: (scene.pattern as string) ?? 'linear-gradient(90deg, #333 0 50%, #555 50% 100%)', backgroundSize: (scene.patternSize as string) ?? '440px 440px', opacity: 0.3}} />
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, rgba(0,0,0,0.1), rgba(0,0,0,0.88) 75%)'}} />
      </AbsoluteFill>
      {/* the hero stays a silhouette */}
      <Boy x={540} y={1520} height={640} stage="adult" skin={sb.character.palette.skin} rim={sb.palette.gold} glow={0.4 + bg * 0.6} />
      {/* giant question mark */}
      <div style={{position: 'absolute', top: 280, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 520, lineHeight: 1,
        color: sb.palette.gold, scale: String(q), opacity: q, translate: `0px ${bob}px`, textShadow: '0 0 80px rgba(255,200,80,0.7)', WebkitTextStroke: '8px #000', paintOrder: 'stroke fill'}}>?</div>
      <div style={{position: 'absolute', top: 860, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 130, color: '#fff',
        opacity: q, WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{(scene.question as string) ?? 'WHO IS HE?'}</div>
      <div style={{position: 'absolute', top: 1040, width: '100%', textAlign: 'center', opacity: ctaS, scale: String(0.8 + ctaS * 0.2)}}>
        <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 46, color: '#000', background: sb.palette.gold, padding: '18px 38px', borderRadius: 60}}>
          {(scene.cta as string) ?? 'Comment your guess 👇'}
        </span>
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

export const STORY2_SCENES: Record<string, React.FC<SceneProps>> = {
  rainyBench: RainyBench,
  ladder: Ladder,
  priceTag: PriceTag,
  skyTribute: SkyTribute,
  guessCard: GuessCard,
};
