import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Shake} from '../components/Fx';
import {CameraRig, Layer, Particles, kf, impulse, impulses, EASE} from '../components/Motion';
import {DailyPill, SeriesBadge} from '../components/Host';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Story set 24 (Guess the Player #22, kindness test 14): mealsHook (W1-A payoff picture first), mumShift, warmupDebut, letterUturn, charityCrates.
   Animation kit v2 (CameraRig + Layer parallax, kf, impulse kicks, Particles). Original cartoon player in a neutral grey kit;
   no club names, crests, kits, buildings or likeness. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; a: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, y, color = '#ffcc4d', size = 62, rot = -3}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < a) return null;
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: 40, right: 140, top: y, textAlign: 'center', scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`, boxShadow: `0 8px 0 ${OL}`}}>{text}</span>
    </div>
  );
};
/* a lunch tray: plate, apple, sandwich, milk */
const Tray: React.FC<{x: number; y: number; s?: number; rot?: number; empty?: boolean}> = ({x, y, s = 1, rot = 0, empty}) => (
  <div style={{position: 'absolute', left: x - 110 * s, top: y - 60 * s, width: 220 * s, height: 120 * s, rotate: `${rot}deg`, background: '#93c5fd', border: `${6 * s}px solid ${OL}`, borderRadius: 18 * s}}>
    <div style={{position: 'absolute', left: 14 * s, top: 14 * s, width: 90 * s, height: 80 * s, borderRadius: '50%', background: '#f8fafc', border: `${4 * s}px solid ${OL}`}}>
      {!empty ? <div style={{position: 'absolute', left: 12 * s, top: 18 * s, width: 58 * s, height: 36 * s, background: '#fbbf24', border: `${4 * s}px solid ${OL}`, borderRadius: 8 * s, clipPath: 'polygon(0 100%, 50% 0, 100% 100%)'}} /> : null}
    </div>
    {!empty ? <>
      <div style={{position: 'absolute', left: 118 * s, top: 22 * s, width: 40 * s, height: 40 * s, borderRadius: '50%', background: '#ef4444', border: `${4 * s}px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 166 * s, top: 16 * s, width: 34 * s, height: 70 * s, background: '#f8fafc', border: `${4 * s}px solid ${OL}`, borderRadius: 6 * s}} />
    </> : null}
  </div>
);
const Ball: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 70 * s, height: 70 * s, borderRadius: 35 * s, background: 'radial-gradient(circle at 35% 35%, #fff 0 55%, #cbd5e1 100%)', border: `${5 * s}px solid ${OL}`, rotate: `${rot}deg`}}>
    <div style={{position: 'absolute', left: '32%', top: '30%', width: '36%', height: '36%', background: OL, clipPath: 'polygon(50% 0, 100% 38%, 82% 100%, 18% 100%, 0 38%)'}} />
  </div>
);
/* faceless adult figure (the mum) in a work tabard */
const Mum: React.FC<{x: number; y: number; s?: number; walk?: number}> = ({x, y, s = 1, walk = 0}) => (
  <svg width={240 * s} height={560 * s} viewBox="0 0 240 560" style={{position: 'absolute', left: x - 120 * s, top: y - 560 * s, overflow: 'visible'}}>
    <path d={`M95 400 L${80 + Math.sin(walk) * 20} 550`} stroke={OL} strokeWidth={26} strokeLinecap="round" />
    <path d={`M145 400 L${160 - Math.sin(walk) * 20} 550`} stroke={OL} strokeWidth={26} strokeLinecap="round" />
    <path d="M60 200 Q120 170 180 200 L195 420 L45 420 Z" fill="#0f766e" stroke={OL} strokeWidth={8} />
    <rect x={80} y={240} width={80} height={120} rx={10} fill="#5eead4" stroke={OL} strokeWidth={6} />
    <circle cx={120} cy={130} r={56} fill="#6b4226" stroke={OL} strokeWidth={8} />
    <path d="M62 128 Q64 60 120 62 Q178 60 178 128 Q170 92 120 92 Q72 92 62 128 Z" fill="#141414" stroke={OL} strokeWidth={6} />
    <path d={`M60 210 L${30 + Math.sin(walk) * 10} 360`} stroke="#0f766e" strokeWidth={30} strokeLinecap="round" />
    <path d={`M180 210 L${210 - Math.sin(walk) * 10} 360`} stroke="#0f766e" strokeWidth={30} strokeLinecap="round" />
  </svg>
);

/* mealsHook: { kidOnWord, millionOnWord } — W1-A: frame 0 = the payoff picture already moving: the grown-up player holds a full tray high while
   trays fly out to a crowd (camera dolly + particles) + "HUNGRY KID → 1M KIDS FED". First cut at 1.2 s to the boy at a canteen table
   ("FREE SCHOOL MEALS"); on "million" a hard cut back to the payoff with a ticking 1,000,000 counter. */
const MealsHook: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cut = 36;
  const mAt = Math.max(cut + 20, at(captions, scene.millionOnWord, fps, dur * 0.6));
  const payoff = frame < cut || frame >= mAt;
  const t = frame < cut ? frame : frame - mAt + 20;
  const cam = {x: 540 + kf(t, [[0, -40], [60, 30, EASE.smooth]]), y: 960, zoom: kf(t, [[0, 1.0], [60, 1.1, EASE.smooth]]) + impulse(frame, mAt, 0.05)};
  if (payoff) {
    const n = Math.round(interpolate(frame, [mAt, mAt + 22], [0, 1000000], clamp));
    return (
      <Shake at={mAt} amount={frame >= mAt ? 9 : 0}>
        <CameraRig cam={cam}>
          <Layer depth={0.4}><AbsoluteFill style={{background: 'radial-gradient(circle at 50% 38%, #fde68a 0%, #f59e0b 30%, #7c2d12 80%)'}} /></Layer>
          <Layer depth={0.7}>
            {new Array(14).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 20 + i * 78, top: 1180 + (i % 2) * 40, width: 70, height: 220, borderRadius: '35px 35px 0 0', background: ['#1e293b', '#334155', '#475569'][i % 3], border: `5px solid ${OL}`}}>
              <div style={{position: 'absolute', left: 9, top: -52, width: 52, height: 52, borderRadius: 26, background: '#1e293b', border: `5px solid ${OL}`, translate: `0 ${Math.sin(frame / 5 + i) * 6}px`}} />
            </div>)}
          </Layer>
          <Layer depth={1}>
            <Boy x={540} y={1250} height={430} stage="adult" pose="cheer" phase={frame / 4} skin={sb.character.palette.skin} rim="#fde68a" glow={0.6} mood="happy" />
            <Tray x={540} y={700 + Math.sin(frame / 5) * 8} s={1.1} rot={Math.sin(frame / 7) * 4} />
            {new Array(7).fill(0).map((_, i) => {
              const p = ((t * 1.6 + i * 14) % 60) / 60;
              const side = i % 2 ? 1 : -1;
              return <Tray key={i} x={540 + side * p * (380 + i * 30)} y={720 - Math.sin(p * Math.PI) * 260 + p * 380} s={0.55} rot={side * p * 160} />;
            })}
          </Layer>
          <Layer depth={1.3}><Particles count={26} color="#fef3c7" size={10} speedY={-0.5} seed={4} opacity={0.6} /></Layer>
        </CameraRig>
        <Tag text="HUNGRY KID → 1M KIDS FED" a={-20} y={300} size={60} color="#f8fafc" rot={-2} />
        {frame >= mAt ? <div style={{position: 'absolute', left: 40, right: 140, top: 430, textAlign: 'center', fontFamily: DISPLAY, fontSize: 120, color: '#facc15', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>{n.toLocaleString('en-GB')}</div> : null}
        {frame >= mAt ? <Tag text="AGE 22" a={mAt + 6} y={1010} size={58} color="#86efac" rot={3} /> : null}
        <SeriesBadge text={scene.badge as string} from={50} />
      </Shake>
    );
  }
  /* flashback: the boy at a canteen table */
  const f = frame - cut;
  const kAt = at(captions, scene.kidOnWord, fps, cut + 6);
  return (
    <CameraRig cam={{x: 540 + f * 0.6, y: 980, zoom: 1.12 - f * 0.0015 + impulse(frame, cut, 0.06)}}>
      <Layer depth={0.5}><AbsoluteFill style={{background: 'linear-gradient(180deg,#e2e8f0 0%, #cbd5e1 55%, #94a3b8 56%, #64748b 100%)'}} />
        {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 80 + i * 330, top: 420, width: 240, height: 200, background: '#bae6fd', border: `8px solid ${OL}`}} />)}
      </Layer>
      <Layer depth={1}>
        <div style={{position: 'absolute', left: 120, top: 1080, width: 840, height: 40, background: '#a16207', border: `6px solid ${OL}`, borderRadius: 10}} />
        <Boy x={400} y={1240} height={300} stage="child" pose="stand" skin={sb.character.palette.skin} rim="#93c5fd" glow={0.2} mood="sad" />
        <Tray x={680} y={1040} s={0.9} />
      </Layer>
      <Tag text="FREE SCHOOL MEALS" a={Math.min(kAt, cut + 4)} y={300} size={62} color="#fde047" rot={2} />
      <SeriesBadge text={scene.badge as string} />
    </CameraRig>
  );
};

/* mumShift: { wageOnWord, gapOnWord } — night: his mum walks to a shift (FULL-TIME · MINIMUM WAGE), a clock spins; the fridge pops open nearly empty;
   on "Breakfast" a school BREAKFAST CLUB sign with toast popping. */
const MumShift: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const wAt = at(captions, scene.wageOnWord, fps, dur * 0.25);
  const eAt = at(captions, scene.emptyOnWord, fps, dur * 0.45);
  const gAt = at(captions, scene.gapOnWord, fps, dur * 0.7);
  const cam = {x: 540 + kf(frame, [[0, 200], [eAt, 0, EASE.smooth], [gAt, -60, EASE.smooth]]), y: 960, zoom: 1.04 + impulses(frame, [eAt, gAt], 0.05)};
  const door = interpolate(frame, [eAt, eAt + 10], [0, 1], {...clamp, easing: EASE.overshoot});
  const toast = spring({frame: frame - gAt, fps, config: {damping: 9}});
  return (
    <CameraRig cam={cam}>
      <Layer depth={0.4}><AbsoluteFill style={{background: 'linear-gradient(180deg,#0b1020 0%, #1e1b4b 60%, #312e81 100%)'}} />
        {new Array(30).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: (i * 131) % 1400 - 100, top: (i * 71) % 600 + 40, width: 5, height: 5, borderRadius: 3, background: '#fff', opacity: 0.5 + 0.5 * Math.sin(frame / 6 + i)}} />)}
      </Layer>
      <Layer depth={1}>
        <div style={{position: 'absolute', left: 520, top: 520, width: 180, height: 180, borderRadius: 90, background: '#f8fafc', border: `8px solid ${OL}`}}>
          <div style={{position: 'absolute', left: 84, top: 30, width: 12, height: 64, background: OL, transformOrigin: '6px 60px', rotate: `${frame * 9}deg`, borderRadius: 6}} />
          <div style={{position: 'absolute', left: 84, top: 50, width: 12, height: 44, background: '#ef4444', transformOrigin: '6px 40px', rotate: `${frame * 1.5}deg`, borderRadius: 6}} />
        </div>
        <Mum x={kf(frame, [[0, 560], [eAt, 860, EASE.smooth]])} y={1320} s={1.15} walk={frame / 3} />
        {/* fridge */}
        <div style={{position: 'absolute', left: 60, top: 760, width: 300, height: 560, background: '#e5e7eb', border: `8px solid ${OL}`, borderRadius: 18}}>
          <div style={{position: 'absolute', left: 30, top: 200, width: 220, height: 8, background: '#94a3b8'}} />
          <div style={{position: 'absolute', left: 30, top: 380, width: 220, height: 8, background: '#94a3b8'}} />
          <div style={{position: 'absolute', left: 50, top: 300, width: 50, height: 74, background: '#f8fafc', border: `5px solid ${OL}`, borderRadius: 8, opacity: door}} />
          <div style={{position: 'absolute', inset: -8, background: '#d1d5db', border: `8px solid ${OL}`, borderRadius: 18, transformOrigin: '100% 50%', transform: `perspective(900px) rotateY(${door * 100}deg)`}} />
        </div>
      </Layer>
      <Tag text="MUM: FULL-TIME" a={Math.min(wAt, 4)} y={300} size={60} color="#f8fafc" />
      {frame >= wAt ? <Tag text="MINIMUM WAGE" a={wAt} y={410} size={56} color="#fca5a5" rot={2} /> : null}
      {frame >= eAt ? <Tag text="NOT ENOUGH" a={eAt} y={660} size={56} color="#fde047" rot={-4} /> : null}
      {frame >= gAt ? <div style={{position: 'absolute', left: 400, top: 900, width: 520, scale: String(toast), rotate: '3deg'}}>
        <div style={{fontFamily: DISPLAY, fontSize: 60, color: '#111', background: '#fef3c7', border: `7px solid ${OL}`, borderRadius: 16, textAlign: 'center', padding: '14px 0', boxShadow: `0 8px 0 ${OL}`}}>🍞 BREAKFAST CLUB</div>
      </div> : null}
      <SeriesBadge text={scene.badge as string} />
    </CameraRig>
  );
};

/* warmupDebut: { injuryOnWord, inOnWord, twiceOnWord } — floodlit warm-up: a grey teammate pulls up clutching his leg (red ✚);
   on "thrown" the 18-year-old sprints on (DEBUT · AGE 18); on "twice" two strikes, 1 + 2 balls in the net. */
const WarmupDebut: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const jAt = at(captions, scene.injuryOnWord, fps, dur * 0.25);
  const iAt = at(captions, scene.inOnWord, fps, dur * 0.5);
  const tAt = at(captions, scene.twiceOnWord, fps, dur * 0.75);
  const cam = {x: kf(frame, [[0, 420], [iAt, 560, EASE.smooth], [tAt, 640, EASE.smooth]]), y: 980, zoom: kf(frame, [[0, 1.0], [iAt, 1.08, EASE.out]]) + impulses(frame, [jAt, tAt, tAt + 10], 0.05)};
  const goals = (frame >= tAt ? 1 : 0) + (frame >= tAt + 10 ? 1 : 0);
  return (
    <CameraRig cam={cam}>
      <Layer depth={0.4}><AbsoluteFill style={{background: 'linear-gradient(180deg,#0b1020 0%, #1e293b 46%, #15803d 47%, #14532d 100%)'}} />
        {[160, 540, 920].map((x) => <div key={x} style={{position: 'absolute', left: x - 70, top: 240, width: 140, height: 40, borderRadius: 20, background: '#fef9c3', boxShadow: '0 0 90px 40px rgba(254,249,195,0.35)'}} />)}
      </Layer>
      <Layer depth={0.8}>
        <div style={{position: 'absolute', left: 560, top: 660, width: 460, height: 240, border: '12px solid #f8fafc', borderBottom: 'none', backgroundImage: 'repeating-linear-gradient(45deg, rgba(248,250,252,0.35) 0 4px, transparent 4px 34px), repeating-linear-gradient(-45deg, rgba(248,250,252,0.35) 0 4px, transparent 4px 34px)'}} />
        {new Array(goals).fill(0).map((_, i) => <Ball key={i} x={680 + i * 120} y={800} s={1.2} rot={frame * 10} />)}
      </Layer>
      <Layer depth={1}>
        <div style={{opacity: interpolate(frame, [iAt, iAt + 10], [1, 0.25], clamp)}}>
          <Boy x={300} y={1240} height={360} stage="adult" pose="stand" skin="#e8c39e" rim="#94a3b8" glow={0.1} mood={frame >= jAt ? 'sad' : 'happy'} lean={frame >= jAt ? 14 : 0} />
          {frame >= jAt ? <div style={{position: 'absolute', left: 330, top: 820, fontFamily: DISPLAY, fontSize: 110, color: '#ef4444', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill', scale: String(spring({frame: frame - jAt, fps, config: {damping: 8}}))}}>✚</div> : null}
        </div>
        {frame >= iAt ? <Boy x={kf(frame, [[iAt, -100], [iAt + 18, 480, EASE.out]])} y={1260} height={400} stage="teen" pose={frame < tAt ? 'run' : 'kick'} phase={frame < tAt ? frame / 3 : Math.min((frame - tAt) / 3, 1.6)} skin={sb.character.palette.skin} rim="#fde68a" glow={0.5} mood="happy" /> : null}
      </Layer>
      <Layer depth={1.25}><Particles count={20} color="#fef9c3" size={5} speedY={0.4} seed={7} opacity={0.4} /></Layer>
      <Tag text="THE WARM-UP" a={2} y={300} size={60} color="#f8fafc" />
      {frame >= iAt ? <Tag text="DEBUT · AGE 18" a={iAt} y={420} size={58} color="#86efac" rot={2} /> : null}
      {frame >= tAt ? <Tag text={goals > 1 ? '2 GOALS' : '1 GOAL'} a={tAt} y={1020} size={72} rot={-2} /> : null}
      <SeriesBadge text={scene.badge as string} />
    </CameraRig>
  );
};

/* letterUturn: { closedOnWord, askOnWord, letterOnWord, uturnOnWord } — school gates swing shut (CLOSED); quick question tag; a letter flies
   into a generic government building (no real landmark); on "changed" a giant U-TURN arrow spins and 1.3M KIDS slaps in. */
const LetterUturn: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.closedOnWord, fps, 6);
  const qAt = at(captions, scene.askOnWord, fps, dur * 0.25);
  const lAt = at(captions, scene.letterOnWord, fps, dur * 0.45);
  const uAt = at(captions, scene.uturnOnWord, fps, dur * 0.8);
  const gate = interpolate(frame, [cAt, cAt + 12], [0, 1], {...clamp, easing: EASE.in});
  const fly = interpolate(frame, [lAt, lAt + 26], [0, 1], {...clamp, easing: EASE.smooth});
  const u = spring({frame: frame - uAt, fps, config: {damping: 9}});
  const cam = {x: kf(frame, [[0, 540], [lAt, 540], [lAt + 26, 700, EASE.smooth]]), y: 960, zoom: kf(frame, [[0, 1.08], [lAt, 1.0, EASE.smooth]]) + impulses(frame, [cAt + 12, uAt], 0.05)};
  return (
    <CameraRig cam={cam}>
      <Layer depth={0.4}><AbsoluteFill style={{background: 'linear-gradient(180deg,#334155 0%, #64748b 60%, #475569 100%)'}} /></Layer>
      <Layer depth={1}>
        {/* school + gates */}
        <div style={{position: 'absolute', left: 60, top: 640, width: 520, height: 420, background: '#b45309', border: `8px solid ${OL}`}}>
          {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 40 + i * 160, top: 60, width: 110, height: 110, background: '#1e293b', border: `6px solid ${OL}`}} />)}
          <div style={{position: 'absolute', left: 0, right: 0, top: -70, textAlign: 'center', fontFamily: DISPLAY, fontSize: 50, color: '#f8fafc', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill'}}>SCHOOL</div>
        </div>
        {[0, 1].map((i) => <div key={i} style={{position: 'absolute', left: i ? 320 : 60, top: 880, width: 260, height: 300, backgroundImage: `repeating-linear-gradient(90deg, ${OL} 0 10px, transparent 10px 44px)`, borderTop: `12px solid ${OL}`, transformOrigin: i ? '100% 50%' : '0% 50%', transform: `perspective(900px) rotateY(${(i ? -1 : 1) * (1 - gate) * 70}deg)`}} />)}
        {frame >= cAt + 10 ? <div style={{position: 'absolute', left: 190, top: 980, width: 260, rotate: '-8deg', fontFamily: DISPLAY, fontSize: 64, color: '#ef4444', background: '#fff', border: '6px solid #ef4444', borderRadius: 10, textAlign: 'center'}}>CLOSED</div> : null}
        {/* government building (generic) */}
        <div style={{position: 'absolute', left: 860, top: 600, width: 460, height: 480, background: '#e7e5e4', border: `8px solid ${OL}`}}>
          <div style={{position: 'absolute', left: -30, right: -30, top: -110, height: 110, background: '#d6d3d1', border: `8px solid ${OL}`, clipPath: 'polygon(0 100%, 50% 0, 100% 100%)'}} />
          {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 40 + i * 105, top: 40, width: 40, height: 400, background: '#f5f5f4', border: `6px solid ${OL}`}} />)}
        </div>
        {frame >= lAt ? <div style={{position: 'absolute', left: interpolate(fly, [0, 1], [380, 1000]), top: interpolate(fly, [0, 1], [900, 760]) - Math.sin(fly * Math.PI) * 220, width: 170, height: 110, background: '#fff', border: `6px solid ${OL}`, borderRadius: 8, rotate: `${fly * 360}deg`, scale: String(1 - fly * 0.4)}}>
          <div style={{position: 'absolute', inset: 0, background: '#e5e7eb', clipPath: 'polygon(0 0, 50% 55%, 100% 0)'}} />
        </div> : null}
        {frame >= uAt ? <div style={{position: 'absolute', left: 820, top: 760, fontSize: 260, scale: String(u), rotate: `${(1 - u) * -180}deg`}}>↩️</div> : null}
      </Layer>
      <Tag text="LOCKDOWN" a={Math.min(cAt, 4)} y={300} size={62} color="#f8fafc" />
      {frame >= qAt && frame < uAt ? <Tag text="SO WHAT DID HE DO?" a={qAt} y={420} size={54} color="#fde047" rot={2} /> : null}
      {frame >= lAt && frame < uAt ? <Tag text="✉️ A LETTER TO EVERY MP" a={lAt} y={540} size={48} color="#e0f2fe" rot={-2} /> : null}
      {frame >= uAt ? <Tag text="GOVERNMENT U-TURN" a={uAt} y={420} size={62} color="#86efac" rot={-2} /> : null}
      {frame >= uAt + 8 ? <Tag text="1.3M KIDS FED ALL SUMMER" a={uAt + 8} y={1130} size={54} color="#fde047" rot={2} /> : null}
      <SeriesBadge text={scene.badge as string} />
    </CameraRig>
  );
};

/* charityCrates: { cratesOnWord } — food crates stack up on a pallet while a £ counter runs to £20M; silent SEND line + daily pill. */
const CharityCrates: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.cratesOnWord, fps, 4);
  const v = Math.round(interpolate(frame, [cAt, cAt + 26], [0, 20], clamp));
  const cam = {x: 540, y: kf(frame, [[0, 1000], [dur, 930, EASE.smooth]]), zoom: kf(frame, [[0, 1.0], [dur, 1.07, EASE.smooth]]) + impulse(frame, cAt + 26, 0.04)};
  return (
    <CameraRig cam={cam}>
      <Layer depth={0.4}><AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #166534 0%, #052e16 80%)'}} /></Layer>
      <Layer depth={1}>
        {new Array(9).fill(0).map((_, i) => {
          const a = cAt + i * 3;
          if (frame < a - 2) return null;
          const d = interpolate(frame, [a - 2, a + 8], [-500, 0], {...clamp, easing: EASE.in});
          return <div key={i} style={{position: 'absolute', left: 560 + (i % 3) * 140, top: 1000 - Math.floor(i / 3) * 120 + d, width: 130, height: 110, background: '#d97706', border: `6px solid ${OL}`, borderRadius: 8, fontSize: 52, textAlign: 'center', lineHeight: '96px'}}>{['🍎', '🥪', '🥛'][i % 3]}</div>;
        })}
        <Boy x={300} y={1220} height={400} stage="adult" pose="stand" skin={sb.character.palette.skin} rim="#fde68a" glow={0.5} mood="happy" arms={[150 + Math.sin(frame / 5) * 15, 20]} />
      </Layer>
      <Layer depth={1.3}><Particles count={18} color="#bbf7d0" size={8} speedY={-0.4} seed={9} opacity={0.5} /></Layer>
      <Tag text="FOOD CHARITY" a={2} y={300} size={60} color="#f8fafc" />
      {frame >= cAt ? <div style={{position: 'absolute', left: 40, right: 140, top: 420, textAlign: 'center', fontFamily: DISPLAY, fontSize: 140, color: '#facc15', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>£{v}M</div> : null}
      <div style={{position: 'absolute', left: 50, right: 150, top: 600, textAlign: 'center', lineHeight: 1.45, opacity: spring({frame: frame - 8, fps, config: {damping: 14}})}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 40, color: '#111', background: '#86efac', padding: '8px 20px', borderRadius: 14, border: `5px solid ${OL}`}}>📤 Send this to the mate who always shares his food</span></div>
      <DailyPill from={20} y={1290} />
      <SeriesBadge text={scene.badge as string} />
    </CameraRig>
  );
};

export const STORY24_SCENES: Record<string, React.FC<SceneProps>> = {mealsHook: MealsHook, mumShift: MumShift, warmupDebut: WarmupDebut, letterUturn: LetterUturn, charityCrates: CharityCrates};
