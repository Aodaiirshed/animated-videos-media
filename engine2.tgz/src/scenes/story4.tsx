import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {Skyline, wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Story scenes, set 4: streetMarket (working parents), twoFlags (choosing a country), panenka (chipped penalty). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Tag: React.FC<{text: string; at: number; x: number; y: number; color: string}> = ({text, at, x, y, color}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - at, fps, config: {damping: 12, stiffness: 170}});
  return (
    <div style={{position: 'absolute', left: x - 260, width: 520, top: y, textAlign: 'center', opacity: s, scale: String(0.7 + s * 0.3)}}>
      <span style={{fontFamily: DISPLAY, fontSize: 60, color: '#000', background: color, padding: '4px 24px', borderRadius: 12, boxShadow: `0 0 40px ${color}88`}}>{text}</span>
    </div>
  );
};

/* streetMarket: { leftTag, leftOnWord, rightTag, rightOnWord } — dusk street: mother with a mop in a lit window (left),
   father at a street stall (right), the boy kicking a ball against a wall between them. */
const StreetMarket: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lAt = scene.leftOnWord ? wordFrame(captions, scene.leftOnWord as string, fps, 10) : 10;
  const rAt = scene.rightOnWord ? wordFrame(captions, scene.rightOnWord as string, fps, dur * 0.5) : dur * 0.5;
  const ballT = (frame % 30) / 30;
  const bx = 470 + Math.sin(ballT * Math.PI) * 120;
  const by = 1290 - Math.sin(ballT * Math.PI) * 90;
  const lampOn = interpolate(frame, [lAt - 3, lAt + 6], [0.15, 1], clamp);
  const stallOn = interpolate(frame, [rAt - 3, rAt + 6], [0.15, 1], clamp);
  return (
    <Camera dur={dur} from={1.1} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #120b26 0%, #3d1f3a 45%, #b2553d 72%, #1a1010 100%)'}} />
      <Skyline y={1080} color="#1d1222" seed="mad" height={320} windows="#ffcf8a" />
      {/* building with lit window (mother cleaning) */}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <rect x={0} y={560} width={420} height={760} fill="#140c18" />
        <rect x={70} y={680} width={280} height={300} rx={6} fill="#ffcf8a" opacity={0.85 * lampOn} />
        <rect x={70} y={680} width={280} height={300} rx={6} fill="none" stroke="#2a1a24" strokeWidth={10} />
        {/* mother silhouette mopping */}
        <g opacity={lampOn} transform={`translate(${200 + Math.sin(frame / 6) * 18} 0)`}>
          <circle cx={0} cy={770} r={24} fill="#1a1016" />
          <path d="M-30 800 Q0 790 30 800 L40 980 L-40 980 Z" fill="#1a1016" />
          <line x1={20} y1={830} x2={70 + Math.sin(frame / 6) * 10} y2={975} stroke="#1a1016" strokeWidth={8} />
          <rect x={50 + Math.sin(frame / 6) * 10} y={968} width={46} height={12} rx={4} fill="#1a1016" />
        </g>
        {/* street stall */}
        <g opacity={0.35 + 0.65 * stallOn}>
          <path d="M700 960 L1040 960 L1010 1010 L730 1010 Z" fill="#c6463a" />
          {new Array(6).fill(0).map((_, i) => <rect key={i} x={735 + i * 48} y={960} width={24} height={50} fill="#f4d6a0" opacity={0.6} />)}
          <rect x={720} y={1140} width={300} height={40} fill="#2a1a18" />
          <rect x={735} y={1180} width={14} height={120} fill="#2a1a18" />
          <rect x={990} y={1180} width={14} height={120} fill="#2a1a18" />
          {new Array(7).fill(0).map((_, i) => (
            <circle key={i} cx={750 + i * 40} cy={1128} r={14} fill={['#ffcc4d', '#ff6b6b', '#5dffb0'][i % 3]} opacity={0.8} />
          ))}
          <ellipse cx={870} cy={1010} rx={60} ry={10} fill="#ffe2a8" opacity={0.7 * stallOn} />
        </g>
      </svg>
      <Boy x={870} y={1300} height={420} stage="adult" hair="short" skin="#140c12" rim="#ffb36b" glow={0.4 + stallOn * 0.4} />
      {/* wall + boy + ball */}
      <div style={{position: 'absolute', left: 0, top: 1300, width: 1080, height: 620, background: '#0e0a0c'}} />
      <Boy x={360} y={1300} height={260} stage="child" pose="kick" phase={ballT * Math.PI * 2} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.8} />
      <div style={{position: 'absolute', left: bx - 18, top: by - 36, width: 36, height: 36, borderRadius: '50%', background: '#f4f4f4', boxShadow: '0 0 20px rgba(255,255,255,0.5)'}} />
      {scene.leftTag ? <Tag text={scene.leftTag as string} at={lAt} x={210} y={560} color="#ffcc4d" /> : null}
      {scene.rightTag ? <Tag text={scene.rightTag as string} at={rAt} x={870} y={860} color="#ffcc4d" /> : null}
    </Camera>
  );
};

/* twoFlags: { left: {label, colors[]}, right: {label, colors[], star?}, chooseOnWord, chosen: 'left'|'right' } —
   the hero stands between two flag panels; on cue the chosen side blazes and the other dims. */
const FlagPanel: React.FC<{colors: string[]; star?: string; x: number; dim: number; glow: number; vertical?: boolean}> = ({colors, star, x, dim, glow}) => {
  const frame = useCurrentFrame();
  const wave = (i: number) => Math.sin(frame / 8 + i) * 6;
  const band = 520 / colors.length;
  return (
    <div style={{position: 'absolute', left: x, top: 460, width: 400, height: 520, opacity: 1 - dim * 0.7, filter: `saturate(${1 - dim * 0.8})`,
      boxShadow: glow ? `0 0 ${80 * glow}px ${30 * glow}px rgba(255,80,80,${0.5 * glow})` : 'none', borderRadius: 14, overflow: 'hidden'}}>
      {colors.map((c, i) => (
        <div key={i} style={{position: 'absolute', left: 0, top: i * band + wave(i), width: 400, height: band + 14, background: c}} />
      ))}
      {star ? (
        <svg width={400} height={520} style={{position: 'absolute', left: 0, top: 0}}>
          <polygon points="200,170 228,252 316,252 245,302 272,385 200,334 128,385 155,302 84,252 172,252" fill="none" stroke={star} strokeWidth={14} strokeLinejoin="round" />
        </svg>
      ) : null}
    </div>
  );
};

const TwoFlags: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = scene.left as {label: string; colors: string[]; star?: string};
  const R = scene.right as {label: string; colors: string[]; star?: string};
  const at = scene.chooseOnWord ? wordFrame(captions, scene.chooseOnWord as string, fps, dur * 0.55) : dur * 0.55;
  const p = spring({frame: frame - at, fps, config: {damping: 14}});
  const right = (scene.chosen as string) !== 'left';
  const turn = interpolate(frame, [0, at], [0, 1], clamp);
  return (
    <Shake at={at} amount={14}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, #1b1b24 0%, #08080b 70%)'}} />
        <FlagPanel colors={L.colors} star={L.star} x={50} dim={right ? p : 0} glow={right ? 0 : p} />
        <FlagPanel colors={R.colors} star={R.star} x={630} dim={right ? 0 : p} glow={right ? p : 0} />
        {[{t: L.label, x: 250}, {t: R.label, x: 830}].map((o) => (
          <div key={o.x} style={{position: 'absolute', left: o.x - 200, width: 400, top: 1000, textAlign: 'center', fontFamily: DISPLAY, fontSize: 64, color: '#fff',
            WebkitTextStroke: '4px #000', paintOrder: 'stroke fill'}}>{o.t}</div>
        ))}
        <div style={{position: 'absolute', left: 0, top: 1310, width: 1080, height: 610, background: '#0a0a0e'}} />
        <Boy x={540 + (right ? 1 : -1) * p * 60} y={1310} height={440} stage="teen" flip={!right && turn > 0.5}
          skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.7 + p * 0.3} />
        <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 96, color: sb.palette.gold,
          opacity: interpolate(frame, [0, 10], [0, 1], clamp), WebkitTextStroke: '5px #000', paintOrder: 'stroke fill'}}>{(scene.title as string) ?? 'WHICH ONE?'}</div>
      </Camera>
    </Shake>
  );
};

/* panenka: { kickOnWord, diveOnWord?, scoreOnWord?, scoreText? } — behind-the-taker view of a goal: the keeper dives one way,
   the ball floats softly down the middle and drops in. */
const Panenka: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const kick = scene.kickOnWord ? wordFrame(captions, scene.kickOnWord as string, fps, dur * 0.3) : dur * 0.3;
  const dive = scene.diveOnWord ? wordFrame(captions, scene.diveOnWord as string, fps, kick + 4) : kick + 4;
  const score = scene.scoreOnWord ? wordFrame(captions, scene.scoreOnWord as string, fps, kick + 30) : kick + 30;
  const t = interpolate(frame, [kick, score], [0, 1], clamp);
  const ballX = 540;
  const ballY = 1420 - t * 640 - Math.sin(t * Math.PI) * 260;
  const ballR = 40 - t * 22;
  const d = spring({frame: frame - dive, fps, config: {damping: 16, stiffness: 120}});
  const net = frame > score ? Math.sin((frame - score) / 2) * Math.exp(-(frame - score) / 10) * 14 : 0;
  const flash = interpolate(frame, [score, score + 3, score + 10], [0, 0.8, 0], clamp);
  const crowd = (i: number) => random(`cr${i}`);
  const S = spring({frame: frame - score, fps, config: {damping: 9, stiffness: 180}});
  return (
    <Shake at={score} amount={22}>
      <Camera dur={dur} from={1.0} to={1.12} panY={40}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #050608 0%, #0c1220 40%, #0b2a16 62%, #0f3a1e 100%)'}} />
        {/* crowd dots */}
        <svg width={1080} height={700} style={{position: 'absolute', top: 200}}>
          {new Array(260).fill(0).map((_, i) => (
            <circle key={i} cx={crowd(i) * 1080} cy={60 + crowd(i + 999) * 440 + (frame > score ? Math.sin(frame / 2 + i) * 6 : 0)} r={5}
              fill={i % 4 === 0 ? '#c1272d' : i % 7 === 0 ? '#006233' : '#3a3f4a'} opacity={0.7} />
          ))}
        </svg>
        {/* floodlight beams */}
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 20%, rgba(220,235,255,0.18), transparent 60%)'}} />
        {/* goal */}
        <svg width={1080} height={600} style={{position: 'absolute', top: 640}}>
          <g stroke="rgba(255,255,255,0.25)" strokeWidth={2}>
            {new Array(18).fill(0).map((_, i) => <line key={`v${i}`} x1={200 + i * 40} y1={20 + net} x2={200 + i * 40 + net} y2={360} />)}
            {new Array(9).fill(0).map((_, i) => <line key={`h${i}`} x1={190} y1={30 + i * 40 + net} x2={890} y2={30 + i * 40 + net} />)}
          </g>
          <path d="M190 360 L190 20 L890 20 L890 360" stroke="#fff" strokeWidth={14} fill="none" />
        </svg>
        {/* keeper diving to the right */}
        <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920,
          translate: `${d * 150}px ${-Math.sin(d * Math.PI) * 50 + d * 30}px`, rotate: `${d * 55}deg`, transformOrigin: '540px 1000px'}}>
          <Boy x={540} y={1000} height={300} stage="adult" hair="short" skin="#151820" rim="#c7d0e0" glow={0.4} pose={frame > dive ? 'cheer' : 'stand'} />
        </div>
        {/* penalty spot + ball */}
        <div style={{position: 'absolute', left: 520, top: 1440, width: 40, height: 12, borderRadius: '50%', background: 'rgba(255,255,255,0.6)'}} />
        <div style={{position: 'absolute', left: ballX - ballR, top: ballY - ballR, width: ballR * 2, height: ballR * 2, borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, #fff, #c9c9c9)', boxShadow: '0 0 30px rgba(255,255,255,0.6)', opacity: t >= 1 && frame > score + 6 ? 0.85 : 1}} />
        {/* the taker (hero) from behind */}
        <Boy x={330 + interpolate(frame, [kick - 12, kick], [-80, 60], clamp)} y={1760} height={400} stage="adult" pose={frame >= kick - 6 && frame < kick + 8 ? 'kick' : 'stand'}
          phase={interpolate(frame, [kick - 6, kick + 4], [0, Math.PI], clamp)} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.9} />
        {scene.scoreText ? (
          <div style={{position: 'absolute', top: 330, width: '100%', textAlign: 'center', opacity: frame >= score ? 1 : 0, scale: String(1.8 - S * 0.8)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 170, color: sb.palette.gold, WebkitTextStroke: '7px #000', paintOrder: 'stroke fill',
              textShadow: '0 0 70px rgba(255,200,80,0.8)'}}>{scene.scoreText as string}</span>
          </div>
        ) : null}
        <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      </Camera>
    </Shake>
  );
};

export const STORY4_SCENES: Record<string, React.FC<SceneProps>> = {
  streetMarket: StreetMarket,
  twoFlags: TwoFlags,
  panenka: Panenka,
};
