import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Story scenes, set 6 (cartoon): campScene, planeMap, homeCare, sprintMeter, headerGoal. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Tent: React.FC<{x: number; y: number; s?: number; c?: string}> = ({x, y, s = 1, c = '#f1f5f9'}) => (
  <svg width={300 * s} height={220 * s} viewBox="0 0 300 220" style={{position: 'absolute', left: x - 150 * s, top: y - 210 * s}}>
    <path d="M150 14 L290 206 L10 206 Z" fill={c} stroke={OL} strokeWidth={9} strokeLinejoin="round" />
    <path d="M150 14 L290 206 L200 206 Z" fill="#000" opacity={0.1} />
    <path d="M150 70 L186 206 L114 206 Z" fill="#475569" stroke={OL} strokeWidth={7} strokeLinejoin="round" />
    <path d="M60 150 L240 150" stroke="#38bdf8" strokeWidth={14} opacity={0.8} />
  </svg>
);

/* campScene: { mode: 'born'|'return', tag?, tagOnWord?, tag2?, tag2OnWord? } — rows of tents in a dusty camp. 'born': the hero as a
   small child with a ball. 'return': the grown-up hero with cheering kids. */
const CampScene: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'born';
  const tAt = at(captions, scene.tagOnWord, fps, 6), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.6);
  const GY = 1120;
  const hop = Math.abs(Math.sin(frame / 5)) * 60;
  return (
    <Shake at={mode === 'born' ? 0 : t2} amount={mode === 'born' ? 18 : 10}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: mode === 'born' ? 'linear-gradient(180deg, #f59e0b 0%, #fcd34d 45%, #fde68a 62%, #d9a066 100%)' : 'linear-gradient(180deg, #38bdf8 0%, #bae6fd 50%, #fde68a 70%, #d9a066 100%)'}} />
        <div style={{position: 'absolute', left: 760, top: 300, width: 190, height: 190, borderRadius: '50%', background: '#fff7c2', border: `8px solid ${OL}`, boxShadow: '0 0 80px #fff7c2'}} />
        {[80, 300, 520, 740, 960].map((x, i) => <Tent key={`b${i}`} x={x + 40} y={GY - 110} s={0.6} c={i % 2 ? '#e2e8f0' : '#f8fafc'} />)}
        {[150, 480, 810].map((x, i) => <Tent key={`m${i}`} x={x + (i === 1 ? 60 : 0)} y={GY - 30} s={0.9} />)}
        <div style={{position: 'absolute', left: 0, top: GY - 40, width: 1080, height: 900, background: 'linear-gradient(180deg, #d9a066, #a16a35)', borderTop: `9px solid ${OL}`}} />
        {new Array(16).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`cx${i}`) * 1080, top: GY + random(`cy${i}`) * 600, width: 30 + random(`cw${i}`) * 40, height: 8, borderRadius: 4, background: '#00000022'}} />)}
        <Tent x={150} y={GY + 120} s={1.25} /><Tent x={950} y={GY + 130} s={1.25} c="#e2e8f0" />
        {mode === 'born' ? (
          <>
            <Boy x={520} y={1300} height={430} stage="child" pose="kick" phase={frame / 4} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood="happy" />
            <div style={{position: 'absolute', left: 610, top: 1240 - hop, width: 54, height: 54, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d8d8d8)', border: `5px solid ${OL}`}} />
          </>
        ) : (
          <>
            {[250, 400, 690, 840].map((kx, i) => <Boy key={kx} x={kx} y={1290 + (i % 2) * 20} height={330} stage="child" skin={`#ck${i}`} rim="#fff" glow={0.1} pose="cheer" phase={frame / 4 + i} mood="laugh" flip={kx > 540} />)}
            <Boy x={540} y={1320} height={600} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="happy" />
          </>
        )}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={300} size={(scene.tagSize as number) ?? 104} color={mode === 'born' ? '#ef4444' : '#38bdf8'} fg="#fff" /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={460} size={64} color="#fff" rot={2} /> : null}
      </Camera>
    </Shake>
  );
};

/* planeMap: { age?, tag?, tagOnWord?, flyOnWord? } — a little plane flies a dotted arc from a warm land to a snowy one. */
const PlaneMap: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fly = at(captions, scene.flyOnWord, fps, 8), tAt = at(captions, scene.tagOnWord, fps, dur * 0.6);
  const p = interpolate(frame, [fly, dur - 12], [0, 1], clamp);
  const A = [820, 1150], B = [270, 560], C = [760, 420];
  const q = (t: number) => [(1 - t) * (1 - t) * A[0] + 2 * (1 - t) * t * C[0] + t * t * B[0], (1 - t) * (1 - t) * A[1] + 2 * (1 - t) * t * C[1] + t * t * B[1]];
  const [px, py] = q(p), [nx, ny] = q(Math.min(1, p + 0.02));
  const ang = (Math.atan2(ny - py, nx - px) * 180) / Math.PI;
  return (
    <Camera dur={dur} from={1.0} to={1.07}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #0ea5e9, #0369a1)'}} />
      {new Array(14).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: (random(`wx${i}`) * 1080 + frame * 0.6) % 1080, top: 260 + random(`wy${i}`) * 1100, width: 70, height: 8, borderRadius: 4, background: '#fff', opacity: 0.25}} />)}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <path d="M620 1040 Q700 960 860 1000 Q1010 1040 1000 1200 Q980 1340 840 1330 Q700 1330 640 1230 Q590 1130 620 1040 Z" fill="#84cc16" stroke={OL} strokeWidth={10} />
        <path d="M700 1090 Q780 1050 860 1100 Q900 1180 820 1220 Q730 1220 700 1090 Z" fill="#fbbf24" opacity={0.8} />
        <path d="M70 520 Q160 380 360 420 Q500 440 520 560 Q520 700 380 740 Q200 780 110 690 Q40 620 70 520 Z" fill="#f8fafc" stroke={OL} strokeWidth={10} />
        {[[180, 560], [300, 520], [400, 620]].map(([x, y], i) => <path key={i} d={`M${x} ${y} l34 -70 l34 70 Z`} fill="#16a34a" stroke={OL} strokeWidth={7} strokeLinejoin="round" />)}
        {new Array(24).fill(0).map((_, i) => { const [x, y] = q(i / 23); return i / 23 <= p ? <circle key={i} cx={x} cy={y} r={9} fill="#fff" stroke={OL} strokeWidth={4} /> : null; })}
        <circle cx={A[0]} cy={A[1]} r={22} fill="#ef4444" stroke={OL} strokeWidth={8} /><circle cx={B[0]} cy={B[1]} r={22} fill="#22c55e" stroke={OL} strokeWidth={8} />
      </svg>
      <svg width={200} height={200} viewBox="-100 -100 200 200" style={{position: 'absolute', left: px - 100, top: py - 100, rotate: `${ang}deg`}}>
        <path d="M-70 0 Q-70 -22 -30 -22 L40 -22 Q80 -14 86 0 Q80 14 40 22 L-30 22 Q-70 22 -70 0 Z" fill="#fff" stroke={OL} strokeWidth={8} />
        <path d="M-10 -20 L-40 -80 L-10 -80 L30 -20 Z M-10 20 L-40 80 L-10 80 L30 20 Z M-60 -16 L-84 -50 L-66 -50 L-44 -18 Z" fill="#ef4444" stroke={OL} strokeWidth={7} strokeLinejoin="round" />
        <circle cx={50} cy={-4} r={9} fill="#38bdf8" stroke={OL} strokeWidth={4} />
      </svg>
      {scene.age ? <Tag text={scene.age as string} at={0} y={250} size={110} color="#fff" rot={-3} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={860} size={84} color="#22c55e" fg="#fff" rot={3} /> : null}
    </Camera>
  );
};

/* homeCare: { tag?, tagOnWord?, tag2?, tag2OnWord? } — a small flat at night; the hero (still a kid) looks after two little siblings. */
const HomeCare: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 8), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.55);
  const calm = frame >= t2;
  return (
    <Camera dur={dur} from={1.06} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fde68a 0%, #fcd34d 100%)'}} />
      {new Array(9).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: i * 130 - 20, top: 0, width: 60, height: 1160, background: '#fbbf2455'}} />)}
      <div style={{position: 'absolute', left: 90, top: 380, width: 360, height: 420, background: 'linear-gradient(180deg, #1e1b4b, #312e81)', border: `12px solid ${OL}`, borderRadius: 14, overflow: 'hidden'}}>
        {new Array(16).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`hs${i}`) * 340, top: (random(`hy${i}`) * 420 + frame * (1.5 + random(`hv${i}`) * 2)) % 420, width: 10, height: 10, borderRadius: 5, background: '#fff'}} />)}
        <div style={{position: 'absolute', left: 168, top: 0, width: 12, height: 420, background: OL}} /><div style={{position: 'absolute', left: 0, top: 200, width: 360, height: 12, background: OL}} />
      </div>
      <svg width={240} height={240} viewBox="-120 -120 240 240" style={{position: 'absolute', left: 720, top: 400}}>
        <circle r={104} fill="#fffdf5" stroke={OL} strokeWidth={12} />
        <line x1={0} y1={0} x2={0} y2={-72} stroke={OL} strokeWidth={10} strokeLinecap="round" transform={`rotate(${frame * 3})`} /><line x1={0} y1={0} x2={0} y2={-48} stroke="#ef4444" strokeWidth={14} strokeLinecap="round" transform={`rotate(${300 + frame / 4})`} />
      </svg>
      <div style={{position: 'absolute', left: 0, top: 1150, width: 1080, height: 800, background: 'linear-gradient(180deg, #b45309, #78350f)', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 110, top: 1010, width: 860, height: 230, background: '#7c3aed', border: `10px solid ${OL}`, borderRadius: 50}} />
      <div style={{position: 'absolute', left: 90, top: 900, width: 900, height: 170, background: '#8b5cf6', border: `10px solid ${OL}`, borderRadius: '60px 60px 20px 20px'}} />
      {[300, 790].map((x, i) => (
        <div key={x}>
          <Boy x={x} y={1290} height={300} stage="child" skin={`#sib${i}`} rim="#fff" glow={0.1} pose={calm ? 'cheer' : 'stand'} phase={frame / 4 + i} mood={calm ? 'laugh' : 'cry'} flip={x > 540} hair={i ? 'long' : 'short'} />
        </div>
      ))}
      <Boy x={545} y={1330} height={500} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood={calm ? 'happy' : 'determined'} pose={calm ? 'cheer' : 'stand'} phase={frame / 6} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={72} color="#fff" rot={-2} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={700} size={76} color="#22c55e" fg="#fff" rot={3} /> : null}
    </Camera>
  );
};

/* sprintMeter: { max, unit, countOnWord?, tag?, tagOnWord? } — the hero sprints; a speedometer needle climbs to max. */
const SprintMeter: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.countOnWord, fps, 10), tAt = at(captions, scene.tagOnWord, fps, dur * 0.7);
  const max = (scene.max as number) ?? 36.5;
  const p = interpolate(frame, [cAt, cAt + 30], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)});
  const v = (max * p).toFixed(1);
  const ang = -120 + p * 220 + (p >= 1 ? Math.sin(frame) * 2 : 0);
  return (
    <Shake at={tAt} amount={16}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #14532d 0%, #16a34a 55%, #22c55e 100%)'}} />
      {new Array(9).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: ((i * 260 - frame * 46) % 2340 + 2340) % 2340 - 260, top: 1000, width: 130, height: 920, background: '#ffffff12', transform: 'skewX(-18deg)'}} />)}
      {new Array(22).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 1300 - ((frame * (40 + random(`sp${i}`) * 40) + random(`so${i}`) * 1600) % 1700), top: 760 + random(`sq${i}`) * 620, width: 220, height: 7, borderRadius: 4, background: '#fff', opacity: 0.5}} />)}
      <div style={{position: 'absolute', left: 0, top: 1300, width: 1080, height: 16, background: '#fff', opacity: 0.7}} />
      {new Array(7).fill(0).map((_, i) => { const t = ((frame + i * 4) % 22) / 22; return <div key={i} style={{position: 'absolute', left: 400 - t * 330, top: 1240 - t * 50, width: 44 + t * 70, height: 44 + t * 70, borderRadius: '50%', background: '#dcfce7', opacity: 0.7 * (1 - t)}} />; })}
      <Boy x={560} y={1310} height={470} stage="teen" pose="run" phase={frame / 1.7} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.6} mood="determined" />
      <div style={{position: 'absolute', left: 620, top: 1265 + Math.abs(Math.sin(frame / 2)) * 12, width: 60, height: 60, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d8d8d8)', border: `5px solid ${OL}`}} />
      <svg width={620} height={420} viewBox="-310 -300 620 420" style={{position: 'absolute', left: 230, top: 170}}>
        <path d="M-260 60 A270 270 0 0 1 260 60" fill="#0f172a" stroke={OL} strokeWidth={14} />
        {new Array(12).fill(0).map((_, i) => { const a = ((-120 + i * 20) * Math.PI) / 180; return <line key={i} x1={Math.sin(a) * 200} y1={60 - Math.cos(a) * 200} x2={Math.sin(a) * 236} y2={60 - Math.cos(a) * 236} stroke={i > 8 ? '#ef4444' : '#fff'} strokeWidth={10} strokeLinecap="round" />; })}
        <line x1={0} y1={60} x2={0} y2={-130} stroke="#ef4444" strokeWidth={16} strokeLinecap="round" transform={`rotate(${ang} 0 60)`} />
        <circle cx={0} cy={60} r={26} fill="#fff" stroke={OL} strokeWidth={10} />
      </svg>
      <div style={{position: 'absolute', top: 470, width: '100%', textAlign: 'center'}}>
        <span style={{fontFamily: DISPLAY, fontSize: 170, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{v}</span>
        <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 54, color: '#fde047', marginLeft: 14, WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.unit as string) ?? 'KM/H'}</span>
      </div>
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={690} size={80} color="#fde047" rot={-4} /> : null}
    </Shake>
  );
};

/* headerGoal: { headOnWord, goalOnWord, scoreText?, tag?, tagOnWord? } — a cross comes in, the hero leaps and heads it into the net. */
const HeaderGoal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const head = at(captions, scene.headOnWord, fps, dur * 0.35), goal = at(captions, scene.goalOnWord, fps, head + 10), tAt = at(captions, scene.tagOnWord, fps, goal + 8);
  const t1 = interpolate(frame, [head - 22, head], [0, 1], clamp), t2 = interpolate(frame, [head, goal], [0, 1], clamp);
  const bx = frame < head ? 60 + t1 * 400 : 460 + t2 * 380, by = frame < head ? 560 + t1 * 130 - Math.sin(t1 * Math.PI) * 180 : 690 + t2 * 230;
  const jump = Math.sin(interpolate(frame, [head - 12, head + 12], [0, 1], clamp) * Math.PI) * 190;
  const S = spring({frame: frame - goal, fps, config: {damping: 9, stiffness: 180}});
  const net = frame > goal ? Math.sin((frame - goal) / 2) * Math.exp(-(frame - goal) / 10) * 16 : 0;
  const flash = interpolate(frame, [goal, goal + 3, goal + 10], [0, 0.8, 0], clamp);
  return (
    <Shake at={goal} amount={24}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0b1020 0%, #1e293b 45%, #166534 62%, #15803d 100%)'}} />
        <svg width={1080} height={620} style={{position: 'absolute', top: 200}}>
          {new Array(300).fill(0).map((_, i) => <circle key={i} cx={random(`hx${i}`) * 1080} cy={40 + random(`hy${i}`) * 480 + (frame > goal ? Math.sin(frame / 2 + i) * 7 : 0)} r={7} fill={['#ef4444', '#f8fafc', '#475569', '#ef4444', '#334155'][i % 5]} opacity={0.8} />)}
        </svg>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 15%, rgba(220,235,255,0.2), transparent 60%)'}} />
        <svg width={420} height={520} style={{position: 'absolute', left: 660, top: 700}}>
          <g stroke="rgba(255,255,255,0.35)" strokeWidth={3}>{new Array(10).fill(0).map((_, i) => <line key={`v${i}`} x1={30 + i * 40 + net} y1={20} x2={30 + i * 40} y2={480} />)}{new Array(12).fill(0).map((_, i) => <line key={`h${i}`} x1={30} y1={30 + i * 40} x2={400 + net} y2={30 + i * 40} />)}</g>
          <path d="M30 480 L30 20 L400 20" stroke="#fff" strokeWidth={18} fill="none" strokeLinejoin="round" />
        </svg>
        <div style={{position: 'absolute', left: 0, top: 1180, width: 1080, height: 800, background: '#15803d', borderTop: '10px solid #fff'}} />
        <Boy x={880} y={1200} height={380} stage="adult" skin="#keeper" rim="#fff" glow={0.1} mood={frame > head ? 'shock' : 'neutral'} pose={frame > head ? 'cheer' : 'stand'} phase={1} flip />
        <Boy x={430} y={1230 - jump} height={560} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.6} mood={frame >= goal ? 'laugh' : 'determined'} pose={frame >= goal ? 'cheer' : 'stand'} phase={frame / 4} />
        <div style={{position: 'absolute', left: bx - 34, top: by - 34, width: 68, height: 68, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #cfcfcf)', border: `6px solid ${OL}`}} />
        <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', opacity: frame >= goal ? 1 : 0, scale: String(1.8 - S * 0.8)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 190, color: '#fde047', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.scoreText as string) ?? 'GOAL!'}</span>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={540} size={66} color="#fff" rot={-3} /> : null}
        <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      </Camera>
    </Shake>
  );
};

export const STORY6_SCENES: Record<string, React.FC<SceneProps>> = {
  campScene: CampScene,
  planeMap: PlaneMap,
  homeCare: HomeCare,
  sprintMeter: SprintMeter,
  headerGoal: HeaderGoal,
};
