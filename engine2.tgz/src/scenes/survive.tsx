import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy, type Mood} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* "Would You Survive?" kit (cartoon explainers with an A/B choice):
   elevatorCabin, choiceAB, shaftBrakes, towerFall, abEnd. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Lying: React.FC<{x: number; y: number; height: number; skin: string; rim: string; mood?: Mood}> = ({x, y, height, skin, rim, mood}) => (
  <div style={{position: 'absolute', inset: 0, rotate: '-90deg', transformOrigin: `${x}px ${y}px`}}>
    <Boy x={x} y={y} height={height} stage="teen" skin={skin} rim={rim} glow={0.2} mood={mood ?? 'determined'} />
  </div>
);

/* The cabin interior (drawn once, reused by the modes). */
const Cabin: React.FC<{floor: number; alarm: number; children?: React.ReactNode}> = ({floor, alarm, children}) => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{background: '#0d1017'}} />
      {/* shaft streaks rushing upward outside */}
      {new Array(26).fill(0).map((_, i) => (
        <div key={i} style={{position: 'absolute', left: i % 2 ? random(`sl${i}`) * 90 : 990 + random(`sl${i}`) * 80, top: 1920 - ((frame * (60 + random(`sv${i}`) * 50) + random(`sy${i}`) * 2200) % 2300), width: 8, height: 180, borderRadius: 4, background: '#ffd27a', opacity: 0.5}} />
      ))}
      <div style={{position: 'absolute', left: 100, top: 300, width: 880, height: 980, background: 'linear-gradient(180deg, #aeb9c9 0%, #8794a8 100%)', border: `10px solid ${OL}`, borderRadius: 26, overflow: 'hidden'}}>
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 30 + i * 208, top: 150, width: 190, height: 700, background: i % 2 ? '#98a5b9' : '#a4b0c3', border: `5px solid ${OL}55`, borderRadius: 10}} />)}
        <div style={{position: 'absolute', left: 0, right: 0, top: 560, height: 16, background: '#dfe6f0', border: `4px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 110, background: '#4b5563', borderTop: `8px solid ${OL}`}} />
        {/* floor display */}
        <div style={{position: 'absolute', left: 300, top: 28, width: 280, height: 100, background: '#111', border: `6px solid ${OL}`, borderRadius: 14, textAlign: 'center',
          fontFamily: DISPLAY, fontSize: 82, lineHeight: '96px', color: '#ff4d2e', textShadow: '0 0 20px #ff4d2e'}}>▼ {floor}</div>
        {/* alarm light */}
        <div style={{position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, background: '#ff2d2d', opacity: alarm * (0.12 + 0.14 * Math.abs(Math.sin(frame / 3)))}} />
      </div>
      {/* sparks at the top corners */}
      {new Array(18).fill(0).map((_, i) => {
        const t = ((frame * 2 + i * 7) % 20) / 20;
        const left = i % 2 === 0;
        return <div key={i} style={{position: 'absolute', left: (left ? 110 : 960) + (left ? -1 : 1) * t * (30 + (i % 5) * 16), top: 300 - t * (60 + (i % 4) * 30) + t * t * 120, width: 10, height: 10, borderRadius: 5, background: i % 3 ? '#ffd27a' : '#fff', opacity: alarm * (1 - t)}} />;
      })}
      {children}
    </>
  );
};

/* elevatorCabin: { mode: 'fall'|'jump'|'flat', badge?, tag?, tagOnWord?, actOnWord?, resultOnWord?, fromFloor?, toFloor? } */
const ElevatorCabin: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'fall';
  const skin = sb.character.palette.skin, rim = sb.character.palette.rim;
  const act = at(captions, scene.actOnWord, fps, dur * 0.35);
  const res = at(captions, scene.resultOnWord, fps, dur * 0.7);
  const tagAt = at(captions, scene.tagOnWord, fps, 6);
  const from = (scene.fromFloor as number) ?? 40, to = (scene.toFloor as number) ?? 28;
  const floor = Math.max(1, Math.round(interpolate(frame, [0, dur], [from, to])));
  const jitter = `${Math.sin(frame * 2.1) * 7}px ${Math.cos(frame * 2.7) * 9}px`;
  const float = Math.sin(frame / 4) * 14;
  const jump = mode === 'jump' ? Math.max(0, Math.sin(Math.min(1, Math.max(0, (frame - act) / 16)) * Math.PI)) * 190 : 0;
  const rs = spring({frame: frame - res, fps, config: {damping: 9, stiffness: 190}});
  const bar = interpolate(frame, [act, act + 14], [0, 1], clamp);
  return (
    <Shake at={mode === 'fall' ? 0 : res} amount={mode === 'fall' ? 26 : 16}>
      <div style={{position: 'absolute', inset: 0, translate: jitter}}>
        <Cabin floor={floor} alarm={1}>
          {mode === 'flat' ? (
            <>
              <Lying x={830} y={1170} height={560} skin={skin} rim={rim} mood="determined" />
              {new Array(9).fill(0).map((_, i) => {
                const p = interpolate(frame, [act + i, act + 10 + i], [0, 1], clamp);
                return <svg key={i} width={60} height={110} style={{position: 'absolute', left: 250 + i * 66, top: 1040 - p * 26, opacity: p}}>
                  <path d="M30 104 L30 30 M10 46 L30 14 L50 46" stroke="#22c55e" strokeWidth={12} fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>;
              })}
            </>
          ) : (
            <Boy x={540} y={1170 - (mode === 'fall' ? 40 + float : jump)} height={mode === 'jump' ? 480 : 600} stage="teen" skin={skin} rim={rim} glow={0.2}
              pose={mode === 'fall' || jump > 10 ? 'cheer' : 'stand'} phase={frame / 2.5} mood={mode === 'jump' && frame >= res ? 'cry' : 'shock'} />
          )}
          {mode === 'jump' ? (
            <div style={{position: 'absolute', left: 150, top: 440, width: 780, opacity: bar}}>
              {[{l: 'FALL SPEED', w: 1, c: '#ef4444'}, {l: 'YOUR JUMP', w: 0.09, c: '#22c55e'}].map((b, i) => (
                <div key={i} style={{marginBottom: 6}}>
                  <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 34, color: '#111'}}>{b.l}</div>
                  <div style={{height: 42, width: 780 * b.w * bar, background: b.c, border: `6px solid ${OL}`, borderRadius: 12}} />
                </div>
              ))}
            </div>
          ) : null}
        </Cabin>
      </div>
      {scene.badge ? <Tag text={scene.badge as string} at={0} y={190} size={58} color="#111" fg="#ffcc4d" rot={0} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tagAt} x={mode === 'fall' ? 800 : 540} y={mode === 'fall' ? 470 : 190} size={mode === 'fall' ? 96 : 84} rot={mode === 'fall' ? 10 : -3} color={mode === 'flat' ? '#22c55e' : '#ff4d2e'} fg="#fff" /> : null}
      {mode === 'jump' ? (
        <div style={{position: 'absolute', left: 0, right: 0, top: 700, textAlign: 'center', opacity: frame >= res ? 1 : 0, scale: String(2.4 - rs * 1.4), rotate: '-8deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 330, color: '#ef4444', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>✗</span>
        </div>
      ) : null}
      {mode === 'flat' ? (
        <div style={{position: 'absolute', left: 0, right: 0, top: 560, textAlign: 'center', opacity: frame >= res ? 1 : 0, scale: String(2.4 - rs * 1.4), rotate: '6deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 300, color: '#22c55e', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>✓</span>
        </div>
      ) : null}
    </Shake>
  );
};

/* choiceAB: { a, b, title?, count: [w3, w2, w1] } — split screen with the two options acted out + a 3-2-1 countdown. */
const ChoiceAB: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const skin = sb.character.palette.skin, rim = sb.character.palette.rim;
  const aAt = at(captions, scene.aOnWord, fps, 6), bAt = at(captions, scene.bOnWord, fps, dur * 0.3);
  const cw = (scene.count as string[]) ?? [];
  const cAts = cw.map((w, i) => at(captions, w, fps, dur * (0.6 + i * 0.12)));
  const fixed = scene.fixedN as number | undefined;
  let n = fixed ?? 0;
  if (!fixed) cAts.forEach((c, i) => { if (frame >= c) n = 3 - i; });
  const nAt = fixed ? 0 : n ? cAts[3 - n] : 0;
  const pop = spring({frame: frame - nAt, fps, config: {damping: 8, stiffness: 220}});
  const sa = fixed ? 1 : spring({frame: frame - aAt, fps, config: {damping: 12}}), sbb = fixed ? 1 : spring({frame: frame - bAt, fps, config: {damping: 12}});
  const hop = Math.abs(Math.sin(frame / 5)) * 120;
  const Panel = ({x, c1, c2, letter, text, s}: {x: number; c1: string; c2: string; letter: string; text: string; s: number}) => (
    <div style={{position: 'absolute', left: x, top: 420, width: 500, height: 860, background: `linear-gradient(180deg, ${c1}, ${c2})`, border: `10px solid ${OL}`, borderRadius: 36,
      scale: String(0.7 + s * 0.3), opacity: s, overflow: 'hidden', boxShadow: `0 14px 0 ${OL}`}}>
      <div style={{position: 'absolute', left: 24, top: 14, fontFamily: DISPLAY, fontSize: 190, lineHeight: 1, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>{letter}</div>
      <div style={{position: 'absolute', left: 190, right: 20, top: 34, textAlign: 'left', fontFamily: DISPLAY, fontSize: 62, lineHeight: 1.04, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{text}</div>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 90, background: '#00000033', borderTop: `8px solid ${OL}`}} />
    </div>
  );
  return (
    <Shake at={nAt} amount={n ? 12 : 0}>
      <Camera dur={dur} from={fixed ? 1.05 : 1.0} to={1.05}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #3b2a6b 0%, #120c26 75%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.12}}>
          {new Array(18).fill(0).map((_, i) => {
            const a = (i / 18) * Math.PI * 2 + frame / 70;
            return <path key={i} d={`M540 860 L${540 + Math.cos(a) * 1700} ${860 + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.17) * 1700} ${860 + Math.sin(a + 0.17) * 1700} Z`} fill="#fff" />;
          })}
        </svg>
        <Tag text={(scene.title as string) ?? 'PICK ONE!'} at={0} y={250} size={110} color="#ffcc4d" rot={-2} />
        <Panel x={30} c1="#ff9a3c" c2="#ea580c" letter="A" text={(scene.a as string) ?? ''} s={sa} />
        <Panel x={550} c1="#2dd4bf" c2="#0f766e" letter="B" text={(scene.b as string) ?? ''} s={sbb} />
        <div style={{opacity: sa, rotate: scene.aAct === 'thrash' ? `${Math.sin(frame * 1.2) * 8}deg` : '0deg', transformOrigin: '280px 1185px'}}><Boy x={280} y={1185 - (scene.aAct === 'thrash' ? 0 : hop * 0.6)} height={400} stage="teen" skin={skin} rim={rim} glow={0.1} pose="cheer" phase={scene.aAct === 'thrash' ? frame * 1.2 : frame / 4} mood="shock" /></div>
        <div style={{opacity: sbb}}><Lying x={1000} y={1120} height={420} skin={skin} rim={rim} mood="shock" /></div>
        {n ? (
          <div style={{position: 'absolute', left: 390, top: 700, width: 300, height: 300, borderRadius: '50%', background: '#fff', border: `14px solid ${OL}`, boxShadow: `0 14px 0 ${OL}`,
            textAlign: 'center', scale: String(1.8 - pop * 0.8)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 230, lineHeight: '290px', color: n === 1 ? '#ef4444' : '#111'}}>{n}</span>
          </div>
        ) : (
          <div style={{position: 'absolute', left: 440, top: 760, width: 200, textAlign: 'center', fontFamily: DISPLAY, fontSize: 130, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill',
            opacity: Math.min(sa, sbb)}}>OR</div>
        )}
      </Camera>
    </Shake>
  );
};

/* shaftBrakes: { snapOnWord, brakeOnWord, tag? } — cutaway shaft: the cables snap, the car drops, the brakes clamp the rails. */
const ShaftBrakes: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const snap = at(captions, scene.snapOnWord, fps, 12), brake = at(captions, scene.brakeOnWord, fps, dur * 0.5);
  const drop = interpolate(frame, [snap, brake], [0, 1], clamp);
  const carY = 480 + drop * drop * 330;
  const braked = frame >= brake;
  const clampS = spring({frame: frame - brake, fps, config: {damping: 10, stiffness: 240}});
  return (
    <Shake at={brake} amount={22}>
      <Camera dur={dur} from={1.04} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b, #0b1220)'}} />
        {new Array(7).fill(0).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: 0, right: 0, top: 260 + i * 190, height: 10, background: '#334155'}} />
        ))}
        <div style={{position: 'absolute', left: 250, top: 200, width: 580, height: 1200, background: '#0f172a', border: `10px solid ${OL}`}} />
        {[262, 792].map((x) => <div key={x} style={{position: 'absolute', left: x, top: 200, width: 26, height: 1200, background: '#94a3b8', border: `5px solid ${OL}`}} />)}
        {/* cables */}
        {[0, 1, 2, 3, 4].map((i) => {
          const x = 440 + i * 50;
          const cut = frame >= snap + i * 2;
          return cut ? (
            <React.Fragment key={i}>
              <div style={{position: 'absolute', left: x, top: 200, width: 8, height: 150 + i * 18, background: '#cbd5e1', rotate: `${Math.sin(frame / 3 + i) * 5}deg`, transformOrigin: '50% 0'}} />
            </React.Fragment>
          ) : <div key={i} style={{position: 'absolute', left: x, top: 200, width: 8, height: carY - 200, background: '#cbd5e1'}} />;
        })}
        {/* car */}
        <div style={{position: 'absolute', left: 312, top: carY, width: 456, height: 440, background: 'linear-gradient(180deg, #aeb9c9, #8794a8)', border: `10px solid ${OL}`, borderRadius: 18, overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 50, background: '#4b5563', borderTop: `6px solid ${OL}`}} />
        </div>
        <Boy x={540} y={carY + 392} height={330} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.1}
          pose={braked ? 'cheer' : 'stand'} phase={frame / 4} mood={braked ? 'laugh' : frame >= snap ? 'shock' : 'neutral'} />
        {/* brake wedges */}
        {[{x: 286, d: 1}, {x: 742, d: -1}].map((b) => (
          <div key={b.x} style={{position: 'absolute', left: b.x - b.d * (1 - clampS) * 40 * -1 + (braked ? 0 : b.d * 26), top: carY + 400, width: 52, height: 70, background: '#facc15', border: `7px solid ${OL}`, borderRadius: 10,
            boxShadow: braked ? '0 0 50px #facc15' : 'none'}} />
        ))}
        {braked ? new Array(16).fill(0).map((_, i) => {
          const t = Math.min(1, (frame - brake - (i % 4)) / 14);
          if (t < 0 || t >= 1) return null;
          const left = i % 2 === 0;
          return <div key={i} style={{position: 'absolute', left: (left ? 290 : 780) + (left ? -1 : 1) * t * (40 + (i % 5) * 22), top: carY + 420 + t * t * 160 - t * (i % 3) * 50, width: 12, height: 12, borderRadius: 6, background: i % 3 ? '#ffd27a' : '#fff', opacity: 1 - t}} />;
        }) : null}
        {scene.tag ? <Tag text={scene.tag as string} at={brake} y={235} size={96} color="#facc15" /> : null}
      </Camera>
    </Shake>
  );
};

/* towerFall: { top?, floors, fallOnWord, stamp, stampOnWord } — a skyscraper at dusk; the lift drops the whole height; stamp slams in. */
const TowerFall: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fall = at(captions, scene.fallOnWord, fps, dur * 0.3), st = at(captions, scene.stampOnWord, fps, dur * 0.8);
  const floors = (scene.floors as number) ?? 75;
  const p = interpolate(frame, [fall, Math.max(fall + 20, st - 6)], [0, 1], clamp);
  const pe = p * p;
  const s = spring({frame: frame - st, fps, config: {damping: 8, stiffness: 200}});
  const by = 380, bh = 900;
  return (
    <Shake at={st} amount={20}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e1b4b 0%, #7c3aed 45%, #fb923c 85%, #fed7aa 100%)'}} />
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`tx${i}`) * 1080, top: random(`ty${i}`) * 700, width: 5, height: 5, borderRadius: 3, background: '#fff', opacity: 0.3 + 0.5 * Math.abs(Math.sin(frame / 15 + i))}} />)}
        {[{x: 40, w: 190, h: 420}, {x: 210, w: 140, h: 300}, {x: 760, w: 160, h: 380}, {x: 900, w: 200, h: 520}].map((b) => (
          <div key={b.x} style={{position: 'absolute', left: b.x, top: by + bh - b.h, width: b.w, height: b.h, background: '#312e81', border: `7px solid ${OL}`}} />
        ))}
        {/* the tower */}
        <div style={{position: 'absolute', left: 525, top: by - 150, width: 30, height: 150, background: '#c4b5fd', border: `6px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 440, top: by - 40, width: 200, height: 60, background: '#a78bfa', border: `8px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 370, top: by, width: 340, height: bh, background: 'linear-gradient(90deg, #a78bfa, #8b5cf6)', border: `9px solid ${OL}`, overflow: 'hidden'}}>
          {new Array(22).fill(0).map((_, r) => [0, 1, 3, 4].map((c) => (
            <div key={`${r}-${c}`} style={{position: 'absolute', left: 22 + c * 62, top: 16 + r * 40, width: 40, height: 22, background: random(`w${r}${c}`) > 0.4 ? '#fde68a' : '#4c1d95', borderRadius: 3}} />
          )))}
          <div style={{position: 'absolute', left: 140, top: 0, width: 46, height: bh, background: '#1e1b4b', borderLeft: `4px solid ${OL}`, borderRight: `4px solid ${OL}`}} />
          <div style={{position: 'absolute', left: 143, top: 10 + pe * (bh - 80), width: 40, height: 50, background: '#facc15', border: `5px solid ${OL}`, borderRadius: 6, boxShadow: '0 0 30px #facc15'}} />
          {p > 0 && p < 1 ? <div style={{position: 'absolute', left: 158, top: 10 + pe * (bh - 80) - 120, width: 10, height: 110, background: 'linear-gradient(180deg, transparent, #fde68a)'}} /> : null}
        </div>
        <div style={{position: 'absolute', left: 0, top: by + bh, width: 1080, height: 700, background: '#1e1b4b', borderTop: `9px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 40, top: 520, width: 310, textAlign: 'center'}}>
          <div style={{fontFamily: DISPLAY, fontSize: 170, lineHeight: 1, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>{Math.round(floors * (1 - pe))}</div>
          <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 40, color: '#fde68a'}}>FLOORS UP</div>
        </div>
        {scene.top ? <Tag text={scene.top as string} at={0} y={200} size={72} color="#fff" rot={0} /> : null}
        <div style={{position: 'absolute', left: 0, right: 0, top: 760, textAlign: 'center', opacity: frame >= st ? 1 : 0, scale: String(2.6 - s * 1.6), rotate: '-9deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 170, color: '#22c55e', background: '#052e16', padding: '0 34px', border: '12px solid #22c55e', borderRadius: 22}}>{(scene.stamp as string) ?? 'SURVIVED'}</span>
        </div>
      </Camera>
    </Shake>
  );
};

/* abEnd: { series, title, cta, answer?: 'A'|'B' } — closing card: two big A/B buttons, the right one glowing. */
const AbEnd: React.FC<SceneProps> = ({scene, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const ans = (scene.answer as string) ?? 'B';
  const s = spring({frame: frame - 4, fps, config: {damping: 11}});
  return (
    <Camera dur={dur} from={1.05} to={1.0}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #3b2a6b 0%, #120c26 75%)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.14}}>
        {new Array(18).fill(0).map((_, i) => {
          const a = (i / 18) * Math.PI * 2 + frame / 70;
          return <path key={i} d={`M540 760 L${540 + Math.cos(a) * 1700} ${760 + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.17) * 1700} ${760 + Math.sin(a + 0.17) * 1700} Z`} fill="#fff" />;
        })}
      </svg>
      <Tag text={(scene.series as string) ?? ''} at={0} y={230} size={56} color="#111" fg="#ffcc4d" rot={0} />
      <div style={{position: 'absolute', top: 350, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 120, lineHeight: 1.05, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill', scale: String(0.7 + s * 0.3)}}>{(scene.title as string) ?? ''}</div>
      {[{l: 'A', x: 130, c: '#ea580c'}, {l: 'B', x: 590, c: '#0f766e'}].map((b, i) => {
        const win = b.l === ans;
        const pulse = 1 + Math.sin(frame / 5 + i * 2) * 0.04;
        return (
          <div key={b.l} style={{position: 'absolute', left: b.x, top: 640, width: 360, height: 360, borderRadius: '50%', background: b.c, border: `14px solid ${OL}`,
            boxShadow: win ? `0 0 90px ${b.c}, 0 14px 0 ${OL}` : `0 14px 0 ${OL}`, textAlign: 'center', scale: String(s * pulse)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 270, lineHeight: '340px', color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>{b.l}</span>
          </div>
        );
      })}
      <div style={{position: 'absolute', top: 1050, width: '100%', textAlign: 'center', opacity: interpolate(frame, [12, 22], [0, 1], clamp)}}>
        <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 52, color: '#111', background: '#ffcc4d', padding: '18px 44px', borderRadius: 60, border: `6px solid ${OL}`}}>{(scene.cta as string) ?? 'Comment A or B 👇'}</span>
      </div>
    </Camera>
  );
};

/* quicksand: { mode: 'sink'|'struggle'|'float'|'waist'|'tide', badge?, tag?, tagOnWord?, resultOnWord?, carOnWord?, lineOnWord? } */
const Quicksand: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'sink';
  const skin = sb.character.palette.skin, rim = sb.character.palette.rim;
  const tagAt = at(captions, scene.tagOnWord, fps, 6);
  const res = at(captions, scene.resultOnWord, fps, dur * 0.6);
  const carAt = at(captions, scene.carOnWord, fps, 1e9);
  const lineAt = at(captions, scene.lineOnWord, fps, dur * 0.6);
  const rs = spring({frame: frame - res, fps, config: {damping: 9, stiffness: 190}});
  const cs = spring({frame: frame - carAt, fps, config: {damping: 11}});
  const ls = spring({frame: frame - lineAt, fps, config: {damping: 12}});
  const SY = 1090, H = 600;
  const depth = mode === 'sink' ? interpolate(frame, [0, dur], [0.12, 0.4], clamp)
    : mode === 'struggle' ? interpolate(frame, [0, dur * 0.7], [0.4, 0.5], clamp) : 0.42;
  const thrash = mode === 'struggle';
  const tide = mode === 'tide' ? interpolate(frame, [8, dur], [0, 1], clamp) : 0;
  const bar = interpolate(frame, [6, 22], [0, 1], clamp);
  return (
    <Shake at={mode === 'sink' ? 0 : mode === 'tide' ? tagAt : res} amount={mode === 'sink' ? 22 : 14}>
      <Camera dur={dur} from={1.07} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8 0%, #bae6fd 45%, #fde68a 62%, #fbbf24 100%)'}} />
        <div style={{position: 'absolute', left: 760, top: 330, width: 190, height: 190, borderRadius: '50%', background: '#fff7c2', border: `8px solid ${OL}`, boxShadow: '0 0 90px #fff7c2'}} />
        <svg width={1080} height={500} style={{position: 'absolute', top: SY - 330}}>
          <path d="M0 330 Q200 150 430 300 Q640 120 860 260 Q980 200 1080 280 L1080 500 L0 500 Z" fill="#f59e0b" stroke={OL} strokeWidth={8} />
          <path d="M-20 360 Q260 250 560 340 Q820 260 1100 350 L1100 500 L-20 500 Z" fill="#fbbf24" stroke={OL} strokeWidth={8} />
          <g transform="translate(120 150)"><rect x={34} y={60} width={22} height={150} fill="#92400e" stroke={OL} strokeWidth={6} />
            {[-70, -35, 0, 35, 70].map((a) => <path key={a} d="M45 64 Q45 0 45 -50" stroke="#16a34a" strokeWidth={22} strokeLinecap="round" fill="none" transform={`rotate(${a} 45 64)`} />)}</g>
        </svg>
        <div style={{position: 'absolute', left: 0, top: SY - 6, width: 1080, height: 900, background: '#fbbf24'}} />
        {/* the pit (back half) */}
        <div style={{position: 'absolute', left: 130, top: SY - 70, width: 820, height: 150, borderRadius: '50%', background: '#a16207', border: `8px solid ${OL}`}} />
        {mode !== 'float' ? (
          <div style={{position: 'absolute', inset: 0, rotate: thrash ? `${Math.sin(frame * 1.3) * 7}deg` : `${Math.sin(frame / 9) * 1.5}deg`, transformOrigin: `540px ${SY}px`}}>
            <Boy x={540} y={SY + depth * H} height={H} stage="teen" skin={skin} rim={rim} glow={0.1}
              pose={mode === 'waist' ? 'stand' : 'cheer'} phase={thrash ? frame * 1.2 : frame / 3}
              mood={mode === 'waist' ? (frame >= lineAt ? 'happy' : 'neutral') : mode === 'struggle' && frame >= res ? 'cry' : 'shock'} />
          </div>
        ) : null}
        {/* the pit (front half) hides the legs */}
        <div style={{position: 'absolute', left: 0, top: SY, width: 1080, height: 900, overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 900, background: 'linear-gradient(180deg, #fbbf24, #d97706)'}} />
          <div style={{position: 'absolute', left: 130, top: -70, width: 820, height: 150, borderRadius: '50%', background: 'linear-gradient(180deg, #a16207, #854d0e)', border: `8px solid ${OL}`}} />
          {[0, 1, 2].map((i) => {
            const t = ((frame + i * 14) % 42) / 42;
            return <div key={i} style={{position: 'absolute', left: 540 - (120 + t * 260), top: 4 - (22 + t * 40) / 2 + 2, width: 2 * (120 + t * 260), height: 22 + t * 40, borderRadius: '50%', border: `5px solid #fde68a`, opacity: (1 - t) * (thrash ? 1 : 0.6)}} />;
          })}
        </div>
        {thrash ? new Array(14).fill(0).map((_, i) => {
          const t = ((frame * 1.4 + i * 5) % 18) / 18;
          const dir = i % 2 ? 1 : -1;
          return <div key={i} style={{position: 'absolute', left: 540 + dir * (90 + t * (60 + (i % 4) * 40)), top: SY - 20 - Math.sin(t * Math.PI) * (110 + (i % 3) * 50), width: 26, height: 26, borderRadius: '50%', background: '#a16207', border: `4px solid ${OL}`, opacity: 1 - t * 0.5}} />;
        }) : null}
        {mode === 'float' ? (
          <div style={{position: 'absolute', inset: 0, translate: `0px ${Math.sin(frame / 8) * 8}px`}}>
            <Lying x={830} y={SY + 34} height={560} skin={skin} rim={rim} mood={frame >= res ? 'happy' : 'determined'} />
            {[0, 1].map((i) => <svg key={i} width={120} height={70} style={{position: 'absolute', left: 700 + i * 70, top: SY - 110 + Math.sin(frame / 4 + i * 2) * 10}}>
              <path d="M10 35 H110 M30 15 L10 35 L30 55 M90 15 L110 35 L90 55" stroke="#38bdf8" strokeWidth={10} fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </svg>)}
          </div>
        ) : null}
        {mode === 'waist' ? (
          <>
            <div style={{position: 'absolute', left: 170, top: 430, width: 740, opacity: bar}}>
              {[{l: 'YOU', v: '1 g/ml', w: 0.5, c: '#38bdf8'}, {l: 'QUICKSAND', v: '2 g/ml', w: 1, c: '#a16207'}].map((b, i) => (
                <div key={i} style={{marginBottom: 12, position: 'relative'}}>
                  <div style={{height: 76, width: 740 * b.w * bar, background: b.c, border: `7px solid ${OL}`, borderRadius: 14}} />
                  <div style={{position: 'absolute', left: 20, top: 12, fontFamily: DISPLAY, fontSize: 46, color: '#fff', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill', whiteSpace: 'nowrap'}}>{b.l} · {b.v}</div>
                </div>
              ))}
            </div>
            <div style={{position: 'absolute', left: 110, top: SY - 4, width: 860 * ls, height: 0, borderTop: '10px dashed #ef4444'}} />
            <Tag text="CAN'T SINK PAST HERE" at={lineAt} y={SY + 40} size={70} color="#ef4444" fg="#fff" rot={-2} />
          </>
        ) : null}
        {mode === 'struggle' && frame >= carAt ? (
          <div style={{position: 'absolute', left: 60, top: 560 - cs * 120, opacity: cs}}>
            <svg width={420} height={230} viewBox="0 0 420 230">
              <path d="M30 150 L60 90 Q80 50 140 50 L270 50 Q320 50 350 100 L390 110 Q405 114 405 135 L405 160 L30 160 Z" fill="#ef4444" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
              <path d="M100 100 L120 70 L190 70 L190 100 Z M205 70 L270 70 Q300 72 315 100 L205 100 Z" fill="#bae6fd" stroke={OL} strokeWidth={6} />
              <circle cx={115} cy={165} r={36} fill="#1f2937" stroke={OL} strokeWidth={8} /><circle cx={115} cy={165} r={13} fill="#cbd5e1" />
              <circle cx={320} cy={165} r={36} fill="#1f2937" stroke={OL} strokeWidth={8} /><circle cx={320} cy={165} r={13} fill="#cbd5e1" />
            </svg>
            <div style={{fontFamily: DISPLAY, fontSize: 54, color: '#fff', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill', textAlign: 'center'}}>= LIFTING A CAR</div>
          </div>
        ) : null}
        {mode === 'tide' ? (
          <div style={{position: 'absolute', left: 0, top: 1920 - tide * (1920 - (SY - 250)), width: 1080, height: 1920, background: 'linear-gradient(180deg, #0ea5e9cc, #0369a1ee)'}}>
            <svg width={1080} height={60} style={{position: 'absolute', top: -40}}>
              <path d={`M0 40 ${new Array(10).fill(0).map((_, i) => `Q${i * 120 + 60 + Math.sin(frame / 6 + i) * 20} ${10 + (i % 2) * 20} ${(i + 1) * 120} 40`).join(' ')} L1080 60 L0 60 Z`} fill="#0ea5e9" stroke={OL} strokeWidth={7} />
            </svg>
          </div>
        ) : null}
        {scene.badge ? <Tag text={scene.badge as string} at={0} y={190} size={58} color="#111" fg="#ffcc4d" rot={0} /> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tagAt} y={mode === 'sink' ? 320 : 250} size={mode === 'sink' ? 110 : 84} color={mode === 'float' ? '#22c55e' : mode === 'tide' ? '#0ea5e9' : '#ff4d2e'} fg="#fff" /> : null}
        {mode === 'struggle' || mode === 'float' ? (
          <div style={{position: 'absolute', left: mode === 'struggle' ? 540 : 0, right: 0, top: 470, textAlign: 'center', opacity: frame >= res ? 1 : 0, scale: String(2.4 - rs * 1.4), rotate: mode === 'float' ? '6deg' : '-8deg'}}>
            <span style={{fontFamily: DISPLAY, fontSize: 300, color: mode === 'float' ? '#22c55e' : '#ef4444', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>{mode === 'float' ? '✓' : '✗'}</span>
          </div>
        ) : null}
      </Camera>
    </Shake>
  );
};

export const SURVIVE_SCENES: Record<string, React.FC<SceneProps>> = {
  elevatorCabin: ElevatorCabin,
  quicksand: Quicksand,
  choiceAB: ChoiceAB,
  shaftBrakes: ShaftBrakes,
  towerFall: TowerFall,
  abEnd: AbEnd,
};
