import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera} from '../components/Fx';
import {BODY, DISPLAY} from '../fonts';
import {wordFrame} from './kit';

/* Tech-explainer scene kit (Wi-Fi, phones, internet...). Same navy "lab" family as the
   body explainers, with electric-blue signal colour. */

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const T = {bg1: '#050d1c', bg2: '#0a1d3a', sig: '#3fe0ff', hot: '#ff6b6b', gold: '#ffcc4d', mint: '#5dffb0', ink: '#e9f6ff', wall: '#1b2a45'};

const TechBg: React.FC = () => (
  <AbsoluteFill style={{background: `radial-gradient(circle at 50% 40%, ${T.bg2} 0%, ${T.bg1} 75%)`}}>
    <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.07}}>
      {new Array(40).fill(0).map((_, i) => <circle key={i} cx={(i % 8) * 140 + 70} cy={Math.floor(i / 8) * 400 + 100} r={3} fill="#fff" />)}
    </svg>
  </AbsoluteFill>
);

/* ---------- icons ---------- */
const Router: React.FC<{x: number; y: number; s?: number; glow?: number}> = ({x, y, s = 1, glow = 0}) => (
  <svg style={{position: 'absolute', left: x - 110 * s, top: y - 110 * s, overflow: 'visible', filter: `drop-shadow(0 0 ${10 + glow * 30}px ${T.sig})`}} width={220 * s} height={220 * s} viewBox="0 0 220 220">
    <line x1={60} y1={120} x2={40} y2={30} stroke={T.ink} strokeWidth={10} strokeLinecap="round" />
    <line x1={160} y1={120} x2={180} y2={30} stroke={T.ink} strokeWidth={10} strokeLinecap="round" />
    <rect x={20} y={110} width={180} height={70} rx={18} fill="#16294a" stroke={T.sig} strokeWidth={5} />
    {[0, 1, 2, 3].map((i) => <circle key={i} cx={55 + i * 36} cy={145} r={7} fill={i < 3 ? T.mint : T.sig} opacity={0.6 + glow * 0.4} />)}
  </svg>
);
const Phone: React.FC<{x: number; y: number; s?: number; bars?: number; screen?: string}> = ({x, y, s = 1, bars = 4, screen}) => (
  <svg style={{position: 'absolute', left: x - 60 * s, top: y - 110 * s, overflow: 'visible', filter: `drop-shadow(0 0 18px ${T.sig})`}} width={120 * s} height={220 * s} viewBox="0 0 120 220">
    <rect x={4} y={4} width={112} height={212} rx={20} fill="#0d1a30" stroke={T.ink} strokeWidth={6} />
    <rect x={14} y={30} width={92} height={160} rx={8} fill={screen ?? '#13355e'} />
    {[0, 1, 2].map((i) => (
      <path key={i} d={`M${60 - 14 - i * 12} ${110 - i * 10} Q60 ${96 - i * 22} ${60 + 14 + i * 12} ${110 - i * 10}`} stroke={T.sig} strokeWidth={6}
        fill="none" strokeLinecap="round" opacity={i < bars ? 1 : 0.15} />
    ))}
    <circle cx={60} cy={118} r={6} fill={T.sig} />
  </svg>
);
const Microwave: React.FC<{x: number; y: number; s?: number; on?: number}> = ({x, y, s = 1, on = 0}) => (
  <svg style={{position: 'absolute', left: x - 130 * s, top: y - 90 * s, overflow: 'visible', filter: `drop-shadow(0 0 ${10 + on * 30}px ${T.hot})`}} width={260 * s} height={180 * s} viewBox="0 0 260 180">
    <rect x={5} y={5} width={250} height={170} rx={16} fill="#1a2238" stroke={T.ink} strokeWidth={6} />
    <rect x={22} y={24} width={160} height={132} rx={10} fill={`rgba(255,170,80,${0.15 + on * 0.5})`} stroke={T.ink} strokeWidth={4} />
    {[0, 1, 2, 3].map((i) => <circle key={i} cx={220} cy={40 + i * 30} r={8} fill={T.ink} opacity={0.7} />)}
  </svg>
);

/* ---------- wifiHome: { mode: "send" | "receive" } ---------- */
const WifiHome: React.FC<SceneProps> = ({scene, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const receive = scene.mode === 'receive';
  const rx = 260, ry = 820, px = 820, py = 900;
  const walls = [430, 640];
  return (
    <>
      <TechBg />
      <Camera dur={dur} from={receive ? 1.15 : 1.0} to={receive ? 1.0 : 1.1}>
       <AbsoluteFill style={{translate: '0px -130px'}}>
        {/* house cross-section */}
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <path d="M60 560 L540 300 L1020 560" stroke={T.ink} strokeWidth={10} fill="none" opacity={0.6} />
          <rect x={80} y={560} width={920} height={560} fill="none" stroke={T.ink} strokeWidth={8} opacity={0.6} />
          {walls.map((w, i) => <rect key={i} x={w} y={560} width={26} height={560} fill={T.wall} stroke={T.ink} strokeOpacity={0.4} />)}
        </svg>
        {/* expanding waves (clipped to stage) */}
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          {new Array(7).fill(0).map((_, i) => {
            const r = ((frame * 9 + i * 120) % 840);
            const o = interpolate(r, [0, 840], [0.9, 0]);
            return <circle key={i} cx={rx} cy={ry} r={r} fill="none" stroke={T.sig} strokeWidth={6} opacity={o} />;
          })}
        </svg>
        {/* data packets travelling router -> phone */}
        {new Array(8).fill(0).map((_, i) => {
          const t = ((frame / 40 + i / 8) % 1);
          const x = rx + (px - rx) * t;
          const y = ry - 80 + Math.sin(t * Math.PI) * -120 + (py - ry) * t;
          return (
            <div key={i} style={{position: 'absolute', left: x - 24, top: y - 24, width: 48, height: 48, borderRadius: 10,
              background: 'rgba(63,224,255,0.15)', border: `3px solid ${T.sig}`, color: T.ink, fontFamily: DISPLAY, fontSize: 28,
              display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: Math.sin(t * Math.PI)}}>{random(`b${i}`) > 0.5 ? '1' : '0'}</div>
          );
        })}
        <Router x={rx} y={ry + 120} s={1} glow={0.5 + 0.5 * Math.sin(frame / 6)} />
        <Phone x={px} y={py + 60} s={1.1} bars={receive ? Math.min(4, 1 + Math.floor(frame / 12)) : 4} />
       </AbsoluteFill>
      </Camera>
    </>
  );
};

/* ---------- spectrum: { markers: [{label, pos (0..1), onWord}] } ---------- */
const BANDS = [
  {n: 'Radio', c: '#2b5cff'}, {n: 'Microwave', c: '#3fa0ff'}, {n: 'Infrared', c: '#a8324a'},
  {n: 'Visible', c: 'rainbow'}, {n: 'UV', c: '#8a3cff'}, {n: 'X-ray', c: '#5f6b8a'}, {n: 'Gamma', c: '#3c4660'},
];
const Spectrum: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const markers = (scene.markers as {label: string; pos: number; onWord?: string; color?: string}[]) ?? [];
  const L = 60, W = 960, Y = 820, H = 120, bw = W / BANDS.length;
  return (
    <>
      <TechBg />
      <Camera dur={dur} from={1.0} to={1.05}>
        {/* wave with rising frequency */}
        <svg width={1080} height={400} style={{position: 'absolute', top: 480}}>
          <path d={(() => {
            let d = `M${L} 200`;
            for (let x = 0; x <= W; x += 3) {
              const f = 0.01 + Math.pow(x / W, 2.2) * 0.55;
              const ph = (x * f) - frame * 0.25;
              d += ` L${L + x} ${200 + Math.sin(ph) * 90}`;
            }
            return d;
          })()} stroke={T.ink} strokeWidth={5} fill="none" opacity={0.8} />
        </svg>
        {BANDS.map((b, i) => (
          <div key={b.n} style={{position: 'absolute', left: L + i * bw, top: Y, width: bw - 4, height: H, borderRadius: 14,
            background: b.c === 'rainbow' ? 'linear-gradient(90deg, #ff3b3b, #ffb13b, #f5ff3b, #3bff6a, #3bb4ff, #7a3bff)' : b.c,
            opacity: 0.9}}>
            <div style={{position: 'absolute', top: H + 14, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 26, color: T.ink, opacity: 0.85}}>{b.n}</div>
          </div>
        ))}
        <div style={{position: 'absolute', top: Y - 120, left: L, fontFamily: BODY, fontWeight: 800, fontSize: 28, color: T.ink, opacity: 0.6}}>LONG WAVES</div>
        <div style={{position: 'absolute', top: Y - 120, right: 60, fontFamily: BODY, fontWeight: 800, fontSize: 28, color: T.ink, opacity: 0.6}}>SHORT WAVES</div>
        {markers.map((m, i) => {
          const at = m.onWord ? wordFrame(captions, m.onWord, fps, 10 + i * 30) : 10 + i * 30;
          const s = spring({frame: frame - at, fps, config: {damping: 13}});
          const x = L + m.pos * W;
          const col = m.color ?? (i ? T.gold : T.sig);
          return (
            <div key={i} style={{position: 'absolute', left: x, top: Y + H + 70, translate: '-50% 0', opacity: s, scale: String(0.6 + s * 0.4), textAlign: 'center'}}>
              <div style={{width: 0, height: 0, margin: '0 auto', borderLeft: '22px solid transparent', borderRight: '22px solid transparent', borderBottom: `30px solid ${col}`}} />
              <div style={{fontFamily: DISPLAY, fontSize: 56, color: col, marginTop: 6, whiteSpace: 'nowrap'}}>{m.label}</div>
            </div>
          );
        })}
      </Camera>
    </>
  );
};

/* ---------- waveEncode: data icons -> bits -> modulated wave ---------- */
const WaveEncode: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bitsAt = scene.bitsOnWord ? wordFrame(captions, scene.bitsOnWord as string, fps, 30) : 30;
  const waveAt = scene.waveOnWord ? wordFrame(captions, scene.waveOnWord as string, fps, 70) : 70;
  const bits = '1011001110100101';
  const shift = (frame * 4) % 120;
  const icons = ['📷', '💬', '🎬'];
  const iconS = spring({frame, fps, config: {damping: 14}});
  const bitO = interpolate(frame, [bitsAt, bitsAt + 10], [0, 1], clamp);
  const waveO = interpolate(frame, [waveAt, waveAt + 12], [0, 1], clamp);
  return (
    <>
      <TechBg />
      <Camera dur={dur} from={1.05} to={1.0}>
        <div style={{position: 'absolute', top: 280, width: '100%', display: 'flex', justifyContent: 'center', gap: 60}}>
          {icons.map((ic, i) => (
            <div key={i} style={{width: 170, height: 170, borderRadius: 34, background: 'rgba(63,224,255,0.08)', border: `4px solid ${T.sig}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 90, scale: String(iconS), opacity: 1 - bitO * 0.5}}>{ic}</div>
          ))}
        </div>
        {/* bit row */}
        <div style={{position: 'absolute', top: 560, left: 0, width: 1080, overflow: 'hidden', height: 110, opacity: bitO}}>
          <div style={{position: 'absolute', left: -shift, display: 'flex'}}>
            {(bits + bits + bits).split('').map((b, i) => (
              <div key={i} style={{width: 60, textAlign: 'center', fontFamily: DISPLAY, fontSize: 84, color: b === '1' ? T.gold : T.sig}}>{b}</div>
            ))}
          </div>
        </div>
        {/* modulated wave: amplitude follows the bits under it */}
        <svg width={1080} height={420} style={{position: 'absolute', top: 700, opacity: waveO}}>
          <path d={(() => {
            let d = 'M0 210';
            for (let x = 0; x <= 1080; x += 3) {
              const idx = Math.floor((x + shift) / 60) % bits.length;
              const amp = bits.at(idx) === '1' ? 150 : 55;
              d += ` L${x} ${210 + Math.sin((x + shift) / 60 * Math.PI * 2) * amp}`;
            }
            return d;
          })()} stroke={T.sig} strokeWidth={7} fill="none" style={{filter: `drop-shadow(0 0 14px ${T.sig})`}} />
        </svg>
        {/* arrows */}
        <div style={{position: 'absolute', top: 470, width: '100%', textAlign: 'center', fontSize: 60, color: T.ink, opacity: bitO * 0.7}}>↓</div>
        <div style={{position: 'absolute', top: 650, width: '100%', textAlign: 'center', fontSize: 60, color: T.ink, opacity: waveO * 0.7}}>↓</div>
      </Camera>
    </>
  );
};

/* ---------- versus: { left: {label, value, icon}, right: {...}, revealOnWord } ---------- */
const Versus: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const l = scene.left as {label: string; value: string; icon: 'router' | 'microwave' | 'phone'};
  const r = scene.right as {label: string; value: string; icon: 'router' | 'microwave' | 'phone'};
  const at = scene.revealOnWord ? wordFrame(captions, scene.revealOnWord as string, fps, 30) : 30;
  const sL = spring({frame, fps, config: {damping: 14}});
  const sR = spring({frame: frame - at, fps, config: {damping: 11}});
  const eq = spring({frame: frame - at - 10, fps, config: {damping: 9}});
  const icon = (k: string, x: number, y: number, on: number) =>
    k === 'router' ? <Router x={x} y={y} s={1.1} glow={on} /> : k === 'microwave' ? <Microwave x={x} y={y} s={1.1} on={on} /> : <Phone x={x} y={y} s={1.1} />;
  const card = (d: {label: string; value: string; icon: string}, x: number, s: number, col: string, on: number) => (
    <div style={{position: 'absolute', left: x - 230, top: 300, width: 460, height: 760, opacity: s, translate: `0px ${(1 - s) * 80}px`}}>
      <div style={{position: 'absolute', inset: 0, borderRadius: 40, border: `5px solid ${col}`, background: 'rgba(255,255,255,0.04)'}} />
      {icon(d.icon, 230, 260, on)}
      <div style={{position: 'absolute', top: 470, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 46, color: T.ink}}>{d.label}</div>
      <div style={{position: 'absolute', top: 560, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 104, color: col}}>{d.value}</div>
    </div>
  );
  return (
    <>
      <TechBg />
      <Camera dur={dur} from={1.0} to={1.06}>
        {card(l, 285, sL, T.sig, 0.6 + 0.4 * Math.sin(frame / 6))}
        {card(r, 795, sR, T.hot, frame > at ? 0.6 + 0.4 * Math.sin(frame / 3) : 0)}
        <div style={{position: 'absolute', left: 540, top: 640, translate: '-50% -50%', width: 130, height: 130, borderRadius: '50%', background: T.gold,
          color: T.bg1, fontFamily: DISPLAY, fontSize: 90, display: 'flex', alignItems: 'center', justifyContent: 'center', scale: String(eq),
          boxShadow: `0 0 50px ${T.gold}`}}>≈</div>
        {/* interference static once both are shown */}
        {frame > at + 20 && new Array(30).fill(0).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: random(`st${i}-${Math.floor(frame / 2)}`) * 1080, top: 300 + random(`sy${i}-${Math.floor(frame / 2)}`) * 760,
            width: 40 + random(`sw${i}`) * 120, height: 4, background: T.ink, opacity: 0.25}} />
        ))}
      </Camera>
    </>
  );
};

export const TECH_SCENES: Record<string, React.FC<SceneProps>> = {
  wifiHome: WifiHome,
  spectrum: Spectrum,
  waveEncode: WaveEncode,
  versus: Versus,
};
