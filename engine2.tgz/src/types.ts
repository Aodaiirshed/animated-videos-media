import type {Caption} from '@remotion/captions';

export type Sfx = {file: string; at?: number; onWord?: string; volume?: number};
export type Transition = 'flash' | 'zoomBlur' | 'slideUp' | 'whipPan' | 'none';

export type SceneDef = {
  id: string;
  visual: string;
  vo: string;
  emphasis?: string[];
  sfx?: Sfx[];
  transition?: Transition; // how the NEXT scene enters
  holdAfter?: number;
  revealName?: string;
  revealSub?: string;
  [k: string]: unknown;
};

export type Storyboard = {
  slug: string;
  player: string;
  language: 'en' | 'ar' | string;
  hook: string;
  character: {id: string; description: string; palette: {skin: string; rim: string; shirt: string}};
  palette: {bg: string; accent: string; gold: string; text: string};
  scenes: SceneDef[];
  music?: {file: string; volume: number};
  cta?: string;
};

export type Timing = {
  slug: string;
  totalSec: number;
  noAudio?: boolean; // preview timing estimated from text (scripts/estimate_timing.py)
  scenes: {id: string; durationSec: number; captions: Caption[]; mouth?: number[]}[];
};

export type SceneProps = {
  sb: Storyboard;
  scene: SceneDef;
  captions: Caption[];
  durationInFrames: number;
  mouth?: number[];
};
