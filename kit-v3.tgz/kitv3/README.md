# Kit v3 (26 Nov 2026) — pilots for Master Strategy v3.0
Remotion 4 project used for the 4 pilots (WonderSynapse sleep paralysis, SecretFootFiles Adriano,
Daftar Noor Fatima al-Fihri, Historical Mysteries Ötzi). Each channel has its own file in src/
(Wonder.tsx, Foot.tsx, Noor.tsx, Hist.tsx) with its own palette, type and scene components; lib.tsx
has shared Scenes/Captions/Cam/Particles/Grain/Vignette helpers and word-synced timing.

Setup:
  tar xzf kit-v3.tgz && cd kitv3 && npm i && npx remotion browser ensure
  pip install --break-system-packages kokoro-onnx piper-tts faster-whisper soundfile
  models: huggingface.co/fastrtc/kokoro-onnx (kokoro-v1.0.onnx, voices-v1.0.bin) -> /home/claude/models
          huggingface.co/rhasspy/piper-voices ar/ar_JO/kareem/medium -> /home/claude/models/ar.onnx(+.json)
Pipeline:
  scripts/lines.py   narration per scene (Arabic must be fully diacritised for piper)
  scripts/tts.py <key>     -> public/audio/<key>_vo.wav + <key>_scenes.json
  scripts/align.py small <key> -> word timings (also an intelligibility check)
  scripts/sound.py <key>   -> procedural score/SFX, ducked mix, loudnorm -> /home/claude/out/<key>_mix.m4a
  npx remotion render src/index.ts <key> out.mp4 --muted --concurrency=2, then mux with the mix
Notes: edge-tts does not work through the session proxy (websocket). Voices: Wonder af_heart, Foot am_fenrir,
History bm_george, Daftar Noor piper ar_JO kareem.
