"""Transcribe each VO with faster-whisper, print transcript (intelligibility check),
and write word-level caption timings aligned to the script words."""
import sys, json, re, difflib
from faster_whisper import WhisperModel

A = "/home/claude/studio/public/audio"
model = WhisperModel(sys.argv[1] if len(sys.argv) > 2 else "small", device="cpu", compute_type="int8")

def norm(w):
    w = re.sub(r"[ً-ْٰ]", "", w)  # strip tashkeel
    w = w.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ة", "ه").replace("ى", "ي")
    return re.sub(r"[^\w]", "", w.lower())

for key in sys.argv[2:] if len(sys.argv) > 2 else sys.argv[1:]:
    sc = json.load(open(f"{A}/{key}_scenes.json"))
    lang = "ar" if key == "noor" else "en"
    import soundfile as sf, numpy as np
    x, sr = sf.read(f"{A}/{key}_vo.wav", dtype="float32")
    x = np.interp(np.linspace(0, len(x)-1, int(len(x)*16000/sr)), np.arange(len(x)), x).astype(np.float32)
    segs, _ = model.transcribe(x, language=lang, word_timestamps=True, beam_size=5)
    hw = [w for s in segs for w in s.words]
    print(f"== {key}:", " ".join(w.word.strip() for w in hw))
    # script words with scene ids
    sw = []
    for s in sc["scenes"]:
        for w in s["text"].replace("...", " ").split():
            sw.append((s["id"], w))
    a = [norm(w) for _, w in sw]; b = [norm(w.word) for w in hw]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    times = [None] * len(sw)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal" or (tag == "replace" and i2 - i1 == j2 - j1):
            for k in range(i2 - i1):
                times[i1 + k] = (hw[j1 + k].start, hw[j1 + k].end)
    matched = sum(t is not None for t in times)
    print(f"   matched {matched}/{len(sw)} words")
    # fill gaps by interpolating within scene bounds
    scen = {s["id"]: s for s in sc["scenes"]}
    for i in range(len(sw)):
        if times[i] is None:
            sid = sw[i][0]
            prev = next((times[j][1] for j in range(i - 1, -1, -1) if times[j] and sw[j][0] == sid), scen[sid]["start"])
            nxt_j = next((j for j in range(i + 1, len(sw)) if times[j] and sw[j][0] == sid), None)
            nxt = times[nxt_j][0] if nxt_j is not None else scen[sid]["end"]
            gap = sum(1 for j in range(i, nxt_j if nxt_j is not None else len(sw)) if sw[j][0] == sid and times[j] is None)
            step = max(0.05, (nxt - prev) / max(1, gap))
            times[i] = (prev, prev + step)
    words = [{"s": sw[i][0], "w": sw[i][1], "t0": round(times[i][0], 3), "t1": round(times[i][1], 3)} for i in range(len(sw))]
    sc["words"] = words
    json.dump(sc, open(f"{A}/{key}_scenes.json", "w"), ensure_ascii=False, indent=1)
