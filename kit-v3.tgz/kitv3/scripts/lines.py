"""Narration lines for the four pilots. Each entry: (scene_id, text). Pause after each line in seconds."""

WONDER = {
    "voice": "am_onyx:0.55,am_michael:0.45", "lang": "en-us", "speed": 1.08, "engine": "kokoro",
    "lines": [
        ("wake", "You wake up. Your eyes open. But you can't move a single muscle.", 0.35),
        ("figure", "And something is standing in the room.", 0.6),
        ("reveal", "This is sleep paralysis. Nothing is holding you down. Your own brain is.", 0.4),
        ("switch", "Every time you dream, a cluster of cells deep in your brainstem flips a switch.", 0.25),
        ("flood", "It floods the nerves to your muscles with chemicals that silence them, so you don't act out your dreams.", 0.4),
        ("spared", "Only two systems escape the shutdown. Your eyes, and your diaphragm, the muscle that keeps you breathing.", 0.4),
        ("glitch", "Sleep paralysis happens when you wake up before that switch turns off. Your mind is awake. Your body is still in dream mode.", 0.4),
        ("dream", "And the figure? Your dream is still running, projected onto a waking room. Your brain's threat detector fills in the rest.", 0.4),
        ("payoff", "It's terrifying, but it usually passes within seconds to a few minutes. If it keeps happening, talk to a doctor.", 0.3),
        ("cta", "Follow for more of what your body does when you're not watching.", 0.6),
    ],
}

FOOT = {
    "voice": "bm_george:0.6,bm_lewis:0.4", "lang": "en-gb", "speed": 1.06, "engine": "kokoro",
    "lines": [
        ("hook", "In July 2004, he was the next Ronaldo. By August, one phone call had broken him.", 0.5),
        ("who", "Adriano. They called him The Emperor.", 0.35),
        ("final", "In the Copa America final, deep in stoppage time, he turned and smashed the equaliser. Brazil won on penalties.", 0.35),
        ("boot", "Seven goals. The Golden Boot. And he dedicated all of it to one man. His father, Almir.", 0.5),
        ("call", "Weeks later, at Inter's pre-season camp, the phone in his room rang.", 0.3),
        ("news", "His father had died of a heart attack. He was forty four.", 0.55),
        ("zanetti", "Javier Zanetti was in the room. He said Adriano threw the phone down and started screaming.", 0.4),
        ("sky", "He kept scoring, pointing to the sky after every goal. But years later he admitted that, back then, he only felt happy when he drank.", 0.45),
        ("fall", "The talent never left him. The man who kept him standing did.", 0.4),
        ("cta", "Follow for the football stories nobody tells.", 0.6),
    ],
}

HIST = {
    "voice": "bm_lewis", "lang": "en-gb", "speed": 1.04, "engine": "kokoro",
    "lines": [
        ("hook", "For ten years, scientists believed he froze to death. Then an X-ray found an arrowhead.", 0.55),
        ("find", "September 1991. Two hikers in the Alps spot a body in the melting ice. They think it's a lost climber.", 0.35),
        ("age", "He is five thousand three hundred years old.", 0.55),
        ("theory", "They call him Otzi. For a decade, the story was simple. A man caught in a storm, high on a mountain pass.", 0.4),
        ("xray", "Then, in 2001, a new X-ray. A flint arrowhead, buried in his left shoulder. Fired from behind.", 0.5),
        ("murder", "Otzi didn't freeze. He was murdered.", 0.6),
        ("axe", "But here is what nobody can explain. Lying beside him was a copper axe, one of the most valuable objects of his world.", 0.4),
        ("left", "His killer left it behind.", 0.55),
        ("question", "Who kills a man, and doesn't take the treasure?", 0.5),
        ("cta", "Historians still argue about the answer. Follow for the mysteries history never solved.", 0.6),
    ],
}

NOOR = {
    "engine": "edge", "voice": "ar-SA-HamedNeural", "rate": "+8%", "lang": "ar",
    "lines": [
        ("hook", "أَقْدَمُ جَامِعَةٍ فِي العَالَمِ، مَا زَالَتْ تَعْمَلُ إِلَى اليَوْم... لَمْ يَبْنِهَا سُلْطَان.", 0.5),
        ("woman", "بَلْ بَنَتْهَا امْرَأَة.", 0.7),
        ("migrate", "تَرْوِي المَصَادِرُ أَنَّ فَاطِمَةَ الفِهْرِيَّةَ، هَاجَرَتْ مَعَ أُسْرَتِهَا، مِنَ القَيْرَوَانِ إِلَى فَاس.", 0.45),
        ("loss", "ثُمَّ فَقَدَتْ أَبَاهَا، وَزَوْجَهَا، وَأَخَاهَا... وَوَرِثَتْ مَالًا كَثِيرًا.", 0.5),
        ("choice", "كَانَ بِوُسْعِهَا أَنْ تَبْنِيَ قَصْرًا. لَكِنَّهَا اشْتَرَتْ أَرْضًا... وَبَنَتْ مَسْجِدًا.", 0.5),
        ("fast", "وَيُرْوَى أَنَّهَا صَامَتْ كُلَّ يَوْمٍ، حَتَّى اكْتَمَلَ البِنَاء.", 0.45),
        ("name", "وَسَمَّتْهُ: القَرَوِيِّين، نِسْبَةً إِلَى مَدِينَتِهَا الأُولَى.", 0.45),
        ("circles", "وَفِي ذَلِكَ المَسْجِدِ، اجْتَمَعَتْ حَلَقَاتُ العِلْمِ... حَتَّى صَارَ جَامِعَة.", 0.45),
        ("still", "وَبَعْدَ أَكْثَرَ مِنْ أَلْفٍ وَمِئَةِ عَامٍ، مَا زَالَ العِلْمُ يُدَرَّسُ فِيه.", 0.6),
        ("moral", "مَالٌ يُبْنَى بِهِ قَصْرٌ... يَزُول. وَمَالٌ يُبْنَى بِهِ عِلْمٌ... يَبْقَى بَعْدَ صَاحِبِهِ قُرُونًا.", 0.8),
    ],
}

ALL = {"wonder": WONDER, "foot": FOOT, "hist": HIST, "noor": NOOR}
