"""Procedural, copyright-free score + sound design per channel, mixed under the VO with ducking."""
import json, sys, subprocess
import numpy as np, soundfile as sf

SR = 48000
A = "/home/claude/studio/public/audio"
rng = np.random.default_rng(7)

def t_arr(d): return np.arange(int(d * SR)) / SR

def lp(x, cutoff):
    # one-pole low-pass, vectorised via scipy-free recursion in chunks
    a = np.exp(-2 * np.pi * cutoff / SR)
    y = np.empty_like(x); acc = 0.0
    for i in range(0, len(x), 4096):
        seg = x[i:i + 4096]
        out = np.empty_like(seg)
        for j, v in enumerate(seg):
            acc = (1 - a) * v + a * acc
            out[j] = acc
        y[i:i + 4096] = out
    return y

def lp_fast(x, cutoff):
    # FFT brickwall-ish low-pass with soft knee
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(len(x), 1 / SR)
    X *= 1 / (1 + (fr / cutoff) ** 4)
    return np.fft.irfft(X, len(x))

def bp_fast(x, lo, hi):
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(len(x), 1 / SR)
    X *= (1 / (1 + (lo / np.maximum(fr, 1)) ** 4)) * (1 / (1 + (fr / hi) ** 4))
    return np.fft.irfft(X, len(x))

def note(f): return 440 * 2 ** ((f - 69) / 12)

def pad(d, chords, chord_len, gain=0.12, bright=1800, detune=0.004):
    t = t_arr(d); out = np.zeros_like(t)
    for ci, ch in enumerate(chords * 50):
        s = ci * chord_len
        if s >= d: break
        e = min(d, s + chord_len + 1.5)
        idx = (t >= s) & (t < e); tt = t[idx] - s
        env = np.minimum(1, tt / 1.2) * np.minimum(1, np.maximum(0, (e - s - tt) / 1.5))
        for n in ch:
            for dt in (-detune, 0, detune):
                fr = note(n) * (1 + dt)
                out[idx] += env * (np.sin(2 * np.pi * fr * tt) * 0.6 + 0.4 * (2 * ((fr * tt) % 1) - 1) * 0.5)
    out = lp_fast(out, bright)
    lfo = 0.85 + 0.15 * np.sin(2 * np.pi * 0.07 * t)
    return out / (np.abs(out).max() + 1e-9) * gain * lfo

def thump(dur=0.18, f0=60, gain=0.6):
    t = t_arr(dur)
    return gain * np.sin(2 * np.pi * f0 * t * (1 + 1.5 * np.exp(-t * 30))) * np.exp(-t * 18)

def boom(dur=2.5, gain=0.7):
    t = t_arr(dur)
    s = np.sin(2 * np.pi * 42 * t * (1 + 2 * np.exp(-t * 8))) * np.exp(-t * 2.2)
    n = lp_fast(rng.standard_normal(len(t)), 300) * np.exp(-t * 4) * 0.5
    return gain * (s + n) / 1.3

def whoosh(dur=0.9, gain=0.25, hi=5000):
    t = t_arr(dur); n = rng.standard_normal(len(t))
    n = bp_fast(n, 300, hi)
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return gain * n / (np.abs(n).max() + 1e-9) * env

def wind(d, gain=0.08, lo=150, hi=900):
    t = t_arr(d); n = bp_fast(rng.standard_normal(len(t)), lo, hi)
    n /= np.abs(n).max() + 1e-9
    return gain * n * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * t) * np.sin(2 * np.pi * 0.037 * t + 1))

def buzz(dur, gain=0.18):
    t = t_arr(dur)
    gate = ((t % 1.0) < 0.45).astype(float)
    return gain * np.sign(np.sin(2 * np.pi * 155 * t)) * gate * 0.5 * (1 - np.exp(-t * 20))

def beep(dur=0.15, f=1000, gain=0.12):
    t = t_arr(dur); return gain * np.sin(2 * np.pi * f * t) * np.minimum(1, (dur - t) * 40)

def crowd(dur, gain=0.3):
    t = t_arr(dur); n = bp_fast(rng.standard_normal(len(t)), 250, 2500)
    n /= np.abs(n).max() + 1e-9
    env = np.minimum(1, t / 0.4) * np.exp(-np.maximum(0, t - 1.0) * 0.9)
    return gain * n * env

def place(buf, clip, at):
    i = int(at * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(clip)); buf[i:j] += clip[: j - i]

def word_t(sc, scene, word, nth=0):
    import re
    nrm = lambda s: re.sub(r"[^\w]", "", re.sub(r"[ً-ْٰ]", "", s.lower()))
    ws = [w for w in sc["words"] if w["s"] == scene and nrm(w["w"]) == nrm(word)]
    return ws[nth]["t0"] if len(ws) > nth else next(s["start"] for s in sc["scenes"] if s["id"] == scene)

def scene_t(sc, sid): return next(s["start"] for s in sc["scenes"] if s["id"] == sid)

LIB = "/home/claude/animated-videos-media/tools/sfx"
def music(name, trim_s, d, gain=0.22):
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", str(trim_s), "-i", f"{LIB}/{name}", "-ac", "1", "-ar", str(SR), f"{td}/m.wav"], check=True)
        m, _ = sf.read(f"{td}/m.wav", dtype="float32")
    n = int(d * SR)
    if len(m) < n: m = np.tile(m, n // len(m) + 1)
    m = m[:n].astype(np.float64)
    m /= np.sqrt(np.mean(m ** 2)) + 1e-9
    t = t_arr(d)[:n]
    fade = np.minimum(1, t / 0.8) * np.minimum(1, np.maximum(0, (d - t) / 1.8))
    return gain * 0.25 * m * fade

def build(key):
    sc = json.load(open(f"{A}/{key}_scenes.json"))
    d = sc["duration"] + 0.6
    vo, vsr = sf.read(f"{A}/{key}_vo.wav", dtype="float32")
    vo = np.interp(np.linspace(0, len(vo) - 1, int(len(vo) * SR / vsr)), np.arange(len(vo)), vo)
    n = int(d * SR); vo = np.pad(vo, (0, max(0, n - len(vo))))[:n]
    mus = np.zeros(n); sfx = np.zeros(n)
    starts = [s["start"] for s in sc["scenes"]][1:]

    if key == "wonder":
        mus += music("px_ambient-electronic-background-explainer.mp3", 3.0, d, 0.07)[:n]
        mus += np.sin(2 * np.pi * 55 * t_arr(d))[:n] * 0.03
        fs, fe = scene_t(sc, "figure"), scene_t(sc, "reveal")
        tt = fs
        while tt < fe + 0.5:
            bpm = 70 + 70 * min(1, (tt - fs) / (fe - fs))
            place(sfx, thump(), tt); place(sfx, thump(gain=0.4), tt + 0.22)
            tt += 60 / bpm
        for s in starts: place(sfx, whoosh(0.8, 0.12), s - 0.45)
        g0 = scene_t(sc, "glitch")
        for k in range(6): place(sfx, bp_fast(rng.standard_normal(int(0.05 * SR)), 2000, 8000) * 0.08, g0 + 0.77 * k)
        place(sfx, boom(1.8, 0.35), word_t(sc, "reveal", "sleep"))
    elif key == "foot":
        mus += music("px_piano.mp3", 0.5, d, 0.085)[:n]
        place(sfx, boom(2.0, 0.5), 0.05)
        place(sfx, crowd(4.0, 0.22), word_t(sc, "final", "smashed") + 0.3)
        place(sfx, thump(0.2, 80, 0.5), word_t(sc, "final", "smashed") + 0.2)
        place(sfx, buzz(2.5), word_t(sc, "call", "rang") - 0.1)
        place(sfx, boom(2.5, 0.55), scene_t(sc, "news") - 0.1)
        for k in range(5): place(sfx, beep(), scene_t(sc, "news") + 0.2 + k * 0.6)
        place(sfx, beep(1.6, 1000, 0.08), scene_t(sc, "news") + 3.2)
        for s in starts: place(sfx, whoosh(0.7, 0.1), s - 0.4)
        # music drops out for the phone-call beat, returns softer
        t = t_arr(d)[:n]
        cs, zs = scene_t(sc, "call"), scene_t(sc, "zanetti")
        mus *= np.where((t > cs) & (t < zs), 0.35, 1.0)
    elif key == "hist":
        t = t_arr(d)
        drone = (np.sin(2 * np.pi * note(38) * t) + 0.5 * np.sin(2 * np.pi * note(45) * t) + 0.3 * (2 * ((note(26) * t) % 1) - 1))
        mus += music("px_unsolved-story-documentary-music.mp3", 2.25, d, 0.075)[:n]
        sfx += wind(d, 0.045)[:n]
        place(sfx, boom(2.0, 0.45), word_t(sc, "hook", "arrowhead"))
        place(sfx, boom(2.5, 0.6), word_t(sc, "murder", "murdered"))
        place(sfx, boom(1.5, 0.35), word_t(sc, "xray", "flint"))
        place(sfx, whoosh(1.2, 0.08, 1500), word_t(sc, "xray", "behind") - 0.2)
        for s in starts: place(sfx, whoosh(1.0, 0.09, 3000), s - 0.5)
        ts, te = scene_t(sc, "theory"), scene_t(sc, "xray")
        place(sfx, wind(te - ts, 0.12, 300, 2500), ts)
    elif key == "noor":
        # no instrumental music: soft air + gentle transitions only
        sfx += wind(d, 0.035, 120, 600)[:n]
        for s in starts: place(sfx, whoosh(1.0, 0.05, 2500), s - 0.5)

    # duck music under voice
    env = np.abs(vo); k = int(0.25 * SR)
    env = np.convolve(env, np.ones(k) / k, mode="same")
    duck = 1 - 0.6 * np.clip(env / (env.max() * 0.15 + 1e-9), 0, 1)
    mix = vo * 1.0 + mus * duck + sfx
    sf.write(f"/tmp/{key}_mix.wav", mix.astype(np.float32) / max(1, np.abs(mix).max()), SR)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", f"/tmp/{key}_mix.wav", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-c:a", "aac", "-b:a", "192k", f"/home/claude/out/{key}_mix.m4a"], check=True)
    print(key, "mixed")

if __name__ == "__main__":
    import os; os.makedirs("/home/claude/out", exist_ok=True)
    for k in sys.argv[1:]: build(k)
