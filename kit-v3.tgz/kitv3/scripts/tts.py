import sys, json, wave, re, difflib
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/scripts")
from lines import ALL

SR = 24000
M = "/home/claude/models"
OUT = "/home/claude/studio/public/audio"

def resample(x, sr_in, sr_out):
    if sr_in == sr_out:
        return x
    n = int(len(x) * sr_out / sr_in)
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)

def trim(x, thr=0.004):
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(0.03 * SR)); b = min(len(x), idx[-1] + int(0.06 * SR))
    return x[a:b]

def synth_kokoro(cfg):
    from kokoro_onnx import Kokoro
    k = Kokoro(f"{M}/kokoro.onnx", f"{M}/voices.bin")
    outs = []
    for sid, text, pause in cfg["lines"]:
        a, sr = k.create(text, voice=cfg["voice"], speed=cfg["speed"], lang=cfg["lang"])
        outs.append((sid, text, pause, trim(resample(np.asarray(a, np.float32), sr, SR))))
    return outs

def synth_piper(cfg):
    from piper import PiperVoice, SynthesisConfig
    v = PiperVoice.load(f"{M}/ar.onnx")
    outs = []
    for sid, text, pause in cfg["lines"]:
        chunks = [c.audio_float_array for c in v.synthesize(text, syn_config=SynthesisConfig(length_scale=0.84, noise_scale=0.6, noise_w_scale=0.7))]
        a = np.concatenate(chunks).astype(np.float32)
        outs.append((sid, text, pause, trim(resample(a, v.config.sample_rate, SR))))
    return outs

def build(key):
    cfg = ALL[key]
    outs = synth_kokoro(cfg) if cfg["engine"] == "kokoro" else synth_piper(cfg)
    lead = int(0.15 * SR)
    buf = [np.zeros(lead, np.float32)]
    t = lead / SR
    scenes = []
    for sid, text, pause, a in outs:
        start = t
        buf.append(a); t += len(a) / SR
        end = t
        buf.append(np.zeros(int(pause * SR), np.float32)); t += pause
        scenes.append({"id": sid, "text": text, "start": round(start, 3), "end": round(end, 3), "next": round(t, 3)})
    full = np.concatenate(buf)
    full = full / max(1e-6, np.abs(full).max()) * 0.9
    sf.write(f"{OUT}/{key}_vo.wav", full, SR)
    json.dump({"duration": round(t, 3), "scenes": scenes}, open(f"{OUT}/{key}_scenes.json", "w"), ensure_ascii=False, indent=1)
    print(key, round(t, 2), "s")

if __name__ == "__main__":
    import os; os.makedirs(OUT, exist_ok=True)
    for k in sys.argv[1:]:
        build(k)
