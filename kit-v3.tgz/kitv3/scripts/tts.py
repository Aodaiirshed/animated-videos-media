import sys, json, wave, re, difflib
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/scripts")
from lines import ALL

SR = 24000
M = "/home/claude/models"
OUT = "/home/claude/studio/public/audio"

def resample(x, sr_in, sr_out):
    if sr_in == sr_out:
        return x
    n = int(len(x) * sr_out / sr_in)
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)

def trim(x, thr=0.004):
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(0.03 * SR)); b = min(len(x), idx[-1] + int(0.06 * SR))
    return x[a:b]

def synth_kokoro(cfg):
    from kokoro_onnx import Kokoro
    k = Kokoro(f"{M}/kokoro.onnx", f"{M}/voices.bin")
    outs = []
    for sid, text, pause in cfg["lines"]:
        a, sr = k.create(text, voice=blend(k, cfg["voice"]), speed=cfg["speed"], lang=cfg["lang"])
        outs.append((sid, text, pause, trim(resample(np.asarray(a, np.float32), sr, SR))))
    return outs

def blend(k, name):
    if "," not in name and ":" not in name:
        return name
    st = None
    for part in name.split(","):
        vn, w = part.split(":")
        v = k.get_voice_style(vn.strip()) * float(w)
        st = v if st is None else st + v
    return st

def synth_edge(cfg):
    import subprocess, tempfile, os
    outs = []
    for sid, text, pause in cfg["lines"]:
        with tempfile.TemporaryDirectory() as td:
            mp3 = f"{td}/a.mp3"; wav = f"{td}/a.wav"
            for attempt in range(3):
                r = subprocess.run(["edge-tts", "--proxy", os.environ.get("HTTPS_PROXY", ""), "--voice", cfg["voice"], f"--rate={cfg.get('rate', '+0%')}", "--text", text, "--write-media", mp3], capture_output=True)
                if r.returncode == 0 and os.path.getsize(mp3) > 1000: break
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp3, "-ar", str(SR), "-ac", "1", wav], check=True)
            a, sr = sf.read(wav, dtype="float32")
        outs.append((sid, text, pause, trim(a)))
    return outs

def synth_piper(cfg):
    from piper import PiperVoice, SynthesisConfig
    v = PiperVoice.load(f"{M}/ar.onnx")
    outs = []
    for sid, text, pause in cfg["lines"]:
        chunks = [c.audio_float_array for c in v.synthesize(text, syn_config=SynthesisConfig(length_scale=0.84, noise_scale=0.6, noise_w_scale=0.7))]
        a = np.concatenate(chunks).astype(np.float32)
        outs.append((sid, text, pause, trim(resample(a, v.config.sample_rate, SR))))
    return outs

def build(key):
    cfg = ALL[key]
    outs = {"kokoro": synth_kokoro, "piper": synth_piper, "edge": synth_edge}[cfg["engine"]](cfg)
    lead = int(0.15 * SR)
    buf = [np.zeros(lead, np.float32)]
    t = lead / SR
    scenes = []
    for sid, text, pause, a in outs:
        start = t
        buf.append(a); t += len(a) / SR
        end = t
        buf.append(np.zeros(int(pause * SR), np.float32)); t += pause
        scenes.append({"id": sid, "text": text, "start": round(start, 3), "end": round(end, 3), "next": round(t, 3)})
    full = np.concatenate(buf)
    full = full / max(1e-6, np.abs(full).max()) * 0.9
    sf.write(f"{OUT}/{key}_vo.wav", full, SR)
    json.dump({"duration": round(t, 3), "scenes": scenes}, open(f"{OUT}/{key}_scenes.json", "w"), ensure_ascii=False, indent=1)
    print(key, round(t, 2), "s")

if __name__ == "__main__":
    import os; os.makedirs(OUT, exist_ok=True)
    for k in sys.argv[1:]:
        build(k)
