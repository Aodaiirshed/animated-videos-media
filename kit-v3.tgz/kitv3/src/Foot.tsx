import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {Cam, Captions, clamp, FontFaces, Grain, inOut, lerp, localF, Particles, Scenes, Timing, Vignette, W, H, wordTime, FPS} from './lib';
import T from '../public/audio/foot_scenes.json';

const timing = T as unknown as Timing;
const C = {bg: '#07080a', gold: '#f2c14e', yellow: '#ffd21a', green: '#0b8f45', paper: '#e9dfc8', red: '#d6342c', night: '#0b1420'};
const wf = (s: string, w: string, n = 0) => localF(timing, s, wordTime(timing, s, w, n));

/** Night stadium with floodlights, layered for parallax. */
const Stadium: React.FC<{f: number; warm?: number; flash?: boolean}> = ({f, warm = 1, flash = true}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#020409" /><stop offset="100%" stopColor="#13233a" /></linearGradient>
      <radialGradient id="flood"><stop offset="0%" stopColor="#fff6dc" /><stop offset="40%" stopColor="#ffe9a8" stopOpacity={0.5} /><stop offset="100%" stopColor="#ffe9a8" stopOpacity={0} /></radialGradient>
      <linearGradient id="pitch" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0d4a26" /><stop offset="100%" stopColor="#07210f" /></linearGradient>
    </defs>
    <rect width={W} height={H} fill="url(#sky)" />
    {[150, 930].map((x, i) => (
      <g key={i}>
        <circle cx={x} cy={140} r={240} fill="url(#flood)" opacity={0.5 * warm} />
        <rect x={x - 60} y={115} width={120} height={50} fill="#fffbe8" opacity={0.95} rx={6} />
      </g>
    ))}
    {/* stands with crowd dots */}
    <path d="M0 620 L1080 620 L1080 960 L0 960 Z" fill="#0c1626" />
    {new Array(260).fill(0).map((_, i) => {
      const x = (i * 37) % 1080 + random('cx' + i) * 20, y = 650 + Math.floor(i / 29) * 34 + random('cy' + i) * 10;
      const fl = flash && random('fl' + i + Math.floor(f / 4)) > 0.985;
      return <circle key={i} cx={x} cy={y} r={fl ? 5 : 3} fill={fl ? '#fff' : i % 3 ? '#2a3b58' : C.yellow} opacity={fl ? 1 : 0.6} />;
    })}
    <path d="M-200 960 L1280 960 L1080 1920 L0 1920 Z" fill="url(#pitch)" />
    {[0, 1, 2, 3, 4, 5].map((i) => <path key={i} d={`M${-200 + i * 300} 960 L${-400 + i * 380} 1920`} stroke="#0f5a2e" strokeWidth={60} opacity={0.25} />)}
    <path d="M140 960 L940 960" stroke="#e8efe6" strokeWidth={4} opacity={0.5} />
  </svg>
);

/** Footballer silhouette, backlit, generic (no number, no badge). */
const Player: React.FC<{x: number; y: number; s?: number; pose?: 'stand' | 'point' | 'strike'; shirt?: string; f: number; back?: boolean}> = ({x, y, s = 1, pose = 'stand', shirt = C.yellow, f}) => {
  const armR = pose === 'point' ? 'M52 62 Q70 0 78 -90' : pose === 'strike' ? 'M52 62 Q85 100 110 140' : 'M52 62 Q62 130 60 205';
  const armL = pose === 'strike' ? 'M-52 62 Q-95 50 -130 20' : 'M-52 62 Q-62 130 -60 205';
  const legR = pose === 'strike' ? `M22 240 Q60 300 ${105 + Math.sin(f / 4) * 8} 360` : 'M22 240 Q28 330 30 440';
  const legL = pose === 'strike' ? 'M-22 240 Q-30 330 -40 440' : 'M-22 240 Q-28 330 -30 440';
  const rim = 'rgba(255,214,120,0.9)';
  return (
    <svg width={W} height={H} style={{position: 'absolute'}}>
      <g transform={`translate(${x},${y}) scale(${s})`} style={{filter: 'drop-shadow(0 0 22px rgba(255,214,120,0.45))'}}>
        <g stroke={rim} strokeWidth={3}>
          {[armR, armL].map((p, i) => <path key={i} d={p} stroke={rim} strokeWidth={36} strokeLinecap="round" fill="none" />)}
          {[legR, legL].map((p, i) => <path key={'l' + i} d={p} stroke={rim} strokeWidth={40} strokeLinecap="round" fill="none" />)}
        </g>
        {[armR, armL].map((p, i) => <path key={i} d={p} stroke="#0b0b0d" strokeWidth={30} strokeLinecap="round" fill="none" />)}
        {[legR, legL].map((p, i) => <path key={'k' + i} d={p} stroke="#0b0b0d" strokeWidth={34} strokeLinecap="round" fill="none" />)}
        <path d="M-58 50 Q-60 30 -30 22 L30 22 Q60 30 58 50 L50 250 L-50 250 Z" fill="#0b0b0d" stroke={rim} strokeWidth={3} />
        <path d="M-58 50 Q-60 30 -30 22 L30 22 Q60 30 58 50 L54 170 L-54 170 Z" fill={shirt} opacity={0.22} />
        <rect x={-14} y={0} width={28} height={30} fill="#0b0b0d" />
        <ellipse cx={0} cy={-18} rx={34} ry={38} fill="#0b0b0d" stroke={rim} strokeWidth={3} />
      </g>
    </svg>
  );
};

const Headline: React.FC<{text: string; sub: string; y: number; inF: number; f: number; rot?: number}> = ({text, sub, y, inF, f, rot = -3}) => (
  <div style={{position: 'absolute', left: 80, right: 80, top: y, background: C.paper, padding: '26px 34px', boxShadow: '0 30px 60px rgba(0,0,0,0.6)', rotate: `${rot}deg`, opacity: lerp(f, [inF, inF + 8], [0, 1]), scale: String(lerp(f, [inF, inF + 10], [1.4, 1]))}}>
    <div style={{fontFamily: 'Oswald', fontSize: 26, letterSpacing: 6, color: '#3a3226', borderBottom: '3px solid #3a3226', paddingBottom: 8}}>{sub}</div>
    <div style={{fontFamily: 'Bebas', fontSize: 120, lineHeight: 1, color: '#151210', marginTop: 12}}>{text}</div>
  </div>
);

const Stamp: React.FC<{text: string; x: number; y: number; inF: number; f: number; color?: string; size?: number}> = ({text, x, y, inF, f, color = C.gold, size = 64}) => (
  <div style={{position: 'absolute', left: x, top: y, fontFamily: 'Bebas', fontSize: size, color, letterSpacing: 4, opacity: lerp(f, [inF, inF + 6], [0, 1]), translate: `0px ${lerp(f, [inF, inF + 10], [30, 0])}px`, textShadow: '0 4px 20px rgba(0,0,0,0.8)'}}>{text}</div>
);

const Hook: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const aug = wf('hook', 'august');
  const dark = lerp(f, [aug - 4, aug + 10], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <AbsoluteFill style={{opacity: 1 - dark * 0.85}}>
        <Cam d={d} from={1.1} to={1.0}>
          <Stadium f={f} />
          <Player x={540} y={1080} s={1.5} pose="point" f={f} />
        </Cam>
      </AbsoluteFill>
      <Stamp text="JULY 2004" x={80} y={210} inF={0} f={f} size={90} />
      <Headline text="THE NEXT RONALDO" sub="BRAZIL · COPA AMÉRICA" y={360} inF={wf('hook', 'ronaldo') - 6} f={f} />
      {/* phone in the dark */}
      <AbsoluteFill style={{opacity: dark}}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 62%, rgba(80,120,200,0.25), rgba(0,0,0,0.95) 55%)'}} />
        <div style={{position: 'absolute', left: 390, top: 1000, width: 300, height: 560, borderRadius: 40, background: '#0d0f14', border: '6px solid #2a2e38', rotate: `${Math.sin(f * 2.2) * 2 * dark}deg`, boxShadow: '0 0 120px rgba(120,170,255,0.45)'}}>
          <div style={{position: 'absolute', inset: 24, borderRadius: 24, background: 'linear-gradient(#1b3a6b,#0b1730)', opacity: 0.6 + 0.4 * Math.sin(f / 3)}} />
        </div>
        <Stamp text="AUGUST 2004" x={80} y={210} inF={aug} f={f} color="#9fb6d8" size={90} />
      </AbsoluteFill>
      <Vignette />
    </AbsoluteFill>
  );
};

const Crown: React.FC<{x: number; y: number; s: number; crack?: number; rot?: number}> = ({x, y, s, crack = 0, rot = 0}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} style={{filter: 'drop-shadow(0 0 30px rgba(242,193,78,0.6))'}}>
      <path d="M-120 60 L-140 -70 L-70 -10 L0 -100 L70 -10 L140 -70 L120 60 Z" fill={C.gold} />
      <rect x={-125} y={55} width={250} height={36} fill="#c9952c" />
      {[-140, 0, 140].map((cx, i) => <circle key={i} cx={cx} cy={i === 1 ? -108 : -78} r={14} fill="#fff3c4" />)}
      {crack > 0 && <path d={`M0 -100 L-12 -40 L14 0 L-10 50 L8 91`} stroke="#000" strokeWidth={8} fill="none" strokeDasharray="300" strokeDashoffset={300 - crack * 300} />}
    </g>
  </svg>
);

const Who: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const emp = wf('who', 'emperor');
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Cam d={d} from={1.0} to={1.12} y={[0, -40]}>
        {/* tunnel */}
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <defs><radialGradient id="tun" cx="50%" cy="55%"><stop offset="0%" stopColor="#fff1c8" /><stop offset="25%" stopColor="#c99a3c" stopOpacity={0.6} /><stop offset="100%" stopColor="#000" stopOpacity={0} /></radialGradient></defs>
          {[0, 1, 2, 3, 4, 5].map((i) => <rect key={i} x={140 + i * 50} y={300 + i * 70} width={800 - i * 100} height={1300 - i * 140} fill="none" stroke="#2a2318" strokeWidth={30} opacity={0.8} />)}
          <ellipse cx={540} cy={1050} rx={300} ry={420} fill="url(#tun)" opacity={0.9} />
        </svg>
        <Player x={540} y={900} s={1.6} f={f} />
      </Cam>
      <div style={{position: 'absolute', top: 260, width: '100%', textAlign: 'center', fontFamily: 'Bebas', fontSize: 210, color: '#fff', letterSpacing: 10, opacity: lerp(f, [0, 6], [0, 1]), scale: String(lerp(f, [0, 12], [1.2, 1])), textShadow: '0 10px 40px #000'}}>ADRIANO</div>
      <Crown x={540} y={240} s={lerp(f, [emp - 4, emp + 8], [0, 0.55])} />
      <Stamp text="“THE EMPEROR”" x={300} y={520} inF={emp - 2} f={f} size={76} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Final: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const turn = wf('final', 'turned');
  const smash = wf('final', 'smashed');
  const pens = wf('final', 'penalties');
  const t = lerp(f, [smash, smash + 12], [0, 1], inOut);
  const bx = interpolate(t, [0, 1], [610, 860]), by = interpolate(t, [0, 0.5, 1], [1500, 1180, 1120]);
  const goal = f > smash + 12;
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Cam d={d} from={1.05} to={1.18} x={[0, -60]}>
        <Stadium f={f} flash={goal} />
        {/* goal frame */}
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <rect x={760} y={1060} width={260} height={150} fill="none" stroke="#f4f4f4" strokeWidth={10} />
          {[...Array(8)].map((_, i) => <line key={i} x1={760 + i * 32} y1={1060} x2={760 + i * 32} y2={1210} stroke="#fff" opacity={0.25 + (goal ? Math.sin(f) * 0.15 : 0)} />)}
          <circle cx={bx} cy={by} r={22} fill="#fff" opacity={f > smash - 2 ? 1 : 0} />
          {f > smash && f < smash + 14 && <line x1={610} y1={1500} x2={bx} y2={by} stroke="#fff" strokeWidth={8} opacity={0.4} />}
        </svg>
        <Player x={lerp(f, [0, turn], [420, 520])} y={1240} s={1.15} pose={f > turn ? 'strike' : 'stand'} f={f} />
      </Cam>
      {goal && <AbsoluteFill style={{background: '#fff', opacity: lerp(f, [smash + 12, smash + 20], [0.6, 0])}} />}
      {/* scoreboard */}
      <div style={{position: 'absolute', left: 80, top: 220, background: 'rgba(0,0,0,0.75)', border: `3px solid ${C.gold}`, padding: '16px 28px', fontFamily: 'Oswald', color: '#fff'}}>
        <div style={{fontSize: 26, letterSpacing: 5, color: C.gold}}>COPA AMÉRICA FINAL · LIMA</div>
        <div style={{fontFamily: 'Bebas', fontSize: 92, letterSpacing: 3}}>ARGENTINA {goal ? '2–2' : '2–1'} BRAZIL</div>
        <div style={{fontSize: 34, color: goal ? C.yellow : '#aaa'}}>{goal ? "ADRIANO 90+3'" : "90+3'"}</div>
      </div>
      <Stamp text="PENALTIES: BRAZIL WIN 4–2" x={80} y={560} inF={pens - 4} f={f} color={C.yellow} size={70} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Boot: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const seven = wf('boot', 'seven');
  const father = wf('boot', 'father');
  const n = Math.round(lerp(f, [seven - 4, seven + 10], [0, 7]));
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #3b2a0b, #07080a 65%)'}}>
      <Particles n={70} color={C.gold} seed="gold" size={[2, 6]} speed={0.5} opacity={0.7} />
      <Cam d={d} from={1.0} to={1.1}>
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <g transform={`translate(540,860) rotate(${Math.sin(f / 20) * 6}) scale(${1 + Math.sin(f / 30) * 0.02})`} style={{filter: 'drop-shadow(0 0 50px rgba(242,193,78,0.8))'}}>
            <path d="M-150 -170 L-20 -170 L-10 40 Q60 50 170 80 Q220 100 210 150 L-170 150 Q-190 60 -150 -170 Z" fill={C.gold} />
            <path d="M-150 -170 L-20 -170 L-10 40 Q60 50 170 80" stroke="#fff3c4" strokeWidth={8} fill="none" opacity={0.7} />
            <rect x={-190} y={150} width={410} height={40} fill="#b8862a" />
            {[0, 1, 2, 3].map((i) => <line key={i} x1={-120 + i * 25} y1={-120 + i * 40} x2={-40 + i * 10} y2={-120 + i * 40} stroke="#8a6420" strokeWidth={8} />)}
          </g>
        </svg>
      </Cam>
      <div style={{position: 'absolute', top: 220, width: '100%', textAlign: 'center', fontFamily: 'Bebas', color: '#fff'}}>
        <div style={{fontSize: 230, lineHeight: 1, color: C.gold, textShadow: '0 0 50px rgba(242,193,78,0.6)'}}>{n}</div>
        <div style={{fontSize: 70, letterSpacing: 8}}>GOALS · GOLDEN BOOT</div>
      </div>
      <Stamp text="DEDICATED TO: HIS FATHER, ALMIR" x={110} y={1180} inF={father - 6} f={f} color="#fff" size={62} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Room: React.FC<{f: number; ring: number; screen?: number}> = ({f, ring, screen = 1}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <defs><radialGradient id="glow"><stop offset="0%" stopColor="#7fb2ff" stopOpacity={0.6} /><stop offset="100%" stopColor="#7fb2ff" stopOpacity={0} /></radialGradient></defs>
    <rect width={W} height={H} fill="#06080d" />
    <rect x={620} y={260} width={360} height={520} fill="#0d1726" />
    <rect x={795} y={260} width={10} height={520} fill="#06080d" />
    <path d="M0 1180 L1080 1180 L1080 1920 L0 1920 Z" fill="#0a0c12" />
    {/* bedside table */}
    <rect x={180} y={1180} width={520} height={60} fill="#1a1510" />
    <rect x={210} y={1240} width={460} height={300} fill="#120e0a" />
    <circle cx={440} cy={1150} r={260 * screen} fill="url(#glow)" opacity={ring} />
    {/* phone lying on table */}
    <g transform={`translate(${440 + Math.sin(f * 2.4) * 5 * ring},1160) rotate(${Math.sin(f * 2.1) * 2 * ring})`}>
      <rect x={-110} y={-26} width={220} height={40} rx={10} fill="#111" stroke="#333" strokeWidth={3} />
      <rect x={-100} y={-24} width={200} height={8} fill="#8ec1ff" opacity={0.5 + 0.5 * ring * screen} />
    </g>
    {ring > 0 && [1, 2, 3].map((i) => <path key={i} d={`M${560 + i * 30} ${1110 - i * 10} q20 40 0 80`} stroke="#8ec1ff" strokeWidth={5} fill="none" opacity={((Math.sin(f / 3 - i) + 1) / 2) * ring} />)}
  </svg>
);

const Call: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const rang = wf('call', 'rang');
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.25} origin="40% 62%">
        <Room f={f} ring={lerp(f, [rang - 4, rang + 2], [0, 1])} />
      </Cam>
      <Stamp text="AUGUST 2004" x={80} y={220} inF={0} f={f} color="#9fb6d8" size={80} />
      <Stamp text="INTER · PRE-SEASON CAMP" x={80} y={310} inF={6} f={f} color="#ccc" size={52} />
      <Vignette strength={0.85} />
    </AbsoluteFill>
  );
};

const News: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const heart = wf('news', 'heart');
  const flat = lerp(f, [heart, heart + 18], [1, 0]);
  const pts: string[] = [];
  for (let x = 0; x <= W; x += 6) {
    const ph = ((x + f * 10) % 300) / 300;
    let v = 0;
    if (ph > 0.4 && ph < 0.44) v = 110; else if (ph > 0.44 && ph < 0.48) v = -50;
    const fade = x > 540 + (1 - flat) * -540 ? flat : 1;
    pts.push(`${x},${1000 - v * fade * flat}`);
  }
  return (
    <AbsoluteFill style={{background: '#040506'}}>
      <svg width={W} height={H} style={{position: 'absolute'}}>
        <polyline points={pts.join(' ')} fill="none" stroke={flat > 0.05 ? '#e8e8e8' : C.red} strokeWidth={6} style={{filter: 'drop-shadow(0 0 12px rgba(255,255,255,0.5))'}} />
      </svg>
      <div style={{position: 'absolute', top: 640, width: '100%', textAlign: 'center', fontFamily: 'Bebas', fontSize: 150, color: '#fff', opacity: lerp(f, [4, 14], [0, 1]), letterSpacing: 8}}>ALMIR</div>
      <div style={{position: 'absolute', top: 1140, width: '100%', textAlign: 'center', fontFamily: 'Oswald', fontSize: 46, color: '#aaa', letterSpacing: 10, opacity: lerp(f, [wf('news', 'forty') - 4, wf('news', 'forty') + 6], [0, 1])}}>AGED 44</div>
      <Vignette />
    </AbsoluteFill>
  );
};

const Quote: React.FC<{q: string; by: string; f: number; inF: number; y?: number}> = ({q, by, f, inF, y = 260}) => (
  <div style={{position: 'absolute', left: 80, right: 80, top: y, opacity: lerp(f, [inF, inF + 10], [0, 1]), translate: `0px ${lerp(f, [inF, inF + 14], [40, 0])}px`}}>
    <div style={{fontFamily: 'Bebas', fontSize: 200, lineHeight: 0.6, color: C.gold}}>“</div>
    <div style={{fontFamily: 'Oswald', fontWeight: 500, fontSize: 64, lineHeight: 1.15, color: '#fff'}}>{q}</div>
    <div style={{fontFamily: 'Oswald', fontSize: 34, letterSpacing: 6, color: C.gold, marginTop: 20}}>— {by}</div>
  </div>
);

const Zanetti: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.15} to={1.05}>
        <Room f={f} ring={0} />
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <rect x={720} y={760} width={260} height={420} fill="#e9c27a" opacity={0.18} />
          <g transform="translate(850,860)">
            <circle cx={0} cy={0} r={34} fill="#000" />
            <path d="M-55 45 Q0 25 55 45 L60 330 L-60 330 Z" fill="#000" />
          </g>
        </svg>
      </Cam>
      <Quote q="He threw the phone down and started screaming." by="JAVIER ZANETTI, INTER CAPTAIN" f={f} inF={wf('zanetti', 'threw') - 6} />
      <Vignette strength={0.85} />
    </AbsoluteFill>
  );
};

const Sky: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const years = wf('sky', 'years');
  const dark = lerp(f, [years - 6, years + 14], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <AbsoluteFill style={{opacity: 1 - dark * 0.9}}>
        <Cam d={d} from={1.0} to={1.1}>
          <Stadium f={f} />
          <Player x={540} y={1050} s={1.5} pose="point" shirt="#1a2a5a" f={f} />
        </Cam>
      </AbsoluteFill>
      <AbsoluteFill style={{opacity: dark}}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 70%, #2a1d0a, #000 60%)'}} />
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <path d="M470 1050 L610 1050 L590 1380 Q540 1400 490 1380 Z" fill="none" stroke={C.gold} strokeWidth={6} opacity={0.8} />
          <path d={`M484 ${1200 + Math.sin(f / 10) * 4} L596 ${1200 + Math.sin(f / 10 + 1) * 4} L590 1380 Q540 1400 490 1380 Z`} fill={C.gold} opacity={0.35} />
        </svg>
        <Quote q="I only felt happy when I drank." by="ADRIANO, 2017 INTERVIEW" f={f} inF={wf('sky', 'happy') - 10} />
      </AbsoluteFill>
      <Vignette />
    </AbsoluteFill>
  );
};

const Fall: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const fallT = lerp(f, [0, d * 0.75], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 70%, #10200f, #000 70%)'}}>
      <Particles n={40} color="#fff" seed="dustf" size={[1, 3]} speed={0.3} opacity={0.4} />
      <Crown x={540} y={interpolate(fallT, [0, 1], [500, 1150])} s={0.9} rot={interpolate(fallT, [0, 1], [0, 28])} crack={lerp(f, [d * 0.7, d * 0.85], [0, 1])} />
      <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', fontFamily: 'Bebas', color: '#fff', fontSize: 100, letterSpacing: 4, lineHeight: 1.05}}>
        <div style={{opacity: lerp(f, [0, 10], [0, 1])}}>THE TALENT NEVER LEFT.</div>
        <div style={{opacity: lerp(f, [wf('fall', 'man') - 4, wf('fall', 'man') + 8], [0, 1]), color: C.gold}}>HIS FATHER DID.</div>
      </div>
      <Vignette />
    </AbsoluteFill>
  );
};

const Cta: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <div style={{position: 'absolute', top: 700, width: '100%', textAlign: 'center', fontFamily: 'Bebas', color: '#fff', fontSize: 150, lineHeight: 0.95, letterSpacing: 6, scale: String(lerp(f, [0, 10], [1.3, 1])), opacity: lerp(f, [0, 6], [0, 1])}}>
        SECRET<br /><span style={{color: C.gold}}>FOOT</span> FILES
      </div>
      <div style={{position: 'absolute', top: 1060, width: '100%', textAlign: 'center', fontFamily: 'Oswald', fontSize: 40, letterSpacing: 10, color: '#bbb'}}>THE STORIES NOBODY TELLS</div>
    </AbsoluteFill>
  );
};

export const FootVideo: React.FC = () => (
  <AbsoluteFill style={{background: C.bg}}>
    <FontFaces />
    <Scenes timing={timing} map={{hook: Hook, who: Who, final: Final, boot: Boot, call: Call, news: News, zanetti: Zanetti, sky: Sky, fall: Fall, cta: Cta}} />
    <Captions words={timing.words} top={1400} active="#ffffff" inactive="#8a8a8a" maxWords={3} emph={['ronaldo', 'adriano', 'emperor', 'equaliser', 'father', 'almir', 'screaming', 'drank']} emphColor={C.gold}
      style={{fontFamily: 'Bebas', fontSize: 104, letterSpacing: 2, lineHeight: 1, textShadow: '0 5px 0 #000, 0 0 20px rgba(0,0,0,0.9)'}} />
    <Grain opacity={0.1} />
  </AbsoluteFill>
);
export const footFrames = Math.ceil(timing.duration * FPS);
