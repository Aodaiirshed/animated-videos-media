import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {Cam, Captions, FontFaces, Grain, inOut, lerp, localF, Particles, Scenes, Timing, Vignette, W, H, wordTime, FPS} from './lib';
import T from '../public/audio/hist_scenes.json';

const timing = T as unknown as Timing;
const C = {bg: '#0b0805', amber: '#e0a84a', ice: '#a9d3ea', ivory: '#efe6d2', blood: '#b3261e', fog: '#8a8478', copper: '#c06a2b'};
const wf = (s: string, w: string, n = 0) => localF(timing, s, wordTime(timing, s, w, n));

const Title: React.FC<{text: string; sub?: string; y: number; f: number; inF?: number; color?: string; size?: number}> = ({text, sub, y, f, inF = 0, color = C.ivory, size = 92}) => (
  <div style={{position: 'absolute', top: y, width: '100%', textAlign: 'center', opacity: lerp(f, [inF, inF + 12], [0, 1]), letterSpacing: lerp(f, [inF, inF + 30], [18, 6])}}>
    {sub && <div style={{fontFamily: 'Cinzel', fontSize: 30, color: C.amber, letterSpacing: 10, marginBottom: 10}}>{sub}</div>}
    <div style={{fontFamily: 'Cinzel', fontWeight: 700, fontSize: size, color, lineHeight: 1.05, textShadow: '0 6px 30px rgba(0,0,0,0.9)'}}>{text}</div>
  </div>
);

/** Layered Alps; offset gives parallax per layer. */
const Alps: React.FC<{f: number; p: number; storm?: number; tint?: string}> = ({f, p, storm = 0, tint = '#1b2430'}) => {
  const layers = [
    {y: 700, amp: 260, c: '#2b3646', speed: 0.2},
    {y: 900, amp: 200, c: '#1f2834', speed: 0.45},
    {y: 1100, amp: 160, c: '#151c25', speed: 0.8},
  ];
  return (
    <svg width={W} height={H} style={{position: 'absolute'}}>
      <defs>
        <linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={storm ? '#1c1f24' : '#0d1420'} /><stop offset="100%" stopColor={storm ? '#4a4c50' : tint} /></linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#hsky)" />
      {layers.map((l, i) => {
        const off = p * 200 * l.speed;
        let d = `M${-300 - off} ${H}`;
        let px = -300 - off, py = l.y;
        for (let x = -300; x <= W + 300; x += 120) {
          const yy = l.y - (random(`m${i}-${Math.floor((x + 300) / 120)}`) * l.amp);
          const cx = x - off;
          d += ` L${cx} ${yy}`;
          px = cx; py = yy;
        }
        d += ` L${W + 300 - off} ${H} Z`;
        let snow = `M${-300 - off} ${l.y}`;
        return (
          <g key={i}>
            <path d={d} fill={l.c} />
            <path d={d} fill="#dfe9f2" opacity={0.08 + i * 0.03} transform={`translate(0,${20 + i * 10})`} />
          </g>
        );
      })}
      {/* glacier field */}
      <path d={`M0 1350 Q540 ${1290 + Math.sin(f / 40) * 6} 1080 1350 L1080 1920 L0 1920 Z`} fill="#cfe3ef" opacity={0.85} />
      <path d="M0 1350 Q540 1290 1080 1350" stroke="#fff" strokeWidth={4} opacity={0.6} fill="none" />
    </svg>
  );
};

const Hiker: React.FC<{x: number; y: number; s: number; f: number; phase?: number}> = ({x, y, s, f, phase = 0}) => {
  const st = Math.sin(f / 6 + phase) * 14;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <circle cx={0} cy={-150} r={16} fill="#0b0d10" />
      <rect x={-18} y={-132} width={36} height={70} rx={10} fill="#0b0d10" />
      <rect x={-30} y={-130} width={22} height={50} rx={6} fill="#20262e" />
      <line x1={-6} y1={-64} x2={-6 - st} y2={0} stroke="#0b0d10" strokeWidth={13} strokeLinecap="round" />
      <line x1={6} y1={-64} x2={6 + st} y2={0} stroke="#0b0d10" strokeWidth={13} strokeLinecap="round" />
      <line x1={14} y1={-120} x2={40} y2={-40 + st} stroke="#0b0d10" strokeWidth={5} />
    </g>
  );
};

/** X-ray of torso from behind, arrowhead in left shoulder (viewer's left). */
const XRay: React.FC<{f: number; scan: number; reveal: number; traj?: number}> = ({f, scan, reveal, traj = 0}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <defs>
      <radialGradient id="xg"><stop offset="0%" stopColor="#bfe6ff" stopOpacity={0.35} /><stop offset="100%" stopColor="#bfe6ff" stopOpacity={0} /></radialGradient>
      <filter id="xb"><feGaussianBlur stdDeviation="2" /></filter>
      <clipPath id="scanclip"><rect x={0} y={0} width={W} height={300 + scan * 1300} /></clipPath>
    </defs>
    <rect width={W} height={H} fill="#03070c" />
    <ellipse cx={540} cy={1000} rx={480} ry={700} fill="url(#xg)" />
    <g clipPath="url(#scanclip)" filter="url(#xb)" stroke="#d8f0ff" fill="none" opacity={0.9}>
      {/* spine */}
      {new Array(14).fill(0).map((_, i) => <rect key={i} x={515} y={480 + i * 62} width={50} height={46} rx={10} strokeWidth={5} />)}
      {/* ribs */}
      {new Array(10).fill(0).map((_, i) => (
        <g key={i} strokeWidth={7} opacity={0.75}>
          <path d={`M515 ${540 + i * 62} Q${330 - i * 4} ${520 + i * 66} ${300 + i * 6} ${640 + i * 70}`} />
          <path d={`M565 ${540 + i * 62} Q${750 + i * 4} ${520 + i * 66} ${780 - i * 6} ${640 + i * 70}`} />
        </g>
      ))}
      {/* scapulae */}
      <path d="M260 520 L440 500 L420 760 Z" strokeWidth={8} />
      <path d="M820 520 L640 500 L660 760 Z" strokeWidth={8} />
      {/* clavicles / shoulders */}
      <path d="M200 470 Q360 440 515 470" strokeWidth={10} />
      <path d="M880 470 Q720 440 565 470" strokeWidth={10} />
      <circle cx={190} cy={490} r={50} strokeWidth={8} />
      <circle cx={890} cy={490} r={50} strokeWidth={8} />
    </g>
    {/* arrowhead */}
    <g opacity={reveal} transform="translate(360,600) rotate(-35)">
      <path d="M0 -46 L20 0 L0 14 L-20 0 Z" fill="#fff" style={{filter: 'drop-shadow(0 0 25px #fff)'}} />
      <circle cx={0} cy={-10} r={70 + Math.sin(f / 4) * 10} fill="none" stroke={C.blood} strokeWidth={6} />
    </g>
    {traj > 0 && <line x1={360 + 420} y1={600 + 600} x2={360 + 420 - traj * 420} y2={600 + 600 - traj * 600} stroke={C.blood} strokeWidth={6} strokeDasharray="22 16" />}
    {/* scan bar */}
    {scan < 1 && <rect x={0} y={290 + scan * 1300} width={W} height={10} fill="#bfe6ff" opacity={0.9} style={{filter: 'drop-shadow(0 0 30px #bfe6ff)'}} />}
  </svg>
);

const Hook: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const x = wf('hook', 'x-ray');
  const arrow = wf('hook', 'arrowhead');
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.25} origin="33% 32%">
        <XRay f={f} scan={lerp(f, [0, x + 8], [0.3, 1], inOut)} reveal={lerp(f, [arrow - 4, arrow + 4], [0, 1])} />
      </Cam>
      <Title text="FROZE TO DEATH?" sub="THE THEORY · 1991–2001" y={230} f={f} size={84} />
      <Vignette strength={0.8} />
    </AbsoluteFill>
  );
};

const Find: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = lerp(f, [0, d], [0, 1], inOut);
  const body = wf('find', 'body');
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.22} x={[0, -90]} y={[0, -60]} origin="60% 75%">
      <Alps f={f} p={p} />
      <svg width={W} height={H} style={{position: 'absolute'}}>
        <Hiker x={lerp(f, [0, d], [180, 470])} y={1420} s={1.4} f={f} />
        <Hiker x={lerp(f, [0, d], [80, 360])} y={1440} s={1.45} f={f} phase={2} />
        {/* body in ice */}
        <g opacity={lerp(f, [body - 4, body + 10], [0, 1])}>
          <ellipse cx={780} cy={1520} rx={170} ry={46} fill="#7a8f9c" opacity={0.5} />
          <path d="M650 1520 Q700 1490 760 1505 Q820 1490 900 1515 Q860 1545 760 1540 Q690 1545 650 1520 Z" fill="#5a3f28" opacity={0.85} />
          <ellipse cx={780} cy={1520} rx={200} ry={70} fill="none" stroke={C.amber} strokeWidth={4} strokeDasharray="12 10" opacity={0.8} />
        </g>
      </svg>
      </Cam>
      <Particles n={70} color="#fff" seed="snowf" size={[2, 5]} speed={0.8} dir={[0.4, 1]} opacity={0.7} />
      <Title text="ÖTZTAL ALPS" sub="SEPTEMBER 1991" y={230} f={f} size={96} />
      <Vignette strength={0.7} />
    </AbsoluteFill>
  );
};

const Age: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const n = Math.round(lerp(f, [0, 34], [0, 5300]));
  const tl = lerp(f, [20, 60], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #2a1d0e, #0b0805 70%)'}}>
      <Particles n={60} color={C.amber} seed="dage" size={[1, 4]} speed={0.3} opacity={0.5} />
      <div style={{position: 'absolute', top: 330, width: '100%', textAlign: 'center', fontFamily: 'Cinzel', fontWeight: 800, fontSize: 210, color: C.amber, textShadow: '0 0 60px rgba(224,168,74,0.5)'}}>{n.toLocaleString('en-US')}</div>
      <div style={{position: 'absolute', top: 580, width: '100%', textAlign: 'center', fontFamily: 'Cinzel', fontSize: 64, letterSpacing: 14, color: C.ivory}}>YEARS OLD</div>
      <svg width={W} height={H} style={{position: 'absolute'}}>
        <line x1={120} y1={900} x2={120 + 840 * tl} y2={900} stroke={C.ivory} strokeWidth={4} />
        {[
          {x: 160, t: 'ÖTZI', s: 'c. 3300 BC', c: C.amber},
          {x: 560, t: 'GIZA PYRAMIDS', s: 'c. 2560 BC', c: C.ivory},
          {x: 920, t: 'TODAY', s: '', c: C.fog},
        ].map((m, i) => (
          <g key={i} opacity={lerp(f, [24 + i * 10, 34 + i * 10], [0, 1])}>
            <circle cx={m.x} cy={900} r={14} fill={m.c} />
            <text x={m.x} y={970} fill={m.c} fontFamily="Cinzel" fontSize={34} fontWeight={700} textAnchor="middle">{m.t}</text>
            <text x={m.x} y={1012} fill={C.fog} fontFamily="Garamond" fontSize={32} textAnchor="middle">{m.s}</text>
          </g>
        ))}
      </svg>
      <Title text="OLDER THAN THE PYRAMIDS" y={1100} f={f} inF={50} size={58} color={C.ivory} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Theory: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.1} to={1.0}>
        <Alps f={f} p={0.5 + f / 400} storm={1} />
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <Hiker x={lerp(f, [0, d], [420, 600])} y={1420} s={2.2} f={f / 2} />
        </svg>
      </Cam>
      <Particles n={220} color="#fff" seed="storm" size={[2, 6]} speed={3.5} dir={[-1.2, 1]} opacity={0.75} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(200,205,210,0.15), rgba(200,205,210,0.35))'}} />
      <div style={{position: 'absolute', left: 90, top: 240, border: `3px solid ${C.ivory}`, padding: '14px 26px', fontFamily: 'Cinzel', color: C.ivory, opacity: lerp(f, [8, 20], [0, 1])}}>
        <div style={{fontSize: 28, letterSpacing: 8, color: C.amber}}>THEORY</div>
        <div style={{fontSize: 62, fontWeight: 700}}>DIED IN A STORM</div>
      </div>
      <Vignette />
    </AbsoluteFill>
  );
};

const Xray2: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const flint = wf('xray', 'flint');
  const behind = wf('xray', 'behind');
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.35} origin="33% 32%">
        <XRay f={f} scan={lerp(f, [0, flint], [0.35, 1], inOut)} reveal={lerp(f, [flint - 2, flint + 6], [0, 1])} traj={lerp(f, [behind - 6, behind + 12], [0, 1])} />
      </Cam>
      <Title text="ARROWHEAD" sub="2001 · NEW X-RAY" y={230} f={f} inF={flint - 4} size={100} />
      <div style={{position: 'absolute', left: 600, top: 620, fontFamily: 'Cinzel', fontSize: 40, color: '#fff', opacity: lerp(f, [flint + 6, flint + 16], [0, 1])}}>LEFT SHOULDER</div>
      <div style={{position: 'absolute', left: 600, top: 680, fontFamily: 'Garamond', fontSize: 36, color: C.ice, opacity: lerp(f, [behind - 4, behind + 6], [0, 1])}}>fired from behind</div>
      <Vignette strength={0.8} />
    </AbsoluteFill>
  );
};

const Murder: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const m = wf('murder', 'murdered');
  const stamp = lerp(f, [m - 3, m + 3], [0, 1]);
  return (
    <AbsoluteFill style={{background: '#120c07'}}>
      <Cam d={d} from={1.05} to={1.0} rot={[-2, 0]}>
        <div style={{position: 'absolute', left: 120, top: 360, width: 840, height: 1040, background: '#d9c9a3', boxShadow: '0 40px 80px rgba(0,0,0,0.7)', rotate: '-3deg'}}>
          <div style={{position: 'absolute', left: -2, top: -60, width: 320, height: 70, background: '#cbb88e', borderRadius: '14px 14px 0 0'}} />
          <div style={{padding: 60, fontFamily: 'Garamond', color: '#2a2016'}}>
            <div style={{fontFamily: 'Cinzel', fontWeight: 700, fontSize: 68, letterSpacing: 4}}>CASE FILE</div>
            <div style={{fontSize: 50, marginTop: 30, lineHeight: 1.5}}>Subject: “Ötzi”<br />Found: Ötztal Alps, 1991<br />Age: c. 5,300 years<br />Cause of death:</div>
            <div style={{fontSize: 52, marginTop: 10, textDecoration: 'line-through', opacity: lerp(f, [0, 10], [0, 0.8])}}>Exposure / storm</div>
          </div>
          <div style={{position: 'absolute', left: 110, top: 680, border: `10px solid ${C.blood}`, color: C.blood, fontFamily: 'Cinzel', fontWeight: 900, fontSize: 140, padding: '0 30px', rotate: '-12deg', opacity: stamp * 0.92, scale: String(interpolate(stamp, [0, 1], [2.2, 1]))}}>MURDER</div>
        </div>
      </Cam>
      <Vignette strength={0.85} />
    </AbsoluteFill>
  );
};

const Axe: React.FC<{f: number; x: number; y: number; s: number; rot: number; glow?: number}> = ({f, x, y, s, rot, glow = 1}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <defs>
      <linearGradient id="cu" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#f0a46a" /><stop offset="50%" stopColor={C.copper} /><stop offset="100%" stopColor="#6b3414" /></linearGradient>
      <linearGradient id="wood" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#4a2c16" /><stop offset="100%" stopColor="#7a4a26" /></linearGradient>
    </defs>
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} style={{filter: `drop-shadow(0 0 ${30 * glow}px rgba(224,140,70,0.6))`}}>
      <path d="M-20 -260 Q20 -270 30 -230 L40 300 Q20 320 0 300 Z" fill="url(#wood)" />
      <path d="M-30 -270 Q-10 -300 40 -280 L45 -200 Q10 -190 -25 -205 Z" fill="url(#wood)" />
      <path d="M40 -265 L170 -300 Q200 -250 170 -190 L40 -215 Z" fill="url(#cu)" />
      <path d="M170 -300 Q200 -250 170 -190" stroke="#ffd2a8" strokeWidth={5} fill="none" opacity={0.6 + 0.4 * Math.sin(f / 6)} />
      <path d="M-20 -230 Q60 -240 60 -230" stroke="#2a1608" strokeWidth={6} />
    </g>
  </svg>
);

const AxeScene: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const axe = wf('axe', 'axe');
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, #3a2412, #0b0805 65%)'}}>
      <svg width={W} height={H} style={{position: 'absolute', opacity: 0.5}}>
        <polygon points="300,0 780,0 1000,1920 80,1920" fill="#e0a84a" opacity={0.07} />
      </svg>
      <Axe f={f} x={500} y={1000} s={lerp(f, [0, d], [1.3, 1.6], inOut)} rot={lerp(f, [0, d], [-18, 8], inOut)} glow={lerp(f, [axe - 6, axe + 10], [0.2, 1.2])} />
      <Particles n={90} color="#f0c890" seed="dust2" size={[1, 4]} speed={0.25} opacity={0.6} />
      <Title text="COPPER AXE" sub="ONE OF HIS MOST VALUABLE POSSESSIONS" y={230} f={f} inF={axe - 4} size={110} color={C.ivory} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Left: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#cfd9e0'}}>
      <Cam d={d} from={1.0} to={1.15} y={[0, -60]}>
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <defs><linearGradient id="fogv" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#6d7680" /><stop offset="60%" stopColor="#c8d3db" /><stop offset="100%" stopColor="#eef3f6" /></linearGradient></defs>
          <rect width={W} height={H} fill="url(#fogv)" />
          {/* footprints leading away */}
          {new Array(12).fill(0).map((_, i) => {
            const t = i / 11;
            const x = 540 + Math.sin(i * 1.3) * 30 * (1 - t) + (i % 2 ? 22 : -22) * (1 - t * 0.7);
            const y = 1600 - t * 900;
            return <ellipse key={i} cx={x} cy={y} rx={22 * (1 - t * 0.7)} ry={36 * (1 - t * 0.7)} fill="#7d8a95" opacity={lerp(f, [i * 2, i * 2 + 8], [0, 0.7 * (1 - t * 0.6)])} />;
          })}
        </svg>
        <Axe f={f} x={300} y={1600} s={0.7} rot={78} glow={0.6} />
      </Cam>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(220,228,234,0.9) 0%, rgba(220,228,234,0) 45%)'}} />
      <Title text="LEFT BEHIND" y={260} f={f} inF={4} size={110} color="#2a2f36" />
      <Vignette strength={0.5} />
    </AbsoluteFill>
  );
};

const Question: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.12}>
        <Alps f={f} p={0.2} tint="#3a2c1c" />
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <g transform="translate(760,1300) scale(1.6)" opacity={lerp(f, [6, 26], [0, 0.95])}>
            <circle cx={0} cy={-150} r={16} fill="#050505" />
            <rect x={-16} y={-132} width={32} height={74} rx={10} fill="#050505" />
            <line x1={-6} y1={-60} x2={-14} y2={0} stroke="#050505" strokeWidth={13} strokeLinecap="round" />
            <line x1={6} y1={-60} x2={12} y2={0} stroke="#050505" strokeWidth={13} strokeLinecap="round" />
            <path d="M-40 -190 Q-80 -110 -40 -30" stroke="#050505" strokeWidth={5} fill="none" />
            <line x1={-40} y1={-190} x2={-40} y2={-30} stroke="#050505" strokeWidth={2} />
          </g>
        </svg>
      </Cam>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 70%, rgba(180,170,150,0.0), rgba(30,22,14,0.65))'}} />
      <Particles n={60} color="#e8dcc4" seed="fogq" size={[30, 80]} speed={0.4} dir={[1, 0]} opacity={0.06} blur={20} />
      <Title text="WHO KILLED ÖTZI?" y={300} f={f} inF={wf('question', 'kills') - 4} size={100} color={C.ivory} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Cta: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #2a1d0e, #070504 70%)'}}>
      <Particles n={50} color={C.amber} seed="ctah" size={[1, 4]} speed={0.3} opacity={0.5} />
      <Title text="UNSOLVED" sub="HISTORIANS STILL DEBATE" y={720} f={f} size={140} color={C.amber} />
      <div style={{position: 'absolute', top: 1000, width: '100%', textAlign: 'center', fontFamily: 'Garamond', fontStyle: 'italic', fontSize: 48, color: C.ivory, opacity: lerp(f, [10, 24], [0, 1])}}>Follow for the mysteries history never solved</div>
    </AbsoluteFill>
  );
};

export const HistVideo: React.FC = () => (
  <AbsoluteFill style={{background: C.bg}}>
    <FontFaces />
    <Scenes timing={timing} map={{hook: Hook, find: Find, age: Age, theory: Theory, xray: Xray2, murder: Murder, axe: AxeScene, left: Left, question: Question, cta: Cta}} xfade={10} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,0,0,0) 62%, rgba(10,7,4,0.6) 72%, rgba(10,7,4,0.6) 86%, rgba(0,0,0,0) 94%)'}} />
    <Captions words={timing.words} top={1420} active={C.ivory} inactive="#9a9182" maxWords={4} strip={(w) => w.replace(/Otzi/g, 'Ötzi')} emph={['arrowhead', 'murdered', 'axe', 'treasure', 'ötzi', 'behind', 'froze']} emphColor={C.amber}
      style={{fontFamily: 'Garamond', fontWeight: 700, fontSize: 82, lineHeight: 1.1, textShadow: '0 4px 0 #000, 0 0 22px rgba(0,0,0,0.95)'}} />
    <Grain opacity={0.12} />
  </AbsoluteFill>
);
export const histFrames = Math.ceil(timing.duration * FPS);
