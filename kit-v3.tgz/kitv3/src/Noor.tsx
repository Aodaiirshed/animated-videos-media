import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {Cam, Captions, FontFaces, Grain, inOut, lerp, localF, Particles, Scenes, Timing, Vignette, W, H, wordTime, FPS, stripTashkeel} from './lib';
import T from '../public/audio/noor_scenes.json';

const timing = T as unknown as Timing;
const C = {night: '#0a1519', deep: '#06100f', gold: '#d4ab55', parch: '#ecdfc0', ink: '#3b2a17', flame: '#ffb347', teal: '#1d4a4f'};
const wf = (s: string, w: string, n = 0) => localF(timing, s, wordTime(timing, s, w, n));
const toAr = (n: number) => String(n).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[+d]);

const ArTitle: React.FC<{text: string; sub?: string; y: number; f: number; inF?: number; size?: number; color?: string}> = ({text, sub, y, f, inF = 0, size = 110, color = C.gold}) => (
  <div style={{position: 'absolute', top: y, left: 60, right: 60, textAlign: 'center', direction: 'rtl', opacity: lerp(f, [inF, inF + 14], [0, 1]), translate: `0px ${lerp(f, [inF, inF + 18], [24, 0])}px`}}>
    <div style={{fontFamily: 'Amiri', fontWeight: 700, fontSize: size, color, lineHeight: 1.35, textShadow: '0 6px 30px rgba(0,0,0,0.85)'}}>{text}</div>
    {sub && <div style={{fontFamily: 'Naskh', fontSize: 38, color: C.parch, opacity: 0.85, marginTop: 6}}>{sub}</div>}
  </div>
);

/** Eight-point star tiling, drawn faintly. */
const Pattern: React.FC<{opacity?: number; color?: string; rot?: number}> = ({opacity = 0.08, color = C.gold, rot = 0}) => {
  const star = (cx: number, cy: number, r: number) => {
    const pts: string[] = [];
    for (let i = 0; i < 16; i++) {
      const a = (i * Math.PI) / 8 + (rot * Math.PI) / 180;
      const rr = i % 2 ? r * 0.62 : r;
      pts.push(`${cx + Math.cos(a) * rr},${cy + Math.sin(a) * rr}`);
    }
    return pts.join(' ');
  };
  return (
    <svg width={W} height={H} style={{position: 'absolute', opacity}}>
      {new Array(9).fill(0).map((_, r) => new Array(6).fill(0).map((__, c) => <polygon key={`${r}-${c}`} points={star(c * 216 + (r % 2) * 108, r * 216 + 60, 90)} fill="none" stroke={color} strokeWidth={3} />))}
    </svg>
  );
};

const Lamp: React.FC<{x: number; y: number; s?: number; lit: number; f: number; seed?: string}> = ({x, y, s = 1, lit, f, seed = 'l'}) => {
  const fl = 1 + Math.sin(f / 3 + random(seed) * 6) * 0.08 + Math.sin(f / 1.7) * 0.04;
  return (
    <svg width={W} height={H} style={{position: 'absolute'}}>
      <defs><radialGradient id={`lg${seed}`}><stop offset="0%" stopColor="#ffd48a" stopOpacity={0.9} /><stop offset="100%" stopColor={C.flame} stopOpacity={0} /></radialGradient></defs>
      <g transform={`translate(${x},${y}) scale(${s})`}>
        <circle cx={0} cy={-70} r={260 * lit * fl} fill={`url(#lg${seed})`} opacity={0.55 * lit} />
        <path d="M-90 0 Q-90 -40 0 -40 Q80 -40 120 -60 Q110 -20 70 0 Q40 20 -60 20 Q-90 20 -90 0 Z" fill="#8a6a2e" stroke={C.gold} strokeWidth={4} />
        <path d="M-100 -10 Q-130 -20 -125 10 Q-120 30 -85 10" stroke={C.gold} strokeWidth={6} fill="none" />
        <path d={`M110 -62 Q${100 + Math.sin(f / 4) * 4} ${-110 * fl} 118 ${-150 * fl} Q${132 + Math.sin(f / 5) * 4} ${-105 * fl} 124 -62 Z`} fill="#ffe2a6" opacity={lit} style={{filter: 'drop-shadow(0 0 20px #ffb347)'}} />
        {lit < 0.5 && lit > 0 && <path d={`M117 -70 q${Math.sin(f / 5) * 10} -60 ${Math.sin(f / 7) * 20} -140`} stroke="#9a9a9a" strokeWidth={4} fill="none" opacity={0.5 - lit} />}
      </g>
    </svg>
  );
};

/** Fez skyline with arches, minaret, and great doors. */
const Skyline: React.FC<{f: number; doors: number}> = ({f, doors}) => (
  <svg width={W} height={H} style={{position: 'absolute'}}>
    <defs>
      <linearGradient id="nsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#050c10" /><stop offset="100%" stopColor="#163038" /></linearGradient>
      <radialGradient id="doorlight"><stop offset="0%" stopColor="#ffe2a6" /><stop offset="100%" stopColor="#ffb347" stopOpacity={0} /></radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#nsky)" />
    <path d="M860 560 A80 80 0 1 0 940 680 A62 62 0 1 1 860 560 Z" fill="#f3e6c4" opacity={0.9} />
    {/* far city */}
    {new Array(14).fill(0).map((_, i) => <rect key={i} x={i * 80 - 20} y={760 - random('b' + i) * 160} width={84} height={600} fill="#0d1d22" />)}
    {/* minaret */}
    <rect x={130} y={420} width={110} height={700} fill="#0a171b" />
    <rect x={150} y={360} width={70} height={70} fill="#0a171b" />
    <path d="M185 300 L200 360 L170 360 Z" fill="#0a171b" />
    <rect x={165} y={480} width={40} height={60} rx={20} fill={C.flame} opacity={0.35} />
    {/* main facade */}
    <rect x={0} y={900} width={W} height={1020} fill="#0e2025" />
    {new Array(5).fill(0).map((_, i) => <path key={i} d={`M${40 + i * 210} 1500 L${40 + i * 210} 1120 Q${40 + i * 210 + 85} 990 ${40 + i * 210 + 170} 1120 L${40 + i * 210 + 170} 1500 Z`} fill="#081316" stroke={C.gold} strokeOpacity={0.3} strokeWidth={4} />)}
    {/* great doorway */}
    <path d="M330 1500 L330 1060 Q540 820 750 1060 L750 1500 Z" fill="#050b0c" stroke={C.gold} strokeWidth={6} />
    <ellipse cx={540} cy={1300} rx={220 * doors + 10} ry={330} fill="url(#doorlight)" opacity={doors} />
    <path d={`M340 1500 L340 1065 Q440 950 540 920 L${540 - 200 * doors} ${940 + doors * 140} L${540 - 200 * doors} 1500 Z`} fill="#3a2612" stroke="#6b4a24" strokeWidth={4} />
    <path d={`M740 1500 L740 1065 Q640 950 540 920 L${540 + 200 * doors} ${940 + doors * 140} L${540 + 200 * doors} 1500 Z`} fill="#3a2612" stroke="#6b4a24" strokeWidth={4} />
    <rect x={0} y={1500} width={W} height={420} fill="#0a1417" />
    <polygon points={`${540 - 200 * doors},1500 ${540 + 200 * doors},1500 ${540 + 420 * doors},1920 ${540 - 420 * doors},1920`} fill="#ffcf80" opacity={0.18 * doors} />
  </svg>
);

const Hook: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.0} to={1.12} y={[0, -30]} origin="50% 70%">
        <Skyline f={f} doors={lerp(f, [4, d * 0.7], [0.05, 1], inOut)} />
      </Cam>
      <Particles n={40} color="#ffe2a6" seed="nh" size={[2, 5]} speed={0.3} opacity={0.6} area={[200, 900, 680, 700]} />
      <ArTitle text="أقدم جامعة في العالم" sub="ما زالت تعمل حتى اليوم — بحسب اليونسكو وغينيس" y={230} f={f} size={104} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Woman: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const w = wf('woman', 'امرأة');
  return (
    <AbsoluteFill style={{background: C.deep}}>
      <Pattern opacity={lerp(f, [w, w + 20], [0, 0.1])} />
      <Cam d={d} from={1.15} to={1.0}>
        <Lamp x={500} y={1100} s={1.8} lit={lerp(f, [w - 10, w + 2], [0, 1])} f={f} seed="w" />
      </Cam>
      <ArTitle text="امرأة" y={360} f={f} inF={w - 2} size={200} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Migrate: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const route = lerp(f, [wf('migrate', 'القيروان') - 4, wf('migrate', 'فاس') + 6], [0, 1], inOut);
  // stylised North African coast: Morocco (left) to Tunisia (right)
  const coast = 'M40 820 Q120 700 260 690 Q420 690 520 660 Q640 640 760 600 Q860 560 900 520 Q960 470 990 560 Q1000 640 1040 660';
  const fez = {x: 250, y: 840}, kai = {x: 930, y: 640};
  const mx = (fez.x + kai.x) / 2, my = Math.min(fez.y, kai.y) - 120;
  const bez = (t: number) => ({x: (1 - t) * (1 - t) * kai.x + 2 * (1 - t) * t * mx + t * t * fez.x, y: (1 - t) * (1 - t) * kai.y + 2 * (1 - t) * t * my + t * t * fez.y});
  const cur = bez(route);
  return (
    <AbsoluteFill style={{background: C.parch}}>
      <Cam d={d} from={1.0} to={1.08}>
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <defs><radialGradient id="par"><stop offset="60%" stopColor="#ecdfc0" stopOpacity={0} /><stop offset="100%" stopColor="#8a6a3a" stopOpacity={0.55} /></radialGradient></defs>
          <g transform="translate(0,300)">
            <path d={`${coast} L1080 0 L0 0 Z`} fill="#b9c9c4" opacity={0.55} />
            <path d={coast} stroke={C.ink} strokeWidth={5} fill="none" />
            <text x={560} y={420} fill={C.ink} fontFamily="Amiri" fontSize={44} textAnchor="middle" opacity={0.6}>البحر المتوسط</text>
            <path d={`M${kai.x} ${kai.y} Q${mx} ${my} ${fez.x} ${fez.y}`} stroke={C.ink} strokeWidth={6} fill="none" strokeDasharray="18 14" pathLength={1000} strokeDashoffset={0} opacity={0.25} />
            <path d={`M${kai.x} ${kai.y} Q${mx} ${my} ${fez.x} ${fez.y}`} stroke="#9a3b1c" strokeWidth={8} fill="none" pathLength={1} strokeDasharray={`${route} 1`} />
            {[{p: kai, t: 'القيروان'}, {p: fez, t: 'فاس'}].map((c, i) => (
              <g key={i}>
                <circle cx={c.p.x} cy={c.p.y} r={18} fill="#9a3b1c" />
                <circle cx={c.p.x} cy={c.p.y} r={34 + Math.sin(f / 6) * 4} fill="none" stroke="#9a3b1c" strokeWidth={3} />
                <text x={c.p.x} y={c.p.y + 80} fill={C.ink} fontFamily="Amiri" fontWeight={700} fontSize={64} textAnchor="middle">{c.t}</text>
              </g>
            ))}
            <circle cx={cur.x} cy={cur.y} r={14} fill={C.ink} opacity={route > 0 && route < 1 ? 1 : 0} />
          </g>
          <rect width={W} height={H} fill="url(#par)" />
        </svg>
      </Cam>
      <ArTitle text="من القيروان إلى فاس" y={250} f={f} size={96} color={C.ink} />
      <Grain opacity={0.15} />
    </AbsoluteFill>
  );
};

const Loss: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const t = [wf('loss', 'أباها'), wf('loss', 'وزوجها'), wf('loss', 'وأخاها')];
  const inh = wf('loss', 'وورثت');
  return (
    <AbsoluteFill style={{background: C.deep}}>
      {[0, 1, 2].map((i) => <Lamp key={i} x={210 + i * 330} y={1050} s={0.95} lit={lerp(f, [t[i] - 2, t[i] + 10], [1, 0])} f={f} seed={'ls' + i} />)}
      <AbsoluteFill style={{opacity: lerp(f, [inh - 6, inh + 10], [0, 1])}}>
        <Particles n={70} color={C.gold} seed="coins" size={[6, 14]} speed={1.4} dir={[0, 1]} opacity={0.9} />
      </AbsoluteFill>
      <ArTitle text="الأب · الزوج · الأخ" y={280} f={f} size={80} color={C.parch} />
      <ArTitle text="ثم الميراث" y={1180} f={f} inF={inh - 4} size={90} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Choice: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const palace = wf('choice', 'قصرا');
  const build = wf('choice', 'وبنت');
  const draw = lerp(f, [build - 10, d], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: `radial-gradient(circle at 50% 50%, ${C.teal}, ${C.deep} 70%)`}}>
      <Pattern opacity={0.06} />
      <svg width={W} height={H} style={{position: 'absolute'}}>
        {/* palace silhouette, fades out */}
        <g opacity={lerp(f, [palace - 6, palace + 4], [0, 1]) * lerp(f, [build - 14, build], [1, 0.12])} transform="translate(540,1000)">
          <rect x={-300} y={-160} width={600} height={260} fill="#c79a4a" opacity={0.4} />
          {[-260, -130, 0, 130, 260].map((x, i) => <path key={i} d={`M${x - 40} -160 L${x - 40} -260 Q${x} -330 ${x + 40} -260 L${x + 40} -160 Z`} fill="#c79a4a" opacity={0.55} />)}
          <path d="M-90 -300 Q0 -480 90 -300 Z" fill="#c79a4a" opacity={0.6} />
        </g>
        {/* mosque: arcade drawn line by line */}
        <g stroke={C.gold} strokeWidth={6} fill="none" transform="translate(0,120)" style={{filter: 'drop-shadow(0 0 14px rgba(212,171,85,0.6))'}}>
          {new Array(5).fill(0).map((_, i) => (
            <path key={i} d={`M${120 + i * 180} 1200 L${120 + i * 180} 920 Q${210 + i * 180} 800 ${300 + i * 180} 920 L${300 + i * 180} 1200`} pathLength={1} strokeDasharray={`${lerp(draw, [i * 0.12, i * 0.12 + 0.45], [0, 1])} 1`} />
          ))}
          <path d="M80 1200 L1000 1200" pathLength={1} strokeDasharray={`${draw} 1`} />
          <path d="M140 740 L940 740" pathLength={1} strokeDasharray={`${lerp(draw, [0.5, 1], [0, 1])} 1`} />
        </g>
      </svg>
      <ArTitle text="قصرٌ؟" y={260} f={f} inF={palace - 6} size={100} color={C.parch} />
      <ArTitle text="بل مسجد" y={420} f={f} inF={build - 4} size={120} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Fast: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const rows = Math.floor(lerp(f, [0, d], [0, 14], inOut));
  const cyc = (f / 34) % 1;
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${interpolate(Math.sin(f / 34 * Math.PI * 2), [-1, 1], [0, 1]) > 0.5 ? '#0b1a22' : '#122a33'}, #06100f)`}}>
      <svg width={W} height={H} style={{position: 'absolute'}}>
        {/* moon arc cycling = days passing */}
        <g transform={`translate(${interpolate(cyc, [0, 1], [-100, 1180])}, ${820 - Math.sin(cyc * Math.PI) * 240})`}>
          <path d="M0 -60 A60 60 0 1 0 60 30 A46 46 0 1 1 0 -60 Z" fill="#f3e6c4" />
        </g>
        {/* rising walls */}
        {new Array(14).fill(0).map((_, r) => new Array(9).fill(0).map((__, c) => {
          const vis = r < rows ? 1 : r === rows ? (lerp(f, [0, d], [0, 14], inOut) % 1) : 0;
          return <rect key={`${r}-${c}`} x={60 + c * 108 + (r % 2) * 54 - 54} y={1560 - r * 52} width={104} height={48} fill="#b58e4e" stroke="#6e5126" strokeWidth={3} opacity={vis} />;
        }))}
      </svg>
      <div style={{position: 'absolute', top: 260, width: '100%', textAlign: 'center', direction: 'rtl', fontFamily: 'Amiri', fontWeight: 700, fontSize: 96, color: C.gold, opacity: lerp(f, [4, 16], [0, 1])}}>صيامٌ حتى تمّ البناء</div>
      <div style={{position: 'absolute', top: 400, width: '100%', textAlign: 'center', direction: 'rtl', fontFamily: 'Naskh', fontSize: 36, color: C.parch, opacity: 0.8}}>كما تروي المصادر</div>
      <Vignette />
    </AbsoluteFill>
  );
};

const Name: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const n = wf('name', 'القرويين');
  return (
    <AbsoluteFill style={{background: `radial-gradient(circle at 50% 45%, #1f3d40, ${C.deep} 70%)`}}>
      <Pattern opacity={0.12} rot={f / 6} />
      <Cam d={d} from={1.1} to={1.0}>
        <div style={{position: 'absolute', top: 640, width: '100%', textAlign: 'center', fontFamily: 'Amiri', fontWeight: 700, fontSize: 230, color: C.gold, direction: 'rtl', opacity: lerp(f, [n - 6, n + 10], [0, 1]), scale: String(lerp(f, [n - 6, n + 20], [1.2, 1])), textShadow: '0 0 60px rgba(212,171,85,0.6)'}}>القرويين</div>
      </Cam>
      <ArTitle text="نسبةً إلى القيروان" y={1020} f={f} inF={wf('name', 'نسبة') - 4} size={70} color={C.parch} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Circles: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const count = Math.floor(lerp(f, [0, d * 0.8], [1, 7]));
  const centers = [[540, 950], [270, 760], [810, 760], [270, 1140], [810, 1140], [540, 600], [540, 1300]];
  return (
    <AbsoluteFill style={{background: '#0b1416'}}>
      <Cam d={d} from={1.25} to={1.0}>
        <svg width={W} height={H} style={{position: 'absolute'}}>
          {/* courtyard tiles */}
          {new Array(12).fill(0).map((_, i) => <line key={i} x1={0} y1={420 + i * 90} x2={W} y2={420 + i * 90} stroke={C.gold} opacity={0.08} />)}
          <rect x={440} y={850} width={200} height={200} fill="none" stroke={C.gold} opacity={0.25} strokeWidth={4} />
          {centers.slice(0, count).map(([cx, cy], k) => (
            <g key={k} opacity={lerp(f, [k * (d * 0.8 / 7), k * (d * 0.8 / 7) + 10], [0, 1])}>
              <circle cx={cx} cy={cy} r={110} fill="#ffb347" opacity={0.08} />
              {new Array(10).fill(0).map((_, i) => {
                const a = (i / 10) * Math.PI * 2;
                return <circle key={i} cx={cx + Math.cos(a) * 90} cy={cy + Math.sin(a) * 90} r={9 + Math.sin(f / 4 + i) * 2} fill="#ffd48a" style={{filter: 'drop-shadow(0 0 10px #ffb347)'}} />;
              })}
              <circle cx={cx} cy={cy} r={14} fill={C.gold} />
            </g>
          ))}
        </svg>
      </Cam>
      <ArTitle text="حلقات العلم" y={240} f={f} size={110} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Still: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const yr = Math.round(lerp(f, [4, d * 0.6], [859, 2026], inOut));
  return (
    <AbsoluteFill>
      <Cam d={d} from={1.12} to={1.0} origin="50% 70%">
        <Skyline f={f} doors={1} />
      </Cam>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(6,16,15,0.85) 0%, rgba(6,16,15,0) 40%)'}} />
      <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', fontFamily: 'Amiri', fontWeight: 700, color: C.gold, fontSize: 190, textShadow: '0 0 50px rgba(212,171,85,0.5)'}}>{toAr(yr)}م</div>
      <ArTitle text="وما زال العلم يُدرَّس فيه" y={500} f={f} inF={wf('still', 'العلم') - 4} size={70} color={C.parch} />
      <Particles n={50} color="#ffe2a6" seed="st" size={[2, 5]} speed={0.4} opacity={0.6} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Moral: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const zul = wf('moral', 'يزول');
  const yabqa = wf('moral', 'يبقى');
  const sand = lerp(f, [zul - 4, zul + 40], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: C.deep}}>
      <Pattern opacity={lerp(f, [yabqa, yabqa + 30], [0.02, 0.12])} />
      <svg width={W} height={H} style={{position: 'absolute'}}>
        {/* palace dissolving to sand on the right (RTL reading: first) */}
        <g transform="translate(780,980)" opacity={1 - sand * 0.9}>
          <rect x={-170} y={-100} width={340} height={200} fill="#c79a4a" opacity={0.6} />
          {[-120, 0, 120].map((x, i) => <path key={i} d={`M${x - 35} -100 L${x - 35} -180 Q${x} -240 ${x + 35} -180 L${x + 35} -100 Z`} fill="#c79a4a" opacity={0.7} />)}
        </g>
      </svg>
      <AbsoluteFill style={{opacity: sand}}>
        <Particles n={90} color="#c79a4a" seed="sand" size={[3, 7]} speed={2} dir={[-0.4, 1]} area={[600, 760, 360, 900]} opacity={0.8} />
      </AbsoluteFill>
      <Lamp x={270} y={1080} s={1.3} lit={lerp(f, [yabqa - 10, yabqa + 4], [0.35, 1])} f={f} seed="moral" />
      <div style={{position: 'absolute', top: 240, left: 60, right: 60, direction: 'rtl', textAlign: 'center', fontFamily: 'Amiri', fontWeight: 700, lineHeight: 1.5}}>
        <div style={{fontSize: 80, color: C.parch, opacity: lerp(f, [0, 12], [0, 1])}}>مالٌ يُبنى به قصرٌ… يزول</div>
        <div style={{fontSize: 88, color: C.gold, opacity: lerp(f, [yabqa - 30, yabqa - 10], [0, 1]), textShadow: '0 0 40px rgba(212,171,85,0.6)'}}>ومالٌ يُبنى به علمٌ… يبقى</div>
      </div>
      <div style={{position: 'absolute', top: 1660, width: '100%', textAlign: 'center', fontFamily: 'ReemKufi', fontSize: 44, color: C.gold, opacity: lerp(f, [d - 50, d - 30], [0, 0.9]), letterSpacing: 2}}>دفتر نور</div>
      <Vignette />
    </AbsoluteFill>
  );
};

export const NoorVideo: React.FC = () => (
  <AbsoluteFill style={{background: C.deep}}>
    <FontFaces />
    <Scenes timing={timing} map={{hook: Hook, woman: Woman, migrate: Migrate, loss: Loss, choice: Choice, fast: Fast, name: Name, circles: Circles, still: Still, moral: Moral}} xfade={10} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,0,0,0) 64%, rgba(4,10,10,0.55) 72%, rgba(4,10,10,0.55) 86%, rgba(0,0,0,0) 94%)'}} />
    <Captions words={timing.words.filter((w) => w.s !== 'moral')} top={1430} rtl strip={stripTashkeel} active="#ffffff" inactive="#d8cba8" maxWords={4} emph={['امرأة', 'القرويين', 'مسجدا', 'جامعة', 'يبقى', 'يزول']} emphColor={C.gold}
      style={{fontFamily: 'Amiri', fontWeight: 700, fontSize: 86, lineHeight: 1.35, textShadow: '0 4px 0 #000, 0 0 20px rgba(0,0,0,0.95)'}} />
    <Grain opacity={0.08} />
  </AbsoluteFill>
);
export const noorFrames = Math.ceil(timing.duration * FPS);
