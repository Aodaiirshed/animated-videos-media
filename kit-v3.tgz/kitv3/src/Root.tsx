import React from 'react';
import {Composition} from 'remotion';
import {WonderVideo, wonderFrames} from './Wonder';
import {FootVideo, footFrames} from './Foot';
import {HistVideo, histFrames} from './Hist';
import {NoorVideo, noorFrames} from './Noor';
export const Root: React.FC = () => (
  <>
    <Composition id="wonder" component={WonderVideo} durationInFrames={wonderFrames} fps={30} width={1080} height={1920} />
    <Composition id="foot" component={FootVideo} durationInFrames={footFrames} fps={30} width={1080} height={1920} />
    <Composition id="hist" component={HistVideo} durationInFrames={histFrames} fps={30} width={1080} height={1920} />
    <Composition id="noor" component={NoorVideo} durationInFrames={noorFrames} fps={30} width={1080} height={1920} />
  </>
);
