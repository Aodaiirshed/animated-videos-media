import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {Cam, Captions, clamp, ease, FontFaces, Grain, inOut, lerp, localF, Particles, Scenes, Timing, Vignette, W, H, wordTime, FPS} from './lib';
import T from '../public/audio/wonder_scenes.json';

const timing = T as unknown as Timing;
const C = {bg: '#040a18', cyan: '#3ef0ff', coral: '#ff4d6d', mint: '#5dffb0', violet: '#9b7bff', ink: '#0b1730'};
const wf = (scene: string, word: string, nth = 0) => localF(timing, scene, wordTime(timing, scene, word, nth));

const BODY = 'M180 150 Q200 160 220 150 L222 170 Q290 175 305 205 Q320 260 325 380 L335 540 Q338 570 322 572 Q310 570 310 540 L295 390 Q290 330 282 290 Q285 420 278 560 Q285 600 282 640 L272 930 Q275 975 258 978 L228 978 Q218 975 220 940 L210 650 Q205 610 200 605 Q195 610 190 650 L180 940 Q182 975 172 978 L142 978 Q125 975 128 930 L118 640 Q115 600 122 560 Q115 420 118 290 Q110 330 105 390 L90 540 Q90 570 78 572 Q62 570 65 540 L75 380 Q80 260 95 205 Q110 175 178 170 Z';
const NERVES = [
  'M200 150 L200 600', // spinal cord
  'M200 200 Q250 200 300 230 Q318 330 322 420 Q328 500 330 555',
  'M200 200 Q150 200 100 230 Q82 330 78 420 Q72 500 70 555',
  'M200 590 Q235 640 245 760 Q250 880 252 970',
  'M200 590 Q165 640 155 760 Q150 880 148 970',
  'M200 330 Q240 340 265 360', 'M200 330 Q160 340 135 360', 'M200 450 Q240 460 262 480', 'M200 450 Q160 460 138 480',
];

const Bg: React.FC<{tint?: string}> = ({tint = C.cyan}) => (
  <AbsoluteFill style={{background: `radial-gradient(circle at 50% 40%, ${C.ink} 0%, ${C.bg} 70%)`}}>
    <svg width={W} height={H} style={{position: 'absolute', opacity: 0.12}}>
      {new Array(28).fill(0).map((_, i) => <line key={i} x1={0} y1={i * 72} x2={W} y2={i * 72} stroke={tint} strokeWidth={1} />)}
      {new Array(16).fill(0).map((_, i) => <line key={'v' + i} x1={i * 72} y1={0} x2={i * 72} y2={H} stroke={tint} strokeWidth={1} />)}
    </svg>
  </AbsoluteFill>
);

const Hud: React.FC<{label: string; value: string; x: number; y: number; color?: string; delay?: number}> = ({label, value, x, y, color = C.cyan, delay = 0}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: x, top: y, fontFamily: 'Sora', color, opacity: lerp(f, [delay, delay + 12], [0, 1]), translate: `${lerp(f, [delay, delay + 12], [-30, 0])}px 0px`}}>
      <div style={{fontSize: 26, letterSpacing: 6, opacity: 0.75, fontWeight: 500}}>{label}</div>
      <div style={{fontSize: 54, fontWeight: 800, textShadow: `0 0 24px ${color}`}}>{value}</div>
    </div>
  );
};

/** Bedroom, side view: sleeper in bed, window with moon. */
const Bedroom: React.FC<{f: number; red?: number; dawn?: number}> = ({f, red = 0, dawn = 0}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute'}}>
    <defs>
      <radialGradient id="moon" cx="50%" cy="50%"><stop offset="0%" stopColor="#dff6ff" /><stop offset="100%" stopColor="#7fc8ff" stopOpacity={0} /></radialGradient>
      <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={dawn ? '#3a3060' : '#0a1630'} /><stop offset="100%" stopColor="#050a18" /></linearGradient>
      <linearGradient id="beam" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor={dawn ? '#ffd9a0' : '#9fd8ff'} stopOpacity={0.35 + dawn * 0.3} /><stop offset="100%" stopColor="#9fd8ff" stopOpacity={0} /></linearGradient>
    </defs>
    <rect width={W} height={H} fill="url(#wall)" />
    {/* window */}
    <g transform={`translate(${620 + Math.sin(f / 90) * 6},330)`}>
      <rect x={0} y={0} width={330} height={460} fill={dawn ? '#ffb27a' : '#0f2b52'} opacity={0.9} />
      <circle cx={220 - dawn * 60} cy={140 + dawn * 120} r={70} fill={dawn ? '#fff1c9' : '#e9f8ff'} />
      <circle cx={220 - dawn * 60} cy={140 + dawn * 120} r={200} fill="url(#moon)" opacity={0.6} />
      <rect x={160} y={0} width={10} height={460} fill="#06101f" />
      <rect x={0} y={225} width={330} height={10} fill="#06101f" />
      {/* curtains sway */}
      <path d={`M-40 -20 L60 -20 Q${50 + Math.sin(f / 25) * 14} 230 ${70 + Math.sin(f / 25) * 20} 500 L-40 500 Z`} fill="#0a1a33" />
      <path d={`M290 -20 L380 -20 L380 500 L${270 + Math.sin(f / 28 + 1) * 18} 500 Q${285 + Math.sin(f / 28) * 12} 230 290 -20 Z`} fill="#0a1a33" />
    </g>
    <polygon points="620,330 950,330 760,1700 0,1700 0,1250" fill="url(#beam)" />
    {/* bed */}
    <rect x={60} y={1080} width={960} height={70} rx={20} fill="#16264a" />
    <rect x={60} y={1150} width={960} height={240} fill="#0d1a36" />
    <rect x={60} y={900} width={50} height={490} rx={14} fill="#1b2d55" />
    <ellipse cx={230} cy={1040} rx={150} ry={52} fill="#d8e6ff" opacity={0.85} />
    {/* sleeper: head + body under blanket */}
    <circle cx={270} cy={1000} r={62} fill="#1a2440" />
    <path d={`M330 1030 Q520 ${955 + Math.sin(f / 22) * 3} 760 990 Q930 1010 990 1060 L990 1120 L320 1120 Z`} fill="#2a4a8a" />
    <path d={`M330 1030 Q520 ${955 + Math.sin(f / 22) * 3} 760 990 Q930 1010 990 1060`} stroke="#5f86d8" strokeWidth={6} fill="none" opacity={0.6} />
    {red > 0 && <rect width={W} height={H} fill={C.coral} opacity={red * 0.18} style={{mixBlendMode: 'screen'}} />}
  </svg>
);

/** Large eye that opens. */
const Eye: React.FC<{open: number; f: number}> = ({open, f}) => {
  const ry = 6 + open * 150;
  return (
    <svg width={W} height={H} style={{position: 'absolute'}}>
      <defs>
        <clipPath id="lid"><ellipse cx={540} cy={820} rx={380} ry={ry} /></clipPath>
        <radialGradient id="iris" cx="50%" cy="50%"><stop offset="0%" stopColor="#0a0a0a" /><stop offset="30%" stopColor="#0a0a0a" /><stop offset="34%" stopColor="#2fd6e6" /><stop offset="70%" stopColor="#0d4f6b" /><stop offset="100%" stopColor="#06202e" /></radialGradient>
      </defs>
      <ellipse cx={540} cy={820} rx={400} ry={ry + 20} fill="#1a2440" />
      <g clipPath="url(#lid)">
        <rect x={140} y={600} width={800} height={440} fill="#dfe8f5" />
        <circle cx={540 + Math.sin(f / 9) * 30 * open} cy={820} r={150} fill="url(#iris)" />
        <circle cx={580 + Math.sin(f / 9) * 30 * open} cy={780} r={26} fill="#fff" opacity={0.9} />
      </g>
      <path d={`M140 820 Q540 ${820 - ry * 1.25} 940 820`} stroke="#0a0f1d" strokeWidth={16} fill="none" />
      {new Array(9).fill(0).map((_, i) => {
        const x = 230 + i * 78; const y = 820 - ry * 1.25 * (1 - Math.pow((x - 540) / 400, 2)) * 0.8;
        return <line key={i} x1={x} y1={y} x2={x + (x - 540) * 0.08} y2={y - 40 - open * 20} stroke="#0a0f1d" strokeWidth={8} strokeLinecap="round" />;
      })}
    </svg>
  );
};

const Wake: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const eyeOpenAt = wf('wake', 'open');
  const open = Math.max(lerp(f, [0, 8], [0.05, 0.22]) * (f < 18 ? 1 : 1) , lerp(f, [eyeOpenAt - 8, eyeOpenAt + 8], [0.22, 1]));
  const pull = lerp(f, [wf('wake', 'but') - 4, wf('wake', 'but') + 16], [0, 1], inOut);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <AbsoluteFill style={{opacity: pull, scale: String(lerp(f, [wf('wake', 'but'), d], [1.25, 1.05], inOut))}}>
        <Bedroom f={f} />
        <Particles n={40} color="#bfe6ff" seed="dust" size={[2, 4]} speed={0.4} opacity={0.4} />
      </AbsoluteFill>
      <AbsoluteFill style={{opacity: 1 - pull, scale: String(1 + pull * 1.5)}}>
        <Eye open={open} f={f} />
      </AbsoluteFill>
      <div style={{opacity: pull}}>
        <Hud label="MOTOR OUTPUT" value="0%" x={70} y={230} color={C.coral} delay={wf('wake', 'move')} />
        <Hud label="CONSCIOUSNESS" value="ONLINE" x={600} y={230} color={C.mint} delay={wf('wake', 'single')} />
      </div>
      {/* muscle bars dropping */}
      <svg width={W} height={H} style={{position: 'absolute', opacity: pull}}>
        {new Array(12).fill(0).map((_, i) => {
          const hgt = lerp(f, [wf('wake', 'muscle') - 10 + i, wf('wake', 'muscle') + 6 + i], [80 + random('b' + i) * 60, 6]);
          return <rect key={i} x={70 + i * 26} y={430 - hgt} width={16} height={hgt} fill={C.coral} opacity={0.8} />;
        })}
      </svg>
      <Vignette />
    </AbsoluteFill>
  );
};

const Ecg: React.FC<{f: number; bpm: number; color: string; y: number}> = ({f, bpm, color, y}) => {
  const pts: string[] = [];
  const period = (60 / bpm) * FPS * 6; // px per beat
  for (let x = 0; x <= W; x += 6) {
    const ph = ((x + f * 14) % period) / period;
    let v = 0;
    if (ph > 0.4 && ph < 0.43) v = -18; else if (ph > 0.43 && ph < 0.46) v = 90; else if (ph > 0.46 && ph < 0.5) v = -40; else if (ph > 0.6 && ph < 0.7) v = 12;
    pts.push(`${x},${y - v}`);
  }
  return <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth={5} style={{filter: `drop-shadow(0 0 10px ${color})`}} />;
};

const Figure: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const appear = lerp(f, [wf('figure', 'something') - 4, wf('figure', 'standing') + 8], [0, 1]);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Cam d={d} from={1.05} to={1.22} x={[0, 120]} y={[0, 40]}>
        <Bedroom f={f} red={appear} />
        <svg width={W} height={H} style={{position: 'absolute'}}>
          <defs>
            <filter id="smoke"><feTurbulence baseFrequency="0.02" numOctaves="3" seed={Math.floor(f / 3)} /><feDisplacementMap in="SourceGraphic" scale={30} /><feGaussianBlur stdDeviation="3" /></filter>
          </defs>
          {/* doorway */}
          <rect x={80} y={420} width={260} height={640} fill="#02050c" opacity={0.9} />
          <g opacity={appear} filter="url(#smoke)">
            <ellipse cx={210} cy={560} rx={60} ry={72} fill="#000" />
            <path d="M120 640 Q210 600 300 640 L330 1060 L90 1060 Z" fill="#000" />
          </g>
          <circle cx={190} cy={560} r={7} fill={C.coral} opacity={appear * 0.8} />
          <circle cx={232} cy={560} r={7} fill={C.coral} opacity={appear * 0.8} />
        </svg>
      </Cam>
      <svg width={W} height={H} style={{position: 'absolute'}}>
        <Ecg f={f} bpm={70 + appear * 70} color={appear > 0.5 ? C.coral : C.mint} y={1640} />
      </svg>
      <Hud label="HEART RATE" value={`${Math.round(68 + appear * 64)} BPM`} x={70} y={230} color={appear > 0.5 ? C.coral : C.mint} />
      <Vignette strength={0.9} />
    </AbsoluteFill>
  );
};

const HEAD = 'M600 520 Q600 360 470 320 Q330 290 260 400 Q215 480 240 560 Q215 600 232 640 L250 660 Q240 700 262 720 Q282 740 300 760 Q300 820 340 840 L470 860 L470 980 L640 980 L620 820 Q650 700 600 520 Z';
const BRAIN = 'M290 470 Q300 380 400 360 Q480 340 540 400 Q600 450 580 530 Q575 580 520 600 Q470 640 400 615 Q330 620 300 570 Q270 530 290 470 Z';

const Reveal: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const title = wf('reveal', 'sleep');
  const brainOn = wf('reveal', 'brain');
  return (
    <AbsoluteFill>
      <Bg />
      <Cam d={d} from={1.4} to={1.0} y={[120, 0]}>
        <svg width={W} height={H} viewBox="80 200 760 1000" style={{position: 'absolute'}}>
          <defs><radialGradient id="bglow"><stop offset="0%" stopColor={C.cyan} stopOpacity={0.9} /><stop offset="100%" stopColor={C.cyan} stopOpacity={0} /></radialGradient></defs>
          <path d={HEAD} fill={C.cyan} fillOpacity={0.06} stroke={C.cyan} strokeWidth={3} strokeOpacity={0.7} />
          <circle cx={430} cy={490} r={lerp(f, [brainOn - 6, brainOn + 12], [40, 230])} fill="url(#bglow)" opacity={lerp(f, [brainOn - 6, brainOn + 12], [0.15, 0.6])} />
          <path d={BRAIN} fill={C.cyan} fillOpacity={0.18} stroke={C.cyan} strokeWidth={4} />
          {[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${320 + i * 50} ${400 + (i % 2) * 20} q20 60 -10 ${120 + i * 10}`} stroke={C.cyan} strokeWidth={3} fill="none" opacity={0.6} />)}
        </svg>
      </Cam>
      <div style={{position: 'absolute', top: 260, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontWeight: 800, fontSize: 104, color: '#fff', letterSpacing: 4, lineHeight: 1, opacity: lerp(f, [title - 3, title + 8], [0, 1]), scale: String(lerp(f, [title - 3, title + 10], [1.3, 1])), textShadow: `0 0 40px ${C.cyan}`}}>
        SLEEP<br />PARALYSIS
      </div>
      <Particles n={50} color={C.cyan} seed="rv" size={[2, 5]} speed={0.6} opacity={0.5} />
      <Vignette />
    </AbsoluteFill>
  );
};

/** Sagittal brain with brainstem, switch flips on "flips". */
const Switch: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const flip = wf('switch', 'flips');
  const on = lerp(f, [flip - 2, flip + 6], [0, 1]);
  const pulse = 0.5 + 0.5 * Math.sin(f / 5);
  return (
    <AbsoluteFill>
      <Bg tint={C.violet} />
      <Cam d={d} from={1} to={1.15} y={[0, -60]} origin="50% 60%">
        <svg width={W} height={H} viewBox="0 0 1080 1920" style={{position: 'absolute'}}>
          <defs><radialGradient id="pons"><stop offset="0%" stopColor={C.violet} /><stop offset="100%" stopColor={C.violet} stopOpacity={0} /></radialGradient></defs>
          {/* cerebrum */}
          <path d="M190 700 Q200 470 430 420 Q640 380 800 480 Q930 570 900 740 Q880 860 760 880 Q640 900 560 860 L470 880 Q330 900 250 840 Q180 790 190 700 Z" fill="#14234a" stroke={C.cyan} strokeWidth={5} />
          {[...Array(7)].map((_, i) => <path key={i} d={`M${260 + i * 90} ${520 + (i % 3) * 30} q40 70 -10 ${150 + (i % 2) * 40}`} stroke={C.cyan} strokeOpacity={0.45} strokeWidth={4} fill="none" />)}
          {/* cerebellum */}
          <path d="M700 880 Q800 870 840 930 Q850 1010 760 1020 Q690 1010 680 950 Z" fill="#14234a" stroke={C.cyan} strokeWidth={4} />
          {/* brainstem */}
          <path d="M560 860 Q600 900 610 990 L620 1300 L560 1300 L560 1000 Q540 920 520 880 Z" fill="#1b2c5a" stroke={C.cyan} strokeWidth={4} />
          {/* pons cluster */}
          <circle cx={585} cy={960} r={60 + on * 60 + pulse * 20} fill="url(#pons)" opacity={0.4 + on * 0.6} />
          <ellipse cx={585} cy={960} rx={34} ry={46} fill={C.violet} opacity={0.6 + on * 0.4} />
          <line x1={585} y1={960} x2={820} y2={1120} stroke="#fff" strokeWidth={3} opacity={lerp(f, [10, 25], [0, 0.8])} />
        </svg>
      </Cam>
      <div style={{position: 'absolute', left: 560, top: 1100, fontFamily: 'Sora', color: '#fff', opacity: lerp(f, [12, 26], [0, 1])}}>
        <div style={{fontSize: 30, letterSpacing: 5, color: C.violet, fontWeight: 600}}>BRAINSTEM</div>
        <div style={{fontSize: 44, fontWeight: 800}}>REM switch</div>
      </div>
      {/* toggle */}
      <div style={{position: 'absolute', left: 290, top: 250, width: 500, height: 170, borderRadius: 90, background: on > 0.5 ? 'rgba(155,123,255,0.35)' : 'rgba(255,255,255,0.08)', border: `4px solid ${on > 0.5 ? C.violet : '#5a6a8a'}`, boxShadow: on > 0.5 ? `0 0 60px ${C.violet}` : 'none'}}>
        <div style={{position: 'absolute', top: 15, left: 15 + on * 330, width: 140, height: 140, borderRadius: 70, background: '#fff'}} />
        <div style={{position: 'absolute', top: 52, left: on > 0.5 ? 50 : 200, fontFamily: 'Sora', fontWeight: 800, fontSize: 54, color: '#fff'}}>{on > 0.5 ? 'ON' : 'OFF'}</div>
      </div>
      <div style={{position: 'absolute', top: 440, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontSize: 34, letterSpacing: 8, color: C.violet, fontWeight: 600}}>MUSCLE SHUTDOWN</div>
      <Vignette />
    </AbsoluteFill>
  );
};

/** Front body: signals travel down nerves; inhibition floods. mode: flood | spared */
const BodyNerves: React.FC<{f: number; inhibit: number; spared: number; breath?: number}> = ({f, inhibit, spared, breath = 0}) => (
  <svg width={W} height={H} viewBox="-140 -60 680 1210" style={{position: 'absolute'}}>
    <defs>
      <filter id="gl"><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
    </defs>
    <circle cx={200} cy={90} r={58} fill={C.cyan} fillOpacity={0.06} stroke={C.cyan} strokeOpacity={0.6} strokeWidth={2.5} />
    <path d={BODY} fill={C.cyan} fillOpacity={0.05 + inhibit * 0.05} stroke={C.cyan} strokeOpacity={0.6} strokeWidth={2.5} />
    {/* brain */}
    <ellipse cx={200} cy={78} rx={40} ry={30} fill={C.cyan} opacity={0.3} />
    {NERVES.map((p, i) => (
      <g key={i}>
        <path d={p} stroke={interpolate(inhibit, [0, 1], [0, 1]) > 0.5 ? '#3a4a6a' : C.cyan} strokeWidth={i === 0 ? 7 : 4} fill="none" opacity={1 - inhibit * 0.55} filter="url(#gl)" />
        {/* signal pulses */}
        <path d={p} stroke="#fff" strokeWidth={i === 0 ? 8 : 6} fill="none" strokeDasharray="14 120" strokeDashoffset={-f * 6 - i * 30} opacity={(1 - inhibit) * 0.9} strokeLinecap="round" />
        {/* inhibitory flood */}
        <path d={p} stroke={C.violet} strokeWidth={i === 0 ? 14 : 10} fill="none" strokeDasharray="1000" strokeDashoffset={1000 - inhibit * 1000} opacity={0.75} strokeLinecap="round" filter="url(#gl)" />
      </g>
    ))}
    {/* spared: eyes + diaphragm */}
    <g opacity={spared}>
      <circle cx={182} cy={88} r={10} fill={C.mint} filter="url(#gl)" />
      <circle cx={218} cy={88} r={10} fill={C.mint} filter="url(#gl)" />
      <path d={`M120 ${430 + breath * 18} Q200 ${370 + breath * 30} 280 ${430 + breath * 18}`} stroke={C.mint} strokeWidth={10} fill="none" filter="url(#gl)" strokeLinecap="round" />
    </g>
  </svg>
);

const Flood: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const silence = wf('flood', 'chemicals');
  const inhibit = lerp(f, [silence - 10, silence + 30], [0, 1], inOut);
  return (
    <AbsoluteFill>
      <Bg tint={C.violet} />
      <Cam d={d} from={1.25} to={1.0} y={[260, 0]}>
        <BodyNerves f={f} inhibit={inhibit} spared={0} />
        <Particles n={70} color={C.violet} seed="gaba" size={[4, 9]} speed={1.4} dir={[0, 1]} area={[300, 300, 480, 1300]} opacity={inhibit * 0.8} />
      </Cam>
      <Hud label="INHIBITORY CHEMICALS" value="GABA + GLYCINE" x={70} y={230} color={C.violet} delay={silence - 4} />
      <Hud label="MUSCLES" value={inhibit > 0.6 ? 'SILENCED' : 'ACTIVE'} x={70} y={380} color={inhibit > 0.6 ? C.coral : C.cyan} delay={6} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Spared: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const eyes = wf('spared', 'eyes');
  const dia = wf('spared', 'diaphragm');
  return (
    <AbsoluteFill>
      <Bg tint={C.mint} />
      <Cam d={d} from={1.0} to={1.12}>
        <BodyNerves f={f} inhibit={1} spared={1} breath={0.5 + 0.5 * Math.sin(f / 14)} />
      </Cam>
      <Hud label="EYES" value="ACTIVE" x={640} y={260} color={C.mint} delay={eyes - 3} />
      <Hud label="DIAPHRAGM" value="ACTIVE" x={640} y={420} color={C.mint} delay={dia - 3} />
      <Hud label="EVERYTHING ELSE" value="OFF" x={70} y={260} color={C.coral} delay={4} />
      <Vignette />
    </AbsoluteFill>
  );
};

const Glitch: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const g = (f % 23 < 3 ? 1 : 0) * 14;
  const mind = wf('glitch', 'mind');
  const body = wf('glitch', 'body');
  return (
    <AbsoluteFill style={{background: C.bg}}>
      {/* top: awake brain */}
      <div style={{position: 'absolute', top: 0, height: H / 2, width: W, overflow: 'hidden', background: 'radial-gradient(circle at 50% 60%, #3a2a10, #0a0805)'}}>
        <svg width={W} height={H / 2} viewBox="180 330 520 330" style={{translate: `${g}px 0px`}}>
          <path d={BRAIN} fill="#ffb347" fillOpacity={0.3 + 0.2 * Math.sin(f / 4)} stroke="#ffcf70" strokeWidth={4} />{[0,1,2,3,4].map((i) => <path key={i} d={`M${320 + i * 50} ${400 + (i % 2) * 20} q20 60 -10 ${120 + i * 10}`} stroke="#ffcf70" strokeWidth={3} fill="none" opacity={0.7} />)}
        </svg>
        <div style={{position: 'absolute', bottom: 70, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontWeight: 800, fontSize: 92, color: '#ffcf70', opacity: lerp(f, [mind - 3, mind + 6], [0, 1]), textShadow: '0 0 30px #ffb347'}}>MIND: AWAKE</div>
      </div>
      <div style={{position: 'absolute', top: H / 2, height: H / 2, width: W, overflow: 'hidden', background: 'radial-gradient(circle at 50% 40%, #0d1f4a, #03060f)'}}>
        <svg width={W} height={H / 2} viewBox="-100 -40 600 1100" style={{translate: `${-g}px 0px`, opacity: 0.9}}>
          <path d={BODY} fill={C.violet} fillOpacity={0.2} stroke={C.violet} strokeWidth={3} />
          <circle cx={200} cy={90} r={58} fill={C.violet} fillOpacity={0.2} stroke={C.violet} strokeWidth={3} />
        </svg>
        <div style={{position: 'absolute', top: 60, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontWeight: 800, fontSize: 92, color: C.violet, opacity: lerp(f, [body - 3, body + 6], [0, 1]), textShadow: `0 0 30px ${C.violet}`}}>BODY: DREAMING</div>
      </div>
      <div style={{position: 'absolute', top: H / 2 - 3 + g / 3, height: 6, width: W, background: '#fff', opacity: 0.8, boxShadow: '0 0 30px #fff'}} />
      {g > 0 && <AbsoluteFill style={{background: 'rgba(62,240,255,0.08)', translate: `${g * 2}px 0px`}} />}
      <Vignette />
    </AbsoluteFill>
  );
};

const ParticleFigure: React.FC<{x: number; y: number; scale?: number; alpha: number; scatter?: number; seed?: string}> = ({x, y, scale = 1, alpha, scatter = 0, seed = 'pf'}) => {
  const f = useCurrentFrame();
  const pts: React.ReactNode[] = [];
  let i = 0, tries = 0;
  while (pts.length < 420 && tries < 6000) {
    tries++;
    const px = random(`${seed}x${tries}`) * 260 - 130, py = random(`${seed}y${tries}`) * 640;
    const inHead = (px * px) / (58 * 58) + ((py - 70) * (py - 70)) / (70 * 70) < 1;
    const w = py > 150 ? 70 + (py - 150) * 0.12 : 0;
    const inBody = py > 150 && Math.abs(px) < w;
    if (!inHead && !inBody) continue;
    i++;
    const dx = Math.sin(f / 18 + i) * 3 + scatter * (random(`${seed}s${i}`) - 0.5) * 600;
    const dy = Math.cos(f / 21 + i) * 3 - scatter * random(`${seed}t${i}`) * 500;
    const sz = 4 + random(`${seed}z${i}`) * 5;
    pts.push(<div key={i} style={{position: 'absolute', left: x + (px + dx) * scale, top: y + (py + dy) * scale, width: sz, height: sz, borderRadius: '50%', background: i % 5 ? C.violet : '#e6dcff', boxShadow: `0 0 ${sz * 3}px ${C.violet}`, opacity: alpha * (0.5 + 0.5 * Math.sin(f / 7 + i))}} />);
  }
  return (
    <AbsoluteFill>
      <svg width={W} height={H} style={{position: 'absolute', opacity: alpha * (1 - scatter)}}>
        <g transform={`translate(${x},${y}) scale(${scale})`} style={{filter: `drop-shadow(0 0 18px ${C.violet})`}}>
          <ellipse cx={0} cy={72} rx={52} ry={64} fill="#0d0620" />
          <path d="M-30 128 Q0 140 30 128 Q95 150 110 210 L130 640 L-130 640 L-110 210 Q-95 150 -30 128 Z" fill="#0d0620" />
        </g>
      </svg>
      {pts}
    </AbsoluteFill>
  );
};

const Dream: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const threat = wf('dream', 'threat');
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Cam d={d} from={1.0} to={1.12} x={[0, 60]} y={[0, 20]}>
        <Bedroom f={f} red={0.4} />
        <ParticleFigure x={800} y={380} scale={1.3} alpha={0.95} />
      </Cam>
      {/* brain inset with threat detector */}
      <div style={{position: 'absolute', left: 60, top: 400, width: 420, height: 320, borderRadius: 30, border: `3px solid ${C.coral}`, background: 'rgba(4,10,24,0.85)', opacity: lerp(f, [threat - 8, threat + 4], [0, 1]), scale: String(lerp(f, [threat - 8, threat + 6], [0.8, 1]))}}>
        <svg width={420} height={250} viewBox="250 330 380 300">
          <path d={BRAIN} fill="#14234a" stroke={C.cyan} strokeWidth={4} />
          <circle cx={460} cy={540} r={18 + 6 * Math.sin(f / 3)} fill={C.coral} style={{filter: `drop-shadow(0 0 16px ${C.coral})`}} />
        </svg>
        <div style={{textAlign: 'center', fontFamily: 'Sora', fontWeight: 700, fontSize: 32, color: C.coral, letterSpacing: 3}}>THREAT DETECTOR</div>
      </div>
      <Hud label="DREAM IMAGERY" value="STILL RUNNING" x={70} y={230} color={C.violet} delay={6} />
      <Vignette strength={0.85} />
    </AbsoluteFill>
  );
};

const Payoff: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const dawn = lerp(f, [0, d * 0.6], [0, 1], inOut);
  const dissolve = lerp(f, [0, 40], [0.85, 0]);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Cam d={d} from={1.12} to={1.0}>
        <Bedroom f={f} dawn={dawn} />
        <ParticleFigure x={800} y={380} scale={1.3} alpha={dissolve / 0.85} scatter={lerp(f, [0, 45], [0, 1])} />
      </Cam>
      <Particles n={40} color="#ffe2b0" seed="dawn" size={[2, 5]} speed={0.4} opacity={0.5 * dawn} />
      <div style={{position: 'absolute', top: 240, width: '100%', textAlign: 'center', fontFamily: 'Sora', color: '#fff', opacity: lerp(f, [10, 24], [0, 1])}}>
        <div style={{fontSize: 32, letterSpacing: 8, color: C.mint, fontWeight: 600}}>USUALLY LASTS</div>
        <div style={{fontSize: 84, fontWeight: 800, textShadow: `0 0 30px ${C.mint}`}}>SECONDS → MINUTES</div>
      </div>
      <div style={{position: 'absolute', top: 1660, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontSize: 32, color: '#cfe', opacity: lerp(f, [wf('payoff', 'doctor') - 20, wf('payoff', 'doctor')], [0, 0.9])}}>Frequent episodes? Talk to a doctor.</div>
      <Vignette strength={0.6} />
    </AbsoluteFill>
  );
};

const Cta: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Bg />
      <svg width={W} height={H} style={{position: 'absolute'}}>
        {[...Array(9)].map((_, i) => {
          const a = (i / 9) * Math.PI * 2 + f / 60;
          return <line key={i} x1={540} y1={760} x2={540 + Math.cos(a) * 230} y2={760 + Math.sin(a) * 230} stroke={C.cyan} strokeWidth={4} opacity={0.6} />;
        })}
        <circle cx={540} cy={760} r={70 + 6 * Math.sin(f / 6)} fill={C.cyan} opacity={0.9} style={{filter: `drop-shadow(0 0 40px ${C.cyan})`}} />
      </svg>
      <div style={{position: 'absolute', top: 1050, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontWeight: 800, fontSize: 96, color: '#fff', letterSpacing: 2, opacity: lerp(f, [0, 14], [0, 1])}}>WonderSynapse</div>
      <div style={{position: 'absolute', top: 1180, width: '100%', textAlign: 'center', fontFamily: 'Sora', fontWeight: 500, fontSize: 40, color: C.cyan, letterSpacing: 6}}>INSIDE THE HUMAN BODY</div>
      <Particles n={60} color={C.cyan} seed="cta" speed={0.5} opacity={0.5} />
    </AbsoluteFill>
  );
};

export const WonderVideo: React.FC = () => (
  <AbsoluteFill style={{background: C.bg}}>
    <FontFaces />
    <Scenes timing={timing} map={{wake: Wake, figure: Figure, reveal: Reveal, switch: Switch, flood: Flood, spared: Spared, glitch: Glitch, dream: Dream, payoff: Payoff, cta: Cta}} />
    <Captions words={timing.words} top={1380} active="#ffffff" inactive="#9fb3d1" maxWords={3} emph={['paralysis', 'brain', 'switch', 'eyes', 'diaphragm', 'awake', 'dream', 'figure', 'terrifying']} emphColor={C.cyan}
      style={{fontFamily: 'Sora', fontWeight: 800, fontSize: 76, lineHeight: 1.1, textShadow: '0 4px 0 #000, 0 0 18px rgba(0,0,0,0.9)', textTransform: 'uppercase'}} />
    <Grain opacity={0.06} />
  </AbsoluteFill>
);
export const wonderFrames = Math.ceil(timing.duration * FPS);
