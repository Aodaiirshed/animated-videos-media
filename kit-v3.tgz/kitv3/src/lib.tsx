import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, staticFile, useCurrentFrame, useVideoConfig, Sequence} from 'remotion';

export const W = 1080, H = 1920, FPS = 30;
export const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const inOut = Easing.bezier(0.65, 0, 0.35, 1);
export const lerp = (f: number, a: number[], b: number[], e = ease) => interpolate(f, a, b, {...clamp, easing: e});

export type SceneT = {id: string; text: string; start: number; end: number; next: number};
export type Word = {s: string; w: string; t0: number; t1: number};
export type Timing = {duration: number; scenes: SceneT[]; words: Word[]};

export const FontFaces: React.FC = () => (
  <style>{`
  @font-face{font-family:'Sora';src:url(${staticFile('fonts/Sora-VF.ttf')});font-weight:100 900;}
  @font-face{font-family:'Oswald';src:url(${staticFile('fonts/Oswald-VF.ttf')});font-weight:200 700;}
  @font-face{font-family:'Bebas';src:url(${staticFile('fonts/BebasNeue-Regular.ttf')});}
  @font-face{font-family:'Cinzel';src:url(${staticFile('fonts/Cinzel-VF.ttf')});font-weight:400 900;}
  @font-face{font-family:'Garamond';src:url(${staticFile('fonts/EBGaramond-VF.ttf')});font-weight:400 800;}
  @font-face{font-family:'Amiri';src:url(${staticFile('fonts/Amiri-Regular.ttf')});font-weight:400;}
  @font-face{font-family:'Amiri';src:url(${staticFile('fonts/Amiri-Bold.ttf')});font-weight:700;}
  @font-face{font-family:'ReemKufi';src:url(${staticFile('fonts/ReemKufi-VF.ttf')});font-weight:400 700;}
  @font-face{font-family:'Naskh';src:url(${staticFile('fonts/NotoNaskhArabic-VF.ttf')});font-weight:400 700;}
  `}</style>
);

/** Lay scenes out on the timeline. Each scene gets [from, to) frames with an overlap for crossfades. */
export const Scenes: React.FC<{timing: Timing; map: Record<string, React.FC<{d: number}>>; xfade?: number}> = ({timing, map, xfade = 8}) => {
  const sc = timing.scenes;
  return (
    <>
      {sc.map((s, i) => {
        const from = i === 0 ? 0 : Math.round(Math.max(0, s.start - 0.12) * FPS);
        const to = i === sc.length - 1 ? Math.ceil(timing.duration * FPS) + 1 : Math.round(Math.max(0, sc[i + 1].start - 0.12) * FPS) + xfade;
        const C = map[s.id];
        const d = to - from;
        return (
          <Sequence key={s.id} from={from} durationInFrames={d} name={s.id}>
            <FadeWrap d={d} xfade={i === 0 ? 0 : xfade}>
              {C ? <C d={d} /> : null}
            </FadeWrap>
          </Sequence>
        );
      })}
    </>
  );
};

const FadeWrap: React.FC<{d: number; xfade: number; children: React.ReactNode}> = ({xfade, children}) => {
  const f = useCurrentFrame();
  const o = xfade ? interpolate(f, [0, xfade], [0, 1], clamp) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

/** Particles drifting; seeded so every render matches. */
export const Particles: React.FC<{n?: number; color?: string; seed?: string; speed?: number; size?: [number, number]; area?: [number, number, number, number]; dir?: [number, number]; blur?: number; opacity?: number}> = ({n = 60, color = '#fff', seed = 'p', speed = 1, size = [2, 6], area = [0, 0, W, H], dir = [0, -1], blur = 0, opacity = 0.7}) => {
  const f = useCurrentFrame();
  const [x0, y0, w, h] = area;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', filter: blur ? `blur(${blur}px)` : undefined}}>
      {new Array(n).fill(0).map((_, i) => {
        const r = (k: string) => random(`${seed}-${i}-${k}`);
        const sp = (0.3 + r('s') * 1.2) * speed;
        const x = x0 + ((r('x') * w + f * sp * dir[0] * 1.5 + Math.sin(f / 30 + r('ph') * 6) * 12) % w + w) % w;
        const y = y0 + ((r('y') * h + f * sp * dir[1] * 1.5) % h + h) % h;
        const s = size[0] + r('z') * (size[1] - size[0]);
        const tw = 0.5 + 0.5 * Math.sin(f / (10 + r('t') * 20) + r('p') * 6);
        return <div key={i} style={{position: 'absolute', left: x, top: y, width: s, height: s, borderRadius: '50%', background: color, opacity: opacity * (0.35 + 0.65 * tw), boxShadow: `0 0 ${s * 3}px ${color}`}} />;
      })}
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{strength?: number; color?: string}> = ({strength = 0.75, color = '0,0,0'}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 45%, rgba(${color},0) 45%, rgba(${color},${strength}) 100%)`, pointerEvents: 'none'}} />
);

/** Film grain: cheap animated noise via an SVG turbulence filter with a shifting seed. */
export const Grain: React.FC<{opacity?: number}> = ({opacity = 0.08}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity, mixBlendMode: 'overlay', pointerEvents: 'none'}}>
      <svg width={W} height={H}>
        <filter id={`g${f % 6}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={f % 6} />
        </filter>
        <rect width={W} height={H} filter={`url(#g${f % 6})`} />
      </svg>
    </AbsoluteFill>
  );
};

/** Camera: slow push / drift for the whole scene. */
export const Cam: React.FC<{d: number; from?: number; to?: number; x?: [number, number]; y?: [number, number]; rot?: [number, number]; children: React.ReactNode; origin?: string}> = ({d, from = 1, to = 1.08, x = [0, 0], y = [0, 0], rot = [0, 0], children, origin = '50% 50%'}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{transformOrigin: origin, scale: String(lerp(f, [0, d], [from, to], inOut)), translate: `${lerp(f, [0, d], x, inOut)}px ${lerp(f, [0, d], y, inOut)}px`, rotate: `${lerp(f, [0, d], rot, inOut)}deg`}}>
      {children}
    </AbsoluteFill>
  );
};

/** Captions: chunk words into short groups, highlight the active word. Times are absolute seconds. */
export const Captions: React.FC<{words: Word[]; style: React.CSSProperties; active: string; inactive?: string; maxWords?: number; rtl?: boolean; strip?: (s: string) => string; top?: number; emph?: string[]; emphColor?: string}> = ({words, style, active, inactive = '#fff', maxWords = 3, rtl = false, strip = (s) => s, top = 1300, emph = [], emphColor}) => {
  const f = useCurrentFrame();
  const t = f / FPS;
  // build chunks: break on punctuation, scene change, or max words
  const chunks: Word[][] = [];
  let cur: Word[] = [];
  words.forEach((w, i) => {
    cur.push(w);
    const nx = words[i + 1];
    const punct = /[.,!?،؟:…]$/.test(w.w);
    if (!nx || cur.length >= maxWords || punct || nx.s !== w.s || nx.t0 - w.t1 > 0.35) {
      chunks.push(cur);
      cur = [];
    }
  });
  const ci = chunks.findIndex((c, i) => t >= c[0].t0 - 0.05 && t < (chunks[i + 1] ? Math.min(chunks[i + 1][0].t0 - 0.05, c[c.length - 1].t1 + 0.6) : c[c.length - 1].t1 + 0.8));
  if (ci < 0) return null;
  const c = chunks[ci];
  const pop = interpolate(t, [c[0].t0 - 0.05, c[0].t0 + 0.12], [0.86, 1], {...clamp, easing: ease});
  return (
    <div style={{position: 'absolute', left: 70, right: 70, top, display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '0 0.28em', direction: rtl ? 'rtl' : 'ltr', scale: String(pop), ...style}}>
      {c.map((w, i) => {
        const on = t >= w.t0 - 0.03;
        const clean = strip(w.w).replace(/\.\.\.|…/g, '');
        const isEmph = emph.some((e) => clean.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '') === e.toLowerCase());
        return (
          <span key={i} style={{color: on ? (isEmph && emphColor ? emphColor : active) : inactive, opacity: on ? 1 : 0.72}}>
            {clean}
          </span>
        );
      })}
    </div>
  );
};

export const stripTashkeel = (s: string) => s.replace(/[ً-ْٰ]/g, '');

/** Time (s) at which a word (normalized match) is spoken inside a scene; for syncing visuals. */
export const wordTime = (timing: Timing, scene: string, word: string, nth = 0) => {
  const n = (x: string) => stripTashkeel(x).toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
  const ws = timing.words.filter((w) => w.s === scene && n(w.w) === n(word));
  const sc = timing.scenes.find((s) => s.id === scene)!;
  return ws[nth] ? ws[nth].t0 : sc.start;
};

/** Converts absolute seconds into the current Sequence's local frame, given scene start. */
export const sceneFrom = (timing: Timing, id: string) => {
  const i = timing.scenes.findIndex((s) => s.id === id);
  const s = timing.scenes[i];
  return i === 0 ? 0 : Math.max(0, s.start - 0.12);
};
export const localF = (timing: Timing, id: string, absSec: number) => (absSec - sceneFrom(timing, id)) * FPS;
