---
name: Viral Hook and Pacing Lab
description: Use to rewrite the first 3 seconds, pacing, cliffhangers, subtitles, visual storyboard, and payoff of football or science YouTube Shorts.
---

# Mission
Create highly watchable Shorts by improving the attention contract and delivering an honest payoff. Optimize for watch choice, completed understanding, and satisfaction, not clickbait or fake facts. Targets: English football mystery/player stories and animated science explainer/What If content.

# When a concept arrives
A. Define the viewer promise in a single sentence. What will viewer know/feel after watching?
B. Write 10 distinct hooks (not synonyms) across archetypes: reveal-first, contradiction, visual anomaly, specific challenge, 'why', unexpected consequence, measurable stake, rare historical detail, relatable question, false-common-belief correction, where appropriate.
C. Score each 1-5 on clarity in silent autoplay, curiosity, specificity, credibility, and speed to meaningful information. Pick top three and explain what could fail.
D. For each chosen hook, specify first visual frame, exact 0-2s voice line (where used), 0-2s caption (<=8 concise words when possible), and first transition.
E. Script with timestamps. Every sentence must add a fact, clue, progression, or visual twist. Cut preambles ('Did you know', 'In today's video', 'Wait until the end') unless they demonstrably outperform.
F. Deliver the promised answer/payoff early enough to be rewarding. For a mystery, put a satisfying reveal before the ending, with follow-up detail; for science, give the scientific answer and concrete illustration.
G. Keep one central idea per video. Make visuals explain the story, not just decorate voiceover. Favor legible mobile captions and good audio, leaving Shorts UI safe margins.
H. End naturally; optional loop only when it improves comprehension. Never manipulate retention by withholding the answer deceptively.

# Output
1. 10 hook candidates with different mechanisms.
2. Top 3 with risk analysis and first-frame brief.
3. Full original voiceover/caption script with timestamped visual storyboard for a proposed 18-35s version (vary length as needed).
4. Editing QA: no blank first frame, silence, identical 5+ second shot, unreadable text, abrupt unrelated stock footage, unverified assertions, stolen sports clips, or needless CTA.
5. A/B experiment: exactly ONE primary variant, e.g., challenge hook vs contradiction hook, keeping rest as similar as possible. Avoid reposting near-duplicates in a spammy manner; test on distinct original videos or prepublication concepts.
6. 2 potential share-worthy moments rooted in real surprise, utility, or emotional payoff.

# Illustrative science hook
Weak: "Today we will learn about the human body."
Stronger: "Your blood is already making a round trip. How fast?" [animated map of circulation; factual answer verified before publishing]

# Illustrative football hook
Weak: "Can you guess this famous footballer?"
Stronger: "He was rejected, then became a Champions League winner. Which player?" Only when both facts are sourced for the selected player; show unmistakable but non-revealing clues.
